using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit.Inputs;
using VRHandPoseTool;
using VRHandPoseTool.Editor;
using Object = UnityEngine.Object;

namespace VRHandPoseTool.Editor.Tests
{
    public class HandPoseControllerHandSetupServiceTests
    {
        readonly List<Object> m_OwnedObjects = new List<Object>();

        [TearDown]
        public void TearDown()
        {
            for (var i = m_OwnedObjects.Count - 1; i >= 0; i--)
            {
                if (m_OwnedObjects[i] != null)
                    Object.DestroyImmediate(m_OwnedObjects[i]);
            }

            m_OwnedObjects.Clear();
        }

        [Test]
        public void EvaluateGripDriver_Fails_WhenSelectedLeftHandHasNoDriver_EvenIfRightHandHasDriver()
        {
            var origin = CreateGameObject("XR Origin");
            var leftHand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var rightHand = CreateValidHandHierarchy(origin.transform, HandSide.Right, "RightHand");

            var controller = CreateGripAnimatorController("RightCtrl");
            var gripAction = CreateGripActionReference(HandSide.Right);
            var apply = HandPoseControllerHandSetupService.ApplySetup(
                rightHand.transform,
                controller,
                gripAction,
                "Grip",
                useSmoothing: false,
                smoothingSpeed: 12f,
                HandSide.Right,
                HandGripControlMode.ToolDefault);
            Assert.IsTrue(apply.success, apply.message);

            var leftStatus = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                leftHand.transform,
                controller,
                gripAction,
                "Grip");

            Assert.IsFalse(leftStatus.hasDriverOnRoot);
            Assert.IsFalse(leftStatus.isValid);
            StringAssert.Contains("현재 선택 손 Root에는 Grip Driver가 없습니다", leftStatus.failureReason);
            Assert.IsNull(leftHand.GetComponent<ControllerHandGripAnimator>());
            Assert.IsNotNull(rightHand.GetComponent<ControllerHandGripAnimator>());
        }

        [Test]
        public void EvaluateGripDriver_Fails_WhenDriverExistsOnlyOnSiblingUnderSameXrOrigin()
        {
            var origin = CreateGameObject("XR Origin");
            var leftHand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var other = CreateGameObject("OtherVisual", origin.transform);
            other.AddComponent<ControllerHandGripAnimator>();

            var status = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                leftHand.transform,
                CreateGripAnimatorController("Ctrl"),
                CreateGripActionReference(HandSide.Left),
                "Grip");

            Assert.IsFalse(status.hasDriverOnRoot);
            Assert.IsFalse(status.isValid);
            StringAssert.Contains("현재 선택 손 Root에는 Grip Driver가 없습니다", status.failureReason);
        }

        [Test]
        public void ApplySetup_ToolDefault_AddsDriverAndInputActionManager()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreateGripActionReference(HandSide.Left);
            Assert.IsTrue(
                HandPoseControllerHandSetupService.TryGetGripInputActionAsset(
                    gripAction, out var gripAsset, out var assetError),
                assetError);

            Assert.IsNull(hand.GetComponent<ControllerHandGripAnimator>());
            Assert.IsNull(origin.GetComponent<InputActionManager>());

            var result = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform,
                controller,
                gripAction,
                "Grip",
                useSmoothing: true,
                smoothingSpeed: 12f,
                HandSide.Left,
                HandGripControlMode.ToolDefault);

            Assert.IsTrue(result.success, result.message);

            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            Assert.AreEqual(1, origin.GetComponents<InputActionManager>().Length);
            Assert.AreEqual(1, origin.GetComponentsInChildren<InputActionManager>(true).Length);

            var manager = origin.GetComponent<InputActionManager>();
            Assert.IsNotNull(manager);
            Assert.IsTrue(
                HandPoseControllerHandSetupService.IsActionAssetRegisteredOnManager(manager, gripAsset));

            var status = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                hand.transform,
                controller,
                gripAction,
                "Grip");
            Assert.IsTrue(status.isValid, status.failureReason);
            Assert.IsTrue(status.hasInputActionManager);
            Assert.IsTrue(status.gripActionAssetRegistered);
            Assert.AreSame(gripAsset, status.gripActionAsset);
        }

        [Test]
        public void ApplySetup_CalledTwice_DoesNotDuplicateDriverOrManagerOrAsset()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreateGripActionReference(HandSide.Left);
            Assert.IsTrue(
                HandPoseControllerHandSetupService.TryGetGripInputActionAsset(
                    gripAction, out var gripAsset, out _));

            var first = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(first.success, first.message);

            var second = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(second.success, second.message);

            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            Assert.AreEqual(1, origin.GetComponentsInChildren<InputActionManager>(true).Length);

            var manager = origin.GetComponent<InputActionManager>();
            Assert.IsNotNull(manager);
            Assert.IsNotNull(manager.actionAssets);
            var assetCount = 0;
            foreach (var asset in manager.actionAssets)
            {
                if (asset == gripAsset)
                    assetCount++;
            }

            Assert.AreEqual(1, assetCount);
        }

        [Test]
        public void ApplySetup_ReusesExistingInputActionManager_AndPreservesAssets()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var existingManager = origin.AddComponent<InputActionManager>();
            var preservedAsset = ScriptableObject.CreateInstance<InputActionAsset>();
            preservedAsset.name = "PreservedActions";
            m_OwnedObjects.Add(preservedAsset);
            existingManager.actionAssets = new List<InputActionAsset> { preservedAsset };

            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreateGripActionReference(HandSide.Left);
            Assert.IsTrue(
                HandPoseControllerHandSetupService.TryGetGripInputActionAsset(
                    gripAction, out var gripAsset, out _));

            var result = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(result.success, result.message);

            Assert.AreEqual(1, origin.GetComponents<InputActionManager>().Length);
            Assert.AreSame(existingManager, origin.GetComponent<InputActionManager>());
            Assert.IsTrue(
                HandPoseControllerHandSetupService.IsActionAssetRegisteredOnManager(
                    existingManager, preservedAsset));
            Assert.IsTrue(
                HandPoseControllerHandSetupService.IsActionAssetRegisteredOnManager(
                    existingManager, gripAsset));
        }

        [Test]
        public void ApplySetup_DoesNotDuplicateAsset_WhenAlreadyRegistered()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var gripAction = CreateGripActionReference(HandSide.Left);
            Assert.IsTrue(
                HandPoseControllerHandSetupService.TryGetGripInputActionAsset(
                    gripAction, out var gripAsset, out _));

            var existingManager = origin.AddComponent<InputActionManager>();
            existingManager.actionAssets = new List<InputActionAsset> { gripAsset };

            var controller = CreateGripAnimatorController("OculusHand_L");
            var result = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(result.success, result.message);

            Assert.AreEqual(1, origin.GetComponents<InputActionManager>().Length);
            Assert.AreEqual(1, existingManager.actionAssets.Count);
            Assert.AreSame(gripAsset, existingManager.actionAssets[0]);
        }

        [Test]
        public void ApplySetup_Fails_WhenGripActionReferenceCannotResolveAsset()
        {
            var hand = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");

            var result = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform,
                controller,
                gripActionReference: null,
                "Grip",
                false,
                12f,
                HandSide.Left,
                HandGripControlMode.ToolDefault);

            Assert.IsFalse(result.success);
            StringAssert.Contains("Grip InputActionReference", result.message);
            Assert.IsNull(hand.GetComponent<ControllerHandGripAnimator>());
            Assert.IsNull(hand.GetComponentInChildren<InputActionManager>(true));
        }

        [Test]
        public void EvaluateGripDriver_Fails_WhenDriverDisabled()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreateGripActionReference(HandSide.Left);

            var apply = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(apply.success, apply.message);

            var driver = hand.GetComponent<ControllerHandGripAnimator>();
            driver.enabled = false;

            var status = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                hand.transform, controller, gripAction, "Grip");

            Assert.IsTrue(status.hasDriverOnRoot);
            Assert.IsFalse(status.isEnabled);
            Assert.IsFalse(status.isValid);
            StringAssert.Contains("비활성", status.failureReason);
        }

        [Test]
        public void EvaluateGripDriver_Fails_WhenDriverReferencesWrongAnimator()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreateGripActionReference(HandSide.Left);

            var apply = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(apply.success, apply.message);

            var other = CreateGameObject("OtherAnimatorHost");
            var wrongAnimator = other.AddComponent<Animator>();
            wrongAnimator.runtimeAnimatorController = controller;

            var driver = hand.GetComponent<ControllerHandGripAnimator>();
            var so = new SerializedObject(driver);
            so.FindProperty("handAnimator").objectReferenceValue = wrongAnimator;
            so.ApplyModifiedPropertiesWithoutUndo();

            var status = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                hand.transform, controller, gripAction, "Grip");

            Assert.IsTrue(status.hasDriverOnRoot);
            Assert.IsFalse(status.handAnimatorMatches);
            Assert.IsFalse(status.isValid);
        }

        [Test]
        public void ApplySetup_ProjectLegacy_DoesNotAddDriverOrRequireInputActionManager()
        {
            var hand = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");

            var result = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform,
                controller,
                gripActionReference: null,
                "Grip",
                false,
                12f,
                HandSide.Left,
                HandGripControlMode.ProjectLegacy);

            Assert.IsTrue(result.success, result.message);
            Assert.IsNotNull(hand.GetComponent<Animator>());
            Assert.IsNull(hand.GetComponent<ControllerHandGripAnimator>());
            Assert.IsNull(hand.GetComponentInChildren<InputActionManager>(true));
        }

        GameObject CreateGameObject(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null)
                go.transform.SetParent(parent, false);
            m_OwnedObjects.Add(go);
            return go;
        }

        GameObject CreateValidHandHierarchy(Transform parent, HandSide handSide, string rootName)
        {
            var root = CreateGameObject(rootName, parent);
            var created = new Dictionary<string, Transform>();

            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                Transform parentTransform;
                if (expectedParentBoneName == HandSkeletonCatalog.ParentIsHandRoot)
                    parentTransform = root.transform;
                else
                    parentTransform = created[expectedParentBoneName];

                var bone = CreateGameObject(boneName, parentTransform);
                created[boneName] = bone.transform;
            }

            var meshHost = CreateGameObject("Mesh", root.transform);
            var smr = meshHost.AddComponent<SkinnedMeshRenderer>();
            var mesh = new Mesh { name = "TestHandMesh" };
            m_OwnedObjects.Add(mesh);
            smr.sharedMesh = mesh;

            return root;
        }

        AnimatorController CreateGripAnimatorController(string name)
        {
            var controller = new AnimatorController { name = name };
            controller.AddParameter("Grip", AnimatorControllerParameterType.Float);
            controller.AddLayer("Base Layer");
            var state = controller.layers[0].stateMachine.AddState("GripBlend");
            var tree = new BlendTree
            {
                name = "GripTree",
                blendParameter = "Grip",
                blendType = BlendTreeType.Simple1D,
            };
            state.motion = tree;
            m_OwnedObjects.Add(controller);
            m_OwnedObjects.Add(tree);
            return controller;
        }

        InputActionReference CreateGripActionReference(HandSide handSide)
        {
            var asset = ScriptableObject.CreateInstance<InputActionAsset>();
            asset.name = $"TestXriActions_{handSide}";
            m_OwnedObjects.Add(asset);

            var mapName = HandSideUtility.GetXriInteractionActionMap(handSide);
            var map = asset.AddActionMap(mapName);
            var action = map.AddAction(
                HandPoseControllerHandSetupService.RecommendedGripActionName,
                InputActionType.Value,
                expectedControlLayout: "Axis");
            action.AddBinding(HandSideUtility.GetRecommendedGripBinding(handSide));

            var reference = InputActionReference.Create(action);
            m_OwnedObjects.Add(reference);
            return reference;
        }
    }
}
