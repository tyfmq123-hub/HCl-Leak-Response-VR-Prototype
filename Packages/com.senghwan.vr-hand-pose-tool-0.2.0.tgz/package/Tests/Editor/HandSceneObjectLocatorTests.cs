using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using VRHandPoseTool;
using VRHandPoseTool.Editor;
using Object = UnityEngine.Object;

namespace VRHandPoseTool.Editor.Tests
{
    public class HandSceneObjectLocatorTests
    {
        const string TempScenePath = "Assets/_VRHandPoseTool_LocatorTest.unity";

        readonly List<Object> m_OwnedObjects = new List<Object>();
        readonly List<string> m_TempAssetPaths = new List<string>();

        [SetUp]
        public void SetUp()
        {
            HandPoseControllerHandPendingSetupBridge.ClearPendingStatus(HandSide.Left);
            HandPoseControllerHandPendingSetupBridge.ClearPendingStatus(HandSide.Right);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Left);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Right);
            HandSceneObjectLocator.ClearAllStored(HandSide.Left);
            HandSceneObjectLocator.ClearAllStored(HandSide.Right);
        }

        [TearDown]
        public void TearDown()
        {
            HandPoseControllerHandPendingSetupBridge.ClearPendingStatus(HandSide.Left);
            HandPoseControllerHandPendingSetupBridge.ClearPendingStatus(HandSide.Right);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Left);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Right);
            HandSceneObjectLocator.ClearAllStored(HandSide.Left);
            HandSceneObjectLocator.ClearAllStored(HandSide.Right);

            for (var i = m_OwnedObjects.Count - 1; i >= 0; i--)
            {
                if (m_OwnedObjects[i] != null)
                    Object.DestroyImmediate(m_OwnedObjects[i]);
            }

            m_OwnedObjects.Clear();
            foreach (var path in m_TempAssetPaths)
            {
                if (!string.IsNullOrEmpty(path) && AssetDatabase.LoadAssetAtPath<Object>(path) != null)
                    AssetDatabase.DeleteAsset(path);
            }

            m_TempAssetPaths.Clear();
            if (AssetDatabase.LoadAssetAtPath<Object>(TempScenePath) != null)
                AssetDatabase.DeleteAsset(TempScenePath);
        }

        [Test]
        public void SiblingIndexPath_ResolvesExactTarget_EvenWithSameNameSiblings()
        {
            CreateAndOpenTempScene();
            var origin = CreateGameObject("XR Origin");
            var decoy = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var target = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");

            Assert.IsTrue(
                HandSceneObjectLocator.TryCapture(
                    target.transform, HandSide.Left, SceneObjectLocatorRole.PlaybackHandRoot,
                    out var locator, out var error),
                error);

            locator.editModeGlobalObjectId = "GlobalObjectId_V1-2-ffffffffffffffffffffffffffffffff-1-0";

            var resolve = HandSceneObjectLocator.Resolve(
                locator, HandSide.Left, SceneObjectLocatorRole.PlaybackHandRoot, false);

            Assert.IsTrue(resolve.success, resolve.message);
            Assert.AreEqual("SiblingIndexPath", resolve.resolveMethod);
            Assert.AreSame(target.transform, resolve.transform);
            Assert.AreNotSame(decoy.transform, resolve.transform);
        }

        [Test]
        public void LeftLocator_DoesNotResolveAsRight()
        {
            CreateAndOpenTempScene();
            var left = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            Assert.IsTrue(
                HandSceneObjectLocator.TryCapture(
                    left.transform, HandSide.Left, SceneObjectLocatorRole.PlaybackHandRoot,
                    out var locator, out var error),
                error);

            var resolve = HandSceneObjectLocator.Resolve(
                locator, HandSide.Right, SceneObjectLocatorRole.PlaybackHandRoot, false);
            Assert.IsFalse(resolve.success);
            StringAssert.Contains("handSide", resolve.message);
        }

        [Test]
        public void VisualOffset_IsCreatedInEditMode_AndStoredAsLocator()
        {
            CreateAndOpenTempScene();
            var parent = CreateGameObject("ControllerParent");
            var hand = CreateValidHandHierarchy(parent.transform, HandSide.Right, "RightHand");

            Assert.IsTrue(
                HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                    hand.transform, HandSide.Right, out var vo, out var error),
                error);

            Assert.IsNotNull(vo);
            Assert.AreEqual(HandControllerVisualAlignmentService.GetVisualOffsetName(HandSide.Right), vo.name);
            Assert.AreSame(vo, hand.transform.parent);
            Assert.IsTrue(
                HandSceneObjectLocator.TryGetStored(
                    HandSide.Right, SceneObjectLocatorRole.VisualOffset, out var stored));
            Assert.IsTrue(stored.isValid);
        }

        [Test]
        public void PendingSetup_UsesEditModeLocator_NotRuntimeGoid()
        {
            var scene = CreateAndOpenTempScene();
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreatePersistedAnimatorController("LocCtrl");
            var grip = CreatePersistedGripActionReference(HandSide.Left);

            Assert.IsTrue(
                HandSceneObjectLocator.CaptureAndStore(
                    hand.transform, HandSide.Left, SceneObjectLocatorRole.PlaybackHandRoot,
                    out var locator, out var error),
                error);

            var pending = new HandPoseControllerHandPendingSetupBridge.PendingSetupData
            {
                applyToken = "tok",
                scenePath = scene.path,
                playbackHandRootGlobalObjectId = "GlobalObjectId_V1-2-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb-9-9",
                playbackLocatorJson = HandSceneObjectLocator.ToJson(locator),
                handSide = (int)HandSide.Left,
                animatorControllerGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(controller)),
                gripActionReferenceGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(grip)),
                gripActionId = grip.action.id.ToString(),
                gripParameterName = "Grip",
                gripControlMode = (int)HandGripControlMode.ToolDefault,
            };

            var apply = HandPoseControllerHandPendingSetupBridge.TryApplyPendingInternalForTests(pending);
            Assert.IsTrue(apply.success, apply.message);
            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            Assert.AreEqual(1, hand.GetComponents<Animator>().Length);
        }

        [Test]
        public void ResolveFailure_SetsFailedStatus_NotWaiting()
        {
            CreateAndOpenTempScene();
            var pending = new HandPoseControllerHandPendingSetupBridge.PendingSetupData
            {
                applyToken = "fail-resolve",
                scenePath = SceneManager.GetActiveScene().path,
                playbackLocatorJson = HandSceneObjectLocator.ToJson(new HandSceneObjectLocator.SceneObjectLocatorData
                {
                    isValid = true,
                    scenePath = SceneManager.GetActiveScene().path,
                    handSide = (int)HandSide.Left,
                    targetRole = (int)SceneObjectLocatorRole.PlaybackHandRoot,
                    siblingIndexPath = new[] { 99 },
                    transformNamePath = new[] { "Missing" },
                    editModeGlobalObjectId = "GlobalObjectId_V1-2-cccccccccccccccccccccccccccccccc-1-0",
                }),
                handSide = (int)HandSide.Left,
                animatorControllerGuid = "00000000000000000000000000000000",
                gripParameterName = "Grip",
                gripControlMode = (int)HandGripControlMode.ProjectLegacy,
                lifecycleStatus = (int)HandPoseControllerHandPendingSetupBridge.PendingLifecycleStatus.PendingWaitingForEditMode,
            };

            HandPoseControllerHandPendingSetupBridge.SavePendingForTests(HandSide.Left, pending);
            var result = HandPoseControllerHandPendingSetupBridge.TryApplyPendingNow(HandSide.Left, forceRetry: true);
            Assert.IsFalse(result.success);
            Assert.IsFalse(HandPoseControllerHandPendingSetupBridge.IsWaitingForEditMode(HandSide.Left));
            Assert.IsTrue(HandPoseControllerHandPendingSetupBridge.HasFailedPending(HandSide.Left));
        }

        [Test]
        public void ReapplyInEditMode_CreatesDriverWithoutPlayMode()
        {
            CreateAndOpenTempScene();
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreatePersistedAnimatorController("ReapplyCtrl");
            var grip = CreatePersistedGripActionReference(HandSide.Left);

            var result = HandPoseControllerHandPendingSetupBridge.TryReapplyInEditMode(
                HandSide.Left, hand.transform, controller, grip, "Grip", false, 12f,
                HandGripControlMode.ToolDefault);

            Assert.IsTrue(result.success, result.message);
            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            Assert.AreEqual(1, hand.GetComponents<Animator>().Length);
            Assert.AreEqual(
                1,
                origin.GetComponentsInChildren<UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager>(true).Length);
        }

        [Test]
        public void PendingAlignment_ApplyUsesVisualOffsetLocator()
        {
            var scene = CreateAndOpenTempScene();
            var parent = CreateGameObject("ControllerParent");
            var hand = CreateValidHandHierarchy(parent.transform, HandSide.Left, "LeftHand");
            Assert.IsTrue(
                HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                    hand.transform, HandSide.Left, out var vo, out var voError),
                voError);
            Assert.IsTrue(
                HandSceneObjectLocator.TryGetStored(
                    HandSide.Left, SceneObjectLocatorRole.VisualOffset, out var locator));

            var expectedPos = new Vector3(0.2f, 0.3f, 0.4f);
            var expectedRot = Quaternion.Euler(5f, 15f, 25f);
            var pending = new HandControllerVisualAlignmentService.PendingAlignmentData
            {
                applyToken = "align",
                scenePath = scene.path,
                visualOffsetLocatorJson = HandSceneObjectLocator.ToJson(locator),
                handSide = (int)HandSide.Left,
                localPosX = expectedPos.x,
                localPosY = expectedPos.y,
                localPosZ = expectedPos.z,
                localRotX = expectedRot.x,
                localRotY = expectedRot.y,
                localRotZ = expectedRot.z,
                localRotW = expectedRot.w,
                localScaleX = 1f,
                localScaleY = 1f,
                localScaleZ = 1f,
                origLocalRotW = 1f,
            };

            Assert.IsTrue(
                HandControllerVisualAlignmentService.TryApplyPendingInternalForTests(pending, out var message),
                message);
            Assert.AreEqual(expectedPos, vo.localPosition);
            Assert.Less(Quaternion.Angle(expectedRot, vo.localRotation), 0.1f);
        }

        Scene CreateAndOpenTempScene()
        {
            if (AssetDatabase.LoadAssetAtPath<Object>(TempScenePath) != null)
                AssetDatabase.DeleteAsset(TempScenePath);
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            Assert.IsTrue(EditorSceneManager.SaveScene(scene, TempScenePath));
            AssetDatabase.Refresh();
            return SceneManager.GetActiveScene();
        }

        GameObject CreateGameObject(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null)
                go.transform.SetParent(parent, false);
            m_OwnedObjects.Add(go);
            return go;
        }

        GameObject CreateValidHandHierarchy(Transform parent, HandSide handSide, string rootName)
        {
            var root = CreateGameObject(rootName, parent);
            var created = new Dictionary<string, Transform>();
            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                var parentTransform = expectedParentBoneName == HandSkeletonCatalog.ParentIsHandRoot
                    ? root.transform
                    : created[expectedParentBoneName];
                created[boneName] = CreateGameObject(boneName, parentTransform).transform;
            }

            var meshHost = CreateGameObject("Mesh", root.transform);
            var smr = meshHost.AddComponent<SkinnedMeshRenderer>();
            var mesh = new Mesh { name = "TestHandMesh" };
            m_OwnedObjects.Add(mesh);
            smr.sharedMesh = mesh;
            return root;
        }

        AnimatorController CreatePersistedAnimatorController(string name)
        {
            var path = $"Assets/_VRHandPoseTool_LocCtrl_{name}.controller";
            if (AssetDatabase.LoadAssetAtPath<Object>(path) != null)
                AssetDatabase.DeleteAsset(path);
            var controller = AnimatorController.CreateAnimatorControllerAtPath(path);
            var hasGrip = false;
            foreach (var p in controller.parameters)
            {
                if (p.name == "Grip" && p.type == AnimatorControllerParameterType.Float)
                    hasGrip = true;
            }

            if (!hasGrip)
                controller.AddParameter("Grip", AnimatorControllerParameterType.Float);
            var state = controller.layers[0].stateMachine.AddState("GripBlend");
            var tree = new BlendTree { name = "GripTree", blendParameter = "Grip", blendType = BlendTreeType.Simple1D };
            AssetDatabase.AddObjectToAsset(tree, controller);
            state.motion = tree;
            AssetDatabase.SaveAssets();
            m_TempAssetPaths.Add(path);
            return controller;
        }

        InputActionReference CreatePersistedGripActionReference(HandSide handSide)
        {
            var assetPath = $"Assets/_VRHandPoseTool_LocActions_{handSide}.asset";
            var refPath = $"Assets/_VRHandPoseTool_LocGripRef_{handSide}.asset";
            if (AssetDatabase.LoadAssetAtPath<Object>(assetPath) != null)
                AssetDatabase.DeleteAsset(assetPath);
            if (AssetDatabase.LoadAssetAtPath<Object>(refPath) != null)
                AssetDatabase.DeleteAsset(refPath);

            var asset = ScriptableObject.CreateInstance<InputActionAsset>();
            var map = asset.AddActionMap(HandSideUtility.GetXriInteractionActionMap(handSide));
            var action = map.AddAction(
                HandPoseControllerHandSetupService.RecommendedGripActionName,
                InputActionType.Value,
                expectedControlLayout: "Axis");
            action.AddBinding(HandSideUtility.GetRecommendedGripBinding(handSide));
            AssetDatabase.CreateAsset(asset, assetPath);
            var reference = InputActionReference.Create(action);
            AssetDatabase.CreateAsset(reference, refPath);
            AssetDatabase.SaveAssets();
            m_TempAssetPaths.Add(refPath);
            m_TempAssetPaths.Add(assetPath);
            return AssetDatabase.LoadAssetAtPath<InputActionReference>(refPath);
        }
    }
}
