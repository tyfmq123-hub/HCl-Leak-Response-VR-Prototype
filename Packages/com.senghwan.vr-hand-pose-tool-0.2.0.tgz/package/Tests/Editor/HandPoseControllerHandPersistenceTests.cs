using System.Collections.Generic;
using NUnit.Framework;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using VRHandPoseTool;
using VRHandPoseTool.Editor;
using Object = UnityEngine.Object;

namespace VRHandPoseTool.Editor.Tests
{
    public class HandPoseControllerHandPersistenceTests
    {
        const string TempScenePath = "Assets/_VRHandPoseTool_PersistenceTest.unity";

        readonly List<Object> m_OwnedObjects = new List<Object>();
        readonly List<string> m_TempAssetPaths = new List<string>();

        [SetUp]
        public void SetUp()
        {
            HandPoseControllerHandPendingSetupBridge.ClearPending(HandSide.Left);
            HandPoseControllerHandPendingSetupBridge.ClearPending(HandSide.Right);
            HandControllerVisualAlignmentService.ClearPending(HandSide.Left);
            HandControllerVisualAlignmentService.ClearPending(HandSide.Right);
        }

        [TearDown]
        public void TearDown()
        {
            HandPoseControllerHandPendingSetupBridge.ClearPending(HandSide.Left);
            HandPoseControllerHandPendingSetupBridge.ClearPending(HandSide.Right);
            HandControllerVisualAlignmentService.ClearPending(HandSide.Left);
            HandControllerVisualAlignmentService.ClearPending(HandSide.Right);

            for (var i = m_OwnedObjects.Count - 1; i >= 0; i--)
            {
                if (m_OwnedObjects[i] != null)
                    Object.DestroyImmediate(m_OwnedObjects[i]);
            }

            m_OwnedObjects.Clear();

            foreach (var path in m_TempAssetPaths)
            {
                if (!string.IsNullOrEmpty(path) && AssetDatabase.LoadAssetAtPath<Object>(path) != null)
                    AssetDatabase.DeleteAsset(path);
            }

            m_TempAssetPaths.Clear();

            if (AssetDatabase.LoadAssetAtPath<Object>(TempScenePath) != null)
                AssetDatabase.DeleteAsset(TempScenePath);
        }

        [Test]
        public void ApplySetup_EditMode_CreatesDriverOnRoot_AndDoesNotDuplicate()
        {
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Left, "LeftHand");
            var controller = CreateGripAnimatorController("OculusHand_L");
            var gripAction = CreatePersistedGripActionReference(HandSide.Left);

            var first = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(first.success, first.message);
            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);

            var second = HandPoseControllerHandSetupService.ApplySetup(
                hand.transform, controller, gripAction, "Grip",
                false, 12f, HandSide.Left, HandGripControlMode.ToolDefault);
            Assert.IsTrue(second.success, second.message);
            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            Assert.AreEqual(1, origin.GetComponentsInChildren<UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager>(true).Length);
        }

        [Test]
        public void PendingSetup_SerializeRestore_PreservesHandSideSceneRootAndAssets()
        {
            var scene = CreateAndOpenTempScene();
            var hand = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var controller = CreatePersistedAnimatorController("PendingCtrl_L");
            var gripAction = CreatePersistedGripActionReference(HandSide.Left);
            var pending = BuildPendingSetup(hand.transform, HandSide.Left, scene.path, controller, gripAction, "token-setup-left");
            pending.useSmoothing = true;
            pending.smoothingSpeed = 9f;

            HandPoseControllerHandPendingSetupBridge.SavePendingForTests(HandSide.Left, pending);
            Assert.IsTrue(HandPoseControllerHandPendingSetupBridge.HasPending(HandSide.Left));
            Assert.IsFalse(HandPoseControllerHandPendingSetupBridge.HasPending(HandSide.Right));

            Assert.IsTrue(
                HandPoseControllerHandPendingSetupBridge.TryLoadPendingForTests(HandSide.Left, out var loaded));
            Assert.AreEqual(pending.applyToken, loaded.applyToken);
            Assert.AreEqual(pending.scenePath, loaded.scenePath);
            Assert.IsFalse(string.IsNullOrEmpty(loaded.playbackLocatorJson));
            Assert.AreEqual((int)HandSide.Left, loaded.handSide);
            Assert.AreEqual(pending.animatorControllerGuid, loaded.animatorControllerGuid);
            Assert.AreEqual(pending.gripActionReferenceGuid, loaded.gripActionReferenceGuid);
            Assert.AreEqual(pending.gripActionId, loaded.gripActionId);
            Assert.AreEqual("Grip", loaded.gripParameterName);
            Assert.AreEqual(9f, loaded.smoothingSpeed, 0.0001f);
        }

        [Test]
        public void PendingSetup_ApplyInEditMode_CreatesDriverAndConnections()
        {
            var scene = CreateAndOpenTempScene();
            var origin = CreateGameObject("XR Origin");
            var hand = CreateValidHandHierarchy(origin.transform, HandSide.Right, "RightHand");
            var controller = CreatePersistedAnimatorController("PendingCtrl_R");
            var gripAction = CreatePersistedGripActionReference(HandSide.Right);
            var pending = BuildPendingSetup(hand.transform, HandSide.Right, scene.path, controller, gripAction, "token-apply-right");

            Assert.IsNull(hand.GetComponent<ControllerHandGripAnimator>());

            var apply = HandPoseControllerHandPendingSetupBridge.TryApplyPendingInternalForTests(pending);
            Assert.IsTrue(apply.success, apply.message);

            Assert.AreEqual(1, hand.GetComponents<ControllerHandGripAnimator>().Length);
            var status = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                hand.transform, controller, gripAction, "Grip");
            Assert.IsTrue(status.isValid, status.failureReason);
            Assert.IsTrue(status.hasInputActionManager);
            Assert.IsTrue(status.gripActionAssetRegistered);
        }

        [Test]
        public void PendingSetup_SceneMismatch_DoesNotApply()
        {
            var scene = CreateAndOpenTempScene();
            var hand = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var controller = CreatePersistedAnimatorController("MismatchCtrl");
            var gripAction = CreatePersistedGripActionReference(HandSide.Left);
            var pending = BuildPendingSetup(hand.transform, HandSide.Left, scene.path, controller, gripAction, "token-mismatch");
            pending.scenePath = "Assets/OtherScene_That_Does_Not_Match.unity";
            // Keep locator scenePath different from active — Resolve checks locator.scenePath
            var locator = HandSceneObjectLocator.FromJson(pending.playbackLocatorJson);
            locator.scenePath = pending.scenePath;
            pending.playbackLocatorJson = HandSceneObjectLocator.ToJson(locator);

            var apply = HandPoseControllerHandPendingSetupBridge.TryApplyPendingInternalForTests(pending);
            Assert.IsFalse(apply.success);
            StringAssert.Contains("Scene", apply.message);
            Assert.IsNull(hand.GetComponent<ControllerHandGripAnimator>());
            Assert.AreEqual(scene.path, SceneManager.GetActiveScene().path);
        }

        [Test]
        public void PendingSetup_InvalidLocator_DoesNotApplyToOtherObjects()
        {
            CreateAndOpenTempScene();
            var otherHand = CreateValidHandHierarchy(null, HandSide.Left, "OtherHand");
            var controller = CreatePersistedAnimatorController("InvalidGoidCtrl");
            var gripAction = CreatePersistedGripActionReference(HandSide.Left);

            var pending = new HandPoseControllerHandPendingSetupBridge.PendingSetupData
            {
                applyToken = "token-bad-goid",
                scenePath = SceneManager.GetActiveScene().path,
                playbackHandRootGlobalObjectId = "GlobalObjectId_V1-2-ffffffffffffffffffffffffffffffff-1-0",
                playbackLocatorJson = HandSceneObjectLocator.ToJson(new HandSceneObjectLocator.SceneObjectLocatorData
                {
                    isValid = true,
                    scenePath = SceneManager.GetActiveScene().path,
                    handSide = (int)HandSide.Left,
                    targetRole = (int)SceneObjectLocatorRole.PlaybackHandRoot,
                    editModeGlobalObjectId = "GlobalObjectId_V1-2-ffffffffffffffffffffffffffffffff-1-0",
                    siblingIndexPath = new[] { 99 },
                    transformNamePath = new[] { "MissingRoot" },
                }),
                handSide = (int)HandSide.Left,
                animatorControllerGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(controller)),
                gripActionReferenceGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(gripAction)),
                gripActionId = gripAction.action.id.ToString(),
                gripParameterName = "Grip",
                gripControlMode = (int)HandGripControlMode.ToolDefault,
            };

            var apply = HandPoseControllerHandPendingSetupBridge.TryApplyPendingInternalForTests(pending);
            Assert.IsFalse(apply.success);
            StringAssert.Contains("복원", apply.message);
            Assert.IsNull(otherHand.GetComponent<ControllerHandGripAnimator>());
        }

        [Test]
        public void PendingSetup_LeftDoesNotApplyToRight()
        {
            var scene = CreateAndOpenTempScene();
            var left = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var right = CreateValidHandHierarchy(null, HandSide.Right, "RightHand");
            var controller = CreatePersistedAnimatorController("SideIsolationCtrl");
            var gripAction = CreatePersistedGripActionReference(HandSide.Left);
            var leftPending = BuildPendingSetup(left.transform, HandSide.Left, scene.path, controller, gripAction, "token-left-only");

            HandPoseControllerHandPendingSetupBridge.SavePendingForTests(HandSide.Left, leftPending);
            Assert.IsTrue(HandPoseControllerHandPendingSetupBridge.HasPending(HandSide.Left));
            Assert.IsFalse(HandPoseControllerHandPendingSetupBridge.HasPending(HandSide.Right));

            var applyLeft = HandPoseControllerHandPendingSetupBridge.TryApplyPendingInternalForTests(leftPending);
            Assert.IsTrue(applyLeft.success, applyLeft.message);
            Assert.IsNotNull(left.GetComponent<ControllerHandGripAnimator>());
            Assert.IsNull(right.GetComponent<ControllerHandGripAnimator>());
        }

        HandPoseControllerHandPendingSetupBridge.PendingSetupData BuildPendingSetup(
            Transform handRoot,
            HandSide handSide,
            string scenePath,
            RuntimeAnimatorController controller,
            InputActionReference gripAction,
            string applyToken = "token")
        {
            Assert.IsTrue(
                HandSceneObjectLocator.TryCapture(
                    handRoot,
                    handSide,
                    SceneObjectLocatorRole.PlaybackHandRoot,
                    out var locator,
                    out var locatorError),
                locatorError);

            return new HandPoseControllerHandPendingSetupBridge.PendingSetupData
            {
                applyToken = applyToken,
                scenePath = scenePath,
                playbackHandRootGlobalObjectId = locator.editModeGlobalObjectId ?? string.Empty,
                playbackLocatorJson = HandSceneObjectLocator.ToJson(locator),
                handSide = (int)handSide,
                animatorControllerGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(controller)),
                gripActionReferenceGuid = AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(gripAction)),
                gripActionId = gripAction.action.id.ToString(),
                gripParameterName = "Grip",
                useSmoothing = false,
                smoothingSpeed = 12f,
                gripControlMode = (int)HandGripControlMode.ToolDefault,
                createdAtUtc = "2026-01-01T00:00:00Z",
                lifecycleStatus = (int)HandPoseControllerHandPendingSetupBridge.PendingLifecycleStatus.PendingWaitingForEditMode,
            };
        }

        Scene CreateAndOpenTempScene()
        {
            if (AssetDatabase.LoadAssetAtPath<Object>(TempScenePath) != null)
                AssetDatabase.DeleteAsset(TempScenePath);

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            Assert.IsTrue(EditorSceneManager.SaveScene(scene, TempScenePath), "temp scene save failed");
            AssetDatabase.Refresh();
            return SceneManager.GetActiveScene();
        }

        GameObject CreateGameObject(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null)
                go.transform.SetParent(parent, false);
            m_OwnedObjects.Add(go);
            return go;
        }

        GameObject CreateValidHandHierarchy(Transform parent, HandSide handSide, string rootName)
        {
            var root = CreateGameObject(rootName, parent);
            var created = new Dictionary<string, Transform>();

            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                Transform parentTransform;
                if (expectedParentBoneName == HandSkeletonCatalog.ParentIsHandRoot)
                    parentTransform = root.transform;
                else
                    parentTransform = created[expectedParentBoneName];

                var bone = CreateGameObject(boneName, parentTransform);
                created[boneName] = bone.transform;
            }

            var meshHost = CreateGameObject("Mesh", root.transform);
            var smr = meshHost.AddComponent<SkinnedMeshRenderer>();
            var mesh = new Mesh { name = "TestHandMesh" };
            m_OwnedObjects.Add(mesh);
            smr.sharedMesh = mesh;
            return root;
        }

        AnimatorController CreateGripAnimatorController(string name)
        {
            var controller = new AnimatorController { name = name };
            controller.AddParameter("Grip", AnimatorControllerParameterType.Float);
            controller.AddLayer("Base Layer");
            var state = controller.layers[0].stateMachine.AddState("GripBlend");
            var tree = new BlendTree
            {
                name = "GripTree",
                blendParameter = "Grip",
                blendType = BlendTreeType.Simple1D,
            };
            state.motion = tree;
            m_OwnedObjects.Add(controller);
            m_OwnedObjects.Add(tree);
            return controller;
        }

        AnimatorController CreatePersistedAnimatorController(string name)
        {
            var path = $"Assets/_VRHandPoseTool_TestCtrl_{name}.controller";
            if (AssetDatabase.LoadAssetAtPath<Object>(path) != null)
                AssetDatabase.DeleteAsset(path);

            var controller = AnimatorController.CreateAnimatorControllerAtPath(path);
            if (!HasFloatParameter(controller, "Grip"))
                controller.AddParameter("Grip", AnimatorControllerParameterType.Float);

            if (controller.layers.Length == 0)
                controller.AddLayer("Base Layer");

            var state = controller.layers[0].stateMachine.AddState("GripBlend");
            var tree = new BlendTree
            {
                name = "GripTree",
                blendParameter = "Grip",
                blendType = BlendTreeType.Simple1D,
            };
            AssetDatabase.AddObjectToAsset(tree, controller);
            state.motion = tree;
            EditorUtility.SetDirty(controller);
            AssetDatabase.SaveAssets();
            m_TempAssetPaths.Add(path);
            return controller;
        }

        static bool HasFloatParameter(AnimatorController controller, string parameterName)
        {
            foreach (var parameter in controller.parameters)
            {
                if (parameter.type == AnimatorControllerParameterType.Float
                    && parameter.name == parameterName)
                    return true;
            }

            return false;
        }

        InputActionReference CreatePersistedGripActionReference(HandSide handSide)
        {
            var assetPath = $"Assets/_VRHandPoseTool_TestActions_{handSide}.asset";
            var refPath = $"Assets/_VRHandPoseTool_TestGripRef_{handSide}.asset";

            if (AssetDatabase.LoadAssetAtPath<Object>(assetPath) != null)
                AssetDatabase.DeleteAsset(assetPath);
            if (AssetDatabase.LoadAssetAtPath<Object>(refPath) != null)
                AssetDatabase.DeleteAsset(refPath);

            var asset = ScriptableObject.CreateInstance<InputActionAsset>();
            asset.name = $"TestXriActions_{handSide}";
            var mapName = HandSideUtility.GetXriInteractionActionMap(handSide);
            var map = asset.AddActionMap(mapName);
            var action = map.AddAction(
                HandPoseControllerHandSetupService.RecommendedGripActionName,
                InputActionType.Value,
                expectedControlLayout: "Axis");
            action.AddBinding(HandSideUtility.GetRecommendedGripBinding(handSide));

            AssetDatabase.CreateAsset(asset, assetPath);
            var reference = InputActionReference.Create(action);
            AssetDatabase.CreateAsset(reference, refPath);
            AssetDatabase.SaveAssets();

            m_TempAssetPaths.Add(refPath);
            m_TempAssetPaths.Add(assetPath);

            return AssetDatabase.LoadAssetAtPath<InputActionReference>(refPath);
        }
    }
}
