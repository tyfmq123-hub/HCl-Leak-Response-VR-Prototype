using System.IO;
using NUnit.Framework;
using VRHandPoseTool.Editor;

namespace VRHandPoseTool.Editor.Tests
{
    public class ProjectAssetPathNormalizationTests
    {
        [Test]
        public void Normalize_WindowsAbsolutePath_UnderAssets_ConvertsToAssetPath()
        {
            var dataPath = @"C:\Projects\MyVR\Assets";
            var raw = @"C:\Projects\MyVR\Assets\Samples\XR Hands\9.9.9\HandVisualizer";

            Assert.IsTrue(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    raw,
                    dataPath,
                    out var assetPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets/Samples/XR Hands/9.9.9/HandVisualizer", assetPath);
        }

        [Test]
        public void Normalize_OtherDriveProject_ConvertsToAssetPath()
        {
            var dataPath = @"D:\Work\Project\Assets";
            var raw = @"D:\Work\Project\Assets\Samples\XR Hands\2.0.0\HandVisualizer";

            Assert.IsTrue(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    raw,
                    dataPath,
                    out var assetPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets/Samples/XR Hands/2.0.0/HandVisualizer", assetPath);
        }

        [Test]
        public void Normalize_AlreadyAssetRelative_KeepsPath()
        {
            Assert.IsTrue(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    "Assets/Samples/XR Hands/1.7.3/HandVisualizer",
                    @"C:\Any\Project\Assets",
                    out var assetPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets/Samples/XR Hands/1.7.3/HandVisualizer", assetPath);
        }

        [Test]
        public void Normalize_MixedSlashes_AndTrailingSlash()
        {
            var dataPath = @"C:\Projects\MyVR\Assets";
            var raw = @"C:/Projects/MyVR/Assets/Samples/XR Hands/9.9.9/HandVisualizer/";

            Assert.IsTrue(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    raw,
                    dataPath,
                    out var assetPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets/Samples/XR Hands/9.9.9/HandVisualizer", assetPath);
        }

        [Test]
        public void Normalize_OutsideAssets_Fails()
        {
            Assert.IsFalse(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    @"C:\OtherFolder\HandVisualizer",
                    @"C:\Projects\MyVR\Assets",
                    out _,
                    out var failure));

            StringAssert.Contains("Assets 폴더 외부", failure);
        }

        [Test]
        public void Normalize_AssetsBackupPrefix_IsNotTreatedAsAssets()
        {
            Assert.IsFalse(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    @"C:\Project\AssetsBackup\Samples\HandVisualizer",
                    @"C:\Project\Assets",
                    out _,
                    out var failure));

            StringAssert.Contains("Assets 폴더 외부", failure);
        }

        [Test]
        public void Normalize_AssetsRootExact_ReturnsAssets()
        {
            Assert.IsTrue(
                HandVisualizerSampleImportService.TryNormalizeProjectAssetPath(
                    @"C:\Projects\MyVR\Assets\",
                    @"C:\Projects\MyVR\Assets",
                    out var assetPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets", assetPath);
        }

        [Test]
        public void ResolveSampleImportPaths_BuildsPhysicalAndAsset()
        {
            var dataPath = Path.GetFullPath(@"C:\Projects\MyVR\Assets");
            var raw = Path.Combine(dataPath, "Samples", "XR Hands", "9.9.9", "HandVisualizer");

            Assert.IsTrue(
                HandVisualizerSampleImportService.TryResolveSampleImportPaths(
                    raw,
                    dataPath,
                    out var assetPath,
                    out var physicalPath,
                    out var failure),
                failure);

            Assert.AreEqual("Assets/Samples/XR Hands/9.9.9/HandVisualizer", assetPath);
            Assert.IsTrue(
                physicalPath.Replace('/', '\\')
                    .EndsWith(@"Samples\XR Hands\9.9.9\HandVisualizer".Replace('/', '\\')),
                physicalPath);
            StringAssert.DoesNotContain("E:\\WorkSpace\\VR_Project", assetPath);
            StringAssert.DoesNotContain("E:\\WorkSpace\\VR_Project", physicalPath);
        }

        [Test]
        public void ImportedSample_AssetImportPath_IsAssetsRelative_AndResolverAcceptsRawAbsolute()
        {
            Assert.IsTrue(
                HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var error),
                error);

            Assert.IsFalse(string.IsNullOrEmpty(sample.assetImportPath));
            Assert.IsTrue(
                sample.assetImportPath.StartsWith("Assets/"),
                sample.assetImportPath);
            Assert.IsFalse(
                Path.IsPathRooted(sample.assetImportPath.Replace('/', Path.DirectorySeparatorChar)));

            // Sample API raw(절대경로 가능)를 직접 넘겨도 Tracking 탐색 성공
            var resolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(
                VRHandPoseTool.HandSide.Left,
                sample.importPath);
            Assert.IsTrue(resolve.success, resolve.message);
            Assert.IsTrue(
                resolve.importPath.StartsWith("Assets/"),
                resolve.importPath);
        }
    }
}
