using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using Unity.XR.CoreUtils;
using VRHandPoseTool;
using VRHandPoseTool.Editor;
using Object = UnityEngine.Object;

namespace VRHandPoseTool.Editor.Tests
{
    public class HandVisualizerSampleAndTrackingSetupTests
    {
        const string TestRootFolder = "Assets/VRHandPoseToolOutput/_EditModeTemp_HandVisualizer";

        readonly List<Object> m_OwnedObjects = new List<Object>();
        readonly List<string> m_OwnedAssetPaths = new List<string>();

        [SetUp]
        public void SetUp()
        {
            HandVisualizerSampleImportService.ClearPendingSetup();
            HandVisualizerSampleImportService.ClearStatus();
            EnsureFolder(TestRootFolder);
        }

        [TearDown]
        public void TearDown()
        {
            HandVisualizerSampleImportService.ClearPendingSetup();
            HandVisualizerSampleImportService.ClearStatus();

            for (var i = m_OwnedObjects.Count - 1; i >= 0; i--)
            {
                if (m_OwnedObjects[i] != null)
                    Object.DestroyImmediate(m_OwnedObjects[i]);
            }

            m_OwnedObjects.Clear();

            for (var i = m_OwnedAssetPaths.Count - 1; i >= 0; i--)
            {
                var path = m_OwnedAssetPaths[i];
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                    AssetDatabase.DeleteAsset(path);
            }

            m_OwnedAssetPaths.Clear();

            if (AssetDatabase.IsValidFolder(TestRootFolder))
                AssetDatabase.DeleteAsset(TestRootFolder);

            AssetDatabase.Refresh();
        }

        [Test]
        public void XrHandsPackageResolver_ReportsInstalledVersion_WithoutHardcodedPath()
        {
            var resolve = XrHandsPackageResolver.ResolveInstalled();
            Assert.IsTrue(resolve.success, resolve.message);
            Assert.IsFalse(string.IsNullOrEmpty(resolve.version));
            StringAssert.DoesNotContain("Assets/Samples/XR Hands/1.7.3", resolve.message);
        }

        [Test]
        public void SampleImportService_WhenAlreadyImported_DoesNotRequestReimport()
        {
            var find = HandVisualizerSampleImportService.FindHandVisualizerSample();
            Assert.IsTrue(find.success, find.message);
            Assert.IsTrue(find.sample.isImported, "이 프로젝트에는 HandVisualizer Sample이 Import되어 있어야 합니다.");

            var ensure = HandVisualizerSampleImportService.EnsureImported(HandSide.Left, openWindowOnResume: false);
            Assert.IsTrue(ensure.success, ensure.message);
            Assert.IsTrue(ensure.alreadyImported);
            Assert.IsFalse(ensure.importRequested);
            Assert.IsFalse(string.IsNullOrEmpty(ensure.sample.importPath));
            Assert.IsFalse(HandVisualizerSampleImportService.HasPendingSetup);
        }

        [Test]
        public void SampleImportService_PendingSetup_RoundTripsHandSide()
        {
            HandVisualizerSampleImportService.StorePendingSetupForTests(
                HandSide.Right,
                resumeAfterImport: true,
                packageVersion: "9.9.9");

            Assert.IsTrue(HandVisualizerSampleImportService.HasPendingSetup);
            var pending = HandVisualizerSampleImportService.GetPendingSetup();
            Assert.IsTrue(pending.exists);
            Assert.AreEqual(HandSide.Right, pending.handSide);
            Assert.IsTrue(pending.resumeAfterImport);
            Assert.AreEqual("9.9.9", pending.packageVersion);

            HandVisualizerSampleImportService.ClearPendingSetup();
            Assert.IsFalse(HandVisualizerSampleImportService.HasPendingSetup);
        }

        [Test]
        public void SampleImportService_MarkNeedsManualContinue_SetsFlagAndMessage()
        {
            HandVisualizerSampleImportService.MarkNeedsManualContinue("수동 계속 필요");
            Assert.IsTrue(HandVisualizerSampleImportService.NeedsManualContinue);
            Assert.AreEqual("수동 계속 필요", HandVisualizerSampleImportService.LastStatusMessage);
            Assert.AreEqual(
                HandSelectedHandFullPrepService.ContinueButtonLabel,
                HandSelectedHandFullPrepService.GetPrimaryButtonLabel());
        }

        [Test]
        public void AssetResolver_FindsLeftTrackingPrefab_UnderImportedSample_WithoutVersionHardcode()
        {
            Assert.IsTrue(
                HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var sampleError),
                sampleError);

            var resolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(
                HandSide.Left,
                sample.importPath); // 절대경로 raw여도 Resolver가 정규화
            Assert.IsTrue(resolve.success, resolve.message);
            Assert.IsNotNull(resolve.prefab);
            var expectedRoot = sample.assetImportPath ?? sample.importPath;
            Assert.IsTrue(
                resolve.assetPath.Replace('\\', '/').StartsWith(expectedRoot.Replace('\\', '/')),
                $"경로가 importPath 범위 밖입니다: {resolve.assetPath} / {expectedRoot}");
            Assert.IsFalse(resolve.assetPath.Contains("Right Hand Tracking"));
        }

        [Test]
        public void AssetResolver_LeftSearch_Fails_WhenOnlyRightPrefabPresent()
        {
            var folder = $"{TestRootFolder}/RightOnly";
            EnsureFolder(folder);

            var right = CreateTrackingPrefabAsset(
                $"{folder}/Right Hand Tracking.prefab",
                HandSide.Right,
                "Right Hand Tracking");

            var resolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(HandSide.Left, folder);
            Assert.IsFalse(resolve.success, "Right만 있을 때 Left는 실패해야 합니다.");
            Assert.AreEqual(0, resolve.validCandidates.Count);
            StringAssert.Contains("0개", resolve.message);
            Assert.IsNotNull(right);
        }

        [Test]
        public void AssetResolver_MultipleValidCandidates_DoesNotAutoSelect()
        {
            var folder = $"{TestRootFolder}/MultiLeft";
            EnsureFolder(folder);

            CreateTrackingPrefabAsset($"{folder}/Left Hand Tracking A.prefab", HandSide.Left, "Left Hand Tracking A");
            CreateTrackingPrefabAsset($"{folder}/Left Hand Tracking B.prefab", HandSide.Left, "Left Hand Tracking B");

            var resolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(HandSide.Left, folder);
            Assert.IsFalse(resolve.success, resolve.message);
            Assert.GreaterOrEqual(resolve.validCandidates.Count, 2);
            StringAssert.Contains("임의 선택하지 않습니다", resolve.message);
        }

        [Test]
        public void AssetResolver_PlaybackModel_ExcludesTrackingPrefabs()
        {
            var folder = $"{TestRootFolder}/PlaybackMix";
            EnsureFolder(folder);

            CreateTrackingPrefabAsset($"{folder}/Left Hand Tracking.prefab", HandSide.Left, "Left Hand Tracking");
            CreatePlaybackModelAsset($"{folder}/LeftHand.prefab", HandSide.Left, "LeftHand");

            var resolve = HandVisualizerAssetResolver.ResolvePlaybackModel(HandSide.Left, folder);
            Assert.IsTrue(resolve.success, resolve.message);
            StringAssert.Contains("LeftHand", resolve.assetPath);
            Assert.IsFalse(resolve.assetPath.Contains("Tracking"));
        }

        [Test]
        public void TrackingHandSetup_CalledTwice_DoesNotDuplicate()
        {
            var sceneRoot = CreateGameObject("TestSceneRoot");
            var originGo = CreateGameObject("XR Origin", sceneRoot.transform);
            var origin = originGo.AddComponent<XROrigin>();
            var cameraOffset = CreateGameObject("Camera Offset", originGo.transform);
            origin.CameraFloorOffsetObject = cameraOffset;

            var folder = $"{TestRootFolder}/TrackingSetup";
            EnsureFolder(folder);
            var prefab = CreateTrackingPrefabAsset(
                $"{folder}/Left Hand Tracking.prefab",
                HandSide.Left,
                "Left Hand Tracking");

            var first = HandTrackingHandSetupService.EnsureTrackingHand(HandSide.Left, prefab, AssetDatabase.GetAssetPath(prefab));
            Assert.IsTrue(first.success, first.message);

            var second = HandTrackingHandSetupService.EnsureTrackingHand(HandSide.Left, prefab, AssetDatabase.GetAssetPath(prefab));
            Assert.IsTrue(second.success, second.message);
            Assert.IsTrue(second.reusedExisting);
            Assert.AreEqual(first.trackingHandRoot, second.trackingHandRoot);

            var existing = HandTrackingHandSetupService.FindExistingValidTrackingHands(
                sceneRoot.scene,
                HandSide.Left);
            Assert.AreEqual(1, existing.Count);
        }

        [Test]
        public void HandSideUtility_GetHandModelAssetPath_UsesDynamicResolver()
        {
            var path = HandSideUtility.GetHandModelAssetPath(HandSide.Left);
            Assert.IsFalse(string.IsNullOrEmpty(path), "Import된 Sample에서 Playback 모델을 해석해야 합니다.");
            Assert.IsTrue(
                HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var err),
                err);
            Assert.IsTrue(
                path.Replace('\\', '/').StartsWith(sample.assetImportPath.Replace('\\', '/')),
                path);

            var display = HandSideUtility.GetHandModelDisplayFileName(HandSide.Left);
            Assert.IsFalse(string.IsNullOrEmpty(display));
        }

        [Test]
        public void SampleNameMatching_AllowsCaseAndWhitespaceDifferences()
        {
            Assert.IsTrue(HandVisualizerSampleImportService.IsHandVisualizerName("HandVisualizer"));
            Assert.IsTrue(HandVisualizerSampleImportService.IsHandVisualizerName("hand visualizer"));
            Assert.IsTrue(HandVisualizerSampleImportService.IsHandVisualizerName("HAND VISUALIZER"));
            Assert.IsTrue(HandVisualizerSampleImportService.IsHandVisualizerName("Samples/HandVisualizer"));
            Assert.IsFalse(HandVisualizerSampleImportService.IsHandVisualizerName("Gestures"));
            Assert.IsFalse(HandVisualizerSampleImportService.IsHandVisualizerName("Hand Capture"));
        }

        [Test]
        public void FullPrepChecklist_Incomplete_WhenTrackingMissing()
        {
            var playback = CreateValidHandHierarchy(null, HandSide.Left, "LeftHand");
            var checklist = HandSelectedHandFullPrepService.EvaluateChecklist(
                HandSide.Left,
                trackingHandRoot: null,
                playbackHandRoot: playback.transform,
                gripAction: null);

            Assert.IsFalse(checklist.isComplete);
            Assert.IsFalse(checklist.trackingHandReady);
            Assert.IsFalse(checklist.gripConnected);
        }

        GameObject CreateGameObject(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null)
                go.transform.SetParent(parent, false);
            m_OwnedObjects.Add(go);
            return go;
        }

        GameObject CreateValidHandHierarchy(Transform parent, HandSide handSide, string rootName)
        {
            var root = CreateGameObject(rootName, parent);
            var created = new Dictionary<string, Transform>();

            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                Transform parentTransform;
                if (expectedParentBoneName == HandSkeletonCatalog.ParentIsHandRoot)
                    parentTransform = root.transform;
                else
                    parentTransform = created[expectedParentBoneName];

                var bone = CreateGameObject(boneName, parentTransform);
                created[boneName] = bone.transform;
            }

            var meshHost = CreateGameObject("Mesh", root.transform);
            var smr = meshHost.AddComponent<SkinnedMeshRenderer>();
            var mesh = new Mesh { name = "TestHandMesh" };
            m_OwnedObjects.Add(mesh);
            smr.sharedMesh = mesh;
            return root;
        }

        GameObject CreateTrackingPrefabAsset(string assetPath, HandSide handSide, string rootName)
        {
            var root = CreateValidHandHierarchy(null, handSide, rootName);
            var events = root.AddComponent<XRHandTrackingEvents>();
            events.handedness = HandSideUtility.ToHandedness(handSide);

            var driver = root.AddComponent<XRHandSkeletonDriver>();
            var refs = new List<JointToTransformReference>();
            var jointId = 1;
            foreach (var boneName in HandSkeletonCatalog.GetRequiredBoneNames(handSide))
            {
                var bone = FindChildByName(root.transform, boneName);
                refs.Add(new JointToTransformReference
                {
                    xrHandJointID = (XRHandJointID)jointId,
                    jointTransform = bone,
                });
                jointId++;
                if (jointId > 26)
                    jointId = 1;
            }

            driver.jointTransformReferences = refs;

            // Mesh controller optional — 없어도 유효
            var prefab = PrefabUtility.SaveAsPrefabAsset(root, assetPath);
            m_OwnedAssetPaths.Add(assetPath);
            Object.DestroyImmediate(root);
            AssetDatabase.ImportAsset(assetPath);
            return prefab;
        }

        GameObject CreatePlaybackModelAsset(string assetPath, HandSide handSide, string rootName)
        {
            var root = CreateValidHandHierarchy(null, handSide, rootName);
            var prefab = PrefabUtility.SaveAsPrefabAsset(root, assetPath);
            m_OwnedAssetPaths.Add(assetPath);
            Object.DestroyImmediate(root);
            AssetDatabase.ImportAsset(assetPath);
            return prefab;
        }

        static Transform FindChildByName(Transform root, string name)
        {
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                if (t != root && t.name == name)
                    return t;
            }

            return null;
        }

        static void EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder))
                return;

            var parts = folder.Split('/');
            var current = parts[0];
            for (var i = 1; i < parts.Length; i++)
            {
                var next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }
}
