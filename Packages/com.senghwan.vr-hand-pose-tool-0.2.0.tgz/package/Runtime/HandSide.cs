namespace VRHandPoseTool
{
    /// <summary>
    /// VR Hand Pose Tool에서 Left / Right 손 작업 대상을 나타냅니다.
    /// </summary>
    public enum HandSide
    {
        Left,
        Right,
    }
}
