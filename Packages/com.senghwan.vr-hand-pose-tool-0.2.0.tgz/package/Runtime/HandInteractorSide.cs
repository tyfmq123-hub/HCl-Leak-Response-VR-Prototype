using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// XR Interactor 또는 컨트롤러 계층의 HandSide를 명시적으로 표시합니다.
    /// Transform·Interactor·입력을 제어하지 않습니다.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("VR Hand Pose Tool/Hand Interactor Side")]
    public sealed class HandInteractorSide : MonoBehaviour
    {
        [SerializeField]
        HandSide m_HandSide = HandSide.Left;

        public HandSide HandSide => m_HandSide;

        public bool Matches(HandSide side) => m_HandSide == side;
    }
}
