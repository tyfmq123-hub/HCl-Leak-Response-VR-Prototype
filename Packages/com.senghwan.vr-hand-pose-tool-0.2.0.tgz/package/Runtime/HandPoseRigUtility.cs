using System;

/// <summary>
/// OculusHand(b_l_/b_r_)와 XR Hands 메시(L_/R_) 본 이름 규칙을 공통 처리합니다.
/// </summary>
public static class HandPoseRigUtility
{
    public static bool IsRigBone(string boneName, HandCaptureSide side)
    {
        if (string.IsNullOrEmpty(boneName))
            return false;

        return side switch
        {
            HandCaptureSide.Right => boneName.StartsWith("b_r_", StringComparison.Ordinal)
                || boneName.StartsWith("R_", StringComparison.Ordinal),
            HandCaptureSide.Left => boneName.StartsWith("b_l_", StringComparison.Ordinal)
                || boneName.StartsWith("L_", StringComparison.Ordinal),
            _ => boneName.StartsWith("b_l_", StringComparison.Ordinal)
                || boneName.StartsWith("b_r_", StringComparison.Ordinal)
                || boneName.StartsWith("L_", StringComparison.Ordinal)
                || boneName.StartsWith("R_", StringComparison.Ordinal)
        };
    }

    public static bool ShouldSkipWristBone(string boneName)
    {
        if (string.IsNullOrEmpty(boneName))
            return false;

        return boneName.EndsWith("Wrist", StringComparison.Ordinal)
            || boneName.EndsWith("wrist", StringComparison.Ordinal);
    }
}
