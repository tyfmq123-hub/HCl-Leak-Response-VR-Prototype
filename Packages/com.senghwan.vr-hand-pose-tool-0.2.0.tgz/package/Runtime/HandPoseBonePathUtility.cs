using System.Collections.Generic;

namespace VRHandPoseTool
{
    /// <summary>
    /// HandBonePoseData의 부모 체인으로 Animator 루트(LeftHand) 기준 본 상대 경로를 만듭니다.
    /// </summary>
    public static class HandPoseBonePathUtility
    {
        public static bool TryBuildPathFromHandRoot(
            string boneName,
            IReadOnlyList<HandBonePoseData> bones,
            string handRootName,
            out string path,
            out string errorMessage)
        {
            path = null;
            errorMessage = null;

            if (string.IsNullOrEmpty(boneName))
            {
                errorMessage = "boneName이 비어 있습니다.";
                return false;
            }

            if (string.IsNullOrEmpty(handRootName))
            {
                errorMessage = "handRootName이 비어 있습니다.";
                return false;
            }

            if (bones == null || bones.Count == 0)
            {
                errorMessage = "bones 목록이 비어 있습니다.";
                return false;
            }

            var boneByName = new Dictionary<string, HandBonePoseData>();
            foreach (var bone in bones)
            {
                if (bone == null || string.IsNullOrEmpty(bone.boneName))
                    continue;

                boneByName[bone.boneName] = bone;
            }

            if (!boneByName.ContainsKey(boneName))
            {
                errorMessage = $"bones 목록에 '{boneName}'이 없습니다.";
                return false;
            }

            var parts = new List<string>();
            var current = boneName;
            var guard = 0;

            while (current != handRootName && guard++ < 64)
            {
                parts.Add(current);

                if (!boneByName.TryGetValue(current, out var bone))
                {
                    errorMessage = $"'{current}'의 부모 정보를 찾을 수 없습니다.";
                    return false;
                }

                if (string.IsNullOrEmpty(bone.parentBoneName) || bone.parentBoneName == handRootName)
                    break;

                current = bone.parentBoneName;
            }

            parts.Reverse();
            path = string.Join("/", parts);
            return true;
        }
    }
}
