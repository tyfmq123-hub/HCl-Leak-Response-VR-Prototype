using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// HandPoseSnapshot의 리그 본(bones) 또는 레거시 조인트(joints) 데이터를 손 메시 본에 적용합니다.
/// </summary>
public static class HandPoseJointApplier
{
    public const string WristJointId = "Wrist";

    static readonly string[] s_BonePrefixes = { "L_", "R_", "b_l_", "b_r_" };

    public static Dictionary<string, Transform> BuildBoneNameMap(Transform handRoot)
    {
        var map = new Dictionary<string, Transform>();
        if (handRoot == null)
            return map;

        foreach (var bone in handRoot.GetComponentsInChildren<Transform>(true))
        {
            if (bone == handRoot)
                continue;

            foreach (var prefix in s_BonePrefixes)
            {
                if (!bone.name.StartsWith(prefix))
                    continue;

                map[bone.name] = bone;
                break;
            }
        }

        return map;
    }

    public static Dictionary<string, Quaternion> CaptureLocalRotations(IReadOnlyDictionary<string, Transform> bones)
    {
        var saved = new Dictionary<string, Quaternion>();
        foreach (var pair in bones)
            saved[pair.Key] = pair.Value.localRotation;

        return saved;
    }

    public static bool HasApplicablePoseData(HandPoseSnapshot snapshot)
    {
        if (snapshot == null)
            return false;

        return snapshot.bones != null && snapshot.bones.Count > 0
            || snapshot.joints != null && snapshot.joints.Count > 0;
    }

    public static void ApplySnapshot(
        HandPoseSnapshot snapshot,
        IReadOnlyDictionary<string, Transform> bones,
        bool skipWrist = true)
    {
        if (snapshot == null || bones == null)
            return;

        if (snapshot.bones != null && snapshot.bones.Count > 0)
            ApplySnapshotBones(snapshot, bones, skipWrist);
        else
            ApplySnapshotJoints(snapshot, bones, skipWrist);
    }

    public static void ApplySnapshotBones(
        HandPoseSnapshot snapshot,
        IReadOnlyDictionary<string, Transform> bones,
        bool skipWrist = true)
    {
        if (snapshot == null || bones == null)
            return;

        foreach (var record in snapshot.bones)
        {
            if (skipWrist && HandPoseRigUtility.ShouldSkipWristBone(record.boneName))
                continue;

            if (bones.TryGetValue(record.boneName, out var bone) && bone != null)
                bone.localRotation = record.localRotation;
        }
    }

    public static void ApplySnapshotJoints(
        HandPoseSnapshot snapshot,
        IReadOnlyDictionary<string, Transform> bones,
        bool skipWrist = true)
    {
        if (snapshot == null || bones == null)
            return;

        foreach (var joint in snapshot.joints)
        {
            if (skipWrist && joint.jointId == WristJointId)
                continue;

            var boneName = "L_" + joint.jointId;
            if (!bones.TryGetValue(boneName, out var bone) || bone == null)
            {
                boneName = "R_" + joint.jointId;
                bones.TryGetValue(boneName, out bone);
            }

            if (bone != null)
                bone.localRotation = joint.localRotation;
        }
    }

    public static void RestoreLocalRotations(
        IReadOnlyDictionary<string, Transform> bones,
        IReadOnlyDictionary<string, Quaternion> savedRotations)
    {
        if (bones == null || savedRotations == null)
            return;

        foreach (var pair in savedRotations)
        {
            if (bones.TryGetValue(pair.Key, out var bone) && bone != null)
                bone.localRotation = pair.Value;
        }
    }
}
