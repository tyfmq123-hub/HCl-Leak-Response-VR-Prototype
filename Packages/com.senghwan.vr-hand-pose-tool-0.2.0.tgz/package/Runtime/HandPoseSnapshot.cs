using System;
using System.Collections.Generic;
using UnityEngine;

public enum HandCaptureSide
{
    Auto,
    Left,
    Right
}

[CreateAssetMenu(fileName = "HandPose", menuName = "VR/Hand Pose Snapshot")]
public class HandPoseSnapshot : ScriptableObject
{
    [Serializable]
    public struct HandBoneRecord
    {
        public string path;
        public string boneName;
        public Vector3 localPosition;
        public Quaternion localRotation;
        public Vector3 localEulerAngles;
        public Vector3 worldPosition;
        public Quaternion worldRotation;
        public Vector3 worldEulerAngles;
    }

    [Serializable]
    public struct HandJointRecord
    {
        public string jointId;
        public int jointIdIndex;
        public Vector3 localPosition;
        public Quaternion localRotation;
        public Vector3 localEulerAngles;
        public Vector3 worldPosition;
        public Quaternion worldRotation;
        public Vector3 worldEulerAngles;
        public float radius;
        public bool hasRadius;
    }

    public string poseName;
    public string handSide;
    public string sourceHandName;
    public string capturedTimeUtc;
    public Vector3 rootWorldPosition;
    public Quaternion rootWorldRotation;
    public Vector3 rootWorldEulerAngles;
    public List<HandBoneRecord> bones = new();
    public List<HandJointRecord> joints = new();

    [Serializable]
    public class JsonPayload
    {
        public string poseName;
        public string handSide;
        public string sourceHandName;
        public string capturedTimeUtc;
        public Vector3 rootWorldPosition;
        public Quaternion rootWorldRotation;
        public Vector3 rootWorldEulerAngles;
        public HandBoneRecord[] bones;
        public HandJointRecord[] joints;
    }

    public JsonPayload ToJsonPayload()
    {
        return new JsonPayload
        {
            poseName = poseName,
            handSide = handSide,
            sourceHandName = sourceHandName,
            capturedTimeUtc = capturedTimeUtc,
            rootWorldPosition = rootWorldPosition,
            rootWorldRotation = rootWorldRotation,
            rootWorldEulerAngles = rootWorldEulerAngles,
            bones = bones.ToArray(),
            joints = joints.ToArray()
        };
    }

    public void CopyFrom(JsonPayload payload)
    {
        poseName = payload.poseName;
        handSide = payload.handSide;
        sourceHandName = payload.sourceHandName;
        capturedTimeUtc = payload.capturedTimeUtc;
        rootWorldPosition = payload.rootWorldPosition;
        rootWorldRotation = payload.rootWorldRotation;
        rootWorldEulerAngles = payload.rootWorldEulerAngles;
        bones = payload.bones != null ? new List<HandBoneRecord>(payload.bones) : new List<HandBoneRecord>();
        joints = payload.joints != null ? new List<HandJointRecord>(payload.joints) : new List<HandJointRecord>();
    }

    public static HandPoseSnapshot CreateFromPayload(JsonPayload payload)
    {
        var snapshot = CreateInstance<HandPoseSnapshot>();
        snapshot.CopyFrom(payload);
        return snapshot;
    }

    public string ToJson(bool prettyPrint = true)
    {
        return JsonUtility.ToJson(ToJsonPayload(), prettyPrint);
    }

    public static JsonPayload JsonPayloadFromString(string json)
    {
        return JsonUtility.FromJson<JsonPayload>(json);
    }
}
