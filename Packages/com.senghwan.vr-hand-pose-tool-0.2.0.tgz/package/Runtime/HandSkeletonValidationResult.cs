using System.Collections.Generic;

namespace VRHandPoseTool
{
    /// <summary>
    /// HandSkeletonCatalog가 Step_05 LeftHand 스켈레톤을 검사한 결과를 담습니다.
    /// Editor Probe 창과 이후 캡처 단계에서 Record 버튼 활성화 여부를 판단할 때 사용합니다.
    /// </summary>
    public class HandSkeletonValidationResult
    {
        /// <summary>
        /// 필수 본 26개·계층·중복 검사를 모두 통과했으면 true입니다.
        /// </summary>
        public bool isValid;

        /// <summary>
        /// LeftHand.fbx / Step_05 기준 필수 L_* 본 개수(26)입니다.
        /// </summary>
        public int expectedBoneCount;

        /// <summary>
        /// handRoot 아래에서 찾은 필수 본 개수입니다.
        /// </summary>
        public int foundBoneCount;

        /// <summary>
        /// 필수 목록에 있으나 handRoot 아래에서 찾지 못한 본 이름입니다.
        /// </summary>
        public List<string> missingBones = new();

        /// <summary>
        /// 같은 boneName을 가진 Transform이 두 개 이상 발견된 경우 그 이름입니다.
        /// </summary>
        public List<string> duplicateBones = new();

        /// <summary>
        /// L_로 시작하지만 필수 26본 목록에 없는 Transform 이름입니다.
        /// </summary>
        public List<string> unexpectedBones = new();

        /// <summary>
        /// 필수 본은 존재하지만 expected parent와 실제 parent.name이 다른 경우 설명 문자열입니다.
        /// </summary>
        public List<string> hierarchyMismatches = new();

        /// <summary>
        /// 오류는 아니지만 사용자에게 알릴 경고(예: SkinnedMeshRenderer 없음)입니다.
        /// </summary>
        public List<string> warnings = new();

        /// <summary>
        /// Probe UI에 표시할 한 줄 요약입니다.
        /// </summary>
        public string summary = string.Empty;
    }
}
