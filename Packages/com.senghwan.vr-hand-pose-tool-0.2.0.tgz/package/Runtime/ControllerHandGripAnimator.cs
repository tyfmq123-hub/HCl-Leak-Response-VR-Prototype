using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

namespace VRHandPoseTool
{
    /// <summary>
    /// 컨트롤러 Grip 입력(0~1)을 Animator Float 파라미터에 전달해 Open/Grab 블렌딩을 구동합니다.
    /// Input Action 활성화는 씬의 InputActionManager에 위임합니다.
    /// </summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(100)]
    public class ControllerHandGripAnimator : MonoBehaviour
    {
        [SerializeField]
        Animator handAnimator;

        [SerializeField]
        InputActionProperty gripAction;

        [SerializeField]
        string gripParameterName = "Grip";

        [SerializeField]
        bool useSmoothing = true;

        [SerializeField]
        float smoothingSpeed = 12f;

        [SerializeField]
        bool enableGripDebugLog;

        const float GripDebugLogDelta = 0.05f;

        int gripParameterHash;
        float currentGrip;
        bool configurationValid;
        bool errorLogged;
        bool setFloatBlockedLogged;
        bool actionDisabledWarned;
        bool startupDiagnosticLogged;
        float lastLoggedGrip = -1f;

        void OnEnable()
        {
            errorLogged = false;
            setFloatBlockedLogged = false;
            actionDisabledWarned = false;
            lastLoggedGrip = -1f;
            configurationValid = TryConfigure();

            if (enableGripDebugLog && !startupDiagnosticLogged)
                LogStartupDiagnostic();
        }

        void OnDisable()
        {
            configurationValid = false;
        }

        void Update()
        {
            var action = gripAction.action;
            if (action == null)
                return;

            if (!IsGripActionReady(action))
                return;

            if (!configurationValid)
            {
                configurationValid = TryConfigure();
                if (!configurationValid)
                    return;
            }

            if (!TryResolveHandAnimator(out var animator))
            {
                configurationValid = false;
                return;
            }

            float targetGrip;
            try
            {
                targetGrip = action.ReadValue<float>();
            }
            catch (System.InvalidOperationException)
            {
                LogErrorOnce("Grip Action에서 float 값을 읽을 수 없습니다.");
                configurationValid = false;
                return;
            }

            targetGrip = Mathf.Clamp01(targetGrip);

            if (useSmoothing)
            {
                currentGrip = Mathf.MoveTowards(
                    currentGrip,
                    targetGrip,
                    smoothingSpeed * Time.deltaTime);
            }
            else
            {
                currentGrip = targetGrip;
            }

            animator.SetFloat(gripParameterHash, currentGrip);
            MaybeLogGripDebug(action, targetGrip, animator);
        }

        bool TryConfigure()
        {
            gripParameterHash = Animator.StringToHash(gripParameterName);

            if (!TryResolveHandAnimator(out var animator))
                return false;

            if (!TryValidateGripParameter(animator, gripParameterName, out var parameterError))
            {
                LogErrorOnce(parameterError);
                return false;
            }

            var action = gripAction.action;
            if (action == null)
            {
                LogErrorOnce("Grip Input Action이 유효하지 않습니다.");
                return false;
            }

            if (action.type != InputActionType.Value
                && action.type != InputActionType.Button)
            {
                LogErrorOnce(
                    $"Grip Action 타입이 float 입력에 적합하지 않습니다 (현재: {action.type}).");
                return false;
            }

            if (!IsGripActionReady(action))
                return false;

            currentGrip = animator.GetFloat(gripParameterHash);
            setFloatBlockedLogged = false;
            return true;
        }

        bool IsGripActionReady(InputAction action)
        {
            if (action == null)
                return false;

            if (action.enabled)
                return true;

            var actionMap = action.actionMap;
            if (actionMap != null && !actionMap.enabled && actionMap.asset != null && actionMap.asset.enabled)
                actionMap.Enable();

            if (action.enabled)
                return true;

            if (!actionDisabledWarned)
            {
                actionDisabledWarned = true;
                var sideLabel = InferSideLabel(action);
                Debug.LogWarning(
                    $"[VR Grip Debug] side={sideLabel} Grip Action/Action Map이 비활성입니다. " +
                    $"actionEnabled={action.enabled} mapEnabled={(actionMap != null ? actionMap.enabled : false)} " +
                    "씬 InputActionManager가 XRI Default Input Actions를 활성화하는지 확인하세요.",
                    this);
            }

            return false;
        }

        bool TryResolveHandAnimator(out Animator animator)
        {
            animator = handAnimator;
            if (animator == null)
                animator = GetComponent<Animator>();

            if (animator == null)
            {
                LogErrorOnce("Animator가 지정되지 않았습니다.");
                return false;
            }

            if (!animator.gameObject.activeInHierarchy || !animator.isActiveAndEnabled)
            {
                LogSetFloatBlockedOnce("Animator가 비활성 상태입니다.");
                return false;
            }

            if (animator.runtimeAnimatorController == null)
            {
                LogSetFloatBlockedOnce("RuntimeAnimatorController가 연결되지 않았습니다.");
                return false;
            }

            if (!animator.isInitialized)
            {
                LogSetFloatBlockedOnce("Animator가 아직 초기화되지 않았습니다.");
                return false;
            }

            if (handAnimator != animator)
                handAnimator = animator;

            return true;
        }

        void MaybeLogGripDebug(InputAction action, float targetGrip, Animator animator)
        {
            if (!enableGripDebugLog || action == null)
                return;

            if (Mathf.Abs(targetGrip - lastLoggedGrip) < GripDebugLogDelta)
                return;

            lastLoggedGrip = targetGrip;
            var sideLabel = InferSideLabel(action);
            var deviceLabel = GetActiveControlDeviceLabel(action);
            var animatorGrip = animator.GetFloat(gripParameterHash);
            Debug.Log(
                $"[VR Grip Debug] side={sideLabel} actionEnabled={action.enabled} " +
                $"mapEnabled={(action.actionMap != null && action.actionMap.enabled)} " +
                $"value={targetGrip:F2} device={deviceLabel} animatorGrip={animatorGrip:F2}",
                this);
        }

        void LogStartupDiagnostic()
        {
            startupDiagnosticLogged = true;
            var action = gripAction.action;
            if (action == null)
            {
                Debug.LogWarning("[VR Grip Debug] gripAction.action is null.", this);
                return;
            }

            var sb = new StringBuilder();
            sb.AppendLine("[VR Grip Debug] Startup diagnostic");
            sb.AppendLine($"  side={InferSideLabel(action)}");
            sb.AppendLine($"  asset={action.actionMap?.asset?.name ?? "(none)"}");
            sb.AppendLine($"  actionMap={action.actionMap?.name ?? "(none)"}");
            sb.AppendLine($"  action={action.name}");
            sb.AppendLine($"  actionEnabled={action.enabled}");
            sb.AppendLine($"  mapEnabled={(action.actionMap != null && action.actionMap.enabled)}");
            sb.AppendLine($"  type={action.type} expectedControlType={action.expectedControlType}");
            foreach (var binding in action.bindings)
                sb.AppendLine($"  binding={binding.path}");
            sb.AppendLine($"  animator={handAnimator?.name ?? GetComponent<Animator>()?.name ?? "(none)"}");
            sb.AppendLine($"  gripParameter={gripParameterName}");
            Debug.Log(sb.ToString().TrimEnd(), this);
        }

        static string InferSideLabel(InputAction action)
        {
            if (action == null)
                return "Unknown";

            foreach (var binding in action.bindings)
            {
                if (binding.path.Contains("{LeftHand}"))
                    return "Left";
                if (binding.path.Contains("{RightHand}"))
                    return "Right";
            }

            return "Unknown";
        }

        static string GetActiveControlDeviceLabel(InputAction action)
        {
            if (action == null)
                return "(none)";

            var activeControl = action.activeControl;
            if (activeControl != null)
                return activeControl.device.displayName;

            foreach (var control in action.controls)
            {
                if (control.IsActuated(0.01f))
                    return control.device.displayName;
            }

            return "(none)";
        }

        static bool TryValidateGripParameter(Animator animator, string parameterName, out string errorMessage)
        {
            errorMessage = null;
            var found = false;

            foreach (var parameter in animator.parameters)
            {
                if (parameter.name != parameterName)
                    continue;

                found = true;
                if (parameter.type != AnimatorControllerParameterType.Float)
                {
                    errorMessage =
                        $"'{parameterName}' 파라미터가 Float가 아닙니다 (현재: {parameter.type}).";
                    return false;
                }

                break;
            }

            if (!found)
            {
                errorMessage = $"Animator에 Float 파라미터 '{parameterName}'이 없습니다.";
                return false;
            }

            return true;
        }

        void LogErrorOnce(string message)
        {
            if (errorLogged)
                return;

            errorLogged = true;
            Debug.LogError($"[{nameof(ControllerHandGripAnimator)}] {message}", this);
        }

        void LogSetFloatBlockedOnce(string message)
        {
            if (setFloatBlockedLogged)
                return;

            setFloatBlockedLogged = true;
            Debug.LogWarning($"[{nameof(ControllerHandGripAnimator)}] {message} SetFloat skipped.", this);
        }
    }
}
