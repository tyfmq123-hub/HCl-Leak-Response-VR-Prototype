using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace VRHandPoseTool
{
    /// <summary>
    /// Grab 시 HandGrabPoseBinding에서 해당 손 HandGrabPoseRecord를 읽어 26본 Pose를 Playback Hand에 적용합니다.
    /// Playback Hand Root를 Ghost Wrist world pose에 정렬해 손 Visual을 Target에 고정합니다.
    /// Release 시 Hand Visual·Animator·ControllerHandGripAnimator를 원래 상태로 복귀시킵니다.
    /// Grab/Release 시 해당 손 방향의 Ghost Renderer를 숨기고 복구합니다.
    /// HandSideAwareGrabInteractable 또는 XRGrabInteractable과 같은 GameObject에 배치하세요.
    /// </summary>
    [AddComponentMenu("XR/Hand Grab Pose Player")]
    public class HandGrabPosePlayer : MonoBehaviour
    {
        const int MaxHierarchyDepth = 12;
        const string LeftControllerToken = "Left Controller";
        const string RightControllerToken = "Right Controller";

        HandGrabPoseBinding m_Binding;
        XRGrabInteractable m_GrabInteractable;

        // ── 진단 로그 (Inspector에서 토글, Grab 1회 후 자동 해제) ─────────────────
        [SerializeField] bool m_EnableGrabDiagnosticLog = false;

        readonly HandGrabSession m_LeftSession = new(HandSide.Left);
        readonly HandGrabSession m_RightSession = new(HandSide.Right);

        sealed class HandGrabSession
        {
            public HandSide HandSide { get; }

            public bool IsActive;
            public HandGrabPoseRecord Record;
            public Transform HandRoot;
            public IReadOnlyDictionary<string, Transform> BoneMap;

            public Transform SavedHandRootParent;
            public Vector3 SavedHandRootLocalPosition;
            public Quaternion SavedHandRootLocalRotation;
            public Vector3 SavedHandRootLocalScale;
            public Vector3 WristLocalPosition;
            public Quaternion WristLocalRotation;
            public Transform GhostWrist;
            public bool VisualAlignActive;

            public Animator SavedAnimator;
            public bool AnimatorWasEnabled;
            public ControllerHandGripAnimator SavedGripAnimator;
            public bool GripAnimatorWasEnabled;

            public Renderer[] CachedGhostRenderers;
            public bool[] CachedGhostRendererEnabled;

            public HandGrabSession(HandSide handSide)
            {
                HandSide = handSide;
            }

            public void Clear()
            {
                IsActive = false;
                Record = null;
                HandRoot = null;
                BoneMap = null;

                SavedHandRootParent = null;
                SavedHandRootLocalPosition = Vector3.zero;
                SavedHandRootLocalRotation = Quaternion.identity;
                SavedHandRootLocalScale = Vector3.one;
                WristLocalPosition = Vector3.zero;
                WristLocalRotation = Quaternion.identity;
                GhostWrist = null;
                VisualAlignActive = false;

                SavedAnimator = null;
                AnimatorWasEnabled = false;
                SavedGripAnimator = null;
                GripAnimatorWasEnabled = false;

                CachedGhostRenderers = null;
                CachedGhostRendererEnabled = null;
            }
        }

        void Awake()
        {
            m_GrabInteractable = GetComponent<XRGrabInteractable>();
            m_Binding = GetComponent<HandGrabPoseBinding>();
        }

        void OnEnable()
        {
            if (m_GrabInteractable != null)
            {
                m_GrabInteractable.selectEntered.AddListener(OnSelectEntered);
                m_GrabInteractable.selectExited.AddListener(OnSelectExited);
            }
        }

        void OnDisable()
        {
            if (m_GrabInteractable != null)
            {
                m_GrabInteractable.selectEntered.RemoveListener(OnSelectEntered);
                m_GrabInteractable.selectExited.RemoveListener(OnSelectExited);
            }

            if (IsAnyHandActive())
                RestoreAllHandSessions();
        }

        void OnDestroy()
        {
            // OnDisable 이후 session이 이미 정리됐으면 no-op.
            // OnDisable이 예외로 중단된 경우를 위해 이중 안전망으로 남깁니다.
            if (IsAnyHandActive())
                RestoreAllHandSessions();
        }

        void LateUpdate()
        {
            UpdateHandSession(m_LeftSession);
            UpdateHandSession(m_RightSession);
        }

        static void UpdateHandSession(HandGrabSession session)
        {
            if (!session.IsActive || session.BoneMap == null || session.Record == null)
                return;

            ApplyBonesToHand(session.BoneMap, session.Record);

            if (!session.VisualAlignActive)
                return;

            if (session.GhostWrist == null)
            {
                session.VisualAlignActive = false;
                return;
            }

            AlignHandRootToGhostWrist(
                session.HandRoot,
                session.GhostWrist,
                session.WristLocalPosition,
                session.WristLocalRotation);
        }

        void OnSelectEntered(SelectEnterEventArgs args)
        {
            if (m_Binding == null)
            {
                m_Binding = GetComponent<HandGrabPoseBinding>();
                if (m_Binding == null)
                    return;
            }

            if (!TryResolveHandSide(args.interactorObject, out var handSide))
                return;

            var session = GetSession(handSide);
            if (session.IsActive)
                return;

            if (!m_Binding.TryGetRecord(handSide, out var record) || record == null || !record.HasBoneData)
                return;

            var handRoot = FindPlaybackHand(args.interactorObject, handSide);
            if (handRoot == null)
            {
                Debug.LogWarning(
                    $"[HandGrabPosePlayer] {handSide} Playback Hand를 찾지 못했습니다. 일반 Grab을 사용합니다.",
                    this);
                return;
            }

            if (!HandSkeletonCatalog.TryBuildBoneMap(handRoot, handSide, out var boneMap, out var mapError))
            {
                Debug.LogWarning(
                    $"[HandGrabPosePlayer] Bone map 생성 실패: {mapError}. 일반 Grab을 사용합니다.",
                    this);
                return;
            }

            if (!TryFindControllerWrist(handRoot, handSide, boneMap, out var controllerWrist))
            {
                Debug.LogWarning(
                    $"[HandGrabPosePlayer] {handSide} Controller Wrist({GetWristBoneName(handSide)})를 찾지 못했습니다. " +
                    "손가락 Pose만 적용합니다.",
                    this);
            }

            SaveHandVisualGrabState(session, handRoot, controllerWrist);

            var ghostWristFound = TryFindGhostWrist(handSide, out var ghostWrist);
            session.GhostWrist = ghostWrist;
            session.VisualAlignActive = ghostWristFound && controllerWrist != null;

            if (!ghostWristFound)
            {
                Debug.LogWarning(
                    $"[HandGrabPosePlayer] {handSide} Ghost Wrist를 찾지 못했습니다. " +
                    "손 Visual 정렬 없이 손가락 Pose만 적용합니다.",
                    this);
            }

            session.SavedGripAnimator = FindGripAnimator(handRoot);
            if (session.SavedGripAnimator != null)
            {
                session.GripAnimatorWasEnabled = session.SavedGripAnimator.enabled;
                session.SavedGripAnimator.enabled = false;
            }

            session.SavedAnimator = FindHandAnimator(handRoot);
            if (session.SavedAnimator != null)
            {
                session.AnimatorWasEnabled = session.SavedAnimator.enabled;
                session.SavedAnimator.enabled = false;
            }

            session.Record = record;
            session.HandRoot = handRoot;
            session.BoneMap = boneMap;
            session.IsActive = true;

            if (m_EnableGrabDiagnosticLog)
            {
                LogGrabDiagnostics(args, handSide, handRoot, session);
                m_EnableGrabDiagnosticLog = false;
            }

            CacheAndHideGhostRenderers(handSide, session);

            ApplyBonesToHand(boneMap, record);

            if (session.VisualAlignActive)
            {
                AlignHandRootToGhostWrist(
                    handRoot,
                    session.GhostWrist,
                    session.WristLocalPosition,
                    session.WristLocalRotation);
            }
        }

        void OnSelectExited(SelectExitEventArgs args)
        {
            if (!TryResolveHandSide(args.interactorObject, out var handSide))
                return;

            RestoreHandSession(handSide);
        }

        void RestoreAllHandSessions()
        {
            RestoreHandSession(HandSide.Left);
            RestoreHandSession(HandSide.Right);
        }

        void RestoreHandSession(HandSide handSide)
        {
            var session = GetSession(handSide);
            if (!session.IsActive)
                return;

            RestoreHandVisualRoot(session);

            if (session.SavedAnimator != null)
            {
                session.SavedAnimator.enabled = session.AnimatorWasEnabled;
            }

            if (session.SavedGripAnimator != null)
            {
                session.SavedGripAnimator.enabled = session.GripAnimatorWasEnabled;
            }

            RestoreGhostRenderers(session);
            session.Clear();
        }

        HandGrabSession GetSession(HandSide handSide) =>
            handSide == HandSide.Left ? m_LeftSession : m_RightSession;

        bool IsAnyHandActive() =>
            m_LeftSession.IsActive || m_RightSession.IsActive;

        static void SaveHandVisualGrabState(HandGrabSession session, Transform handRoot, Transform controllerWrist)
        {
            session.SavedHandRootParent = handRoot.parent;
            session.SavedHandRootLocalPosition = handRoot.localPosition;
            session.SavedHandRootLocalRotation = handRoot.localRotation;
            session.SavedHandRootLocalScale = handRoot.localScale;

            if (controllerWrist != null)
            {
                session.WristLocalPosition = handRoot.InverseTransformPoint(controllerWrist.position);
                session.WristLocalRotation = Quaternion.Inverse(handRoot.rotation) * controllerWrist.rotation;
            }
        }

        static void RestoreHandVisualRoot(HandGrabSession session)
        {
            var handRoot = session.HandRoot;
            if (handRoot != null && handRoot.parent == session.SavedHandRootParent)
            {
                handRoot.localPosition = session.SavedHandRootLocalPosition;
                handRoot.localRotation = session.SavedHandRootLocalRotation;
                handRoot.localScale = session.SavedHandRootLocalScale;
            }
        }

        static void AlignHandRootToGhostWrist(
            Transform handRoot,
            Transform ghostWrist,
            Vector3 wristLocalPosition,
            Quaternion wristLocalRotation)
        {
            if (handRoot == null || ghostWrist == null)
                return;

            handRoot.rotation = ghostWrist.rotation * Quaternion.Inverse(wristLocalRotation);
            handRoot.position = ghostWrist.position - handRoot.rotation * wristLocalPosition;
        }

        bool TryFindGhostWrist(HandSide handSide, out Transform ghostWrist)
        {
            ghostWrist = null;

            var targetInstanceId = gameObject.GetInstanceID();
            var sideLabel = handSide.ToString();
            var wristName = GetWristBoneName(handSide);

            var allMarkers = Object.FindObjectsByType<HandGhostPreviewMarker>(FindObjectsInactive.Include);
            foreach (var marker in allMarkers)
            {
                if (marker == null)
                    continue;

                if (marker.TargetGrabObjectInstanceId != targetInstanceId)
                    continue;

                if (!string.Equals(marker.HandSide, sideLabel, System.StringComparison.Ordinal))
                    continue;

                ghostWrist = FindBoneInChildren(marker.transform, wristName);
                if (ghostWrist != null)
                    return true;
            }

            return false;
        }

        static bool TryFindControllerWrist(
            Transform handRoot,
            HandSide handSide,
            IReadOnlyDictionary<string, Transform> boneMap,
            out Transform controllerWrist)
        {
            controllerWrist = null;
            if (handRoot == null)
                return false;

            var wristName = GetWristBoneName(handSide);
            if (boneMap != null && boneMap.TryGetValue(wristName, out controllerWrist) && controllerWrist != null)
                return true;

            controllerWrist = handRoot.Find(wristName) ?? FindBoneInChildren(handRoot, wristName);
            return controllerWrist != null;
        }

        static string GetWristBoneName(HandSide handSide) =>
            handSide == HandSide.Left ? "L_Wrist" : "R_Wrist";

        // ── Ghost Renderer 가시성 관리 ───────────────────────────────────────────

        void CacheAndHideGhostRenderers(HandSide handSide, HandGrabSession session)
        {
            var handSideString = handSide.ToString(); // "Left" or "Right"

            // FindObjectsInactive.Include: Ghost GO가 비활성 부모 아래 있어도 탐색
            var allMarkers = Object.FindObjectsByType<HandGhostPreviewMarker>(FindObjectsInactive.Include);

            var rendererList = new List<Renderer>();
            var enabledList = new List<bool>();

            foreach (var marker in allMarkers)
            {
                if (marker == null)
                    continue;

                // HandGhostPreviewMarker.HandSide 문자열로 손 방향 판정 (이름 문자열 불사용)
                if (!string.Equals(marker.HandSide, handSideString, System.StringComparison.Ordinal))
                    continue;

                // Ghost 루트 및 하위 전체 Renderer 수집 (비활성 포함)
                var renderers = marker.GetComponentsInChildren<Renderer>(true);
                foreach (var r in renderers)
                {
                    if (r == null)
                        continue;

                    rendererList.Add(r);
                    enabledList.Add(r.enabled);
                    r.enabled = false;
                }
            }

            session.CachedGhostRenderers = rendererList.ToArray();
            session.CachedGhostRendererEnabled = enabledList.ToArray();
        }

        static void RestoreGhostRenderers(HandGrabSession session)
        {
            if (session.CachedGhostRenderers == null)
                return;

            for (var i = 0; i < session.CachedGhostRenderers.Length; i++)
            {
                var r = session.CachedGhostRenderers[i];
                if (r == null) // Ghost가 씬에서 삭제됐을 경우 안전 처리
                    continue;

                r.enabled = session.CachedGhostRendererEnabled[i];
            }
        }

        // ── 본 적용 ──────────────────────────────────────────────────────────────

        static void ApplyBonesToHand(IReadOnlyDictionary<string, Transform> boneMap, HandGrabPoseRecord record)
        {
            if (record == null || boneMap == null)
                return;

            foreach (var bone in record.Bones)
            {
                if (bone == null || string.IsNullOrEmpty(bone.boneName))
                    continue;

                if (!boneMap.TryGetValue(bone.boneName, out var boneTransform) || boneTransform == null)
                    continue;

                // Wrist 본(R_Wrist / L_Wrist): Record Pose 적용 제외.
                // 손 전체 위치·회전은 Ghost Wrist 정렬(HandGrabPosePlayer)이 담당합니다.
                if (IsWristBone(bone.boneName))
                    continue;

                // 손가락 본: localRotation만 적용합니다.
                // ‣ localPosition 미적용: Tracking Hand(XRHandSkeletonDriver) 계층과
                //   Controller Rig(Animator 구동) 계층의 본 offset·배치가 달라,
                //   Tracking localPosition을 그대로 복사하면 손가락 길이·축이 틀어집니다.
                // ‣ localScale 미적용: Controller Rig 원래 스케일 유지.
                boneTransform.localRotation = bone.localRotation;
            }
        }

        /// <summary>
        /// Wrist 본 여부 판정. 대상: "R_Wrist" 또는 "L_Wrist" (Ordinal 대소문자 구분).
        /// HandPoseRigUtility.ShouldSkipWristBone과 동일 의도이나, Runtime 파일 간
        /// 불필요한 크로스 폴더 의존성을 피하기 위해 인라인으로 유지합니다.
        /// </summary>
        static bool IsWristBone(string boneName)
        {
            return string.Equals(boneName, "R_Wrist", System.StringComparison.Ordinal)
                || string.Equals(boneName, "L_Wrist", System.StringComparison.Ordinal);
        }

        // ── Hand Side / Hand Root 탐색 ───────────────────────────────────────────

        static bool TryResolveHandSide(IXRInteractor interactor, out HandSide handSide)
        {
            handSide = default;
            if (interactor == null)
                return false;

            var t = (interactor as Component)?.transform;
            if (t == null)
                return false;

            var explicitSide = t.GetComponentInParent<HandInteractorSide>();
            if (explicitSide != null)
            {
                handSide = explicitSide.HandSide;
                return true;
            }

            var current = t;
            for (var i = 0; i < MaxHierarchyDepth && current != null; i++)
            {
                if (current.name == LeftControllerToken)
                {
                    handSide = HandSide.Left;
                    return true;
                }

                if (current.name == RightControllerToken)
                {
                    handSide = HandSide.Right;
                    return true;
                }

                current = current.parent;
            }

            if (t.name.StartsWith("Left_", System.StringComparison.Ordinal))
            {
                handSide = HandSide.Left;
                return true;
            }

            if (t.name.StartsWith("Right_", System.StringComparison.Ordinal))
            {
                handSide = HandSide.Right;
                return true;
            }

            return false;
        }

        static Transform FindPlaybackHand(IXRInteractor interactor, HandSide handSide)
        {
            var t = (interactor as Component)?.transform;
            if (t == null)
                return null;

            var controllerToken = handSide == HandSide.Left ? LeftControllerToken : RightControllerToken;

            // Walk up hierarchy to find controller root
            var current = t;
            Transform controllerRoot = null;
            for (var i = 0; i < MaxHierarchyDepth && current != null; i++)
            {
                if (current.name == controllerToken)
                {
                    controllerRoot = current;
                    break;
                }

                current = current.parent;
            }

            if (controllerRoot != null)
            {
                var found = SearchForHandRootUnder(controllerRoot, handSide);
                if (found != null)
                    return found;
            }

            // Broad scene fallback: find any SkinnedMeshRenderer not under a ghost
            var allSmrs = Object.FindObjectsByType<SkinnedMeshRenderer>(FindObjectsInactive.Exclude);
            foreach (var smr in allSmrs)
            {
                if (smr == null || !smr.gameObject.activeInHierarchy)
                    continue;

                if (smr.GetComponentInParent<HandGhostPreviewMarker>() != null)
                    continue;

                var candidate = FindValidHandRootAbove(smr.transform, handSide);
                if (candidate != null)
                    return candidate;
            }

            return null;
        }

        static Transform SearchForHandRootUnder(Transform root, HandSide handSide)
        {
            var smrs = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in smrs)
            {
                if (smr == null)
                    continue;

                if (smr.GetComponentInParent<HandGhostPreviewMarker>() != null)
                    continue;

                var candidate = FindValidHandRootAbove(smr.transform, handSide);
                if (candidate != null && IsDescendantOfOrSelf(candidate, root))
                    return candidate;
            }

            return null;
        }

        static Transform FindValidHandRootAbove(Transform start, HandSide handSide)
        {
            var current = start;
            for (var i = 0; i < MaxHierarchyDepth && current != null; i++)
            {
                var validation = HandSkeletonCatalog.Validate(current, handSide);
                if (validation.isValid && validation.foundBoneCount >= HandSkeletonCatalog.RequiredBoneCount)
                    return current;

                current = current.parent;
            }

            return null;
        }

        static bool IsDescendantOfOrSelf(Transform child, Transform ancestor)
        {
            var current = child;
            while (current != null)
            {
                if (current == ancestor)
                    return true;

                current = current.parent;
            }

            return false;
        }

        static Animator FindHandAnimator(Transform handRoot)
        {
            var animator = handRoot.GetComponent<Animator>();
            if (animator != null)
                return animator;

            var parent = handRoot.parent;
            for (var i = 0; i < MaxHierarchyDepth && parent != null; i++)
            {
                animator = parent.GetComponent<Animator>();
                if (animator != null)
                    return animator;

                parent = parent.parent;
            }

            return null;
        }

        static ControllerHandGripAnimator FindGripAnimator(Transform handRoot)
        {
            var grip = handRoot.GetComponent<ControllerHandGripAnimator>();
            if (grip != null)
                return grip;

            var parent = handRoot.parent;
            for (var i = 0; i < MaxHierarchyDepth && parent != null; i++)
            {
                grip = parent.GetComponent<ControllerHandGripAnimator>();
                if (grip != null)
                    return grip;

                parent = parent.parent;
            }

            return null;
        }

        // ── 진단 로그 ─────────────────────────────────────────────────────────

        void LogGrabDiagnostics(SelectEnterEventArgs args, HandSide handSide, Transform handRoot, HandGrabSession session)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("[HandGrabPosePlayer] ===== GRAB DIAGNOSTIC =====");
            sb.AppendLine($"HandSide: {handSide}");

            // --- Interactor ---
            var interactorComp = args.interactorObject as XRBaseInteractor;
            sb.AppendLine($"args.interactorObject type : {args.interactorObject?.GetType().Name}");
            sb.AppendLine($"Interactor path            : {GetTransformPath(interactorComp?.transform)}");
            sb.AppendLine($"Interactor.attachTransform : {(interactorComp != null && interactorComp.attachTransform != null ? GetTransformPath(interactorComp.attachTransform) : "null")}");

            // XRI가 실제로 사용하는 Attach
            Transform xriInteractorAttach = null;
            if (interactorComp != null)
            {
                xriInteractorAttach = interactorComp.GetAttachTransform(m_GrabInteractable);
                sb.AppendLine($"GetAttachTransform(interactable): {GetTransformPath(xriInteractorAttach)}");
                sb.AppendLine($"  world pos : {xriInteractorAttach?.position.ToString("F4")}");
                sb.AppendLine($"  world rot : {xriInteractorAttach?.rotation.eulerAngles.ToString("F2")}");
            }

            // --- Object (Rifle) ---
            var rifleT = m_GrabInteractable != null ? m_GrabInteractable.transform : null;
            sb.AppendLine($"Rifle path     : {GetTransformPath(rifleT)}");
            sb.AppendLine($"  world pos    : {rifleT?.position.ToString("F4")}");
            sb.AppendLine($"  world rot    : {rifleT?.rotation.eulerAngles.ToString("F2")}");

            // --- Object Attach (from Binding) ---
            Transform objectAttach = m_Binding?.GetAttachTransform(handSide);
            sb.AppendLine($"Object Attach  : {GetTransformPath(objectAttach)}");
            if (objectAttach != null)
            {
                sb.AppendLine($"  local pos    : {objectAttach.localPosition.ToString("F4")}");
                sb.AppendLine($"  local rot    : {objectAttach.localRotation.eulerAngles.ToString("F2")}");
                sb.AppendLine($"  world pos    : {objectAttach.position.ToString("F4")}");
                sb.AppendLine($"  world rot    : {objectAttach.rotation.eulerAngles.ToString("F2")}");
            }

            // Interactor → ObjectAttach 거리
            if (xriInteractorAttach != null && objectAttach != null)
                sb.AppendLine($"Interactor <-> ObjectAttach dist: {Vector3.Distance(xriInteractorAttach.position, objectAttach.position):F4}m");

            // --- Controller Hand Root ---
            sb.AppendLine($"Controller HandRoot: {GetTransformPath(handRoot)}");
            sb.AppendLine($"  world pos    : {handRoot?.position.ToString("F4")}");
            sb.AppendLine($"  world rot    : {handRoot?.rotation.eulerAngles.ToString("F2")}");

            // --- Controller Wrist ---
            var wristName = GetWristBoneName(handSide);
            Transform wristBone = null;
            if (handRoot != null)
                wristBone = handRoot.Find(wristName)
                    ?? FindBoneInChildren(handRoot, wristName);
            sb.AppendLine($"Controller Wrist ({wristName}): {GetTransformPath(wristBone)}");
            if (wristBone != null)
            {
                sb.AppendLine($"  world pos    : {wristBone.position.ToString("F4")}");
                sb.AppendLine($"  world rot    : {wristBone.rotation.eulerAngles.ToString("F2")}");
                if (xriInteractorAttach != null)
                    sb.AppendLine($"  Interactor<->Wrist offset: {(wristBone.position - xriInteractorAttach.position).ToString("F4")}");
            }

            // --- Ghost ---
            var sideStr = handSide.ToString();
            var allMarkers = Object.FindObjectsByType<HandGhostPreviewMarker>(FindObjectsInactive.Include);
            foreach (var marker in allMarkers)
            {
                if (marker == null) continue;
                if (!string.Equals(marker.HandSide, sideStr, System.StringComparison.Ordinal)) continue;

                sb.AppendLine($"Ghost marker   : {GetTransformPath(marker.transform)}");
                sb.AppendLine($"  world pos    : {marker.transform.position.ToString("F4")}");

                // Ghost Wrist: 마커 하위에서 Wrist 본 이름으로 탐색
                var ghostWrist = FindBoneInChildren(marker.transform, wristName);
                if (ghostWrist != null)
                {
                    sb.AppendLine($"Ghost Wrist ({wristName}): {GetTransformPath(ghostWrist)}");
                    sb.AppendLine($"  world pos    : {ghostWrist.position.ToString("F4")}");
                    if (wristBone != null)
                    {
                        sb.AppendLine($"  CtrlWrist<->GhostWrist pos dist : {Vector3.Distance(wristBone.position, ghostWrist.position):F4}m");
                        sb.AppendLine($"  CtrlWrist<->GhostWrist rot diff : {Quaternion.Angle(wristBone.rotation, ghostWrist.rotation):F2}°");
                    }
                }
                break;
            }

            // --- Finger bone sample (Index_Proximal) ---
            var indexName = handSide == HandSide.Right ? "R_Index1" : "L_Index1";
            if (session.BoneMap != null && session.Record != null
                && session.BoneMap.TryGetValue(indexName, out var idxT) && idxT != null)
            {
                var recordBone = System.Linq.Enumerable.FirstOrDefault(
                    session.Record.Bones, b => b?.boneName == indexName);
                if (recordBone != null)
                {
                    sb.AppendLine($"IndexProximal ({indexName}) - Controller localRot: {idxT.localRotation.eulerAngles:F2}");
                    sb.AppendLine($"IndexProximal ({indexName}) - Record   localRot  : {recordBone.localRotation.eulerAngles:F2}");
                }
            }

            sb.AppendLine("[HandGrabPosePlayer] ===========================");
            Debug.Log(sb.ToString(), this);
        }

        static string GetTransformPath(Transform t)
        {
            if (t == null) return "null";
            var parts = new System.Collections.Generic.List<string>();
            var cur = t;
            while (cur != null) { parts.Insert(0, cur.name); cur = cur.parent; }
            return string.Join("/", parts);
        }

        static Transform FindBoneInChildren(Transform root, string boneName)
        {
            if (root == null) return null;
            for (var i = 0; i < root.childCount; i++)
            {
                var child = root.GetChild(i);
                if (child.name == boneName) return child;
                var found = FindBoneInChildren(child, boneName);
                if (found != null) return found;
            }
            return null;
        }
    }
}
