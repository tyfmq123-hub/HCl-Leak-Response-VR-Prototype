using System.Collections.Generic;
using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// HandPoseCaptureService가 Play 중 포즈를 읽은 결과를 담습니다.
    /// 성공 시 bones/joints가 채워지고, 실패 시 errors에 구체적 사유가 들어갑니다.
    /// </summary>
    public class HandPoseCaptureResult
    {
        public bool success;
        public string message;

        public List<string> errors = new();
        public List<string> warnings = new();

        public string sourceHandName;
        public string targetName;

        public List<HandBonePoseData> bones = new();
        public List<HandJointTrackingData> joints = new();

        public Vector3 rootWorldPosition;
        public Quaternion rootWorldRotation;

        public bool hasTargetRelativePose;
        public Vector3 targetRelativePosition;
        public Quaternion targetRelativeRotation;

        public int validJointPoseCount;
    }
}
