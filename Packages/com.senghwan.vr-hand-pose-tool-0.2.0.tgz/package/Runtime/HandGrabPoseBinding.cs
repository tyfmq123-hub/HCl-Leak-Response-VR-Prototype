using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace VRHandPoseTool
{
    /// <summary>
    /// Grab Target에 Left/Right Grab Pose Record와 손별 Attach Transform을 연결합니다.
    /// Target Root는 이 컴포넌트와 XRGrabInteractable이 붙은 GameObject입니다.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("VR Hand Pose Tool/Hand Grab Pose Binding")]
    public sealed class HandGrabPoseBinding : MonoBehaviour
    {
        public const string AttachLeftObjectName = "VRHandPoseTool_Attach_Left";
        public const string AttachRightObjectName = "VRHandPoseTool_Attach_Right";

        [SerializeField]
        HandGrabPoseRecord m_LeftRecord;

        [SerializeField]
        HandGrabPoseRecord m_RightRecord;

        [SerializeField]
        Transform m_AttachLeft;

        [SerializeField]
        Transform m_AttachRight;

        // Controller Wrist Offset 보정 적용 여부 (Editor Pending Apply 시 설정)
        [SerializeField]
        bool m_WristCorrectionAppliedLeft;

        [SerializeField]
        bool m_WristCorrectionAppliedRight;

        XRGrabInteractable m_CachedGrabInteractable;

        public HandGrabPoseRecord LeftRecord => m_LeftRecord;
        public HandGrabPoseRecord RightRecord => m_RightRecord;
        public Transform AttachLeft => m_AttachLeft;
        public Transform AttachRight => m_AttachRight;

        /// <summary>
        /// Controller Wrist Offset 보정이 실제로 적용된 Attach인지 여부.
        /// false이면 Tracking Wrist 기준 임시 Attach 상태입니다.
        /// </summary>
        public bool IsWristCorrectionApplied(HandSide handSide) =>
            handSide == HandSide.Left ? m_WristCorrectionAppliedLeft : m_WristCorrectionAppliedRight;

        public void SetWristCorrectionApplied(HandSide handSide, bool value)
        {
            if (handSide == HandSide.Left) m_WristCorrectionAppliedLeft = value;
            else m_WristCorrectionAppliedRight = value;
        }

        public struct SetBindingResult
        {
            public bool success;
            public string errorMessage;

            public static SetBindingResult Succeeded() => new() { success = true };

            public static SetBindingResult Failed(string message) =>
                new() { success = false, errorMessage = message };
        }

        public static string GetAttachObjectName(HandSide handSide) =>
            handSide == HandSide.Left ? AttachLeftObjectName : AttachRightObjectName;

        public XRGrabInteractable GrabInteractable => ResolveGrabInteractable();

        void Awake()
        {
            CacheGrabInteractable();
        }

        void OnValidate()
        {
            WarnIfRecordSideMismatch(m_LeftRecord, HandSide.Left, nameof(m_LeftRecord));
            WarnIfRecordSideMismatch(m_RightRecord, HandSide.Right, nameof(m_RightRecord));
        }

        public HandGrabPoseRecord GetRecord(HandSide handSide)
        {
            return TryGetRecord(handSide, out var record) ? record : null;
        }

        public Transform GetAttachTransform(HandSide handSide)
        {
            return TryGetAttachTransform(handSide, out var attach) ? attach : null;
        }

        public bool TryGetRecord(HandSide handSide, out HandGrabPoseRecord record)
        {
            record = handSide == HandSide.Left ? m_LeftRecord : m_RightRecord;
            if (record == null)
                return false;

            if (!record.IsHandSideValid || !record.MatchesHandSide(handSide))
                return false;

            return true;
        }

        public bool TryGetAttachTransform(HandSide handSide, out Transform attach)
        {
            attach = handSide == HandSide.Left ? m_AttachLeft : m_AttachRight;
            return attach != null;
        }

        public bool HasRecordSideMismatch(HandSide handSide)
        {
            var record = handSide == HandSide.Left ? m_LeftRecord : m_RightRecord;
            return record != null && !record.MatchesHandSide(handSide);
        }

        public string DescribeRecordIssue(HandSide handSide)
        {
            var record = handSide == HandSide.Left ? m_LeftRecord : m_RightRecord;
            if (record == null)
                return $"{handSide} record is not assigned.";

            if (!record.IsHandSideValid)
                return $"{handSide} record has invalid hand side.";

            if (!record.MatchesHandSide(handSide))
                return $"{handSide} slot references record with handSide={record.HandSide}.";

            return null;
        }

        public string DescribeAttachIssue(HandSide handSide)
        {
            var attach = handSide == HandSide.Left ? m_AttachLeft : m_AttachRight;
            return attach == null ? $"{handSide} attach transform is not assigned." : null;
        }

        /// <summary>
        /// 지정 HandSide 슬롯에 Record와 Attach Transform을 연결합니다. 반대 손 슬롯은 변경하지 않습니다.
        /// </summary>
        public SetBindingResult SetBinding(
            HandSide handSide,
            HandGrabPoseRecord record,
            Transform attachTransform)
        {
            if (handSide != HandSide.Left && handSide != HandSide.Right)
                return SetBindingResult.Failed($"Invalid handSide: {handSide}.");

            if (record != null)
            {
                if (!record.IsHandSideValid)
                    return SetBindingResult.Failed("Record hand side is invalid.");

                if (!record.MatchesHandSide(handSide))
                {
                    return SetBindingResult.Failed(
                        $"Record '{record.name}' handSide={record.HandSide} does not match slot {handSide}.");
                }
            }

            if (attachTransform != null && attachTransform.parent != transform)
            {
                return SetBindingResult.Failed(
                    "Attach transform must be a direct child of the HandGrabPoseBinding GameObject.");
            }

            var existingRecord = handSide == HandSide.Left ? m_LeftRecord : m_RightRecord;
            var existingAttach = handSide == HandSide.Left ? m_AttachLeft : m_AttachRight;
            if (existingRecord == record && existingAttach == attachTransform)
                return SetBindingResult.Succeeded();

            if (handSide == HandSide.Left)
            {
                m_LeftRecord = record;
                m_AttachLeft = attachTransform;
            }
            else
            {
                m_RightRecord = record;
                m_AttachRight = attachTransform;
            }

            return SetBindingResult.Succeeded();
        }

        void CacheGrabInteractable()
        {
            if (m_CachedGrabInteractable == null)
                m_CachedGrabInteractable = GetComponent<XRGrabInteractable>();
        }

        XRGrabInteractable ResolveGrabInteractable()
        {
            if (m_CachedGrabInteractable == null)
                CacheGrabInteractable();

            return m_CachedGrabInteractable;
        }

        static void WarnIfRecordSideMismatch(
            HandGrabPoseRecord record,
            HandSide expectedSide,
            string fieldName)
        {
            if (record == null || record.MatchesHandSide(expectedSide))
                return;

            Debug.LogWarning(
                $"[HandGrabPoseBinding] {fieldName} expects {expectedSide} but references " +
                $"record '{record.name}' with handSide={record.HandSide}.",
                record);
        }
    }
}
