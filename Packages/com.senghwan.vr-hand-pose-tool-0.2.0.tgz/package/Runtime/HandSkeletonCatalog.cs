using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// Left/Right 손 L_* / R_* 본 26개를 수집·검증합니다.
    /// </summary>
    public static class HandSkeletonCatalog
    {
        public const int RequiredBoneCount = 26;
        public const string ParentIsHandRoot = null;

        static readonly RequiredBoneDefinition[] s_RequiredLeftHandBones =
        {
            new("L_Wrist", ParentIsHandRoot),
            new("L_Palm", "L_Wrist"),
            new("L_ThumbMetacarpal", "L_Wrist"),
            new("L_ThumbProximal", "L_ThumbMetacarpal"),
            new("L_ThumbDistal", "L_ThumbProximal"),
            new("L_ThumbTip", "L_ThumbDistal"),
            new("L_IndexMetacarpal", "L_Wrist"),
            new("L_IndexProximal", "L_IndexMetacarpal"),
            new("L_IndexIntermediate", "L_IndexProximal"),
            new("L_IndexDistal", "L_IndexIntermediate"),
            new("L_IndexTip", "L_IndexDistal"),
            new("L_MiddleMetacarpal", "L_Wrist"),
            new("L_MiddleProximal", "L_MiddleMetacarpal"),
            new("L_MiddleIntermediate", "L_MiddleProximal"),
            new("L_MiddleDistal", "L_MiddleIntermediate"),
            new("L_MiddleTip", "L_MiddleDistal"),
            new("L_RingMetacarpal", "L_Wrist"),
            new("L_RingProximal", "L_RingMetacarpal"),
            new("L_RingIntermediate", "L_RingProximal"),
            new("L_RingDistal", "L_RingIntermediate"),
            new("L_RingTip", "L_RingDistal"),
            new("L_LittleMetacarpal", "L_Wrist"),
            new("L_LittleProximal", "L_LittleMetacarpal"),
            new("L_LittleIntermediate", "L_LittleProximal"),
            new("L_LittleDistal", "L_LittleIntermediate"),
            new("L_LittleTip", "L_LittleDistal"),
        };

        static readonly RequiredBoneDefinition[] s_RequiredRightHandBones =
            s_RequiredLeftHandBones
                .Select(b => new RequiredBoneDefinition(
                    b.boneName.Replace("L_", "R_", StringComparison.Ordinal),
                    b.expectedParentBoneName?.Replace("L_", "R_", StringComparison.Ordinal)))
                .ToArray();

        static readonly string[] s_LeftFingerAnimationBoneNames =
        {
            "L_ThumbMetacarpal", "L_ThumbProximal", "L_ThumbDistal", "L_ThumbTip",
            "L_IndexMetacarpal", "L_IndexProximal", "L_IndexIntermediate", "L_IndexDistal", "L_IndexTip",
            "L_MiddleMetacarpal", "L_MiddleProximal", "L_MiddleIntermediate", "L_MiddleDistal", "L_MiddleTip",
            "L_RingMetacarpal", "L_RingProximal", "L_RingIntermediate", "L_RingDistal", "L_RingTip",
            "L_LittleMetacarpal", "L_LittleProximal", "L_LittleIntermediate", "L_LittleDistal", "L_LittleTip",
        };

        static readonly string[] s_RightFingerAnimationBoneNames =
            s_LeftFingerAnimationBoneNames
                .Select(name => name.Replace("L_", "R_", StringComparison.Ordinal))
                .ToArray();

        readonly struct RequiredBoneDefinition
        {
            internal readonly string boneName;
            internal readonly string expectedParentBoneName;

            internal RequiredBoneDefinition(string boneName, string expectedParentBoneName)
            {
                this.boneName = boneName;
                this.expectedParentBoneName = expectedParentBoneName;
            }
        }

        public static IReadOnlyList<string> GetRequiredLeftHandBoneNames()
        {
            return GetRequiredBoneNames(HandSide.Left);
        }

        public static IReadOnlyList<(string boneName, string expectedParentBoneName)> GetRequiredLeftHandHierarchy()
        {
            return GetRequiredHierarchy(HandSide.Left);
        }

        public static IReadOnlyList<string> GetRequiredBoneNames(HandSide handSide)
        {
            return GetRequiredDefinitions(handSide).Select(b => b.boneName).ToArray();
        }

        public static IReadOnlyList<(string boneName, string expectedParentBoneName)> GetRequiredHierarchy(
            HandSide handSide)
        {
            return GetRequiredDefinitions(handSide)
                .Select(b => (b.boneName, b.expectedParentBoneName))
                .ToArray();
        }

        public static IReadOnlyList<string> GetFingerAnimationBoneNames()
        {
            return GetFingerAnimationBoneNames(HandSide.Left);
        }

        public static IReadOnlyList<string> GetFingerAnimationBoneNames(HandSide handSide)
        {
            return handSide == HandSide.Left
                ? s_LeftFingerAnimationBoneNames
                : s_RightFingerAnimationBoneNames;
        }

        public static bool TryBuildBoneMap(
            Transform handRoot,
            out IReadOnlyDictionary<string, Transform> boneMap,
            out string errorMessage)
        {
            return TryBuildBoneMap(handRoot, HandSide.Left, out boneMap, out errorMessage);
        }

        public static bool TryBuildBoneMap(
            Transform handRoot,
            HandSide handSide,
            out IReadOnlyDictionary<string, Transform> boneMap,
            out string errorMessage)
        {
            boneMap = null;
            errorMessage = null;

            if (handRoot == null)
            {
                errorMessage = "handRoot가 null입니다.";
                return false;
            }

            var requiredNames = new HashSet<string>(
                GetRequiredBoneNames(handSide),
                StringComparer.Ordinal);
            var map = new Dictionary<string, Transform>();
            foreach (var transform in handRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == handRoot || !IsHandBoneName(transform.name, handSide))
                    continue;

                if (!requiredNames.Contains(transform.name))
                    continue;

                map[transform.name] = transform;
            }

            boneMap = map;
            return true;
        }

        public static HandSkeletonValidationResult Validate(Transform handRoot)
        {
            return Validate(handRoot, HandSide.Left);
        }

        public static HandSkeletonValidationResult Validate(Transform handRoot, HandSide handSide)
        {
            var result = new HandSkeletonValidationResult
            {
                expectedBoneCount = RequiredBoneCount,
                foundBoneCount = 0,
                isValid = false,
            };

            var requiredDefinitions = GetRequiredDefinitions(handSide);
            var requiredNameSet = new HashSet<string>(
                requiredDefinitions.Select(b => b.boneName),
                StringComparer.Ordinal);
            var oppositePrefix = handSide == HandSide.Left ? "R_" : "L_";

            if (handRoot == null)
            {
                result.summary = "Tracking Hand Root가 지정되지 않았습니다.";
                result.missingBones.AddRange(GetRequiredBoneNames(handSide));
                return result;
            }

            var bonesByName = new Dictionary<string, List<Transform>>();
            var unexpected = new List<string>();
            var oppositeBones = new List<string>();

            foreach (var transform in handRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == handRoot)
                    continue;

                if (transform.name.StartsWith(oppositePrefix, StringComparison.Ordinal))
                {
                    oppositeBones.Add(transform.name);
                    continue;
                }

                if (!IsHandBoneName(transform.name, handSide))
                    continue;

                if (!bonesByName.TryGetValue(transform.name, out var list))
                {
                    list = new List<Transform>();
                    bonesByName[transform.name] = list;
                }

                list.Add(transform);

                if (!requiredNameSet.Contains(transform.name))
                    unexpected.Add(transform.name);
            }

            if (oppositeBones.Count > 0)
            {
                result.hierarchyMismatches.Add(
                    $"반대 손 접두사 본 {oppositeBones.Count}개 감지 ({oppositePrefix}*)");
            }

            foreach (var pair in bonesByName)
            {
                if (pair.Value.Count > 1)
                    result.duplicateBones.Add(pair.Key);
            }

            result.unexpectedBones.AddRange(unexpected.Distinct().OrderBy(n => n));

            foreach (var required in requiredDefinitions)
            {
                if (!bonesByName.TryGetValue(required.boneName, out var transforms) || transforms.Count == 0)
                {
                    result.missingBones.Add(required.boneName);
                    continue;
                }

                if (transforms.Count > 1)
                    continue;

                var boneTransform = transforms[0];
                var actualParent = boneTransform.parent;
                if (actualParent == null)
                {
                    result.hierarchyMismatches.Add(
                        $"{required.boneName}: 부모 Transform이 null입니다.");
                    continue;
                }

                if (required.expectedParentBoneName == ParentIsHandRoot)
                {
                    if (actualParent != handRoot)
                    {
                        result.hierarchyMismatches.Add(
                            $"{required.boneName}: 부모가 '{handRoot.name}'(손 루트)여야 하는데 '{actualParent.name}'입니다.");
                    }
                }
                else if (actualParent.name != required.expectedParentBoneName)
                {
                    result.hierarchyMismatches.Add(
                        $"{required.boneName}: 부모가 '{required.expectedParentBoneName}'여야 하는데 '{actualParent.name}'입니다.");
                }
            }

            result.foundBoneCount = requiredDefinitions.Count(b =>
                bonesByName.TryGetValue(b.boneName, out var list) && list.Count == 1);

            if (handRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) == null)
            {
                result.warnings.Add("SkinnedMeshRenderer를 handRoot 하위에서 찾지 못했습니다.");
            }

            result.isValid =
                oppositeBones.Count == 0
                && result.missingBones.Count == 0
                && result.duplicateBones.Count == 0
                && result.hierarchyMismatches.Count == 0;

            result.summary = BuildSummary(result, handRoot.name, handSide);
            return result;
        }

        static RequiredBoneDefinition[] GetRequiredDefinitions(HandSide handSide)
        {
            return handSide == HandSide.Left ? s_RequiredLeftHandBones : s_RequiredRightHandBones;
        }

        static string BuildSummary(HandSkeletonValidationResult result, string handRootName, HandSide handSide)
        {
            var prefix = handSide == HandSide.Left ? "L_" : "R_";
            var sb = new StringBuilder();
            if (result.isValid)
            {
                sb.Append($"{GetSideLabel(handSide)} hand skeleton 검증 성공");
                sb.Append($" ({handRootName})");
                sb.Append($"\n{prefix}* 필수 본: {result.foundBoneCount} / {result.expectedBoneCount}");
            }
            else
            {
                sb.Append($"{GetSideLabel(handSide)} hand skeleton 검증 실패");
                sb.Append($" ({handRootName})");
                sb.Append($"\n{prefix}* 필수 본: {result.foundBoneCount} / {result.expectedBoneCount}");
                if (result.missingBones.Count > 0)
                    sb.Append($"\n누락: {result.missingBones.Count}개");
                if (result.duplicateBones.Count > 0)
                    sb.Append($"\n중복: {result.duplicateBones.Count}개");
                if (result.hierarchyMismatches.Count > 0)
                    sb.Append($"\n계층 불일치: {result.hierarchyMismatches.Count}개");
            }

            if (result.unexpectedBones.Count > 0)
                sb.Append($"\n예상 외 {prefix}*: {result.unexpectedBones.Count}개");

            return sb.ToString();
        }

        static string GetSideLabel(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left" : "Right";
        }

        static bool IsHandBoneName(string boneName, HandSide handSide)
        {
            if (string.IsNullOrEmpty(boneName))
                return false;

            var prefix = handSide == HandSide.Left ? "L_" : "R_";
            return boneName.StartsWith(prefix, StringComparison.Ordinal);
        }
    }
}
