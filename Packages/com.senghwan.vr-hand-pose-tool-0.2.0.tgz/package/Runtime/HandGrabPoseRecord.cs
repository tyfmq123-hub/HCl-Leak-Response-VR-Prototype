using System;
using System.Collections.Generic;
using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// 손별 Grab Pose 데이터입니다. Scene Object·Transform 참조를 저장하지 않습니다.
    /// </summary>
    [CreateAssetMenu(
        fileName = "HandGrabPoseRecord",
        menuName = "VR Hand Pose Tool/Hand Grab Pose Record")]
    public sealed class HandGrabPoseRecord : ScriptableObject
    {
        const float QuaternionUnitTolerance = 0.01f;

        [Header("Identity")]
        [SerializeField]
        string m_RecordId;

        [SerializeField]
        string m_PoseName;

        [SerializeField]
        HandSide m_HandSide = HandSide.Left;

        [Header("Capture Metadata")]
        [SerializeField]
        string m_CaptureSource;

        [SerializeField]
        string m_CapturedAtUtc;

        [SerializeField]
        string m_SourceHandRootName;

        [SerializeField]
        string m_TargetObjectName;

        [Header("Target-Relative Spatial (local to grab target root)")]
        [SerializeField]
        Vector3 m_HandRootLocalPosition;

        [SerializeField]
        Quaternion m_HandRootLocalRotation = Quaternion.identity;

        [SerializeField]
        Vector3 m_AttachLocalPosition;

        [SerializeField]
        Quaternion m_AttachLocalRotation = Quaternion.identity;

        [SerializeField]
        Vector3 m_InteractorAttachLocalPosition;

        [SerializeField]
        Quaternion m_InteractorAttachLocalRotation = Quaternion.identity;

        [SerializeField]
        Vector3 m_InteractorToHandRootLocalPosition;

        [SerializeField]
        Quaternion m_InteractorToHandRootLocalRotation = Quaternion.identity;

        [SerializeField]
        bool m_CapturedWhileGrabbed;

        [Header("Bones")]
        [SerializeField]
        List<HandBonePoseData> m_Bones = new();

        public string RecordId => m_RecordId;
        public string PoseName => m_PoseName;
        public HandSide HandSide => m_HandSide;
        public string CaptureSource => m_CaptureSource;
        public string CapturedAtUtc => m_CapturedAtUtc;
        public string SourceHandRootName => m_SourceHandRootName;
        public string TargetObjectName => m_TargetObjectName;

        public Vector3 HandRootLocalPosition => m_HandRootLocalPosition;
        public Quaternion HandRootLocalRotation => m_HandRootLocalRotation;
        public Vector3 AttachLocalPosition => m_AttachLocalPosition;
        public Quaternion AttachLocalRotation => m_AttachLocalRotation;
        public Vector3 InteractorAttachLocalPosition => m_InteractorAttachLocalPosition;
        public Quaternion InteractorAttachLocalRotation => m_InteractorAttachLocalRotation;
        public Vector3 InteractorToHandRootLocalPosition => m_InteractorToHandRootLocalPosition;
        public Quaternion InteractorToHandRootLocalRotation => m_InteractorToHandRootLocalRotation;
        public bool CapturedWhileGrabbed => m_CapturedWhileGrabbed;

        public IReadOnlyList<HandBonePoseData> Bones => m_Bones;

        public int BoneCount => m_Bones != null ? m_Bones.Count : 0;

        public bool HasBoneData => BoneCount > 0;

        public bool IsHandSideValid =>
            m_HandSide == HandSide.Left || m_HandSide == HandSide.Right;

        public bool MatchesHandSide(HandSide handSide) => m_HandSide == handSide;

        public bool AreSpatialRotationsValid =>
            IsUnitQuaternion(m_HandRootLocalRotation)
            && IsUnitQuaternion(m_AttachLocalRotation)
            && IsUnitQuaternion(m_InteractorAttachLocalRotation)
            && IsUnitQuaternion(m_InteractorToHandRootLocalRotation);

        public bool HasValidIdentity =>
            IsHandSideValid && HasBoneData && AreSpatialRotationsValid;

        /// <summary>
        /// Editor 캡처 서비스가 Record를 채울 때 사용하는 값 묶음입니다. Scene 참조는 포함하지 않습니다.
        /// </summary>
        public struct CaptureData
        {
            public string recordId;
            public string poseName;
            public HandSide handSide;
            public string captureSource;
            public string capturedAtUtc;
            public string sourceHandRootName;
            public string targetObjectName;
            public bool capturedWhileGrabbed;
            public Vector3 handRootLocalPosition;
            public Quaternion handRootLocalRotation;
            public Vector3 attachLocalPosition;
            public Quaternion attachLocalRotation;
            public Vector3 interactorAttachLocalPosition;
            public Quaternion interactorAttachLocalRotation;
            public Vector3 interactorToHandRootLocalPosition;
            public Quaternion interactorToHandRootLocalRotation;
            public IReadOnlyList<HandBonePoseData> bones;
        }

        /// <summary>
        /// 캡처 데이터로 Record 필드를 채웁니다. bone 목록은 깊은 복사합니다.
        /// </summary>
        public void Initialize(CaptureData data)
        {
            m_RecordId = string.IsNullOrWhiteSpace(data.recordId)
                ? Guid.NewGuid().ToString("N")
                : data.recordId.Trim();

            m_PoseName = data.poseName ?? string.Empty;
            m_HandSide = data.handSide;
            m_CaptureSource = data.captureSource ?? string.Empty;
            m_CapturedAtUtc = string.IsNullOrWhiteSpace(data.capturedAtUtc)
                ? DateTime.UtcNow.ToString("o")
                : data.capturedAtUtc;
            m_SourceHandRootName = data.sourceHandRootName ?? string.Empty;
            m_TargetObjectName = data.targetObjectName ?? string.Empty;
            m_CapturedWhileGrabbed = data.capturedWhileGrabbed;

            m_HandRootLocalPosition = SanitizeVector3(data.handRootLocalPosition);
            m_HandRootLocalRotation = SanitizeQuaternion(data.handRootLocalRotation);
            m_AttachLocalPosition = SanitizeVector3(data.attachLocalPosition);
            m_AttachLocalRotation = SanitizeQuaternion(data.attachLocalRotation);
            m_InteractorAttachLocalPosition = SanitizeVector3(data.interactorAttachLocalPosition);
            m_InteractorAttachLocalRotation = SanitizeQuaternion(data.interactorAttachLocalRotation);
            m_InteractorToHandRootLocalPosition = SanitizeVector3(data.interactorToHandRootLocalPosition);
            m_InteractorToHandRootLocalRotation = SanitizeQuaternion(data.interactorToHandRootLocalRotation);

            m_Bones = CloneBoneList(data.bones);
        }

        static Vector3 SanitizeVector3(Vector3 value)
        {
            if (float.IsNaN(value.x) || float.IsNaN(value.y) || float.IsNaN(value.z)
                || float.IsInfinity(value.x) || float.IsInfinity(value.y) || float.IsInfinity(value.z))
            {
                return Vector3.zero;
            }

            return value;
        }

        static Quaternion SanitizeQuaternion(Quaternion value)
        {
            if (float.IsNaN(value.x) || float.IsNaN(value.y) || float.IsNaN(value.z) || float.IsNaN(value.w)
                || float.IsInfinity(value.x) || float.IsInfinity(value.y) || float.IsInfinity(value.z)
                || float.IsInfinity(value.w))
            {
                return Quaternion.identity;
            }

            if (value == default)
                return Quaternion.identity;

            var magnitude = value.x * value.x + value.y * value.y + value.z * value.z + value.w * value.w;
            if (magnitude <= 0.000001f)
                return Quaternion.identity;

            return Quaternion.Normalize(value);
        }

        static List<HandBonePoseData> CloneBoneList(IReadOnlyList<HandBonePoseData> source)
        {
            var clone = new List<HandBonePoseData>();
            if (source == null)
                return clone;

            foreach (var bone in source)
            {
                if (bone == null)
                    continue;

                clone.Add(new HandBonePoseData
                {
                    boneName = bone.boneName,
                    parentBoneName = bone.parentBoneName,
                    localPosition = SanitizeVector3(bone.localPosition),
                    localRotation = SanitizeQuaternion(bone.localRotation),
                    localScale = SanitizeVector3(bone.localScale),
                });
            }

            return clone;
        }

        static bool IsUnitQuaternion(Quaternion rotation)
        {
            if (rotation == default)
                return false;

            var magnitude = rotation.x * rotation.x
                + rotation.y * rotation.y
                + rotation.z * rotation.z
                + rotation.w * rotation.w;

            return Mathf.Abs(magnitude - 1f) <= QuaternionUnitTolerance;
        }
    }
}
