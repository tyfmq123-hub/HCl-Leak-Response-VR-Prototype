using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace VRHandPoseTool
{
    /// <summary>
    /// HandGrabPoseBinding의 손별 Attach Transform을 XRI GetAttachTransform에 연결합니다.
    /// useDynamicAttach=false(에디터 기본)일 때는 손별 static attach를 반환하고,
    /// 첫 Select 시 Dynamic Attach를 활성화해 Grab 순간 Target world pose를 보존합니다.
    /// </summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("XR/Hand Side Aware Grab Interactable")]
    public class HandSideAwareGrabInteractable : XRGrabInteractable
    {
        const string LeftControllerToken = "Left Controller";
        const string RightControllerToken = "Right Controller";
        const string DynamicAttachNameToken = "Dynamic Attach";
        const float PosePreservePositionEpsilon = 0.0001f;
        const float PosePreserveRotationEpsilon = 0.05f;
        const float DiagRotationChangeEpsilon = 0.01f;

        static readonly HashSet<int> s_HandSideFallbackWarningLogged = new();

        [SerializeField]
        bool m_LogObjectGrabPosePreserve = false;

        [SerializeField]
        bool m_LogGrabSelectDiagnostics = false;

        [SerializeField]
        int m_GrabSelectDiagnosticLateUpdateFrames = 5;

        HandGrabPoseBinding m_CachedBinding;
        bool m_RouteGetAttachTransformToBindingStaticOnce;
        bool m_PreservedGrabTargetPoseValid;
        Vector3 m_PreservedGrabTargetPosition;
        Quaternion m_PreservedGrabTargetRotation;

        // ── 첫 Select 진단 세션 (임시) ───────────────────────────────────────
        bool m_DiagSessionActive;
        IXRInteractor m_DiagInteractor;
        int m_DiagGetAttachCallCount;
        int m_DiagLateUpdateFramesRemaining;
        Vector3 m_DiagInitialTargetPos;
        Quaternion m_DiagInitialTargetRot;
        Vector3 m_DiagLastSnapshotPos;
        Quaternion m_DiagLastSnapshotRot;
        bool m_DiagHasLastSnapshotPose;
        bool m_DiagReportedFirstRotationChange;
        bool m_DiagSuppressGetAttachLogging;

        HandGrabPoseBinding Binding
        {
            get
            {
                if (m_CachedBinding == null)
                    m_CachedBinding = GetComponent<HandGrabPoseBinding>();

                return m_CachedBinding;
            }
        }

        protected override void Awake()
        {
            base.Awake();
            CacheBinding();
        }

        void OnValidate()
        {
            CacheBinding();
        }

        void LateUpdate()
        {
            if (!m_DiagSessionActive || m_DiagLateUpdateFramesRemaining <= 0)
                return;

            var frameIndex = m_GrabSelectDiagnosticLateUpdateFrames - m_DiagLateUpdateFramesRemaining + 1;
            var label = frameIndex == 1
                ? "4-FirstLateUpdate"
                : $"5-LateUpdate+{frameIndex - 1}";
            LogDiagnosticSnapshot(label);

            m_DiagLateUpdateFramesRemaining--;
            if (m_DiagLateUpdateFramesRemaining <= 0)
                EndDiagnosticSession("LateUpdate frames complete");
        }

        /// <inheritdoc />
        protected override void OnSelectEntering(SelectEnterEventArgs args)
        {
            var isFirstSelect = interactorsSelecting.Count == 0;
            Vector3 worldPosBefore = default;
            Quaternion worldRotBefore = default;
            var hasPoseBefore = false;

            if (isFirstSelect)
            {
                worldPosBefore = transform.position;
                worldRotBefore = transform.rotation;
                hasPoseBefore = true;

                m_PreservedGrabTargetPoseValid = true;
                m_PreservedGrabTargetPosition = worldPosBefore;
                m_PreservedGrabTargetRotation = worldRotBefore;

                if (m_LogGrabSelectDiagnostics)
                    BeginDiagnosticSession(args.interactorObject, worldPosBefore, worldRotBefore);

                useDynamicAttach = true;
                matchAttachPosition = true;
                matchAttachRotation = true;
            }

            if (m_DiagSessionActive)
                LogDiagnosticSnapshot("1-BeforeOnSelectEntering");

            if (isFirstSelect)
                m_RouteGetAttachTransformToBindingStaticOnce = true;

            try
            {
                base.OnSelectEntering(args);
            }
            finally
            {
                m_RouteGetAttachTransformToBindingStaticOnce = false;
                m_PreservedGrabTargetPoseValid = false;
            }

            if (m_DiagSessionActive)
                LogDiagnosticSnapshot("2-AfterBaseOnSelectEntering");

            if (isFirstSelect && hasPoseBefore && m_LogObjectGrabPosePreserve)
                LogObjectGrabPosePreserve(args, worldPosBefore, worldRotBefore);
        }

        /// <inheritdoc />
        protected override void OnSelectEntered(SelectEnterEventArgs args)
        {
            base.OnSelectEntered(args);

            if (!m_DiagSessionActive)
                return;

            LogDiagnosticSnapshot("3-AfterOnSelectEntered");
            m_DiagLateUpdateFramesRemaining = Mathf.Max(1, m_GrabSelectDiagnosticLateUpdateFrames);
        }

        /// <inheritdoc />
        protected override void InitializeDynamicAttachPose(
            IXRSelectInteractor interactor,
            Transform dynamicAttachTransform)
        {
            if (m_DiagSessionActive)
            {
                LogDynamicAttachInitPhase(
                    "6-AfterWithStatic-BeforeMatch",
                    interactor,
                    dynamicAttachTransform);
            }

            base.InitializeDynamicAttachPose(interactor, dynamicAttachTransform);

            if (m_PreservedGrabTargetPoseValid)
                ApplyTransformerCompatibleDynamicAttachPose(interactor, dynamicAttachTransform);

            if (m_DiagSessionActive)
            {
                LogDynamicAttachInitPhase(
                    "7-AfterInitializeDynamicAttachPose",
                    interactor,
                    dynamicAttachTransform);
            }
        }

        /// <summary>
        /// XRSingleGrabFreeTransformer.UpdateTarget / XRGeneralGrabTransformer.OnGrab 역산:
        /// 첫 tick에서 targetRot = interactorRot * inv(inv(targetRot)*attachRot) == grab 직전 targetRot 가 되려면
        /// attach world rotation == interactor attach rotation 이어야 합니다.
        /// target-local pose는 grab 직전 target world pose 기준으로 설정합니다.
        /// </summary>
        void ApplyTransformerCompatibleDynamicAttachPose(
            IXRSelectInteractor interactor,
            Transform dynamicAttachTransform)
        {
            var interactorAttachTransform = interactor.GetAttachTransform(this);
            var interactorAttachPose = new Pose(
                interactorAttachTransform.position,
                interactorAttachTransform.rotation);

            var matchPosition = ShouldMatchAttachPosition(interactor);
            var matchRotation = ShouldMatchAttachRotation(interactor);

            if (matchPosition && matchRotation)
            {
                dynamicAttachTransform.SetPositionAndRotation(
                    interactorAttachPose.position,
                    interactorAttachPose.rotation);
            }
            else if (matchPosition)
            {
                dynamicAttachTransform.position = interactorAttachPose.position;
            }
            else if (matchRotation)
            {
                dynamicAttachTransform.rotation = interactorAttachPose.rotation;
            }

            if (dynamicAttachTransform.parent == transform)
            {
                var localPosition = transform.InverseTransformPoint(dynamicAttachTransform.position);
                var localRotation = Quaternion.Inverse(transform.rotation) * dynamicAttachTransform.rotation;
                dynamicAttachTransform.SetLocalPositionAndRotation(localPosition, localRotation);
            }
            else
            {
                dynamicAttachTransform.SetPositionAndRotation(
                    dynamicAttachTransform.position,
                    dynamicAttachTransform.rotation);
            }

            m_PreservedGrabTargetPoseValid = false;
        }

        /// <inheritdoc />
        public override Transform GetAttachTransform(IXRInteractor interactor)
        {
            Transform result;
            string route;

            if (TryConsumeBindingStaticAttachRoute(interactor, out result))
            {
                route = "override->binding static (dynamic init seed)";
            }
            else if (useDynamicAttach)
            {
                result = base.GetAttachTransform(interactor);
                route = "override->base(useDynamicAttach)";
            }
            else if (ShouldUseBaseMultiHandAttach(interactor))
            {
                result = base.GetAttachTransform(interactor);
                route = "override->base(multiHand secondary)";
            }
            else
            {
                var binding = Binding;
                var hasHandSide = TryResolveInteractorHandSide(interactor, out var handSide);
                if (binding != null
                    && hasHandSide
                    && binding.TryGetAttachTransform(handSide, out var handedAttach)
                    && handedAttach != null)
                {
                    result = handedAttach;
                    route = $"override->binding static ({handSide})";
                }
                else
                {
                    if (binding != null && interactor != null && !hasHandSide)
                        LogHandSideFallbackWarningOnce(interactor);

                    result = base.GetAttachTransform(interactor);
                    route = "override->base(fallback)";
                }
            }

            if (m_DiagSessionActive && !m_DiagSuppressGetAttachLogging)
                LogGetAttachTransformCall(interactor, result, route);

            return result;
        }

        bool TryConsumeBindingStaticAttachRoute(IXRInteractor interactor, out Transform attachTransform)
        {
            attachTransform = null;
            if (!m_RouteGetAttachTransformToBindingStaticOnce)
                return false;

            m_RouteGetAttachTransformToBindingStaticOnce = false;

            if (ShouldUseBaseMultiHandAttach(interactor))
                return false;

            var binding = Binding;
            if (binding != null
                && TryResolveInteractorHandSide(interactor, out var handSide)
                && binding.TryGetAttachTransform(handSide, out var handedAttach)
                && handedAttach != null)
            {
                attachTransform = handedAttach;
                return true;
            }

            return false;
        }

        bool ShouldUseBaseMultiHandAttach(IXRInteractor interactor)
        {
            if (interactorsSelecting.Count <= 1)
                return false;

            var isFirst = ReferenceEquals(interactor, interactorsSelecting[0]);
            if (isFirst)
                return false;

            return secondaryAttachTransform != null;
        }

        void BeginDiagnosticSession(
            IXRInteractor interactor,
            Vector3 initialPos,
            Quaternion initialRot)
        {
            m_DiagSessionActive = true;
            m_DiagInteractor = interactor;
            m_DiagGetAttachCallCount = 0;
            m_DiagLateUpdateFramesRemaining = 0;
            m_DiagInitialTargetPos = initialPos;
            m_DiagInitialTargetRot = initialRot;
            m_DiagLastSnapshotPos = initialPos;
            m_DiagLastSnapshotRot = initialRot;
            m_DiagHasLastSnapshotPose = true;
            m_DiagReportedFirstRotationChange = false;
        }

        void EndDiagnosticSession(string reason)
        {
            if (!m_DiagSessionActive)
                return;

            Debug.Log(
                $"[HandSideAwareGrabInteractable][GrabDiag] Session ended — {reason}. " +
                $"GetAttachTransform total calls={m_DiagGetAttachCallCount}",
                this);

            m_DiagSessionActive = false;
            m_DiagInteractor = null;
        }

        void LogGetAttachTransformCall(IXRInteractor interactor, Transform overrideResult, string route)
        {
            m_DiagGetAttachCallCount++;

            Transform baseResult = null;
            try
            {
                baseResult = base.GetAttachTransform(interactor);
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[HandSideAwareGrabInteractable][GrabDiag] base.GetAttachTransform failed: {ex.Message}",
                    this);
            }

            var sameAsBase = baseResult == overrideResult;

            var sb = new StringBuilder();
            sb.AppendLine(
                $"[HandSideAwareGrabInteractable][GrabDiag] GetAttachTransform call #{m_DiagGetAttachCallCount}");
            sb.AppendLine($"  Frame                    : {Time.frameCount}");
            sb.AppendLine($"  Route                    : {route}");
            sb.AppendLine($"  m_RouteBindingStaticOnce : {m_RouteGetAttachTransformToBindingStaticOnce}");
            sb.AppendLine($"  useDynamicAttach         : {useDynamicAttach}");
            sb.AppendLine($"  Override result path     : {GetTransformPath(overrideResult)}");
            sb.AppendLine($"  Override attach kind     : {ClassifyAttachTransform(overrideResult)}");
            sb.AppendLine($"  Base result path         : {GetTransformPath(baseResult)}");
            sb.AppendLine($"  Base attach kind         : {ClassifyAttachTransform(baseResult)}");
            sb.AppendLine($"  Override == Base ref     : {sameAsBase}");
            if (overrideResult != null)
            {
                sb.AppendLine($"  Override world pos       : {overrideResult.position:F6}");
                sb.AppendLine($"  Override world rot       : {overrideResult.rotation.eulerAngles:F3}");
            }

            Debug.Log(sb.ToString().TrimEnd(), this);
        }

        void LogDynamicAttachInitPhase(
            string phaseLabel,
            IXRSelectInteractor interactor,
            Transform dynamicAttachTransform)
        {
            var interactorAttach = interactor?.GetAttachTransform(this);
            var sb = new StringBuilder();
            sb.AppendLine($"[HandSideAwareGrabInteractable][GrabDiag] {phaseLabel}");
            sb.AppendLine($"  Frame                    : {Time.frameCount}");
            sb.AppendLine($"  Dynamic Attach path      : {GetTransformPath(dynamicAttachTransform)}");
            sb.AppendLine($"  Dynamic Attach exists    : {dynamicAttachTransform != null}");
            if (dynamicAttachTransform != null)
            {
                sb.AppendLine($"  Dynamic local pos        : {dynamicAttachTransform.localPosition:F6}");
                sb.AppendLine($"  Dynamic local rot        : {dynamicAttachTransform.localRotation.eulerAngles:F3}");
                sb.AppendLine($"  Dynamic world pos        : {dynamicAttachTransform.position:F6}");
                sb.AppendLine($"  Dynamic world rot        : {dynamicAttachTransform.rotation.eulerAngles:F3}");
            }

            sb.AppendLine($"  Interactor Attach path   : {GetTransformPath(interactorAttach)}");
            if (interactorAttach != null)
            {
                sb.AppendLine($"  Interactor Attach world pos: {interactorAttach.position:F6}");
                sb.AppendLine($"  Interactor Attach world rot: {interactorAttach.rotation.eulerAngles:F3}");
            }

            if (dynamicAttachTransform != null && interactorAttach != null)
            {
                sb.AppendLine(
                    $"  Dynamic↔Interactor pos Δ : {Vector3.Distance(dynamicAttachTransform.position, interactorAttach.position):F6} m");
                sb.AppendLine(
                    $"  Dynamic↔Interactor rot Δ : {Quaternion.Angle(dynamicAttachTransform.rotation, interactorAttach.rotation):F3}°");
            }

            Debug.Log(sb.ToString().TrimEnd(), this);
        }

        void LogDiagnosticSnapshot(string phaseLabel)
        {
            var interactor = m_DiagInteractor;
            var interactorComponent = interactor as Component;

            Transform overrideAttach = null;
            Transform baseAttach = null;
            Transform interactorAttach = null;

            if (interactor != null)
            {
                m_DiagSuppressGetAttachLogging = true;
                try
                {
                    try { overrideAttach = GetAttachTransform(interactor); }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[HandSideAwareGrabInteractable][GrabDiag] override GetAttachTransform failed: {ex.Message}",
                            this);
                    }

                    try { baseAttach = base.GetAttachTransform(interactor); }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[HandSideAwareGrabInteractable][GrabDiag] base GetAttachTransform failed: {ex.Message}",
                            this);
                    }

                    try { interactorAttach = interactor.GetAttachTransform(this); }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[HandSideAwareGrabInteractable][GrabDiag] interactor GetAttachTransform failed: {ex.Message}",
                            this);
                    }
                }
                finally
                {
                    m_DiagSuppressGetAttachLogging = false;
                }
            }

            var worldPos = transform.position;
            var worldRot = transform.rotation;

            var deltaFromLastPos = m_DiagHasLastSnapshotPose
                ? Vector3.Distance(m_DiagLastSnapshotPos, worldPos)
                : 0f;
            var deltaFromLastRot = m_DiagHasLastSnapshotPose
                ? Quaternion.Angle(m_DiagLastSnapshotRot, worldRot)
                : 0f;
            var deltaFromInitialPos = Vector3.Distance(m_DiagInitialTargetPos, worldPos);
            var deltaFromInitialRot = Quaternion.Angle(m_DiagInitialTargetRot, worldRot);

            if (!m_DiagReportedFirstRotationChange
                && deltaFromLastRot > DiagRotationChangeEpsilon
                && phaseLabel != "1-BeforeOnSelectEntering")
            {
                m_DiagReportedFirstRotationChange = true;
                Debug.LogWarning(
                    $"[HandSideAwareGrabInteractable][GrabDiag] *** FIRST TARGET ROTATION CHANGE *** " +
                    $"phase={phaseLabel} frame={Time.frameCount} " +
                    $"Δrot(from last)={deltaFromLastRot:F3}° " +
                    $"overrideAttach={GetTransformPath(overrideAttach)} " +
                    $"interactorAttach={GetTransformPath(interactorAttach)}",
                    this);
            }

            var sb = new StringBuilder();
            sb.AppendLine($"[HandSideAwareGrabInteractable][GrabDiag] Snapshot — {phaseLabel}");
            sb.AppendLine($"  Frame                    : {Time.frameCount}");
            sb.AppendLine($"  Target path              : {GetTransformPath(transform)}");
            sb.AppendLine($"  Target world pos         : {worldPos:F6}");
            sb.AppendLine($"  Target world rot         : {worldRot.eulerAngles:F3}");
            sb.AppendLine($"  Δpos vs last snapshot    : {deltaFromLastPos:F6} m");
            sb.AppendLine($"  Δrot vs last snapshot    : {deltaFromLastRot:F3}°");
            sb.AppendLine($"  Δpos vs select-start     : {deltaFromInitialPos:F6} m");
            sb.AppendLine($"  Δrot vs select-start     : {deltaFromInitialRot:F3}°");
            sb.AppendLine($"  useDynamicAttach         : {useDynamicAttach}");
            sb.AppendLine($"  interactorsSelecting.Count: {interactorsSelecting.Count}");
            sb.AppendLine($"  m_RouteBindingStaticOnce : {m_RouteGetAttachTransformToBindingStaticOnce}");
            sb.AppendLine($"  trackPosition            : {trackPosition}");
            sb.AppendLine($"  trackRotation            : {trackRotation}");
            sb.AppendLine($"  GetAttachTransform calls : {m_DiagGetAttachCallCount} (cumulative)");
            sb.AppendLine(
                $"  Interactor path          : {GetTransformPath(interactorComponent != null ? interactorComponent.transform : null)}");
            sb.AppendLine($"  base.GetAttachTransform  : {GetTransformPath(baseAttach)} ({ClassifyAttachTransform(baseAttach)})");
            sb.AppendLine($"  override GetAttachTransform: {GetTransformPath(overrideAttach)} ({ClassifyAttachTransform(overrideAttach)})");
            sb.AppendLine($"  override == base ref     : {overrideAttach == baseAttach}");

            if (overrideAttach != null)
            {
                sb.AppendLine($"  Override attach world pos: {overrideAttach.position:F6}");
                sb.AppendLine($"  Override attach world rot: {overrideAttach.rotation.eulerAngles:F3}");
            }

            if (interactorAttach != null)
            {
                sb.AppendLine($"  Interactor attach world pos: {interactorAttach.position:F6}");
                sb.AppendLine($"  Interactor attach world rot: {interactorAttach.rotation.eulerAngles:F3}");
            }

            if (overrideAttach != null && interactorAttach != null)
            {
                sb.AppendLine(
                    $"  Object↔Interactor attach pos Δ: {Vector3.Distance(overrideAttach.position, interactorAttach.position):F6} m");
                sb.AppendLine(
                    $"  Object↔Interactor attach rot Δ: {Quaternion.Angle(overrideAttach.rotation, interactorAttach.rotation):F3}°");
            }

            AppendBindingStaticAttachInfo(sb);

            Debug.Log(sb.ToString().TrimEnd(), this);

            m_DiagLastSnapshotPos = worldPos;
            m_DiagLastSnapshotRot = worldRot;
            m_DiagHasLastSnapshotPose = true;
        }

        void AppendBindingStaticAttachInfo(StringBuilder sb)
        {
            var binding = Binding;
            if (binding == null)
            {
                sb.AppendLine("  Binding static attaches  : (no binding)");
                return;
            }

            AppendHandStaticAttachLine(sb, binding, HandSide.Left);
            AppendHandStaticAttachLine(sb, binding, HandSide.Right);
        }

        static void AppendHandStaticAttachLine(StringBuilder sb, HandGrabPoseBinding binding, HandSide handSide)
        {
            if (!binding.TryGetAttachTransform(handSide, out var attach) || attach == null)
            {
                sb.AppendLine($"  Binding static {handSide}    : (none)");
                return;
            }

            sb.AppendLine($"  Binding static {handSide} path: {GetTransformPath(attach)}");
            sb.AppendLine($"  Binding static {handSide} world pos: {attach.position:F6}");
            sb.AppendLine($"  Binding static {handSide} world rot: {attach.rotation.eulerAngles:F3}");
        }

        string ClassifyAttachTransform(Transform attach)
        {
            if (attach == null)
                return "null";

            if (attach.name.IndexOf(DynamicAttachNameToken, StringComparison.Ordinal) >= 0)
                return "Dynamic Attach";

            var binding = Binding;
            if (binding != null)
            {
                if (binding.TryGetAttachTransform(HandSide.Left, out var left) && attach == left)
                    return "Binding Static (Left)";

                if (binding.TryGetAttachTransform(HandSide.Right, out var right) && attach == right)
                    return "Binding Static (Right)";
            }

            if (attach == transform)
                return "Interactable Root";

            if (attachTransform != null && attach == attachTransform)
                return "Serialized attachTransform";

            if (secondaryAttachTransform != null && attach == secondaryAttachTransform)
                return "Serialized secondaryAttachTransform";

            return "Other";
        }

        void LogObjectGrabPosePreserve(
            SelectEnterEventArgs args,
            Vector3 worldPosBefore,
            Quaternion worldRotBefore)
        {
            var interactor = args.interactorObject;
            var interactorComponent = interactor as Component;
            var hasHandSide = TryResolveInteractorHandSide(interactor, out var handSide);

            Transform attachTransform = null;
            if (interactor != null)
            {
                try
                {
                    attachTransform = GetAttachTransform(interactor);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[HandSideAwareGrabInteractable] Attach Transform 조회 실패: {ex.Message}",
                        this);
                }
            }

            var worldPosAfter = transform.position;
            var worldRotAfter = transform.rotation;
            var positionDelta = Vector3.Distance(worldPosBefore, worldPosAfter);
            var rotationDelta = Quaternion.Angle(worldRotBefore, worldRotAfter);

            var sb = new StringBuilder();
            sb.AppendLine("[HandSideAwareGrabInteractable] Object Grab Pose Preserve Verification");
            sb.AppendLine($"Target path              : {GetTransformPath(transform)}");
            sb.AppendLine(
                $"Interactor path          : {GetTransformPath(interactorComponent != null ? interactorComponent.transform : null)}");
            sb.AppendLine(
                $"Resolved HandSide        : {(hasHandSide ? handSide.ToString() : "(unresolved)")}");
            sb.AppendLine(
                $"Target world pos (before): {worldPosBefore.ToString("F6")}");
            sb.AppendLine(
                $"Target world rot (before): {worldRotBefore.eulerAngles.ToString("F3")}");
            sb.AppendLine(
                $"Target world pos (after) : {worldPosAfter.ToString("F6")}");
            sb.AppendLine(
                $"Target world rot (after) : {worldRotAfter.eulerAngles.ToString("F3")}");
            sb.AppendLine($"Position delta (m)       : {positionDelta:F6}");
            sb.AppendLine($"Rotation delta (deg)     : {rotationDelta:F3}");
            sb.AppendLine(
                $"Attach Transform path    : {GetTransformPath(attachTransform)} ({ClassifyAttachTransform(attachTransform)})");
            sb.AppendLine($"useDynamicAttach         : {useDynamicAttach}");
            sb.AppendLine($"trackPosition            : {trackPosition}");
            sb.AppendLine($"trackRotation            : {trackRotation}");

            var preserved = positionDelta <= PosePreservePositionEpsilon
                            && rotationDelta <= PosePreserveRotationEpsilon;
            sb.AppendLine(
                preserved
                    ? "Result                   : PASS (Target world pose preserved at grab)"
                    : "Result                   : FAIL (Target world pose changed at grab)");

            if (preserved)
                Debug.Log(sb.ToString().TrimEnd(), this);
            else
                Debug.LogWarning(sb.ToString().TrimEnd(), this);
        }

        void CacheBinding()
        {
            if (m_CachedBinding == null)
                m_CachedBinding = GetComponent<HandGrabPoseBinding>();
        }

        static void LogHandSideFallbackWarningOnce(IXRInteractor interactor)
        {
            if (interactor is not Component interactorComponent)
                return;

            var instanceId = interactorComponent.GetInstanceID();
            if (!s_HandSideFallbackWarningLogged.Add(instanceId))
                return;

            Debug.LogWarning(
                "[HandSideAwareGrabInteractable] Interactor hand side could not be resolved. " +
                "Add HandInteractorSide to the Interactor or parent Controller for reliable handed attach selection. " +
                "Falling back to base attach.",
                interactorComponent);
        }

        static bool TryResolveInteractorHandSide(IXRInteractor interactor, out HandSide handSide)
        {
            handSide = default;

            if (interactor == null)
                return false;

            var interactorTransform = interactor.transform;
            if (interactorTransform == null)
                return false;

            var explicitSide = interactorTransform.GetComponentInParent<HandInteractorSide>();
            if (explicitSide != null)
            {
                handSide = explicitSide.HandSide;
                return true;
            }

            if (TryResolveHandSideFromNameFallback(interactorTransform, out handSide))
                return true;

            return false;
        }

        static bool TryResolveHandSideFromNameFallback(Transform interactorTransform, out HandSide handSide)
        {
            if (TryResolveHandSideFromHierarchy(interactorTransform, out handSide))
                return true;

            return TryResolveHandSideFromInteractorName(interactorTransform.name, out handSide);
        }

        static bool TryResolveHandSideFromHierarchy(Transform start, out HandSide handSide)
        {
            handSide = default;

            var current = start;
            while (current != null)
            {
                if (string.Equals(current.name, LeftControllerToken, StringComparison.Ordinal))
                {
                    handSide = HandSide.Left;
                    return true;
                }

                if (string.Equals(current.name, RightControllerToken, StringComparison.Ordinal))
                {
                    handSide = HandSide.Right;
                    return true;
                }

                current = current.parent;
            }

            return false;
        }

        static bool TryResolveHandSideFromInteractorName(string interactorName, out HandSide handSide)
        {
            handSide = default;

            if (string.IsNullOrEmpty(interactorName))
                return false;

            if (interactorName.StartsWith("Left_", StringComparison.Ordinal))
            {
                handSide = HandSide.Left;
                return true;
            }

            if (interactorName.StartsWith("Right_", StringComparison.Ordinal))
            {
                handSide = HandSide.Right;
                return true;
            }

            return false;
        }

        static string GetTransformPath(Transform t)
        {
            if (t == null)
                return "(null)";

            var sb = new StringBuilder(t.name);
            var current = t.parent;
            while (current != null)
            {
                sb.Insert(0, current.name + "/");
                current = current.parent;
            }

            return sb.ToString();
        }
    }
}
