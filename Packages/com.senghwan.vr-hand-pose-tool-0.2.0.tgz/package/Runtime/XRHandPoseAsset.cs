using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace VRHandPoseTool
{
    /// <summary>
    /// Play 모드에서 캡처한 Open/Grab/Current 포즈를 저장하는 ScriptableObject입니다.
    /// 손가락 재생에는 bones의 local Transform만 사용하고, joints는 추적 기록·검증용입니다.
    /// </summary>
    public class XRHandPoseAsset : ScriptableObject
    {
        [Header("Identity")]
        public string poseName;
        public Handedness handedness = Handedness.Left;
        public string sourceHandName;
        public string sourceSkeletonName = "LeftHand.fbx";
        public string targetName;
        public string capturedAtIso8601;

        [Header("Hand Root (World)")]
        public Vector3 rootWorldPosition;
        public Quaternion rootWorldRotation;

        [Header("Target Relative")]
        public bool hasTargetRelativePose;
        public Vector3 targetRelativePosition;
        public Quaternion targetRelativeRotation;

        [Header("Bones (Apply Pose From Here)")]
        public List<HandBonePoseData> bones = new();

        [Header("Joints (Tracking Reference Only)")]
        public List<HandJointTrackingData> joints = new();

        [Header("Capture Diagnostics")]
        public int expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount;
        public int capturedBoneCount;
        public int capturedJointCount;
        public int validJointPoseCount;
        public bool skeletonValid;
        public string captureSummary;
    }
}
