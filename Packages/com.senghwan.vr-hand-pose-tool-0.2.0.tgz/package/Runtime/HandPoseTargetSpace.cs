using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// Target Transform 기준 손 루트의 상대 위치·회전을 계산·복원합니다.
    /// </summary>
    public static class HandPoseTargetSpace
    {
        public struct RelativePose
        {
            public bool isValid;
            public Vector3 relativePosition;
            public Quaternion relativeRotation;
        }

        /// <summary>
        /// handRoot의 월드 pose를 target 기준 상대 pose로 변환합니다.
        /// target이 null이면 isValid=false를 반환합니다.
        /// </summary>
        public static RelativePose ComputeRelativePose(Transform handRoot, Transform target)
        {
            if (handRoot == null || target == null)
            {
                return new RelativePose { isValid = false };
            }

            return new RelativePose
            {
                isValid = true,
                relativePosition = target.InverseTransformPoint(handRoot.position),
                relativeRotation = Quaternion.Inverse(target.rotation) * handRoot.rotation,
            };
        }

        /// <summary>
        /// target 기준 상대 pose를 월드 pose로 복원합니다.
        /// </summary>
        public static void ApplyRelativePoseToWorld(
            Transform target,
            Vector3 relativePosition,
            Quaternion relativeRotation,
            out Vector3 worldPosition,
            out Quaternion worldRotation)
        {
            worldPosition = target.TransformPoint(relativePosition);
            worldRotation = target.rotation * relativeRotation;
        }
    }
}
