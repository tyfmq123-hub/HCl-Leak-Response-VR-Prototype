using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// Editor 고스트 손 미리보기 오브젝트 식별용 마커입니다. 런타임 로직은 없습니다.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class HandGhostPreviewMarker : MonoBehaviour
    {
        [SerializeField]
        int m_TargetGrabObjectInstanceId;

        [SerializeField]
        string m_TargetGrabObjectName;

        [SerializeField]
        string m_HandSide = "Left";

        public int TargetGrabObjectInstanceId => m_TargetGrabObjectInstanceId;
        public string TargetGrabObjectName => m_TargetGrabObjectName;
        public string HandSide => m_HandSide;

        public void Initialize(GameObject targetGrabObject, string handSide)
        {
            m_TargetGrabObjectInstanceId = targetGrabObject != null ? targetGrabObject.GetInstanceID() : 0;
            m_TargetGrabObjectName = targetGrabObject != null ? targetGrabObject.name : string.Empty;
            m_HandSide = handSide;
        }
    }
}
