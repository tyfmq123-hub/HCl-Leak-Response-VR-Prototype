using System;
using UnityEngine;

namespace VRHandPoseTool
{
    /// <summary>
    /// LeftHand(L_*) 본 하나의 로컬 Transform 스냅샷을 담는 직렬화 가능 데이터입니다.
    /// Stage 1에서는 구조만 정의하며, 실제 저장·적용은 이후 단계에서 수행합니다.
    /// </summary>
    [Serializable]
    public class HandBonePoseData
    {
        /// <summary>
        /// 본 Transform 이름입니다. Step_05 LeftHand 기준으로 L_Wrist, L_IndexTip 등 L_* 형식입니다.
        /// 같은 이름의 본을 나중에 다시 찾을 때 사용합니다.
        /// </summary>
        public string boneName;

        /// <summary>
        /// 이 본의 부모 본 이름입니다. L_Wrist처럼 손 루트(LeftHand) 직속 자식이면 LeftHand 이름이 들어갑니다.
        /// 계층 검증 및 프리팹 재생성 시 부모-자식 관계를 복원하는 데 사용합니다.
        /// </summary>
        public string parentBoneName;

        /// <summary>
        /// 부모 본 기준 로컬 위치입니다. 손가락 관절 위치를 재현할 때 사용합니다.
        /// XR joint tracking position과는 다른 좌표계이므로 혼용하지 않습니다.
        /// </summary>
        public Vector3 localPosition;

        /// <summary>
        /// 부모 본 기준 로컬 회전입니다. Open/Grab 포즈 재생·블렌딩의 핵심 데이터입니다.
        /// XR joint tracking rotation을 여기에 넣지 않습니다.
        /// </summary>
        public Quaternion localRotation;

        /// <summary>
        /// 부모 본 기준 로컬 스케일입니다. LeftHand.fbx는 보통 (1,1,1)이지만 캡처 시점 값을 그대로 보존합니다.
        /// </summary>
        public Vector3 localScale = Vector3.one;
    }
}
