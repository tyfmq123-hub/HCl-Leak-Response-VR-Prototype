using System;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace VRHandPoseTool
{
    /// <summary>
    /// XR Hand Subsystem이 제공하는 조인트 추적 정보를 기록하기 위한 데이터입니다.
    /// Bone localRotation과는 별개의 좌표계이므로 포즈 재생에 사용하지 않습니다.
    /// Stage 1에서는 구조만 정의하며, Subsystem에서 읽는 기능은 이후 단계에서 구현합니다.
    /// </summary>
    [Serializable]
    public class HandJointTrackingData
    {
        /// <summary>
        /// XR Hands 패키지가 정의한 조인트 ID입니다. Wrist, IndexTip 등 26개 관절과 대응합니다.
        /// </summary>
        public XRHandJointID jointId;

        /// <summary>
        /// 캡처 시점에 TryGetPose 등으로 유효한 추적 값을 얻었는지 여부입니다.
        /// false이면 trackingPosition/Rotation은 참고용으로만 저장합니다.
        /// </summary>
        public bool poseValid;

        /// <summary>
        /// XR 추적 공간에서의 조인트 위치입니다. Bone localPosition과 동일하지 않습니다.
        /// </summary>
        public Vector3 trackingPosition;

        /// <summary>
        /// XR 추적 공간에서의 조인트 회전입니다. Bone localRotation과 동일하지 않습니다.
        /// Bone 적용 fallback으로 사용하지 않습니다.
        /// </summary>
        public Quaternion trackingRotation;
    }
}
