using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace VRHandPoseTool
{
    /// <summary>
    /// Play 중 LeftHand / Wrist Transform이 Grip 또는 XR Grab 시점에 변경되는지 진단합니다.
    /// Transform을 수정하지 않으며 로그만 출력합니다.
    /// </summary>
    [DisallowMultipleComponent]
    public class HandGrabTransformDiagnostic : MonoBehaviour
    {
        const string LogPrefix = "[HandGrabDiagnostic]";
        const float PositionThreshold = 0.001f;
        const float RotationAngleThreshold = 0.5f;
        const float ScaleThreshold = 0.001f;
        const float GripPressedThreshold = 0.5f;

        [SerializeField]
        Transform playbackHandRoot;

        [SerializeField]
        Transform wristTransform;

        [SerializeField]
        XRBaseInteractor interactor;

        [SerializeField]
        InputActionProperty gripAction;

        [SerializeField]
        bool logComponentInventoryOnStart = true;

        TransformSnapshot m_PlayStartHandSnapshot;
        TransformSnapshot m_PlayStartWristSnapshot;
        TransformSnapshot m_LastHandSnapshot;
        TransformSnapshot m_LastWristSnapshot;

        TransformSnapshot m_LateCompareBeforeHand;
        TransformSnapshot m_LateCompareBeforeWrist;
        string m_LateCompareLabel;

        bool m_InventoryLogged;
        bool m_BaselineCaptured;
        bool m_PendingLateCompare;
        bool m_GripOnlyLoggedThisPress;
        bool m_ErrorLogged;

        enum DiagnosticPhase
        {
            Idle,
            GripOnly,
            Grabbed,
        }

        DiagnosticPhase m_Phase = DiagnosticPhase.Idle;

        public Transform PlaybackHandRoot => playbackHandRoot;
        public Transform WristTransform => wristTransform;
        public XRBaseInteractor Interactor => interactor;

        public void Configure(
            Transform handRoot,
            Transform wrist,
            XRBaseInteractor xrInteractor,
            InputActionReference gripActionReference = null)
        {
            playbackHandRoot = handRoot;
            wristTransform = wrist;
            interactor = xrInteractor;

            if (gripActionReference != null)
            {
                gripAction = new InputActionProperty(gripActionReference);
            }
        }

        void OnEnable()
        {
            SubscribeInteractorEvents();
        }

        void Start()
        {
            if (!ValidateConfiguration())
                return;

            CaptureBaseline();
            LogComponentInventoryIfNeeded();
            LogBaselineState("Play start baseline");
            m_Phase = DiagnosticPhase.Idle;
            m_GripOnlyLoggedThisPress = false;
        }

        void Update()
        {
            if (!ValidateConfiguration())
                return;

            if (playbackHandRoot != null)
                m_LastHandSnapshot = TransformSnapshot.Capture(playbackHandRoot);

            if (wristTransform != null)
                m_LastWristSnapshot = TransformSnapshot.Capture(wristTransform);

            UpdateGripOnlyState();
        }

        void LateUpdate()
        {
            if (!m_PendingLateCompare)
                return;

            ComparePair(
                m_LateCompareLabel,
                playbackHandRoot,
                wristTransform,
                m_LateCompareBeforeHand,
                m_LateCompareBeforeWrist,
                TransformSnapshot.Capture(playbackHandRoot),
                TransformSnapshot.Capture(wristTransform));

            m_PendingLateCompare = false;
        }

        void OnDisable()
        {
            UnsubscribeInteractorEvents();
            m_PendingLateCompare = false;
        }

        void SubscribeInteractorEvents()
        {
            if (interactor == null)
                return;

            interactor.selectEntered.AddListener(OnSelectEntered);
            interactor.selectExited.AddListener(OnSelectExited);
        }

        void UnsubscribeInteractorEvents()
        {
            if (interactor == null)
                return;

            interactor.selectEntered.RemoveListener(OnSelectEntered);
            interactor.selectExited.RemoveListener(OnSelectExited);
        }

        void CaptureBaseline()
        {
            m_PlayStartHandSnapshot = TransformSnapshot.Capture(playbackHandRoot);
            m_PlayStartWristSnapshot = TransformSnapshot.Capture(wristTransform);
            m_LastHandSnapshot = m_PlayStartHandSnapshot;
            m_LastWristSnapshot = m_PlayStartWristSnapshot;
            m_BaselineCaptured = playbackHandRoot != null;
        }

        void UpdateGripOnlyState()
        {
            if (interactor != null && interactor.hasSelection)
            {
                m_Phase = DiagnosticPhase.Grabbed;
                m_GripOnlyLoggedThisPress = false;
                return;
            }

            var gripValue = ReadGripValue();
            var gripPressed = gripValue >= GripPressedThreshold;

            if (gripPressed)
            {
                if (m_Phase != DiagnosticPhase.GripOnly && !m_GripOnlyLoggedThisPress)
                {
                    ComparePair(
                        "Grip only (no grab)",
                        playbackHandRoot,
                        wristTransform,
                        m_PlayStartHandSnapshot,
                        m_PlayStartWristSnapshot,
                        TransformSnapshot.Capture(playbackHandRoot),
                        TransformSnapshot.Capture(wristTransform));

                    m_GripOnlyLoggedThisPress = true;
                }

                m_Phase = DiagnosticPhase.GripOnly;
                return;
            }

            if (m_Phase != DiagnosticPhase.Idle)
            {
                m_Phase = DiagnosticPhase.Idle;
            }

            m_GripOnlyLoggedThisPress = false;
        }

        void OnSelectEntered(SelectEnterEventArgs args)
        {
            if (!ValidateConfiguration())
                return;

            var interactableName = args.interactableObject != null
                ? args.interactableObject.transform.name
                : "(unknown)";

            var beforeHand = m_LastHandSnapshot;
            var beforeWrist = m_LastWristSnapshot;
            var afterHand = TransformSnapshot.Capture(playbackHandRoot);
            var afterWrist = TransformSnapshot.Capture(wristTransform);

            Debug.Log($"{LogPrefix} selectEntered · interactable={interactableName}", this);

            ComparePair(
                "select immediate",
                playbackHandRoot,
                wristTransform,
                beforeHand,
                beforeWrist,
                afterHand,
                afterWrist);

            m_LateCompareLabel = "select LateUpdate";
            m_LateCompareBeforeHand = beforeHand;
            m_LateCompareBeforeWrist = beforeWrist;
            m_PendingLateCompare = true;
            m_Phase = DiagnosticPhase.Grabbed;
        }

        void OnSelectExited(SelectExitEventArgs args)
        {
            if (!ValidateConfiguration())
                return;

            var interactableName = args.interactableObject != null
                ? args.interactableObject.transform.name
                : "(unknown)";

            var beforeHand = m_LastHandSnapshot;
            var beforeWrist = m_LastWristSnapshot;
            var afterHand = TransformSnapshot.Capture(playbackHandRoot);
            var afterWrist = TransformSnapshot.Capture(wristTransform);

            Debug.Log($"{LogPrefix} selectExited · interactable={interactableName}", this);

            ComparePair(
                "selectExited immediate",
                playbackHandRoot,
                wristTransform,
                beforeHand,
                beforeWrist,
                afterHand,
                afterWrist);

            m_LateCompareLabel = "selectExited LateUpdate";
            m_LateCompareBeforeHand = beforeHand;
            m_LateCompareBeforeWrist = beforeWrist;
            m_PendingLateCompare = true;
            m_Phase = ReadGripValue() >= GripPressedThreshold
                ? DiagnosticPhase.GripOnly
                : DiagnosticPhase.Idle;
        }

        void ComparePair(
            string label,
            Transform handRoot,
            Transform wrist,
            TransformSnapshot beforeHand,
            TransformSnapshot beforeWrist,
            TransformSnapshot afterHand,
            TransformSnapshot afterWrist)
        {
            CompareTransform(label, "LeftHand", handRoot, beforeHand, afterHand);
            CompareTransform(label, "Wrist", wrist, beforeWrist, afterWrist);
        }

        static void CompareTransform(
            string label,
            string targetLabel,
            Transform transform,
            TransformSnapshot before,
            TransformSnapshot after)
        {
            if (transform == null)
            {
                Debug.Log($"{LogPrefix} {targetLabel} transform missing during {label}");
                return;
            }

            if (!before.IsValid || !after.IsValid)
                return;

            var localPosChanged = Vector3.Distance(before.localPosition, after.localPosition) >= PositionThreshold;
            var localRotChanged = Quaternion.Angle(before.localRotation, after.localRotation) >= RotationAngleThreshold;
            var localScaleChanged = Vector3.Distance(before.localScale, after.localScale) >= ScaleThreshold;
            var worldPosChanged = Vector3.Distance(before.worldPosition, after.worldPosition) >= PositionThreshold;
            var worldRotChanged = Quaternion.Angle(before.worldRotation, after.worldRotation) >= RotationAngleThreshold;

            if (!localPosChanged && !localRotChanged && !localScaleChanged && !worldPosChanged && !worldRotChanged)
            {
                Debug.Log($"{LogPrefix} {targetLabel} unchanged ({label})");
                return;
            }

            if (localRotChanged || worldRotChanged)
            {
                var angleDelta = Quaternion.Angle(before.localRotation, after.localRotation);
                Debug.Log(
                    $"{LogPrefix} {targetLabel} localRotation changed on {label}\n" +
                    $"Before: {FormatQuaternion(before.localRotation)}\n" +
                    $"After: {FormatQuaternion(after.localRotation)}\n" +
                    $"Angle Delta: {angleDelta:F3} degrees");
            }

            if (localPosChanged)
            {
                Debug.Log(
                    $"{LogPrefix} {targetLabel} localPosition changed on {label}\n" +
                    $"Before: {FormatVector3(before.localPosition)}\n" +
                    $"After: {FormatVector3(after.localPosition)}\n" +
                    $"Delta: {Vector3.Distance(before.localPosition, after.localPosition):F4}");
            }

            if (worldPosChanged)
            {
                Debug.Log(
                    $"{LogPrefix} {targetLabel} world position changed on {label}\n" +
                    $"Before: {FormatVector3(before.worldPosition)}\n" +
                    $"After: {FormatVector3(after.worldPosition)}\n" +
                    $"Delta: {Vector3.Distance(before.worldPosition, after.worldPosition):F4}");
            }

            if (worldRotChanged && !localRotChanged)
            {
                Debug.Log(
                    $"{LogPrefix} {targetLabel} world rotation changed on {label}\n" +
                    $"Before: {FormatQuaternion(before.worldRotation)}\n" +
                    $"After: {FormatQuaternion(after.worldRotation)}\n" +
                    $"Angle Delta: {Quaternion.Angle(before.worldRotation, after.worldRotation):F3} degrees");
            }

            if (localScaleChanged)
            {
                Debug.Log(
                    $"{LogPrefix} {targetLabel} localScale changed on {label}\n" +
                    $"Before: {FormatVector3(before.localScale)}\n" +
                    $"After: {FormatVector3(after.localScale)}\n" +
                    $"Delta: {Vector3.Distance(before.localScale, after.localScale):F4}");
            }
        }

        void LogBaselineState(string label)
        {
            if (playbackHandRoot != null)
            {
                Debug.Log(
                    $"{LogPrefix} {label} · LeftHand\n" +
                    $"localPosition={FormatVector3(m_PlayStartHandSnapshot.localPosition)}\n" +
                    $"localRotation={FormatQuaternion(m_PlayStartHandSnapshot.localRotation)}\n" +
                    $"localScale={FormatVector3(m_PlayStartHandSnapshot.localScale)}\n" +
                    $"worldPosition={FormatVector3(m_PlayStartHandSnapshot.worldPosition)}\n" +
                    $"worldRotation={FormatQuaternion(m_PlayStartHandSnapshot.worldRotation)}",
                    this);
            }

            if (wristTransform != null)
            {
                Debug.Log(
                    $"{LogPrefix} {label} · Wrist\n" +
                    $"localPosition={FormatVector3(m_PlayStartWristSnapshot.localPosition)}\n" +
                    $"localRotation={FormatQuaternion(m_PlayStartWristSnapshot.localRotation)}\n" +
                    $"localScale={FormatVector3(m_PlayStartWristSnapshot.localScale)}\n" +
                    $"worldPosition={FormatVector3(m_PlayStartWristSnapshot.worldPosition)}\n" +
                    $"worldRotation={FormatQuaternion(m_PlayStartWristSnapshot.worldRotation)}",
                    this);
            }
        }

        void LogComponentInventoryIfNeeded()
        {
            if (!logComponentInventoryOnStart || m_InventoryLogged)
                return;

            m_InventoryLogged = true;

            var sb = new StringBuilder();
            sb.AppendLine($"{LogPrefix} Component inventory");

            LogComponentsOnTransform(playbackHandRoot, "Playback Hand Root", sb);

            if (wristTransform != null && wristTransform != playbackHandRoot)
                LogComponentsOnTransform(wristTransform, "Wrist", sb);

            var current = playbackHandRoot != null ? playbackHandRoot.parent : null;
            while (current != null)
            {
                LogComponentsOnTransform(current, GetHierarchyPath(current), sb);
                if (current.name.IndexOf("Left Controller", StringComparison.OrdinalIgnoreCase) >= 0)
                    break;

                current = current.parent;
            }

            Debug.Log(sb.ToString(), this);
        }

        static void LogComponentsOnTransform(Transform target, string label, StringBuilder sb)
        {
            if (target == null)
                return;

            sb.AppendLine($"[{label}] {GetHierarchyPath(target)}");
            var components = target.GetComponents<Component>();
            foreach (var component in components)
            {
                if (component == null)
                    continue;

                var typeName = component.GetType().Name;
                var fullName = component.GetType().FullName ?? typeName;
                var marker = IsAttentionComponent(fullName, typeName) ? " **" : string.Empty;
                sb.AppendLine($"  • {typeName}{marker}");
            }
        }

        static bool IsAttentionComponent(string fullName, string typeName)
        {
            if (typeName == "Animator"
                || typeName == "TrackedPoseDriver"
                || typeName == "XRHandSkeletonDriver"
                || typeName == "ParentConstraint"
                || typeName == "PositionConstraint"
                || typeName == "RotationConstraint"
                || typeName == "ScaleConstraint"
                || typeName == "RigBuilder"
                || typeName == "TwoBoneIKConstraint"
                || typeName == "MultiRotationConstraint"
                || typeName == "MultiAimConstraint")
            {
                return true;
            }

            if (typeName.IndexOf("HandVisualizer", StringComparison.OrdinalIgnoreCase) >= 0)
                return true;

            if (fullName.StartsWith("UnityEngine.", StringComparison.Ordinal)
                || fullName.StartsWith("Unity.", StringComparison.Ordinal)
                || fullName.StartsWith("UnityEngine.XR.", StringComparison.Ordinal)
                || fullName.StartsWith("UnityEngine.InputSystem.", StringComparison.Ordinal))
            {
                return false;
            }

            return typeName.EndsWith("Behaviour", StringComparison.Ordinal)
                || fullName.Contains(".Scripts.", StringComparison.Ordinal);
        }

        float ReadGripValue()
        {
            if (gripAction.action == null)
                return 0f;

            try
            {
                if (!gripAction.action.enabled)
                    gripAction.action.Enable();

                return Mathf.Clamp01(gripAction.action.ReadValue<float>());
            }
            catch (Exception)
            {
                return 0f;
            }
        }

        bool ValidateConfiguration()
        {
            if (playbackHandRoot == null)
            {
                LogErrorOnce("Playback Hand Root가 연결되지 않았습니다.");
                return false;
            }

            if (interactor == null)
            {
                LogErrorOnce("XR Interactor가 연결되지 않았습니다.");
                return false;
            }

            return true;
        }

        void LogErrorOnce(string message)
        {
            if (m_ErrorLogged)
                return;

            m_ErrorLogged = true;
            Debug.LogError($"{LogPrefix} {message}", this);
        }

        static string GetHierarchyPath(Transform transform)
        {
            if (transform == null)
                return "(none)";

            var parts = new List<string>();
            var current = transform;
            while (current != null)
            {
                parts.Add(current.name);
                current = current.parent;
            }

            parts.Reverse();
            return string.Join("/", parts);
        }

        static string FormatVector3(Vector3 value) => value.ToString("F4");

        static string FormatQuaternion(Quaternion value) =>
            $"(x={value.x:F4}, y={value.y:F4}, z={value.z:F4}, w={value.w:F4})";

        [Serializable]
        struct TransformSnapshot
        {
            public bool IsValid;
            public Vector3 localPosition;
            public Quaternion localRotation;
            public Vector3 localScale;
            public Vector3 worldPosition;
            public Quaternion worldRotation;

            public static TransformSnapshot Capture(Transform transform)
            {
                if (transform == null)
                {
                    return new TransformSnapshot { IsValid = false };
                }

                return new TransformSnapshot
                {
                    IsValid = true,
                    localPosition = transform.localPosition,
                    localRotation = transform.localRotation,
                    localScale = transform.localScale,
                    worldPosition = transform.position,
                    worldRotation = transform.rotation,
                };
            }
        }
    }
}
