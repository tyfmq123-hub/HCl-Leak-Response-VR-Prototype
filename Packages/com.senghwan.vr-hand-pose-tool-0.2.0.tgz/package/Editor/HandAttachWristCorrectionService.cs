using System;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Target 아래 Ghost Wrist와 Controller Wrist·Interactor Attach를 사용해
    /// Object Attach local Pose를 계산합니다.
    /// </summary>
    public static class HandAttachWristCorrectionService
    {
        public struct Pose
        {
            public Vector3 position;
            public Quaternion rotation;

            public static Pose Identity => new Pose
            {
                position = Vector3.zero,
                rotation = Quaternion.identity,
            };
        }

        public struct ComputeResult
        {
            public bool success;
            public string errorMessage;
            public Vector3 attachLocalPosition;
            public Quaternion attachLocalRotation;
            public string validationLog;
        }

        public static ComputeResult TryComputeAttachLocalPose(
            Transform targetTransform,
            HandSide handSide,
            XRGrabInteractable grabInteractable = null)
        {
            var result = new ComputeResult();

            if (targetTransform == null)
            {
                result.errorMessage = "Target Transform이 null입니다.";
                return result;
            }

            if (!TryFindTargetGhostWrist(targetTransform, handSide, out var ghostWrist, out var ghostRoot, out var ghostError))
            {
                result.errorMessage = ghostError;
                return result;
            }

            if (!TryFindControllerWrist(handSide, out var controllerWrist, out var controllerError))
            {
                result.errorMessage = controllerError;
                return result;
            }

            if (!TryFindInteractorAttach(handSide, grabInteractable, out var interactorAttach, out var interactorError))
            {
                result.errorMessage = interactorError;
                return result;
            }

            var capturedGhostWristInTarget = PoseInParentSpace(ghostWrist, targetTransform);
            var controllerWristInInteractor = PoseInParentSpace(controllerWrist, interactorAttach);
            var objectAttachInTarget = Multiply(
                capturedGhostWristInTarget,
                Inverse(controllerWristInInteractor));

            result.success = true;
            result.attachLocalPosition = objectAttachInTarget.position;
            result.attachLocalRotation = objectAttachInTarget.rotation;
            result.validationLog = BuildValidationLog(
                targetTransform,
                ghostRoot,
                ghostWrist,
                controllerWrist,
                interactorAttach,
                capturedGhostWristInTarget,
                controllerWristInInteractor,
                objectAttachInTarget);
            return result;
        }

        public static bool TryFindTargetGhostWrist(
            Transform targetTransform,
            HandSide handSide,
            out Transform ghostWrist,
            out Transform ghostRoot,
            out string errorMessage)
        {
            ghostWrist = null;
            ghostRoot = null;
            errorMessage = null;

            if (targetTransform == null)
            {
                errorMessage = "Target Transform이 null입니다.";
                return false;
            }

            var targetObject = targetTransform.gameObject;
            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var wristName = HandSideUtility.GetWristBoneName(handSide);

            var ghostsRoot = FindGhostsRootUnder(targetTransform)
                ?? FindGhostsRootInScene(targetTransform.gameObject.scene);

            if (ghostsRoot == null)
            {
                errorMessage =
                    $"Target '{targetObject.name}' 아래 {HandGhostPreviewService.GhostsRootName}를 찾지 못했습니다.";
                return false;
            }

            var ghostRootObject = FindGhostRoot(ghostsRoot, targetObject, handSide);
            if (ghostRootObject == null)
            {
                errorMessage =
                    $"Target '{targetObject.name}' / HandSide {HandSideUtility.GetLabel(handSide)} Ghost Scene Instance를 찾지 못했습니다.";
                return false;
            }

            ghostRoot = ghostRootObject.transform;

            var marker = ghostRootObject.GetComponent<HandGhostPreviewMarker>();
            if (marker == null
                || marker.TargetGrabObjectInstanceId != targetObject.GetInstanceID()
                || !string.Equals(marker.HandSide, sideLabel, StringComparison.Ordinal))
            {
                errorMessage =
                    "HandGhostPreviewMarker가 현재 Target/HandSide와 일치하는 Ghost만 사용할 수 있습니다.";
                return false;
            }

            ghostWrist = FindBoneRecursive(ghostRoot, wristName);
            if (ghostWrist == null)
            {
                errorMessage = $"Ghost '{ghostRootObject.name}' 하위에서 {wristName} 본을 찾지 못했습니다.";
                return false;
            }

            return true;
        }

        static bool TryFindControllerWrist(HandSide handSide, out Transform controllerWrist, out string errorMessage)
        {
            controllerWrist = null;
            errorMessage = null;

            var wristName = HandSideUtility.GetWristBoneName(handSide);
            var findResult = HandPlaybackHandFinder.FindPlaybackHand(handSide);
            if (findResult.success && findResult.candidates.Count > 0)
            {
                var ctrlRoot = findResult.candidates[0].handRoot;
                if (ctrlRoot != null)
                {
                    controllerWrist = FindBoneRecursive(ctrlRoot, wristName);
                    if (controllerWrist != null)
                        return true;
                }
            }

            foreach (var t in Resources.FindObjectsOfTypeAll<Transform>())
            {
                if (t == null || t.name != wristName || !t.gameObject.scene.IsValid())
                    continue;

                if (t.GetComponentInParent<HandGhostPreviewMarker>() != null)
                    continue;

                controllerWrist = t;
                return true;
            }

            errorMessage = $"Controller Wrist 본 '{wristName}'을 찾지 못했습니다.";
            return false;
        }

        public static bool TryFindInteractorAttach(
            HandSide handSide,
            XRGrabInteractable grabInteractable,
            out Transform interactorAttach,
            out string errorMessage)
        {
            interactorAttach = null;
            errorMessage = null;

            var candidates = HandInteractorFinder.FindInteractorCandidates(handSide);
            if (candidates == null || candidates.Count == 0)
            {
                errorMessage = $"{HandSideUtility.GetLabel(handSide)} Interactor를 찾지 못했습니다.";
                return false;
            }

            var interactor = candidates[0].interactor;
            if (interactor == null)
            {
                errorMessage = "Interactor가 null입니다.";
                return false;
            }

            if (grabInteractable != null)
                interactorAttach = interactor.GetAttachTransform(grabInteractable);

            if (interactorAttach == null)
            {
                interactorAttach = interactor.attachTransform != null
                    ? interactor.attachTransform
                    : interactor.transform;
            }

            return true;
        }

        static Pose PoseInParentSpace(Transform child, Transform parent)
        {
            return new Pose
            {
                position = parent.InverseTransformPoint(child.position),
                rotation = Quaternion.Inverse(parent.rotation) * child.rotation,
            };
        }

        static Pose Inverse(Pose pose)
        {
            var invRot = Quaternion.Inverse(pose.rotation);
            return new Pose
            {
                rotation = invRot,
                position = invRot * (-pose.position),
            };
        }

        static Pose Multiply(Pose parentPose, Pose childPose)
        {
            return new Pose
            {
                rotation = parentPose.rotation * childPose.rotation,
                position = parentPose.rotation * childPose.position + parentPose.position,
            };
        }

        static string BuildValidationLog(
            Transform targetTransform,
            Transform ghostRoot,
            Transform ghostWrist,
            Transform controllerWrist,
            Transform interactorAttach,
            Pose capturedGhostWristInTarget,
            Pose controllerWristInInteractor,
            Pose objectAttachInTarget)
        {
            var attachWorldPos = targetTransform.TransformPoint(objectAttachInTarget.position);
            var attachWorldRot = targetTransform.rotation * objectAttachInTarget.rotation;
            var attachToGhostDistance = Vector3.Distance(attachWorldPos, ghostWrist.position);

            var predictedControllerWristWorldPos = interactorAttach.TransformPoint(controllerWristInInteractor.position);
            var predictedControllerWristWorldRot =
                interactorAttach.rotation * controllerWristInInteractor.rotation;
            var controllerToGhostDistance = Vector3.Distance(predictedControllerWristWorldPos, ghostWrist.position);
            var controllerToGhostAngle = Quaternion.Angle(predictedControllerWristWorldRot, ghostWrist.rotation);

            var sb = new StringBuilder();
            sb.AppendLine("[VRHandPoseTool] Attach Wrist Correction Validation");
            sb.AppendLine($"Ghost Root: {GetTransformPath(ghostRoot)}");
            sb.AppendLine($"Ghost Wrist: {GetTransformPath(ghostWrist)}");
            sb.AppendLine($"Controller Wrist: {GetTransformPath(controllerWrist)}");
            sb.AppendLine($"Interactor Attach: {GetTransformPath(interactorAttach)}");
            sb.AppendLine(
                $"Ghost Wrist Target localPosition={capturedGhostWristInTarget.position:F4} " +
                $"localRotation={capturedGhostWristInTarget.rotation.eulerAngles:F2}");
            sb.AppendLine(
                $"Computed Attach localPosition={objectAttachInTarget.position:F4} " +
                $"localRotation={objectAttachInTarget.rotation.eulerAngles:F2}");
            sb.AppendLine($"Attach ↔ Ghost Wrist world distance={attachToGhostDistance:F4} m");
            sb.AppendLine(
                $"XRI align 예상 Controller↔Ghost world distance={controllerToGhostDistance:F4} m, " +
                $"rotation error={controllerToGhostAngle:F2}°");
            return sb.ToString().TrimEnd();
        }

        static GameObject FindGhostsRootUnder(Transform targetTransform)
        {
            if (targetTransform == null)
                return null;

            for (var i = 0; i < targetTransform.childCount; i++)
            {
                var child = targetTransform.GetChild(i);
                if (child.name == HandGhostPreviewService.GhostsRootName)
                    return child.gameObject;
            }

            return null;
        }

        static GameObject FindGhostsRootInScene(Scene scene)
        {
            if (!scene.IsValid())
                return null;

            foreach (var root in scene.GetRootGameObjects())
            {
                if (root.name == HandGhostPreviewService.GhostsRootName)
                    return root;
            }

            return null;
        }

        static GameObject FindGhostRoot(GameObject ghostsRoot, GameObject targetGrabObject, HandSide handSide)
        {
            if (ghostsRoot == null || targetGrabObject == null)
                return null;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var targetId = targetGrabObject.GetInstanceID();

            foreach (var marker in ghostsRoot.GetComponentsInChildren<HandGhostPreviewMarker>(true))
            {
                if (marker == null)
                    continue;

                if (marker.TargetGrabObjectInstanceId == targetId
                    && string.Equals(marker.HandSide, sideLabel, StringComparison.Ordinal))
                {
                    return marker.gameObject;
                }
            }

            var expectedName = HandSideUtility.BuildGhostName(targetGrabObject.name, handSide);
            var namedChild = ghostsRoot.transform.Find(expectedName);
            return namedChild != null ? namedChild.gameObject : null;
        }

        static Transform FindBoneRecursive(Transform root, string boneName)
        {
            if (root == null)
                return null;

            if (root.name == boneName)
                return root;

            foreach (Transform child in root)
            {
                var found = FindBoneRecursive(child, boneName);
                if (found != null)
                    return found;
            }

            return null;
        }

        static string GetTransformPath(Transform transform)
        {
            if (transform == null)
                return "(null)";

            var sb = new StringBuilder(transform.name);
            var current = transform.parent;
            while (current != null)
            {
                sb.Insert(0, current.name + "/");
                current = current.parent;
            }

            return sb.ToString();
        }
    }
}
