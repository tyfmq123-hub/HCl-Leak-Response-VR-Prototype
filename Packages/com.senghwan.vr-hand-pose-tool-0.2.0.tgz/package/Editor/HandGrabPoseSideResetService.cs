using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 현재 Target + HandSide의 2차 Grab Pose 결과만 안전하게 초기화합니다.
    /// 반대 손·1차 Open/Grip 결과·Target 런타임 컴포넌트는 보존합니다.
    /// </summary>
    public static class HandGrabPoseSideResetService
    {
        public enum ResetItemKind
        {
            SceneBindingSlot,
            SceneAttach,
            SceneGhost,
            AssetRecord,
            AssetGhostPrefab,
            SessionPendingApply,
            EditorDeviceVerified,
        }

        public struct ResetItem
        {
            public ResetItemKind kind;
            public string label;
            public string detail;
        }

        public struct ResetPlan
        {
            public bool canExecute;
            public string blockReason;
            public GameObject targetObject;
            public HandSide handSide;
            public List<ResetItem> items;
            public HandGrabPoseBinding binding;
            public HandGrabPoseRecord record;
            public Transform attachTransform;
            public string recordAssetPath;
            public string ghostPrefabPath;
            public bool clearPendingApply;
            public bool clearDeviceVerified;
        }

        public struct ResetResult
        {
            public bool success;
            public string message;
            public int deletedSceneObjects;
            public int deletedAssets;
            public int clearedSessionItems;
        }

        public static ResetPlan BuildPlan(GameObject targetObject, HandSide handSide)
        {
            var plan = new ResetPlan
            {
                handSide = handSide,
                targetObject = targetObject,
                items = new List<ResetItem>(),
            };

            if (Application.isPlaying)
            {
                plan.blockReason = "Play Mode를 종료한 뒤 초기화하세요.";
                return plan;
            }

            if (PrefabStageUtility.GetCurrentPrefabStage() != null)
            {
                plan.blockReason = "Prefab Stage에서는 초기화할 수 없습니다. Scene View에서 Target Scene을 여세요.";
                return plan;
            }

            if (targetObject == null)
            {
                plan.blockReason = "Target Grab Object가 지정되지 않았습니다.";
                return plan;
            }

            if (!targetObject.scene.IsValid())
            {
                plan.blockReason = "씬에 있는 Target Grab Object를 지정하세요.";
                return plan;
            }

            var sideLabel = HandSideUtility.GetLabel(handSide);
            plan.binding = targetObject.GetComponent<HandGrabPoseBinding>();

            if (plan.binding != null)
            {
                plan.record = plan.binding.GetRecord(handSide);
                plan.attachTransform = plan.binding.GetAttachTransform(handSide);

                if (plan.record != null || plan.attachTransform != null
                    || plan.binding.IsWristCorrectionApplied(handSide))
                {
                    plan.items.Add(new ResetItem
                    {
                        kind = ResetItemKind.SceneBindingSlot,
                        label = $"HandGrabPoseBinding {sideLabel} 슬롯",
                        detail = "Record / Attach 참조 해제, WristCorrectionApplied=false",
                    });
                }
            }

            CollectAttachTargets(targetObject, handSide, plan);

            if (HasGhostSceneInstance(targetObject, handSide))
            {
                var ghostName = HandSideUtility.BuildGhostName(targetObject.name, handSide);
                plan.items.Add(new ResetItem
                {
                    kind = ResetItemKind.SceneGhost,
                    label = $"Ghost Scene Instance ({sideLabel})",
                    detail = ghostName,
                });
            }

            CollectRecordAssets(targetObject, handSide, plan);

            plan.ghostPrefabPath = HandGhostPreviewService.GetGhostPrefabPath(targetObject.name, handSide);
            if (!string.IsNullOrEmpty(plan.ghostPrefabPath)
                && !string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(plan.ghostPrefabPath)))
            {
                plan.items.Add(new ResetItem
                {
                    kind = ResetItemKind.AssetGhostPrefab,
                    label = $"Ghost Prefab Asset ({sideLabel})",
                    detail = plan.ghostPrefabPath,
                });
            }

            if (HandGrabPosePendingApplyBridge.PendingMatchesTargetAndSide(targetObject, handSide))
            {
                plan.clearPendingApply = true;
                var pending = HandGrabPosePendingApplyBridge.GetPendingSummary();
                plan.items.Add(new ResetItem
                {
                    kind = ResetItemKind.SessionPendingApply,
                    label = "Pending Apply",
                    detail = $"{pending.targetDisplayName} / {HandSideUtility.GetLabel(pending.handSide)}",
                });
            }

            plan.clearDeviceVerified = true;
            plan.items.Add(new ResetItem
            {
                kind = ResetItemKind.EditorDeviceVerified,
                label = "실기기 검증 상태",
                detail = "미검증으로 되돌림",
            });

            plan.canExecute = true;
            return plan;
        }

        public static string FormatPlanDialogMessage(ResetPlan plan)
        {
            var sb = new StringBuilder();
            sb.AppendLine(
                $"Target: {plan.targetObject.name}  |  Hand Side: {HandSideUtility.GetLabel(plan.handSide)}");
            sb.AppendLine();
            sb.AppendLine("다음 항목을 초기화합니다:");
            sb.AppendLine();

            foreach (var item in plan.items)
                sb.AppendLine($"• {item.label}\n  {item.detail}");

            sb.AppendLine();
            sb.AppendLine("보존:");
            sb.AppendLine("• 반대 HandSide 2차 결과");
            sb.AppendLine("• Open/Grip Pose Asset · AnimationClip · AnimatorController · Grip Driver");
            sb.AppendLine("• XRGrabInteractable · HandSideAwareGrabInteractable · HandGrabPosePlayer");
            sb.AppendLine("• 다른 Target의 결과");
            sb.AppendLine();
            sb.AppendLine("Asset 삭제는 Undo로 되돌릴 수 없습니다.");
            return sb.ToString().TrimEnd();
        }

        public static ResetResult TryExecute(ResetPlan plan)
        {
            var result = new ResetResult();

            if (!plan.canExecute)
            {
                result.message = plan.blockReason ?? "초기화할 수 없습니다.";
                return result;
            }

            if (Application.isPlaying)
            {
                result.message = "Play Mode를 종료한 뒤 초기화하세요.";
                return result;
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Reset Hand Grab Pose Side");
            var undoGroup = Undo.GetCurrentGroup();

            try
            {
                ClearBindingSlot(plan, ref result);
                DeleteAttachTransforms(plan, ref result);
                RemoveGhostSceneInstance(plan, ref result);
                DeleteRecordAssets(plan, ref result);
                DeleteGhostPrefabAsset(plan, ref result);
                ClearPendingApply(plan, ref result);

                if (plan.targetObject.scene.IsValid())
                    EditorSceneManager.MarkSceneDirty(plan.targetObject.scene);

                Undo.CollapseUndoOperations(undoGroup);
            }
            catch (Exception ex)
            {
                Undo.RevertAllDownToGroup(undoGroup);
                result.success = false;
                result.message = $"초기화 실패: {ex.Message}";
                return result;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            result.success = true;
            result.message =
                $"[{HandSideUtility.GetLabel(plan.handSide)}] 2차 결과 초기화 완료\n" +
                $"Scene 오브젝트 {result.deletedSceneObjects}개, Asset {result.deletedAssets}개, " +
                $"Session {result.clearedSessionItems}개 처리";
            return result;
        }

        static void ClearBindingSlot(ResetPlan plan, ref ResetResult result)
        {
            if (plan.binding == null)
                return;

            var hadSlotData = plan.binding.GetRecord(plan.handSide) != null
                || plan.binding.GetAttachTransform(plan.handSide) != null
                || plan.binding.IsWristCorrectionApplied(plan.handSide);

            if (!hadSlotData)
                return;

            Undo.RecordObject(plan.binding, "Clear Hand Grab Pose Binding Slot");
            plan.binding.SetBinding(plan.handSide, null, null);
            plan.binding.SetWristCorrectionApplied(plan.handSide, false);
            EditorUtility.SetDirty(plan.binding);
        }

        static void DeleteAttachTransforms(ResetPlan plan, ref ResetResult result)
        {
            var attachName = HandGrabPoseBinding.GetAttachObjectName(plan.handSide);
            var targetRoot = plan.targetObject.transform;
            var toDelete = new List<GameObject>();

            if (plan.attachTransform != null
                && plan.attachTransform.parent == targetRoot
                && !toDelete.Contains(plan.attachTransform.gameObject))
            {
                toDelete.Add(plan.attachTransform.gameObject);
            }

            for (var i = 0; i < targetRoot.childCount; i++)
            {
                var child = targetRoot.GetChild(i);
                if (string.Equals(child.name, attachName, StringComparison.Ordinal)
                    && !toDelete.Contains(child.gameObject))
                {
                    toDelete.Add(child.gameObject);
                }
            }

            foreach (var go in toDelete)
            {
                Undo.DestroyObjectImmediate(go);
                result.deletedSceneObjects++;
            }
        }

        static void RemoveGhostSceneInstance(ResetPlan plan, ref ResetResult result)
        {
            if (!HasGhostSceneInstance(plan.targetObject, plan.handSide))
                return;

            var ghostResult = HandGhostPreviewService.RemoveGhost(plan.targetObject, plan.handSide);
            if (ghostResult.success)
                result.deletedSceneObjects++;
        }

        static void DeleteRecordAssets(ResetPlan plan, ref ResetResult result)
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            if (!string.IsNullOrEmpty(plan.recordAssetPath))
                paths.Add(plan.recordAssetPath);

            if (plan.record != null)
            {
                var boundPath = AssetDatabase.GetAssetPath(plan.record);
                if (!string.IsNullOrEmpty(boundPath))
                    paths.Add(boundPath);
            }

            foreach (var path in FindRecordAssetPaths(plan.targetObject, plan.handSide))
                paths.Add(path);

            foreach (var path in paths)
            {
                if (string.IsNullOrEmpty(path)
                    || string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(path)))
                {
                    continue;
                }

                if (AssetDatabase.DeleteAsset(path))
                    result.deletedAssets++;
            }
        }

        static void DeleteGhostPrefabAsset(ResetPlan plan, ref ResetResult result)
        {
            if (string.IsNullOrEmpty(plan.ghostPrefabPath)
                || string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(plan.ghostPrefabPath)))
            {
                return;
            }

            if (AssetDatabase.DeleteAsset(plan.ghostPrefabPath))
                result.deletedAssets++;
        }

        static void ClearPendingApply(ResetPlan plan, ref ResetResult result)
        {
            if (!plan.clearPendingApply)
                return;

            if (HandGrabPosePendingApplyBridge.ClearPendingIfMatches(plan.targetObject, plan.handSide))
                result.clearedSessionItems++;
        }

        static void CollectAttachTargets(GameObject targetObject, HandSide handSide, ResetPlan plan)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var attachName = HandGrabPoseBinding.GetAttachObjectName(handSide);
            var targetRoot = targetObject.transform;
            var listed = new HashSet<int>();

            void TryAddAttach(Transform attach)
            {
                if (attach == null || attach.parent != targetRoot)
                    return;

                var id = attach.gameObject.GetInstanceID();
                if (!listed.Add(id))
                    return;

                plan.items.Add(new ResetItem
                {
                    kind = ResetItemKind.SceneAttach,
                    label = $"Attach Transform ({sideLabel})",
                    detail = GetTransformPath(attach),
                });
            }

            if (plan.binding != null)
                TryAddAttach(plan.binding.GetAttachTransform(handSide));

            for (var i = 0; i < targetRoot.childCount; i++)
            {
                var child = targetRoot.GetChild(i);
                if (string.Equals(child.name, attachName, StringComparison.Ordinal))
                    TryAddAttach(child);
            }
        }

        static void CollectRecordAssets(GameObject targetObject, HandSide handSide, ResetPlan plan)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var paths = FindRecordAssetPaths(targetObject, handSide);

            if (plan.binding != null)
            {
                var boundRecord = plan.binding.GetRecord(handSide);
                if (boundRecord != null)
                {
                    plan.record = boundRecord;
                    var boundPath = AssetDatabase.GetAssetPath(boundRecord);
                    if (!string.IsNullOrEmpty(boundPath))
                        paths.Add(boundPath);
                }
            }

            foreach (var path in paths.OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
            {
                plan.recordAssetPath = path;
                plan.items.Add(new ResetItem
                {
                    kind = ResetItemKind.AssetRecord,
                    label = $"HandGrabPoseRecord Asset ({sideLabel})",
                    detail = path,
                });
            }
        }

        static HashSet<string> FindRecordAssetPaths(GameObject targetObject, HandSide handSide)
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var targetName = targetObject.name;

            var defaultPath =
                $"{HandGrabPoseRecordFactory.OutputFolder}/" +
                $"{HandGrabPoseRecordFactory.BuildDefaultFileName(targetName, handSide)}.asset";
            if (!string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(defaultPath)))
                paths.Add(defaultPath);

            var guids = AssetDatabase.FindAssets("t:HandGrabPoseRecord", new[] { HandGrabPoseRecordFactory.OutputFolder });
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var record = AssetDatabase.LoadAssetAtPath<HandGrabPoseRecord>(path);
                if (record == null || !record.MatchesHandSide(handSide))
                    continue;

                if (RecordMatchesTarget(record, targetName, path))
                    paths.Add(path);
            }

            return paths;
        }

        static bool RecordMatchesTarget(HandGrabPoseRecord record, string targetName, string assetPath)
        {
            if (!string.IsNullOrEmpty(record.TargetObjectName)
                && string.Equals(record.TargetObjectName, targetName, StringComparison.Ordinal))
            {
                return true;
            }

            var fileName = System.IO.Path.GetFileNameWithoutExtension(assetPath);
            var expectedPrefix = HandGrabPoseRecordFactory.BuildDefaultFileName(targetName, record.HandSide);
            return fileName.StartsWith(expectedPrefix, StringComparison.Ordinal);
        }

        static bool HasGhostSceneInstance(GameObject targetObject, HandSide handSide)
        {
            var ghostsRoot = FindGhostsRootUnder(targetObject.transform)
                ?? FindGhostsRootInScene(targetObject.scene);
            if (ghostsRoot == null)
                return false;

            return FindGhostUnderRoot(ghostsRoot, targetObject, handSide) != null;
        }

        static GameObject FindGhostsRootUnder(Transform targetTransform)
        {
            if (targetTransform == null)
                return null;

            for (var i = 0; i < targetTransform.childCount; i++)
            {
                var child = targetTransform.GetChild(i);
                if (child.name == HandGhostPreviewService.GhostsRootName)
                    return child.gameObject;
            }

            return null;
        }

        static GameObject FindGhostsRootInScene(Scene scene)
        {
            if (!scene.IsValid())
                return null;

            foreach (var root in scene.GetRootGameObjects())
            {
                if (root.name == HandGhostPreviewService.GhostsRootName)
                    return root;
            }

            return null;
        }

        static GameObject FindGhostUnderRoot(
            GameObject ghostsRoot,
            GameObject targetGrabObject,
            HandSide handSide)
        {
            if (ghostsRoot == null || targetGrabObject == null)
                return null;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var targetId = targetGrabObject.GetInstanceID();

            foreach (var marker in ghostsRoot.GetComponentsInChildren<HandGhostPreviewMarker>(true))
            {
                if (marker == null)
                    continue;

                if (marker.TargetGrabObjectInstanceId == targetId
                    && string.Equals(marker.HandSide, sideLabel, StringComparison.Ordinal))
                {
                    return marker.gameObject;
                }
            }

            var expectedName = HandSideUtility.BuildGhostName(targetGrabObject.name, handSide);
            var namedChild = ghostsRoot.transform.Find(expectedName);
            return namedChild != null ? namedChild.gameObject : null;
        }

        static string GetTransformPath(Transform transform)
        {
            if (transform == null)
                return "(null)";

            var parts = new List<string>();
            var current = transform;
            while (current != null)
            {
                parts.Insert(0, current.name);
                current = current.parent;
            }

            return string.Join("/", parts);
        }
    }
}
