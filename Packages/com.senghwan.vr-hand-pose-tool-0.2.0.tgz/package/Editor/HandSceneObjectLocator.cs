using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    public enum SceneObjectLocatorRole
    {
        PlaybackHandRoot = 0,
        VisualOffset = 1,
    }

    /// <summary>
    /// Edit Mode Scene 오브젝트를 Play Mode 종료 후에도 안정적으로 복원하기 위한 Locator.
    /// Play Mode에서 얻은 GlobalObjectId만으로 복원하지 않습니다.
    /// </summary>
    [InitializeOnLoad]
    public static class HandSceneObjectLocator
    {
        const string StoredJsonKeyPrefix = "VRHandPoseTool.SceneObjectLocator.";
        const string InvalidGoid = "GlobalObjectId_V1-0-00000000000000000000000000000000-0-0";

        [Serializable]
        public sealed class SceneObjectLocatorData
        {
            public string scenePath;
            public string sceneGuid;
            public string editModeGlobalObjectId;
            public int[] siblingIndexPath;
            public string[] transformNamePath;
            public string prefabSourceGuid;
            public int handSide;
            public int targetRole;
            public bool hasSkinnedMeshRenderer;
            public bool skeletonValid;
            public string xrOriginHintName;
            public string controllerHierarchyHint;
            public string capturedAtUtc;
            public bool isValid;
        }

        public struct ResolveResult
        {
            public bool success;
            public Transform transform;
            public string message;
            public string resolveMethod;
        }

        static HandSceneObjectLocator()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
        }

        static void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            // ExitingEditMode: 진입 직전 Edit Mode Locator를 한 번 더 확정할 수 있도록
            // 윈도우 측 Capture 훅이 주 경로입니다. 여기서는 상태만 유지합니다.
            if (state == PlayModeStateChange.ExitingEditMode)
                return;
        }

        public static bool TryCapture(
            Transform target,
            HandSide handSide,
            SceneObjectLocatorRole role,
            out SceneObjectLocatorData data,
            out string errorMessage)
        {
            data = null;
            errorMessage = null;

            if (Application.isPlaying || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                errorMessage = "Locator는 Edit Mode에서만 캡처할 수 있습니다.";
                return false;
            }

            if (target == null)
            {
                errorMessage = "Locator 대상 Transform이 null입니다.";
                return false;
            }

            var scene = target.gameObject.scene;
            if (!scene.IsValid())
            {
                errorMessage = "Locator 대상이 유효한 Scene에 속하지 않습니다.";
                return false;
            }

            var scenePath = scene.path;
            if (string.IsNullOrWhiteSpace(scenePath))
            {
                errorMessage =
                    "저장되지 않은 Scene(Untitled)에서는 Locator를 캡처할 수 없습니다. Scene을 저장하세요.";
                return false;
            }

            if (!TryBuildHierarchyPaths(target, out var siblingPath, out var namePath, out var pathError))
            {
                errorMessage = pathError;
                return false;
            }

            string goid = string.Empty;
            TryGetEditModeGlobalObjectId(target.gameObject, out goid, out _);

            string prefabGuid = string.Empty;
            if (PrefabUtility.IsPartOfPrefabInstance(target.gameObject))
            {
                var source = PrefabUtility.GetCorrespondingObjectFromSource(target.gameObject);
                if (source != null)
                {
                    var prefabPath = AssetDatabase.GetAssetPath(source);
                    if (!string.IsNullOrEmpty(prefabPath))
                        prefabGuid = AssetDatabase.AssetPathToGUID(prefabPath);
                }
            }

            var skeletonValid = false;
            var hasSmr = false;
            if (role == SceneObjectLocatorRole.PlaybackHandRoot)
            {
                var validation = HandSkeletonCatalog.Validate(target, handSide);
                skeletonValid = validation.isValid;
                hasSmr = target.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;
            }
            else if (role == SceneObjectLocatorRole.VisualOffset)
            {
                hasSmr = false;
                skeletonValid = true;
            }

            FindHierarchyHints(target, out var xrOriginHint, out var controllerHint);

            data = new SceneObjectLocatorData
            {
                scenePath = scenePath,
                sceneGuid = AssetDatabase.AssetPathToGUID(scenePath),
                editModeGlobalObjectId = goid ?? string.Empty,
                siblingIndexPath = siblingPath,
                transformNamePath = namePath,
                prefabSourceGuid = prefabGuid ?? string.Empty,
                handSide = (int)handSide,
                targetRole = (int)role,
                hasSkinnedMeshRenderer = hasSmr,
                skeletonValid = skeletonValid,
                xrOriginHintName = xrOriginHint ?? string.Empty,
                controllerHierarchyHint = controllerHint ?? string.Empty,
                capturedAtUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture),
                isValid = true,
            };

            return true;
        }

        public static bool CaptureAndStore(
            Transform target,
            HandSide handSide,
            SceneObjectLocatorRole role,
            out SceneObjectLocatorData data,
            out string errorMessage)
        {
            if (!TryCapture(target, handSide, role, out data, out errorMessage))
                return false;

            Store(handSide, role, data);
            return true;
        }

        public static void Store(HandSide handSide, SceneObjectLocatorRole role, SceneObjectLocatorData data)
        {
            if (data == null)
                return;
            SessionState.SetString(StoredKey(handSide, role), JsonUtility.ToJson(data));
        }

        public static bool TryGetStored(
            HandSide handSide,
            SceneObjectLocatorRole role,
            out SceneObjectLocatorData data)
        {
            data = null;
            var json = SessionState.GetString(StoredKey(handSide, role), string.Empty);
            if (string.IsNullOrWhiteSpace(json))
                return false;

            try
            {
                data = JsonUtility.FromJson<SceneObjectLocatorData>(json);
                return data != null && data.isValid && data.handSide == (int)handSide;
            }
            catch
            {
                data = null;
                return false;
            }
        }

        public static void ClearStored(HandSide handSide, SceneObjectLocatorRole role)
        {
            SessionState.EraseString(StoredKey(handSide, role));
        }

        public static void ClearAllStored(HandSide handSide)
        {
            ClearStored(handSide, SceneObjectLocatorRole.PlaybackHandRoot);
            ClearStored(handSide, SceneObjectLocatorRole.VisualOffset);
        }

        public static ResolveResult Resolve(
            SceneObjectLocatorData locator,
            HandSide expectedHandSide,
            SceneObjectLocatorRole expectedRole,
            bool allowPlaybackFinderFallback)
        {
            var result = new ResolveResult();

            if (locator == null || !locator.isValid)
            {
                result.message = "Locator 데이터가 비어 있거나 유효하지 않습니다.";
                return result;
            }

            if ((HandSide)locator.handSide != expectedHandSide)
            {
                result.message =
                    $"Locator handSide={((HandSide)locator.handSide)}가 기대값={expectedHandSide}과 다릅니다.";
                return result;
            }

            if ((SceneObjectLocatorRole)locator.targetRole != expectedRole)
            {
                result.message =
                    $"Locator role={((SceneObjectLocatorRole)locator.targetRole)}가 기대값={expectedRole}과 다릅니다.";
                return result;
            }

            var activeScene = SceneManager.GetActiveScene();
            if (!activeScene.IsValid())
            {
                result.message = "활성 Scene이 없습니다.";
                return result;
            }

            var activePath = activeScene.path;
            if (string.IsNullOrWhiteSpace(activePath)
                || !string.Equals(activePath, locator.scenePath, StringComparison.OrdinalIgnoreCase))
            {
                result.message =
                    $"활성 Scene('{activePath}')이 Locator Scene('{locator.scenePath}')과 다릅니다.";
                return result;
            }

            // 1) Edit Mode GlobalObjectId
            if (!string.IsNullOrWhiteSpace(locator.editModeGlobalObjectId)
                && GlobalObjectId.TryParse(locator.editModeGlobalObjectId, out var goid))
            {
                var resolved = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(goid);
                var go = ResolveGameObject(resolved);
                if (go != null
                    && go.scene == activeScene
                    && TryValidateResolved(go.transform, locator, expectedHandSide, expectedRole, out _))
                {
                    result.success = true;
                    result.transform = go.transform;
                    result.resolveMethod = "EditModeGlobalObjectId";
                    result.message = "Edit Mode GlobalObjectId로 복원했습니다.";
                    return result;
                }
            }

            // 2) Scene Root + sibling index (+ name verification)
            string validateError = string.Empty;
            var siblingResolved = TryResolveBySiblingPath(activeScene, locator, out var byPath, out var pathMessage);
            var siblingValidated = false;
            if (siblingResolved)
                siblingValidated = TryValidateResolved(byPath, locator, expectedHandSide, expectedRole, out validateError);

            if (siblingResolved && siblingValidated)
            {
                result.success = true;
                result.transform = byPath;
                result.resolveMethod = "SiblingIndexPath";
                result.message = "Sibling index 경로로 복원했습니다.";
                return result;
            }

            if (byPath != null && !string.IsNullOrEmpty(validateError))
            {
                // continue to fallback
            }

            // 3) Playback finder fallback (exactly one candidate)
            if (allowPlaybackFinderFallback && expectedRole == SceneObjectLocatorRole.PlaybackHandRoot)
            {
                var find = HandPlaybackHandFinder.FindPlaybackHand(expectedHandSide);
                if (find.success && find.handRoot != null && find.candidates != null && find.candidates.Count == 1)
                {
                    if (find.handRoot.gameObject.scene == activeScene
                        && TryValidateResolved(
                            find.handRoot, locator, expectedHandSide, expectedRole, out _))
                    {
                        result.success = true;
                        result.transform = find.handRoot;
                        result.resolveMethod = "PlaybackHandFinderUnique";
                        result.message = "Playback Hand Finder 유일 후보로 복원했습니다.";
                        return result;
                    }
                }

                if (find.candidates != null && find.candidates.Count > 1)
                {
                    result.message =
                        $"Scene 대상 복원 실패: Playback Hand 후보가 {find.candidates.Count}개라 임의 적용하지 않습니다. " +
                        (pathMessage ?? string.Empty);
                    return result;
                }
            }

            result.message =
                "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다." +
                (string.IsNullOrEmpty(pathMessage) ? string.Empty : "\n" + pathMessage);
            return result;
        }

        public static bool TryValidateResolved(
            Transform resolved,
            SceneObjectLocatorData locator,
            HandSide expectedHandSide,
            SceneObjectLocatorRole expectedRole,
            out string errorMessage)
        {
            errorMessage = null;
            if (resolved == null)
            {
                errorMessage = "복원된 Transform이 null입니다.";
                return false;
            }

            if ((HandSide)locator.handSide != expectedHandSide)
            {
                errorMessage = "HandSide 불일치";
                return false;
            }

            if (!string.IsNullOrEmpty(locator.prefabSourceGuid)
                && PrefabUtility.IsPartOfPrefabInstance(resolved.gameObject))
            {
                var source = PrefabUtility.GetCorrespondingObjectFromSource(resolved.gameObject);
                if (source != null)
                {
                    var path = AssetDatabase.GetAssetPath(source);
                    var guid = string.IsNullOrEmpty(path) ? string.Empty : AssetDatabase.AssetPathToGUID(path);
                    if (!string.Equals(guid, locator.prefabSourceGuid, StringComparison.OrdinalIgnoreCase))
                    {
                        errorMessage = "Prefab source GUID가 Locator와 일치하지 않습니다.";
                        return false;
                    }
                }
            }
            else if (!string.IsNullOrEmpty(locator.prefabSourceGuid)
                     && !PrefabUtility.IsPartOfPrefabInstance(resolved.gameObject))
            {
                // Prefab이었던 대상이 일반 오브젝트가 된 경우 — 거부하지 않고 구조 검증으로 진행
            }

            if (expectedRole == SceneObjectLocatorRole.PlaybackHandRoot)
            {
                var validation = HandSkeletonCatalog.Validate(resolved, expectedHandSide);
                if (!validation.isValid)
                {
                    errorMessage = "HandSkeletonCatalog 검증 실패";
                    return false;
                }

                if (resolved.GetComponentInChildren<SkinnedMeshRenderer>(true) == null)
                {
                    errorMessage = "SkinnedMeshRenderer가 없습니다.";
                    return false;
                }

                if (!HandSideUtility.MatchesHandSide(resolved, expectedHandSide)
                    && HandSideUtility.ContainsOppositeHandBonePrefix(resolved.name, expectedHandSide))
                {
                    errorMessage = "반대 손 Root로 보입니다.";
                    return false;
                }
            }
            else if (expectedRole == SceneObjectLocatorRole.VisualOffset)
            {
                var expectedName = "VRHandPoseTool_VisualOffset_"
                    + (expectedHandSide == HandSide.Left ? "Left" : "Right");
                if (!string.Equals(resolved.name, expectedName, StringComparison.Ordinal))
                {
                    errorMessage = $"Visual Offset 이름 불일치 (기대: {expectedName})";
                    return false;
                }
            }

            return true;
        }

        public static bool TryBuildHierarchyPaths(
            Transform target,
            out int[] siblingIndexPath,
            out string[] transformNamePath,
            out string errorMessage)
        {
            siblingIndexPath = null;
            transformNamePath = null;
            errorMessage = null;

            if (target == null)
            {
                errorMessage = "대상이 null입니다.";
                return false;
            }

            var indices = new List<int>();
            var names = new List<string>();
            var current = target;

            while (current != null)
            {
                names.Insert(0, current.name);

                if (current.parent == null)
                {
                    var scene = current.gameObject.scene;
                    if (!scene.IsValid())
                    {
                        errorMessage = "Scene Root를 확인할 수 없습니다.";
                        return false;
                    }

                    var roots = scene.GetRootGameObjects();
                    var rootIndex = -1;
                    for (var i = 0; i < roots.Length; i++)
                    {
                        if (roots[i] != null && roots[i].transform == current)
                        {
                            rootIndex = i;
                            break;
                        }
                    }

                    if (rootIndex < 0)
                    {
                        errorMessage = "Scene Root 목록에서 대상을 찾지 못했습니다.";
                        return false;
                    }

                    indices.Insert(0, rootIndex);
                    break;
                }

                indices.Insert(0, current.GetSiblingIndex());
                current = current.parent;
            }

            siblingIndexPath = indices.ToArray();
            transformNamePath = names.ToArray();
            return true;
        }

        public static bool TryResolveBySiblingPath(
            Scene scene,
            SceneObjectLocatorData locator,
            out Transform resolved,
            out string message)
        {
            resolved = null;
            message = null;

            if (locator?.siblingIndexPath == null || locator.siblingIndexPath.Length == 0)
            {
                message = "sibling index 경로가 비어 있습니다.";
                return false;
            }

            var roots = scene.GetRootGameObjects();
            var rootIndex = locator.siblingIndexPath[0];
            if (rootIndex < 0 || rootIndex >= roots.Length)
            {
                message = $"Scene Root index {rootIndex}가 범위를 벗어났습니다.";
                return false;
            }

            var current = roots[rootIndex].transform;
            if (locator.transformNamePath != null
                && locator.transformNamePath.Length > 0
                && !string.Equals(current.name, locator.transformNamePath[0], StringComparison.Ordinal))
            {
                message =
                    $"Root 이름 불일치 (기대: {locator.transformNamePath[0]}, 실제: {current.name}). " +
                    "이름만으로 대체 탐색하지 않습니다.";
                return false;
            }

            for (var i = 1; i < locator.siblingIndexPath.Length; i++)
            {
                var childIndex = locator.siblingIndexPath[i];
                if (childIndex < 0 || childIndex >= current.childCount)
                {
                    message = $"경로 depth {i}에서 sibling index {childIndex}가 범위를 벗어났습니다.";
                    return false;
                }

                current = current.GetChild(childIndex);
                if (locator.transformNamePath != null
                    && i < locator.transformNamePath.Length
                    && !string.Equals(current.name, locator.transformNamePath[i], StringComparison.Ordinal))
                {
                    message =
                        $"경로 depth {i} 이름 불일치 (기대: {locator.transformNamePath[i]}, 실제: {current.name}).";
                    return false;
                }
            }

            resolved = current;
            message = "Sibling index 경로 해석 성공";
            return true;
        }

        static void FindHierarchyHints(Transform target, out string xrOriginHint, out string controllerHint)
        {
            xrOriginHint = string.Empty;
            controllerHint = string.Empty;
            var current = target;
            while (current != null)
            {
                if (string.IsNullOrEmpty(xrOriginHint)
                    && current.name.IndexOf("XR Origin", StringComparison.OrdinalIgnoreCase) >= 0)
                    xrOriginHint = current.name;

                if (string.IsNullOrEmpty(controllerHint)
                    && (current.name.IndexOf("Controller", StringComparison.OrdinalIgnoreCase) >= 0
                        || current.name.IndexOf("LeftHand", StringComparison.OrdinalIgnoreCase) >= 0
                        || current.name.IndexOf("RightHand", StringComparison.OrdinalIgnoreCase) >= 0))
                    controllerHint = current.name;

                current = current.parent;
            }
        }

        static bool TryGetEditModeGlobalObjectId(
            UnityEngine.Object target,
            out string globalObjectIdString,
            out string errorMessage)
        {
            globalObjectIdString = null;
            errorMessage = null;
            if (target == null)
            {
                errorMessage = "null";
                return false;
            }

            try
            {
                var goid = GlobalObjectId.GetGlobalObjectIdSlow(target);
                globalObjectIdString = goid.ToString();
                if (string.IsNullOrWhiteSpace(globalObjectIdString)
                    || globalObjectIdString == InvalidGoid)
                {
                    errorMessage = "invalid goid";
                    globalObjectIdString = string.Empty;
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return false;
            }
        }

        static GameObject ResolveGameObject(UnityEngine.Object resolvedObject)
        {
            if (resolvedObject == null) return null;
            if (resolvedObject is GameObject go) return go;
            if (resolvedObject is Component c) return c.gameObject;
            return null;
        }

        static string StoredKey(HandSide handSide, SceneObjectLocatorRole role) =>
            StoredJsonKeyPrefix + handSide + "." + role;

        /// <summary>테스트용: Locator JSON 직렬화 왕복.</summary>
        public static string ToJson(SceneObjectLocatorData data) => JsonUtility.ToJson(data);

        public static SceneObjectLocatorData FromJson(string json) =>
            string.IsNullOrWhiteSpace(json) ? null : JsonUtility.FromJson<SceneObjectLocatorData>(json);

        public static string Describe(SceneObjectLocatorData data)
        {
            if (data == null) return "(null)";
            var sb = new StringBuilder();
            sb.Append("role=").Append((SceneObjectLocatorRole)data.targetRole);
            sb.Append(" side=").Append((HandSide)data.handSide);
            sb.Append(" scene=").Append(data.scenePath);
            if (data.siblingIndexPath != null)
                sb.Append(" path=[").Append(string.Join(",", data.siblingIndexPath)).Append(']');
            return sb.ToString();
        }
    }
}
