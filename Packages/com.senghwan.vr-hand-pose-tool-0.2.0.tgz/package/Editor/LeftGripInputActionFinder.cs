using System.Collections.Generic;
using UnityEngine.InputSystem;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 왼손 Grip InputAction 탐색의 하위 호환 래퍼입니다.
    /// 구현은 <see cref="HandGripInputActionFinder"/>에 위임합니다.
    /// </summary>
    public static class LeftGripInputActionFinder
    {
        public const string PreferredActionMapName = "XRI Left Interaction";
        public const string PreferredActionName = HandGripInputActionFinder.PreferredActionName;
        public const string ReferenceOutputFolder = HandGripInputActionFinder.ReferenceOutputFolder;
        public const string PreferredReferenceAssetPath = ReferenceOutputFolder + "/Left_Grip_Select_Value.asset";

        public struct CandidateInfo
        {
            public string inputActionAssetPath;
            public string actionMapName;
            public string actionName;
            public string actionId;
            public string actionType;
            public string expectedControlType;
            public string bindingPath;
            public int score;
        }

        public struct FindResult
        {
            public bool success;
            public bool requiresUserSelection;
            public List<CandidateInfo> tiedCandidates;

            public string inputActionAssetPath;
            public string actionMapName;
            public string actionName;
            public string actionId;
            public string actionType;
            public string expectedControlType;
            public string bindingPath;

            public InputActionReference inputActionReference;
            public string referenceAssetPath;
            public bool reusedExistingReference;
            public bool createdNewReference;

            public string failureReason;
            public string displaySummary;
        }

        public static FindResult FindAndResolveReference(CandidateInfo? selectedCandidate = null)
        {
            return ToLegacy(
                HandGripInputActionFinder.FindAndResolveReference(
                    HandSide.Left,
                    selectedCandidate.HasValue ? ToShared(selectedCandidate.Value) : null));
        }

        public static FindResult ResolveReferenceForCandidate(CandidateInfo candidate)
        {
            return ToLegacy(HandGripInputActionFinder.ResolveReferenceForCandidate(HandSide.Left, ToShared(candidate)));
        }

        public static string FormatCandidateLabel(CandidateInfo candidate)
        {
            return HandGripInputActionFinder.FormatCandidateLabel(ToShared(candidate));
        }

        static HandGripInputActionFinder.CandidateInfo ToShared(CandidateInfo candidate)
        {
            return new HandGripInputActionFinder.CandidateInfo
            {
                inputActionAssetPath = candidate.inputActionAssetPath,
                actionMapName = candidate.actionMapName,
                actionName = candidate.actionName,
                actionId = candidate.actionId,
                actionType = candidate.actionType,
                expectedControlType = candidate.expectedControlType,
                bindingPath = candidate.bindingPath,
                score = candidate.score,
            };
        }

        static CandidateInfo ToLegacy(HandGripInputActionFinder.CandidateInfo candidate)
        {
            return new CandidateInfo
            {
                inputActionAssetPath = candidate.inputActionAssetPath,
                actionMapName = candidate.actionMapName,
                actionName = candidate.actionName,
                actionId = candidate.actionId,
                actionType = candidate.actionType,
                expectedControlType = candidate.expectedControlType,
                bindingPath = candidate.bindingPath,
                score = candidate.score,
            };
        }

        static FindResult ToLegacy(HandGripInputActionFinder.FindResult result)
        {
            List<CandidateInfo> tiedCandidates = null;
            if (result.tiedCandidates != null)
            {
                tiedCandidates = new List<CandidateInfo>(result.tiedCandidates.Count);
                foreach (var candidate in result.tiedCandidates)
                {
                    tiedCandidates.Add(ToLegacy(candidate));
                }
            }

            return new FindResult
            {
                success = result.success,
                requiresUserSelection = result.requiresUserSelection,
                tiedCandidates = tiedCandidates,
                inputActionAssetPath = result.inputActionAssetPath,
                actionMapName = result.actionMapName,
                actionName = result.actionName,
                actionId = result.actionId,
                actionType = result.actionType,
                expectedControlType = result.expectedControlType,
                bindingPath = result.bindingPath,
                inputActionReference = result.inputActionReference,
                referenceAssetPath = result.referenceAssetPath,
                reusedExistingReference = result.reusedExistingReference,
                createdNewReference = result.createdNewReference,
                failureReason = result.failureReason,
                displaySummary = result.displaySummary,
            };
        }
    }
}
