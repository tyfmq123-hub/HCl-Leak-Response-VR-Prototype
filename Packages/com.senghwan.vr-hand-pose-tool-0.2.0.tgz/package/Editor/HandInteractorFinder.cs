using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Left/Right Controller 계층에서 XR Interactor 후보를 탐색합니다.
    /// </summary>
    public static class HandInteractorFinder
    {
        public const string GenericDirectInteractorName = "Direct Interactor";

        public struct Candidate
        {
            public XRBaseInteractor interactor;
            public string hierarchyPath;
            public string objectName;
            public string componentTypeName;
            public bool underControllerHierarchy;
        }

        public static List<Candidate> FindInteractorCandidates(HandSide handSide)
        {
            var candidates = new List<Candidate>();
            var seenInstanceIds = new HashSet<int>();
            var nearFarName = GetNearFarInteractorName(handSide);
            var directName = GetDirectInteractorName(handSide);
            var controllerToken = HandSideUtility.GetControllerNameToken(handSide);

            var allInteractors = Resources.FindObjectsOfTypeAll<XRBaseInteractor>();
            foreach (var interactor in allInteractors)
            {
                if (interactor == null || interactor.hideFlags != HideFlags.None)
                    continue;

                if (!interactor.gameObject.scene.IsValid())
                    continue;

                if (!seenInstanceIds.Add(interactor.GetInstanceID()))
                    continue;

                var transform = interactor.transform;
                var objectName = transform.name;
                if (!IsTargetInteractorName(objectName, nearFarName, directName))
                    continue;

                var underControllerHierarchy = IsUnderControllerHierarchy(transform, controllerToken);
                if (!underControllerHierarchy)
                    continue;

                candidates.Add(new Candidate
                {
                    interactor = interactor,
                    hierarchyPath = HandPoseCaptureService.GetHierarchyPath(transform),
                    objectName = objectName,
                    componentTypeName = interactor.GetType().Name,
                    underControllerHierarchy = underControllerHierarchy,
                });
            }

            candidates.Sort(CompareCandidates);
            return candidates;
        }

        public static string GetNearFarInteractorName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_NearFarInteractor" : "Right_NearFarInteractor";
        }

        public static string GetDirectInteractorName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left Direct Interactor" : "Right Direct Interactor";
        }

        static bool IsTargetInteractorName(string objectName, string nearFarName, string directName)
        {
            if (string.Equals(objectName, nearFarName, StringComparison.Ordinal))
                return true;

            if (string.Equals(objectName, directName, StringComparison.Ordinal))
                return true;

            return string.Equals(objectName, GenericDirectInteractorName, StringComparison.Ordinal);
        }

        static bool IsUnderControllerHierarchy(Transform transform, string controllerToken)
        {
            var current = transform;
            while (current != null)
            {
                if (current.name.IndexOf(controllerToken, StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;

                current = current.parent;
            }

            return false;
        }

        static int CompareCandidates(Candidate left, Candidate right)
        {
            var nameCompare = string.Compare(left.objectName, right.objectName, StringComparison.OrdinalIgnoreCase);
            if (nameCompare != 0)
                return nameCompare;

            return string.Compare(left.hierarchyPath, right.hierarchyPath, StringComparison.OrdinalIgnoreCase);
        }
    }
}
