using System;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play Mode에서 요청한 Controller Hand 설정을 SessionState에 보관하고,
    /// EnteredEditMode에서 Edit Mode Locator로 Scene 오브젝트를 복원해 영구 적용합니다.
    /// </summary>
    [InitializeOnLoad]
    public static class HandPoseControllerHandPendingSetupBridge
    {
        const string PendingJsonKeyPrefix = "VRHandPoseTool.ControllerHandSetup.PendingJson.";
        const string LastMessageKeyPrefix = "VRHandPoseTool.ControllerHandSetup.LastMessage.";
        const string LastSucceededKeyPrefix = "VRHandPoseTool.ControllerHandSetup.LastSucceeded.";
        const string StatusKeyPrefix = "VRHandPoseTool.ControllerHandSetup.Status.";

        public enum PendingLifecycleStatus
        {
            None = 0,
            PendingWaitingForEditMode = 1,
            ApplyingInEditMode = 2,
            Applied = 3,
            FailedToResolveTarget = 4,
            FailedToApply = 5,
        }

        [Serializable]
        public sealed class PendingSetupData
        {
            public string applyToken;
            public string scenePath;
            public string playbackHandRootGlobalObjectId; // legacy / diagnostic only
            public string playbackLocatorJson;
            public int handSide;
            public string animatorControllerGuid;
            public string gripActionReferenceGuid;
            public string gripActionId;
            public string gripParameterName;
            public bool useSmoothing;
            public float smoothingSpeed;
            public int gripControlMode;
            public string createdAtUtc;
            public bool autoApplyAttempted;
            public string lastFailureReason;
            public int lifecycleStatus;
        }

        public struct RegisterResult
        {
            public bool success;
            public string message;
        }

        public struct ApplyResult
        {
            public bool success;
            public string message;
        }

        static HandPoseControllerHandPendingSetupBridge()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            EditorApplication.delayCall -= TryApplyAllPendingOnEditMode;
            EditorApplication.delayCall += TryApplyAllPendingOnEditMode;
        }

        public static bool HasPending(HandSide handSide) => TryLoadPending(handSide, out _);

        public static bool IsWaitingForEditMode(HandSide handSide)
        {
            var status = GetStatus(handSide);
            return status == PendingLifecycleStatus.PendingWaitingForEditMode
                   || status == PendingLifecycleStatus.ApplyingInEditMode;
        }

        public static bool HasFailedPending(HandSide handSide)
        {
            var status = GetStatus(handSide);
            return status == PendingLifecycleStatus.FailedToResolveTarget
                   || status == PendingLifecycleStatus.FailedToApply;
        }

        public static PendingLifecycleStatus GetStatus(HandSide handSide)
        {
            if (TryLoadPending(handSide, out var pending))
            {
                if (pending.lifecycleStatus != 0)
                    return (PendingLifecycleStatus)pending.lifecycleStatus;
                if (pending.autoApplyAttempted)
                {
                    return IsResolveFailureMessage(pending.lastFailureReason)
                        ? PendingLifecycleStatus.FailedToResolveTarget
                        : PendingLifecycleStatus.FailedToApply;
                }

                return PendingLifecycleStatus.PendingWaitingForEditMode;
            }

            if (GetLastSucceeded(handSide))
                return PendingLifecycleStatus.Applied;

            var stored = SessionState.GetInt(StatusKey(handSide), 0);
            return (PendingLifecycleStatus)stored;
        }

        public static string GetStatusUiMessage(HandSide handSide)
        {
            var status = GetStatus(handSide);
            switch (status)
            {
                case PendingLifecycleStatus.PendingWaitingForEditMode:
                    return "Play Mode를 종료한 뒤 Controller 설정을 Scene에 적용합니다.";
                case PendingLifecycleStatus.ApplyingInEditMode:
                    return "Edit Mode Scene에 Controller 설정을 적용하는 중…";
                case PendingLifecycleStatus.Applied:
                    return string.IsNullOrEmpty(GetLastMessage(handSide))
                        ? "Controller 설정이 Scene에 적용되었습니다. Scene을 저장하세요."
                        : GetLastMessage(handSide);
                case PendingLifecycleStatus.FailedToResolveTarget:
                    return "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다.";
                case PendingLifecycleStatus.FailedToApply:
                    return string.IsNullOrEmpty(GetLastMessage(handSide))
                        ? "Controller 설정 적용에 실패했습니다."
                        : GetLastMessage(handSide);
                default:
                    return null;
            }
        }

        public static string GetLastMessage(HandSide handSide) =>
            SessionState.GetString(LastMessageKey(handSide), string.Empty);

        public static bool GetLastSucceeded(HandSide handSide) =>
            SessionState.GetBool(LastSucceededKey(handSide), false);

        public static RegisterResult TryRegisterAndExitPlayMode(
            HandSide handSide,
            Transform playbackHandRoot,
            RuntimeAnimatorController animatorController,
            InputActionReference gripActionReference,
            string gripParameterName,
            bool useSmoothing,
            float smoothingSpeed,
            HandGripControlMode gripControlMode)
        {
            if (!EditorApplication.isPlaying)
            {
                return Failed("Play Mode에서만 pending setup을 등록할 수 있습니다. Edit Mode에서는 즉시 적용하세요.");
            }

            if (playbackHandRoot == null)
                return Failed("Playback Hand Root가 지정되지 않았습니다.");

            if (!HandSceneObjectLocator.TryGetStored(
                    handSide,
                    SceneObjectLocatorRole.PlaybackHandRoot,
                    out var locator)
                || locator == null
                || !locator.isValid)
            {
                return Failed(
                    "Edit Mode Locator가 없습니다. Play Mode 진입 전에 Playback Hand Root를 지정하거나 " +
                    "Edit Mode에서 [현재 Edit Mode Scene에 Controller 설정 재적용]을 사용하세요.");
            }

            var scenePath = locator.scenePath;
            if (string.IsNullOrWhiteSpace(scenePath))
            {
                return Failed(
                    "Locator Scene 경로가 비어 있습니다. Edit Mode에서 Scene을 저장한 뒤 Locator를 다시 캡처하세요.");
            }

            if (animatorController == null)
                return Failed("Animator Controller가 지정되지 않았습니다.");

            var controllerPath = AssetDatabase.GetAssetPath(animatorController);
            var controllerGuid = string.IsNullOrEmpty(controllerPath)
                ? string.Empty
                : AssetDatabase.AssetPathToGUID(controllerPath);
            if (string.IsNullOrEmpty(controllerGuid))
                return Failed("Animator Controller Asset GUID를 구할 수 없습니다.");

            string gripRefGuid = string.Empty;
            string gripActionId = string.Empty;
            if (gripControlMode == HandGripControlMode.ToolDefault)
            {
                if (gripActionReference == null)
                    return Failed("Grip InputActionReference가 지정되지 않았습니다.");

                var gripPath = AssetDatabase.GetAssetPath(gripActionReference);
                gripRefGuid = string.IsNullOrEmpty(gripPath)
                    ? string.Empty
                    : AssetDatabase.AssetPathToGUID(gripPath);
                if (string.IsNullOrEmpty(gripRefGuid))
                    return Failed("Grip InputActionReference Asset GUID를 구할 수 없습니다.");

                var action = gripActionReference.action;
                if (action == null)
                    return Failed("Grip InputActionReference에서 action을 resolve할 수 없습니다.");

                gripActionId = action.id.ToString();
            }

            if (string.IsNullOrWhiteSpace(gripParameterName))
                return Failed("Grip Parameter Name이 비어 있습니다.");

            var pending = new PendingSetupData
            {
                applyToken = Guid.NewGuid().ToString("N"),
                scenePath = scenePath,
                playbackHandRootGlobalObjectId = locator.editModeGlobalObjectId ?? string.Empty,
                playbackLocatorJson = HandSceneObjectLocator.ToJson(locator),
                handSide = (int)handSide,
                animatorControllerGuid = controllerGuid,
                gripActionReferenceGuid = gripRefGuid,
                gripActionId = gripActionId,
                gripParameterName = gripParameterName,
                useSmoothing = useSmoothing,
                smoothingSpeed = smoothingSpeed,
                gripControlMode = (int)gripControlMode,
                createdAtUtc = DateTime.UtcNow.ToString("o"),
                autoApplyAttempted = false,
                lastFailureReason = string.Empty,
                lifecycleStatus = (int)PendingLifecycleStatus.PendingWaitingForEditMode,
            };

            SavePending(handSide, pending);
            SetStatus(handSide, PendingLifecycleStatus.PendingWaitingForEditMode);
            ClearLastMessage(handSide);

            EditorApplication.isPlaying = false;

            return new RegisterResult
            {
                success = true,
                message = "Play Mode를 종료한 뒤 Controller 설정을 Scene에 적용합니다.",
            };
        }

        /// <summary>
        /// Edit Mode에서 현재 Playback Root에 즉시 재적용합니다.
        /// 실패 pending의 설정값을 재사용하되, Play Mode GOID는 사용하지 않습니다.
        /// </summary>
        public static ApplyResult TryReapplyInEditMode(
            HandSide handSide,
            Transform playbackHandRoot,
            RuntimeAnimatorController animatorController,
            InputActionReference gripActionReference,
            string gripParameterName,
            bool useSmoothing,
            float smoothingSpeed,
            HandGripControlMode gripControlMode)
        {
            if (EditorApplication.isPlaying)
            {
                return new ApplyResult
                {
                    success = false,
                    message = "Edit Mode에서만 재적용할 수 있습니다.",
                };
            }

            if (playbackHandRoot == null)
            {
                return new ApplyResult
                {
                    success = false,
                    message = "Playback Hand Root가 지정되지 않았습니다.",
                };
            }

            // pending 설정값 재사용 (자산 GUID)
            if (TryLoadPending(handSide, out var pending))
            {
                if (animatorController == null && !string.IsNullOrEmpty(pending.animatorControllerGuid))
                {
                    var path = AssetDatabase.GUIDToAssetPath(pending.animatorControllerGuid);
                    animatorController = AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(path);
                }

                if (gripActionReference == null && !string.IsNullOrEmpty(pending.gripActionReferenceGuid))
                {
                    TryResolveGripActionReference(
                        pending.gripActionReferenceGuid,
                        pending.gripActionId,
                        out gripActionReference,
                        out _);
                }

                if (string.IsNullOrWhiteSpace(gripParameterName) && !string.IsNullOrWhiteSpace(pending.gripParameterName))
                    gripParameterName = pending.gripParameterName;

                if (pending.gripControlMode == (int)HandGripControlMode.ProjectLegacy
                    || pending.gripControlMode == (int)HandGripControlMode.ToolDefault)
                    gripControlMode = (HandGripControlMode)pending.gripControlMode;

                useSmoothing = pending.useSmoothing;
                smoothingSpeed = pending.smoothingSpeed;
            }

            if (!HandSceneObjectLocator.CaptureAndStore(
                    playbackHandRoot,
                    handSide,
                    SceneObjectLocatorRole.PlaybackHandRoot,
                    out _,
                    out var locatorError))
            {
                return new ApplyResult
                {
                    success = false,
                    message = "Locator 캡처 실패: " + locatorError,
                };
            }

            SetStatus(handSide, PendingLifecycleStatus.ApplyingInEditMode);

            var apply = HandPoseControllerHandSetupService.ApplySetup(
                playbackHandRoot,
                animatorController,
                gripActionReference,
                gripParameterName,
                useSmoothing,
                smoothingSpeed,
                handSide,
                gripControlMode);

            if (!apply.success)
            {
                SetStatus(handSide, PendingLifecycleStatus.FailedToApply);
                SetLastMessage(handSide, apply.message, succeeded: false);
                if (TryLoadPending(handSide, out var failPending))
                {
                    failPending.autoApplyAttempted = true;
                    failPending.lastFailureReason = apply.message;
                    failPending.lifecycleStatus = (int)PendingLifecycleStatus.FailedToApply;
                    SavePending(handSide, failPending);
                }

                return new ApplyResult { success = false, message = apply.message };
            }

            RecordPrefabModifications(playbackHandRoot.gameObject);

            if (gripControlMode == HandGripControlMode.ToolDefault)
            {
                var verify = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                    playbackHandRoot,
                    animatorController,
                    gripActionReference,
                    gripParameterName);
                if (!verify.isValid)
                {
                    var msg = "재적용 후 검증 실패: " + (verify.failureReason ?? "검증 실패");
                    SetStatus(handSide, PendingLifecycleStatus.FailedToApply);
                    SetLastMessage(handSide, msg, succeeded: false);
                    return new ApplyResult { success = false, message = msg };
                }
            }

            if (playbackHandRoot.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);

            ClearPending(handSide);
            var successMsg = "Controller 설정이 Scene에 적용되었습니다. Scene을 저장하세요.\n"
                             + (apply.summary ?? string.Empty);
            SetStatus(handSide, PendingLifecycleStatus.Applied);
            SetLastMessage(handSide, successMsg.TrimEnd(), succeeded: true);
            return new ApplyResult { success = true, message = successMsg.TrimEnd() };
        }

        public static ApplyResult TryApplyPendingNow(HandSide handSide, bool forceRetry = true)
        {
            var ok = TryApplyPending(handSide, forceRetry, out var message);
            return new ApplyResult { success = ok, message = message };
        }

        public static void ClearPending(HandSide handSide)
        {
            SessionState.EraseString(PendingJsonKey(handSide));
        }

        public static void ClearPendingStatus(HandSide handSide)
        {
            ClearPending(handSide);
            ClearLastMessage(handSide);
            SessionState.EraseInt(StatusKey(handSide));
        }

        public static void ClearAllPendingStatuses()
        {
            ClearPendingStatus(HandSide.Left);
            ClearPendingStatus(HandSide.Right);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Left);
            HandControllerVisualAlignmentService.ClearPendingStatus(HandSide.Right);
        }

        public static void SavePendingForTests(HandSide handSide, PendingSetupData pending) =>
            SavePending(handSide, pending);

        public static bool TryLoadPendingForTests(HandSide handSide, out PendingSetupData pending) =>
            TryLoadPending(handSide, out pending);

        public static ApplyResult TryApplyPendingInternalForTests(PendingSetupData pending)
        {
            var ok = TryApplyPendingInternal(pending, out var message);
            return new ApplyResult { success = ok, message = message };
        }

        static void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state != PlayModeStateChange.EnteredEditMode)
                return;

            EditorApplication.delayCall -= TryApplyAllPendingOnEditMode;
            EditorApplication.delayCall += TryApplyAllPendingOnEditMode;
        }

        static void TryApplyAllPendingOnEditMode()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            TryApplyPending(HandSide.Left, forceRetry: false, out _);
            TryApplyPending(HandSide.Right, forceRetry: false, out _);
        }

        static bool TryApplyPending(HandSide handSide, bool forceRetry, out string message)
        {
            message = null;

            if (!TryLoadPending(handSide, out var pending))
            {
                message = "적용 대기 중인 Controller 설정이 없습니다.";
                return false;
            }

            if ((HandSide)pending.handSide != handSide)
            {
                message = "Pending handSide가 요청 handSide와 일치하지 않습니다.";
                MarkFailed(handSide, pending, message, PendingLifecycleStatus.FailedToApply);
                return false;
            }

            var status = (PendingLifecycleStatus)pending.lifecycleStatus;
            if (pending.autoApplyAttempted
                && !forceRetry
                && (status == PendingLifecycleStatus.FailedToResolveTarget
                    || status == PendingLifecycleStatus.FailedToApply
                    || status == 0))
            {
                message = string.IsNullOrEmpty(pending.lastFailureReason)
                    ? GetLastMessage(handSide)
                    : pending.lastFailureReason;
                return false;
            }

            SetStatus(handSide, PendingLifecycleStatus.ApplyingInEditMode);
            pending.lifecycleStatus = (int)PendingLifecycleStatus.ApplyingInEditMode;
            SavePending(handSide, pending);

            if (!TryApplyPendingInternal(pending, out message))
            {
                var failStatus = IsResolveFailureMessage(message)
                    ? PendingLifecycleStatus.FailedToResolveTarget
                    : PendingLifecycleStatus.FailedToApply;
                MarkFailed(handSide, pending, message, failStatus);
                return false;
            }

            ClearPending(handSide);
            SetStatus(handSide, PendingLifecycleStatus.Applied);
            SetLastMessage(handSide, message, succeeded: true);
            return true;
        }

        static bool TryApplyPendingInternal(PendingSetupData pending, out string message)
        {
            message = null;

            if (pending == null || string.IsNullOrWhiteSpace(pending.applyToken))
            {
                message = "자동 적용 실패: pending applyToken이 비어 있습니다.";
                return false;
            }

            var handSide = (HandSide)pending.handSide;
            var locator = HandSceneObjectLocator.FromJson(pending.playbackLocatorJson);

            // 구버전 pending(locator 없음) — Edit Mode 저장 Locator 또는 실패
            if (locator == null || !locator.isValid)
            {
                if (!HandSceneObjectLocator.TryGetStored(
                        handSide, SceneObjectLocatorRole.PlaybackHandRoot, out locator)
                    || locator == null
                    || !locator.isValid)
                {
                    message =
                        "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다.\n" +
                        "(Edit Mode Locator가 pending에 없습니다. Play Mode GlobalObjectId는 사용하지 않습니다.)";
                    return false;
                }
            }

            var resolve = HandSceneObjectLocator.Resolve(
                locator,
                handSide,
                SceneObjectLocatorRole.PlaybackHandRoot,
                allowPlaybackFinderFallback: true);

            if (!resolve.success || resolve.transform == null)
            {
                message = string.IsNullOrEmpty(resolve.message)
                    ? "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다."
                    : resolve.message;
                return false;
            }

            var rootGo = resolve.transform.gameObject;

            var controllerPath = AssetDatabase.GUIDToAssetPath(pending.animatorControllerGuid);
            var animatorController = string.IsNullOrEmpty(controllerPath)
                ? null
                : AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(controllerPath);
            if (animatorController == null)
            {
                message = $"자동 적용 실패: AnimatorController를 찾을 수 없습니다. (GUID={pending.animatorControllerGuid})";
                return false;
            }

            InputActionReference gripActionReference = null;
            var gripControlMode = (HandGripControlMode)pending.gripControlMode;
            if (gripControlMode == HandGripControlMode.ToolDefault)
            {
                if (!TryResolveGripActionReference(
                        pending.gripActionReferenceGuid,
                        pending.gripActionId,
                        out gripActionReference,
                        out var gripError))
                {
                    message = gripError;
                    return false;
                }
            }

            var apply = HandPoseControllerHandSetupService.ApplySetup(
                rootGo.transform,
                animatorController,
                gripActionReference,
                pending.gripParameterName,
                pending.useSmoothing,
                pending.smoothingSpeed,
                handSide,
                gripControlMode);

            if (!apply.success)
            {
                message = "자동 적용 실패: " + (apply.message ?? "ApplySetup 실패");
                return false;
            }

            RecordPrefabModifications(rootGo);

            if (gripControlMode == HandGripControlMode.ToolDefault)
            {
                var verify = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                    rootGo.transform,
                    animatorController,
                    gripActionReference,
                    pending.gripParameterName);

                if (!verify.isValid)
                {
                    message =
                        "자동 적용 후 검증 실패: " +
                        (verify.failureReason ?? "Grip Driver/InputActionManager 연결을 확인할 수 없습니다.");
                    return false;
                }
            }

            if (rootGo.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(rootGo.scene);

            var sb = new StringBuilder();
            sb.AppendLine("Controller 설정이 Scene에 적용되었습니다. Scene을 저장하세요.");
            sb.AppendLine($"복원 방법: {resolve.resolveMethod}");
            if (!string.IsNullOrEmpty(apply.summary))
                sb.Append(apply.summary);
            message = sb.ToString().TrimEnd();
            return true;
        }

        static void MarkFailed(
            HandSide handSide,
            PendingSetupData pending,
            string message,
            PendingLifecycleStatus status)
        {
            pending.autoApplyAttempted = true;
            pending.lastFailureReason = message;
            pending.lifecycleStatus = (int)status;
            SavePending(handSide, pending);
            SetStatus(handSide, status);
            SetLastMessage(handSide, message, succeeded: false);
        }

        static bool IsResolveFailureMessage(string message)
        {
            if (string.IsNullOrEmpty(message))
                return false;
            return message.IndexOf("복원 실패", StringComparison.Ordinal) >= 0
                   || message.IndexOf("GlobalObjectId", StringComparison.Ordinal) >= 0
                   || message.IndexOf("Locator", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        static bool TryResolveGripActionReference(
            string gripActionReferenceGuid,
            string gripActionId,
            out InputActionReference reference,
            out string errorMessage)
        {
            reference = null;
            errorMessage = null;

            var path = AssetDatabase.GUIDToAssetPath(gripActionReferenceGuid);
            if (string.IsNullOrEmpty(path))
            {
                errorMessage =
                    $"자동 적용 실패: Grip InputActionReference GUID를 해석할 수 없습니다. ({gripActionReferenceGuid})";
                return false;
            }

            reference = AssetDatabase.LoadAssetAtPath<InputActionReference>(path);
            if (reference == null)
            {
                errorMessage = $"자동 적용 실패: Grip InputActionReference를 로드할 수 없습니다. ({path})";
                return false;
            }

            var action = reference.action;
            if (action == null)
            {
                errorMessage = "자동 적용 실패: Grip InputActionReference의 action을 resolve할 수 없습니다.";
                return false;
            }

            if (!string.IsNullOrEmpty(gripActionId)
                && !string.Equals(action.id.ToString(), gripActionId, StringComparison.Ordinal))
            {
                errorMessage =
                    "자동 적용 실패: Grip Action ID가 pending 값과 일치하지 않습니다. " +
                    "다른 Action에는 적용하지 않습니다.";
                reference = null;
                return false;
            }

            return true;
        }

        static void RecordPrefabModifications(GameObject rootGo)
        {
            if (rootGo == null)
                return;

            if (PrefabUtility.IsPartOfPrefabInstance(rootGo))
            {
                PrefabUtility.RecordPrefabInstancePropertyModifications(rootGo);
                foreach (var behaviour in rootGo.GetComponents<MonoBehaviour>())
                {
                    if (behaviour != null)
                        PrefabUtility.RecordPrefabInstancePropertyModifications(behaviour);
                }
            }

            var animator = rootGo.GetComponent<Animator>();
            if (animator != null && PrefabUtility.IsPartOfPrefabInstance(animator))
                PrefabUtility.RecordPrefabInstancePropertyModifications(animator);

            var manager = HandPoseControllerHandSetupService.FindInputActionManagerForPlaybackHand(rootGo.transform);
            if (manager != null && PrefabUtility.IsPartOfPrefabInstance(manager))
                PrefabUtility.RecordPrefabInstancePropertyModifications(manager);
        }

        static bool TryLoadPending(HandSide handSide, out PendingSetupData pending)
        {
            pending = null;
            var json = SessionState.GetString(PendingJsonKey(handSide), string.Empty);
            if (string.IsNullOrWhiteSpace(json))
                return false;

            try
            {
                pending = JsonUtility.FromJson<PendingSetupData>(json);
                return pending != null
                    && !string.IsNullOrWhiteSpace(pending.applyToken)
                    && !string.IsNullOrWhiteSpace(pending.scenePath)
                    && pending.handSide == (int)handSide;
            }
            catch
            {
                pending = null;
                return false;
            }
        }

        static void SavePending(HandSide handSide, PendingSetupData pending)
        {
            SessionState.SetString(PendingJsonKey(handSide), JsonUtility.ToJson(pending));
        }

        static void SetStatus(HandSide handSide, PendingLifecycleStatus status)
        {
            SessionState.SetInt(StatusKey(handSide), (int)status);
        }

        static void SetLastMessage(HandSide handSide, string message, bool succeeded)
        {
            SessionState.SetString(LastMessageKey(handSide), message ?? string.Empty);
            SessionState.SetBool(LastSucceededKey(handSide), succeeded);
        }

        static void ClearLastMessage(HandSide handSide)
        {
            SessionState.EraseString(LastMessageKey(handSide));
            SessionState.SetBool(LastSucceededKey(handSide), false);
        }

        static string PendingJsonKey(HandSide handSide) => PendingJsonKeyPrefix + handSide;
        static string LastMessageKey(HandSide handSide) => LastMessageKeyPrefix + handSide;
        static string LastSucceededKey(HandSide handSide) => LastSucceededKeyPrefix + handSide;
        static string StatusKey(HandSide handSide) => StatusKeyPrefix + handSide;

        static RegisterResult Failed(string message) =>
            new RegisterResult { success = false, message = message };
    }
}
