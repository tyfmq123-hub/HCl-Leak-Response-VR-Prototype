using System;
using System.Linq;
using UnityEditor.PackageManager;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 프로젝트에 등록된 com.unity.xr.hands 패키지 설치 여부와 실제 버전을 조회합니다.
    /// </summary>
    public static class XrHandsPackageResolver
    {
        public const string PackageName = "com.unity.xr.hands";

        public struct ResolveResult
        {
            public bool success;
            public string packageName;
            public string version;
            public string displayName;
            public PackageSource source;
            public string message;
        }

        public static ResolveResult ResolveInstalled()
        {
            var result = new ResolveResult
            {
                packageName = PackageName,
            };

            PackageInfo packageInfo = null;

            try
            {
                packageInfo = PackageInfo.FindForPackageName(PackageName);
            }
            catch (Exception ex)
            {
                result.message =
                    $"XR Hands 패키지 조회 중 예외가 발생했습니다: {ex.Message}";
                return result;
            }

            if (packageInfo == null)
            {
                try
                {
                    packageInfo = PackageInfo.GetAllRegisteredPackages()
                        .FirstOrDefault(info =>
                            info != null
                            && string.Equals(info.name, PackageName, StringComparison.OrdinalIgnoreCase));
                }
                catch (Exception ex)
                {
                    result.message =
                        $"등록된 패키지 목록 조회 중 예외가 발생했습니다: {ex.Message}";
                    return result;
                }
            }

            if (packageInfo == null || string.IsNullOrEmpty(packageInfo.version))
            {
                result.message =
                    $"XR Hands 패키지({PackageName})가 프로젝트에 설치되어 있지 않습니다.\n" +
                    "Package Manager에서 com.unity.xr.hands를 설치하거나, " +
                    "com.senghwan.vr-hand-pose-tool 패키지 의존성으로 설치되는지 확인하세요. Client.Add를 자동 실행하지 않습니다.";
                return result;
            }

            result.success = true;
            result.version = packageInfo.version;
            result.displayName = string.IsNullOrEmpty(packageInfo.displayName)
                ? "XR Hands"
                : packageInfo.displayName;
            result.source = packageInfo.source;
            result.message =
                $"{result.displayName} {result.version} 설치 확인 ({result.source})";
            return result;
        }

        public static bool IsInstalled(out string version, out string message)
        {
            var resolve = ResolveInstalled();
            version = resolve.version;
            message = resolve.message;
            return resolve.success;
        }
    }
}
