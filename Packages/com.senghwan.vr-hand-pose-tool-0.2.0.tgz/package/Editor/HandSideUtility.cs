using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Hand Side별 이름·경로·바인딩 규칙을 제공합니다.
    /// </summary>
    public static class HandSideUtility
    {
        public const string PosesOutputFolder = "Assets/VRHandPoseToolOutput/Poses";
        public const string AnimationsOutputFolder = "Assets/VRHandPoseToolOutput/Animations";
        public const string GrabSnapshotsOutputFolder = "Assets/VRHandPoseToolOutput/GrabSnapshots";
        public const string InputActionsOutputFolder = "Assets/VRHandPoseToolOutput/InputActions";

        public static string GetLabel(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left" : "Right";
        }

        public static Handedness ToHandedness(HandSide handSide)
        {
            return handSide == HandSide.Left ? Handedness.Left : Handedness.Right;
        }

        public static string GetBonePrefix(HandSide handSide)
        {
            return handSide == HandSide.Left ? "L_" : "R_";
        }

        public static string GetOppositeBonePrefix(HandSide handSide)
        {
            return handSide == HandSide.Left ? "R_" : "L_";
        }

        public static string GetWristBoneName(HandSide handSide)
        {
            return GetBonePrefix(handSide) + "Wrist";
        }

        public static string GetPreferredHandRootName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "LeftHand" : "RightHand";
        }

        public static string GetControllerNameToken(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left Controller" : "Right Controller";
        }

        public static string GetXriInteractionActionMap(HandSide handSide)
        {
            return handSide == HandSide.Left ? "XRI Left Interaction" : "XRI Right Interaction";
        }

        public static string GetXriTrackingActionMap(HandSide handSide)
        {
            return handSide == HandSide.Left ? "XRI Left" : "XRI Right";
        }

        /// <summary>
        /// Import된 HandVisualizer Sample에서 Playback 모델 경로를 동적으로 해석합니다.
        /// Sample이 없거나 후보가 모호하면 null을 반환합니다. 버전 경로를 하드코딩하지 않습니다.
        /// </summary>
        public static string GetHandModelAssetPath(HandSide handSide)
        {
            var resolve = HandVisualizerAssetResolver.ResolvePlaybackModelForImportedSample(handSide);
            return resolve.success ? resolve.assetPath : null;
        }

        /// <summary>
        /// 표시·메타데이터용 모델 파일명. 동적 해석 실패 시 PreferredHandRootName.fbx를 반환합니다.
        /// </summary>
        public static string GetHandModelDisplayFileName(HandSide handSide)
        {
            var path = GetHandModelAssetPath(handSide);
            if (!string.IsNullOrEmpty(path))
                return System.IO.Path.GetFileName(path);

            return GetPreferredHandRootName(handSide) + ".fbx";
        }

        public static string GetGripBindingToken(HandSide handSide)
        {
            return handSide == HandSide.Left ? "LeftHand" : "RightHand";
        }

        public static string GetRecommendedGripBinding(HandSide handSide)
        {
            return $"<XRController>{{{GetGripBindingToken(handSide)}}}/{{Grip}}";
        }

        public static string GetGripReferenceAssetFileName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_Grip_Select_Value.asset" : "Right_Grip_Select_Value.asset";
        }

        public static string GetGripReferenceAssetPath(HandSide handSide)
        {
            return $"{InputActionsOutputFolder}/{GetGripReferenceAssetFileName(handSide)}";
        }

        public static string GetOpenPoseName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_Open" : "Right_Open";
        }

        public static string GetGrabPoseName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_Grab" : "Right_Grab";
        }

        public static string GetGrabSnapshotOutputName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_Grab_Bone" : "Right_Grab_Bone";
        }

        public static string GetDefaultGrabPoseAssetPath(HandSide handSide)
        {
            return $"{PosesOutputFolder}/{GetGrabPoseName(handSide)}.asset";
        }

        public static string GetDefaultGrabSnapshotAssetPath(HandSide handSide)
        {
            return $"{GrabSnapshotsOutputFolder}/{GetGrabSnapshotOutputName(handSide)}.asset";
        }

        public static string GetDefaultOpenAnimationClipPath(HandSide handSide)
        {
            return $"{AnimationsOutputFolder}/{GetOpenPoseName(handSide)}.anim";
        }

        public static string GetDefaultGrabAnimationClipPath(HandSide handSide)
        {
            return $"{AnimationsOutputFolder}/{GetGrabPoseName(handSide)}.anim";
        }

        public const string LeftAnimatorControllerPath =
            "Assets/VRHandPoseToolOutput/Animations/OculusHand_L.controller";

        public const string RightAnimatorControllerPath =
            "Assets/VRHandPoseToolOutput/Animations/OculusHand_R.controller";

        public static string GetAnimatorControllerPath(HandSide handSide)
        {
            return handSide == HandSide.Left ? LeftAnimatorControllerPath : RightAnimatorControllerPath;
        }

        public static string GetDefaultAnimatorControllerPath(HandSide handSide)
        {
            return GetAnimatorControllerPath(handSide);
        }

        public static RuntimeAnimatorController TryLoadDefaultAnimatorController(HandSide handSide)
        {
            var path = GetDefaultAnimatorControllerPath(handSide);
            if (string.IsNullOrEmpty(path))
                return null;

            return AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(path);
        }

        public static string GetCurrentPoseDefaultName(HandSide handSide)
        {
            return handSide == HandSide.Left ? "Left_Current" : "Right_Current";
        }

        public static string GetGhostSuffix(HandSide handSide)
        {
            return handSide == HandSide.Left ? "_LeftHand_Ghost" : "_RightHand_Ghost";
        }

        public static string BuildGhostName(string targetGrabObjectName, HandSide handSide)
        {
            return targetGrabObjectName + GetGhostSuffix(handSide);
        }

        public static string GetHandSideLabelForMarker(HandSide handSide)
        {
            return GetLabel(handSide);
        }

        public static bool IsHandBoneName(string boneName, HandSide handSide)
        {
            if (string.IsNullOrEmpty(boneName))
                return false;

            var prefix = GetBonePrefix(handSide);
            return boneName.StartsWith(prefix, StringComparison.Ordinal);
        }

        public static bool ContainsOppositeHandBonePrefix(string boneName, HandSide handSide)
        {
            if (string.IsNullOrEmpty(boneName))
                return false;

            var opposite = GetOppositeBonePrefix(handSide);
            return boneName.StartsWith(opposite, StringComparison.Ordinal);
        }

        public static bool TryInferHandSideFromBoneNames(
            IEnumerable<string> boneNames,
            out HandSide handSide,
            out string errorMessage)
        {
            handSide = HandSide.Left;
            errorMessage = null;

            var hasLeft = false;
            var hasRight = false;

            if (boneNames != null)
            {
                foreach (var boneName in boneNames)
                {
                    if (string.IsNullOrEmpty(boneName))
                        continue;

                    if (boneName.StartsWith("L_", StringComparison.Ordinal))
                        hasLeft = true;
                    else if (boneName.StartsWith("R_", StringComparison.Ordinal))
                        hasRight = true;
                }
            }

            if (hasLeft && hasRight)
            {
                errorMessage = "L_와 R_ 접두사 본이 섞여 있습니다.";
                return false;
            }

            if (hasRight)
            {
                handSide = HandSide.Right;
                return true;
            }

            if (hasLeft)
            {
                handSide = HandSide.Left;
                return true;
            }

            errorMessage = "L_ 또는 R_ 접두사 본을 찾지 못했습니다.";
            return false;
        }

        public static bool MatchesHandSide(Transform handRoot, HandSide handSide)
        {
            if (handRoot == null)
                return false;

            if (handRoot.name.IndexOf(GetPreferredHandRootName(handSide), StringComparison.OrdinalIgnoreCase) >= 0)
                return true;

            return HandSkeletonCatalog.Validate(handRoot, handSide).isValid;
        }

        /// <summary>
        /// HandInteractorSide → Controller 계층 → Interactor 이름(Left_/Right_) 순으로 Interactor HandSide를 해석합니다.
        /// </summary>
        public static bool TryResolveInteractorHandSide(Transform interactorTransform, out HandSide handSide)
        {
            handSide = default;

            if (interactorTransform == null)
                return false;

            var explicitSide = interactorTransform.GetComponentInParent<HandInteractorSide>();
            if (explicitSide != null)
            {
                handSide = explicitSide.HandSide;
                return true;
            }

            var current = interactorTransform;
            while (current != null)
            {
                if (string.Equals(current.name, GetControllerNameToken(HandSide.Left), StringComparison.Ordinal))
                {
                    handSide = HandSide.Left;
                    return true;
                }

                if (string.Equals(current.name, GetControllerNameToken(HandSide.Right), StringComparison.Ordinal))
                {
                    handSide = HandSide.Right;
                    return true;
                }

                current = current.parent;
            }

            var interactorName = interactorTransform.name;
            if (string.IsNullOrEmpty(interactorName))
                return false;

            if (interactorName.StartsWith("Left_", StringComparison.Ordinal))
            {
                handSide = HandSide.Left;
                return true;
            }

            if (interactorName.StartsWith("Right_", StringComparison.Ordinal))
            {
                handSide = HandSide.Right;
                return true;
            }

            return false;
        }

        public static bool IsDefaultOpenPoseName(string poseName, HandSide handSide)
        {
            return string.Equals(poseName, GetOpenPoseName(handSide), StringComparison.Ordinal);
        }

        public static bool IsDefaultGrabPoseName(string poseName, HandSide handSide)
        {
            return string.Equals(poseName, GetGrabPoseName(handSide), StringComparison.Ordinal);
        }

        public static bool IsDefaultCurrentPoseName(string poseName, HandSide handSide)
        {
            return string.Equals(poseName, GetCurrentPoseDefaultName(handSide), StringComparison.Ordinal);
        }

        public static bool IsDefaultGrabSnapshotOutputName(string outputName, HandSide handSide)
        {
            return string.Equals(outputName, GetGrabSnapshotOutputName(handSide), StringComparison.Ordinal);
        }

        public static bool IsDefaultAssetPath(string assetPath, HandSide handSide, string defaultPath)
        {
            return string.Equals(assetPath, defaultPath, StringComparison.OrdinalIgnoreCase);
        }
    }
}
