using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using VRHandPoseTool;
using System.Text;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play Mode Grab Pose Record 캡처 후 Edit Mode에서 Attach·Binding을 Scene에 적용합니다.
    /// Pending 메타데이터는 SessionState에만 저장합니다.
    /// </summary>
    [InitializeOnLoad]
    public static class HandGrabPosePendingApplyBridge
    {
        const string PendingJsonSessionKey = "VRHandPoseTool.HandGrabPose.PendingApplyJson";
        const string LastApplyMessageSessionKey = "VRHandPoseTool.HandGrabPose.LastApplyMessage";
        const string LastApplySucceededSessionKey = "VRHandPoseTool.HandGrabPose.LastApplySucceeded";

        [Serializable]
        sealed class PendingApplyData
        {
            public string applyToken;
            public string scenePath;
            public string targetGlobalObjectId;
            public string recordAssetPath;
            public int handSide;
            public string createdAtUtc;
            public string targetDisplayName;
            public bool autoApplyAttempted;
        }

        public struct PendingSummary
        {
            public string targetDisplayName;
            public HandSide handSide;
            public string scenePath;
            public string recordAssetPath;
            public bool autoApplyAttempted;
        }

        public struct RegisterResult
        {
            public bool success;
            public string message;
        }

        static HandGrabPosePendingApplyBridge()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
        }

        public static bool HasPendingApply => TryLoadPending(out _);

        public static bool LastApplySucceeded =>
            SessionState.GetBool(LastApplySucceededSessionKey, false);

        public static string LastApplyMessage =>
            SessionState.GetString(LastApplyMessageSessionKey, string.Empty);

        public static bool HasRetryablePending =>
            TryLoadPending(out var pending) && pending.autoApplyAttempted;

        public static PendingSummary GetPendingSummary()
        {
            if (!TryLoadPending(out var pending))
            {
                return default;
            }

            return new PendingSummary
            {
                targetDisplayName = pending.targetDisplayName,
                handSide = (HandSide)pending.handSide,
                scenePath = pending.scenePath,
                recordAssetPath = pending.recordAssetPath,
                autoApplyAttempted = pending.autoApplyAttempted,
            };
        }

        public static RegisterResult TryRegisterPending(
            GameObject targetObject,
            HandSide handSide,
            string recordAssetPath)
        {
            if (targetObject == null)
                return Failed("Target Object가 null이라 Pending Apply를 등록할 수 없습니다.");

            if (string.IsNullOrWhiteSpace(recordAssetPath))
                return Failed("Record Asset path가 비어 있어 Pending Apply를 등록할 수 없습니다.");

            if (!EditorApplication.isPlaying)
            {
                return Failed("Play Mode에서만 Pending Apply를 등록할 수 있습니다.");
            }

            if (HasPendingApply)
            {
                return Failed(
                    "이미 적용 대기 중인 Grab Pose Record가 있습니다. " +
                    "기존 Pending을 적용하거나 삭제한 뒤 다시 캡처하세요.");
            }

            var grab = targetObject.GetComponent<XRGrabInteractable>();
            if (grab == null)
            {
                return Failed("Target Object에 XRGrabInteractable이 없어 Pending Apply를 등록할 수 없습니다.");
            }

            var scene = targetObject.scene;
            if (!scene.IsValid())
                return Failed("Target Object가 유효한 Scene에 속하지 않습니다.");

            var scenePath = scene.path;
            if (string.IsNullOrWhiteSpace(scenePath))
            {
                return Failed(
                    "저장되지 않은 Scene(Untitled)에서는 Pending Apply를 등록할 수 없습니다. " +
                    "Scene을 저장한 뒤 다시 캡처하세요.");
            }

            if (!TryGetGlobalObjectIdString(grab, out var globalObjectId, out var globalIdError))
                return Failed(globalIdError);

            var pending = new PendingApplyData
            {
                applyToken = Guid.NewGuid().ToString("N"),
                scenePath = scenePath,
                targetGlobalObjectId = globalObjectId,
                recordAssetPath = recordAssetPath,
                handSide = (int)handSide,
                createdAtUtc = DateTime.UtcNow.ToString("o"),
                targetDisplayName = targetObject.name,
                autoApplyAttempted = false,
            };

            SavePending(pending);
            ClearLastApplyMessage();

            return new RegisterResult
            {
                success = true,
                message =
                    $"적용 대기 등록: {pending.targetDisplayName} / {HandSideUtility.GetLabel(handSide)}\n" +
                    "Play Mode를 종료하면 Attach와 Binding이 Scene에 적용됩니다.",
            };
        }

        public static bool TryApplyPendingNow()
        {
            return TryApplyPending(forceRetry: true, out _);
        }

        public static void ClearPending()
        {
            SessionState.EraseString(PendingJsonSessionKey);
        }

        public static bool PendingMatchesTargetAndSide(GameObject targetObject, HandSide handSide)
        {
            if (targetObject == null || !TryLoadPending(out var pending))
                return false;

            if ((HandSide)pending.handSide != handSide)
                return false;

            if (!GlobalObjectId.TryParse(pending.targetGlobalObjectId, out var globalObjectId))
                return false;

            var resolved = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(globalObjectId);
            var pendingTarget = ResolveGameObject(resolved);
            return pendingTarget == targetObject;
        }

        public static bool ClearPendingIfMatches(GameObject targetObject, HandSide handSide)
        {
            if (!PendingMatchesTargetAndSide(targetObject, handSide))
                return false;

            ClearPending();
            ClearLastApplyMessage();
            return true;
        }

        static void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state != PlayModeStateChange.EnteredEditMode)
                return;

            if (!TryLoadPending(out var pending) || pending.autoApplyAttempted)
                return;

            TryApplyPending(forceRetry: false, out _);
        }

        static bool TryApplyPending(bool forceRetry, out string message)
        {
            message = null;

            if (PrefabStageUtility.GetCurrentPrefabStage() != null)
            {
                message = "Prefab Stage에서는 Grab Pose 자동 적용을 수행할 수 없습니다. Scene View에서 Target Scene을 열어 주세요.";
                SetLastApplyMessage(message, succeeded: false);
                MarkAutoApplyAttempted();
                return false;
            }

            if (!TryLoadPending(out var pending))
            {
                message = "적용 대기 중인 Grab Pose Record가 없습니다.";
                SetLastApplyMessage(message, succeeded: false);
                return false;
            }

            if (pending.autoApplyAttempted && !forceRetry)
            {
                message = LastApplyMessage;
                return false;
            }

            if (!TryApplyPendingInternal(pending, out message))
            {
                SetLastApplyMessage(message, succeeded: false);
                MarkAutoApplyAttempted();
                return false;
            }

            ClearPending();
            SetLastApplyMessage(message, succeeded: true);
            return true;
        }

        static bool TryApplyPendingInternal(PendingApplyData pending, out string message)
        {
            message = null;

            if (string.IsNullOrWhiteSpace(pending.applyToken))
            {
                message = "자동 적용 실패: Pending applyToken이 비어 있습니다.";
                return false;
            }

            var activeScene = SceneManager.GetActiveScene();
            if (!activeScene.IsValid())
            {
                message = "자동 적용 실패: 활성 Scene이 없습니다.";
                return false;
            }

            var activeScenePath = activeScene.path;
            if (string.IsNullOrWhiteSpace(activeScenePath))
            {
                message = "자동 적용 실패: 활성 Scene이 저장되지 않았습니다.";
                return false;
            }

            if (!string.Equals(activeScenePath, pending.scenePath, StringComparison.OrdinalIgnoreCase))
            {
                message =
                    $"자동 적용 실패: 활성 Scene('{activeScenePath}')이 Pending Scene('{pending.scenePath}')과 다릅니다. " +
                    "Pending Scene을 연 뒤 다시 시도하세요.";
                return false;
            }

            if (!GlobalObjectId.TryParse(pending.targetGlobalObjectId, out var globalObjectId))
            {
                message = "자동 적용 실패: Target GlobalObjectId를 파싱할 수 없습니다.";
                return false;
            }

            var resolvedObject = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(globalObjectId);
            var targetGameObject = ResolveGameObject(resolvedObject);
            if (targetGameObject == null)
            {
                message = "자동 적용 실패: Target GlobalObjectId로 Scene Object를 복원하지 못했습니다.";
                return false;
            }

            if (targetGameObject.scene != activeScene)
            {
                message = "자동 적용 실패: 복원된 Target이 활성 Scene에 속하지 않습니다.";
                return false;
            }

            var grabInteractable = targetGameObject.GetComponent<XRGrabInteractable>();
            if (grabInteractable == null)
            {
                message = "자동 적용 실패: Target에 XRGrabInteractable이 없습니다.";
                return false;
            }

            var record = AssetDatabase.LoadAssetAtPath<HandGrabPoseRecord>(pending.recordAssetPath);
            if (record == null)
            {
                message = $"자동 적용 실패: Record Asset을 찾을 수 없습니다. ({pending.recordAssetPath})";
                return false;
            }

            var handSide = (HandSide)pending.handSide;
            if (!record.MatchesHandSide(handSide))
            {
                message =
                    $"자동 적용 실패: Record handSide={record.HandSide}가 Pending handSide={handSide}와 일치하지 않습니다.";
                return false;
            }

            if (!TryApplyToTarget(grabInteractable, handSide, record, out var attachName, out var applyError))
            {
                message = $"자동 적용 실패: {applyError}";
                return false;
            }

            var sb = new StringBuilder();
            sb.AppendLine("적용 완료:");
            sb.AppendLine(attachName);
            sb.AppendLine($"HandGrabPoseBinding {HandSideUtility.GetLabel(handSide)} 슬롯 연결");

            // Auto-add HandGrabPosePlayer for runtime pose application
            if (targetGameObject.GetComponent<HandGrabPosePlayer>() == null)
            {
                Undo.AddComponent<HandGrabPosePlayer>(targetGameObject);
                sb.AppendLine("✓ HandGrabPosePlayer 자동 추가");
            }

            // Auto-migrate to HandSideAwareGrabInteractable
            var migReadiness = HandSideAwareGrabInteractableMigrationService.EvaluateReadiness(targetGameObject);
            if (migReadiness.canMigrate)
            {
                var migResult = HandSideAwareGrabInteractableMigrationService.TryMigrate(targetGameObject);
                sb.AppendLine(migResult.success
                    ? "✓ HandSideAwareGrabInteractable 자동 전환 완료"
                    : $"⚠ 자동 전환 실패 (수동 전환 필요): {migResult.message}");
            }
            else if (migReadiness.existingHandSideAware != null)
            {
                sb.AppendLine("✓ HandSideAwareGrabInteractable 이미 적용됨");
            }
            else
            {
                sb.AppendLine("⚠ HandSideAwareGrabInteractable 전환 불가 — 4단계에서 수동 전환하세요");
            }

            sb.Append("Scene을 저장하세요.");
            EditorSceneManager.MarkSceneDirty(activeScene);

            message = sb.ToString().TrimEnd();
            return true;
        }

        static bool TryApplyToTarget(
            XRGrabInteractable grabInteractable,
            HandSide handSide,
            HandGrabPoseRecord record,
            out string attachObjectName,
            out string errorMessage)
        {
            attachObjectName = HandGrabPoseBinding.GetAttachObjectName(handSide);
            errorMessage = null;

            var targetRoot = grabInteractable.transform;

            if (!TryResolveAttachTransform(targetRoot, handSide, out var attachTransform, out errorMessage))
                return false;

            var bindings = targetRoot.GetComponents<HandGrabPoseBinding>();
            if (bindings.Length > 1)
            {
                errorMessage = "HandGrabPoseBinding 컴포넌트가 2개 이상 있어 적용할 수 없습니다.";
                return false;
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Apply Hand Grab Pose");
            var undoGroup = Undo.GetCurrentGroup();

            try
            {
                Undo.RecordObject(attachTransform, "Apply Grab Attach Pose");
                var (attachPos, attachRot, wristCorrected, corrNote) =
                    ComputeAttachWithWristOffset(handSide, grabInteractable);
                if (wristCorrected)
                {
                    attachTransform.localPosition = attachPos;
                    attachTransform.localRotation = attachRot;
                    attachTransform.localScale = Vector3.one;
                    attachObjectName += $"\n  {corrNote}";
                }
                else
                {
                    attachTransform.localScale = Vector3.one;
                    attachObjectName += $"\n  임시 Attach — Ghost Wrist 보정 필요 ({corrNote})";
                }

                HandGrabPoseBinding binding;
                if (bindings.Length == 1)
                {
                    binding = bindings[0];
                }
                else
                {
                    binding = Undo.AddComponent<HandGrabPoseBinding>(targetRoot.gameObject);
                }

                Undo.RecordObject(binding, "Apply Hand Grab Pose Binding");
                var setResult = binding.SetBinding(handSide, record, attachTransform);
                if (!setResult.success)
                {
                    errorMessage = setResult.errorMessage;
                    Undo.RevertAllDownToGroup(undoGroup);
                    return false;
                }

                // Controller Wrist Offset 보정 여부를 Binding에 기록합니다.
                // 폴백(보정 불가) 상태는 false → 2차 완료 조건 미충족으로 표시됩니다.
                binding.SetWristCorrectionApplied(handSide, wristCorrected);

                EditorUtility.SetDirty(binding);
                EditorUtility.SetDirty(attachTransform);
            }
            catch (Exception ex)
            {
                Undo.RevertAllDownToGroup(undoGroup);
                errorMessage = ex.Message;
                return false;
            }

            Undo.CollapseUndoOperations(undoGroup);
            return true;
        }

        static bool TryResolveAttachTransform(
            Transform targetRoot,
            HandSide handSide,
            out Transform attachTransform,
            out string errorMessage)
        {
            attachTransform = null;
            errorMessage = null;

            var attachName = HandGrabPoseBinding.GetAttachObjectName(handSide);
            Transform firstMatch = null;
            var matchCount = 0;

            for (var i = 0; i < targetRoot.childCount; i++)
            {
                var child = targetRoot.GetChild(i);
                if (!string.Equals(child.name, attachName, StringComparison.Ordinal))
                    continue;

                matchCount++;
                if (firstMatch == null)
                    firstMatch = child;
            }

            if (matchCount > 1)
            {
                errorMessage = $"Target에 '{attachName}' 이름의 Attach Transform이 {matchCount}개 있어 적용할 수 없습니다.";
                return false;
            }

            if (firstMatch != null)
            {
                attachTransform = firstMatch;
                return true;
            }

            var attachObject = new GameObject(attachName);
            Undo.RegisterCreatedObjectUndo(attachObject, "Create Hand Grab Attach");
            attachTransform = attachObject.transform;
            attachTransform.SetParent(targetRoot, false);
            return true;
        }

        static bool TryGetGlobalObjectIdString(
            UnityEngine.Object target,
            out string globalObjectIdString,
            out string errorMessage)
        {
            globalObjectIdString = null;
            errorMessage = null;

            if (target == null)
            {
                errorMessage = "Target GlobalObjectId를 구할 수 없습니다. (null)";
                return false;
            }

            try
            {
                var globalObjectId = GlobalObjectId.GetGlobalObjectIdSlow(target);
                globalObjectIdString = globalObjectId.ToString();
                if (string.IsNullOrWhiteSpace(globalObjectIdString))
                {
                    errorMessage = "Target GlobalObjectId가 비어 있습니다.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"Target GlobalObjectId를 구하지 못했습니다: {ex.Message}";
                return false;
            }
        }

        static GameObject ResolveGameObject(UnityEngine.Object resolvedObject)
        {
            if (resolvedObject == null)
                return null;

            if (resolvedObject is GameObject gameObject)
                return gameObject;

            if (resolvedObject is Component component)
                return component.gameObject;

            return null;
        }

        static bool TryLoadPending(out PendingApplyData pending)
        {
            pending = null;
            var json = SessionState.GetString(PendingJsonSessionKey, string.Empty);
            if (string.IsNullOrWhiteSpace(json))
                return false;

            try
            {
                pending = JsonUtility.FromJson<PendingApplyData>(json);
                return pending != null
                    && !string.IsNullOrWhiteSpace(pending.applyToken)
                    && !string.IsNullOrWhiteSpace(pending.scenePath)
                    && !string.IsNullOrWhiteSpace(pending.targetGlobalObjectId)
                    && !string.IsNullOrWhiteSpace(pending.recordAssetPath);
            }
            catch
            {
                pending = null;
                return false;
            }
        }

        static void SavePending(PendingApplyData pending)
        {
            SessionState.SetString(PendingJsonSessionKey, JsonUtility.ToJson(pending));
        }

        static void MarkAutoApplyAttempted()
        {
            if (!TryLoadPending(out var pending))
                return;

            pending.autoApplyAttempted = true;
            SavePending(pending);
        }

        static void SetLastApplyMessage(string message, bool succeeded)
        {
            SessionState.SetString(LastApplyMessageSessionKey, message ?? string.Empty);
            SessionState.SetBool(LastApplySucceededSessionKey, succeeded);
        }

        static void ClearLastApplyMessage()
        {
            SessionState.EraseString(LastApplyMessageSessionKey);
            SessionState.SetBool(LastApplySucceededSessionKey, false);
        }

        static RegisterResult Failed(string message) =>
            new() { success = false, message = message };

        // ── Wrist Offset 보정 ────────────────────────────────────────────────

        /// <summary>
        /// Ghost Wrist(Target local) × inverse(Controller Wrist in Interactor) 공식으로
        /// Object Attach local Pose를 계산합니다.
        /// Ghost가 없으면 Attach Pose를 변경하지 않습니다.
        /// </summary>
        static (Vector3 pos, Quaternion rot, bool corrected, string note) ComputeAttachWithWristOffset(
            HandSide handSide,
            XRGrabInteractable grabInteractable)
        {
            if (grabInteractable == null)
            {
                return (Vector3.zero, Quaternion.identity, false, "XRGrabInteractable 없음");
            }

            var compute = HandAttachWristCorrectionService.TryComputeAttachLocalPose(
                grabInteractable.transform,
                handSide,
                grabInteractable);

            if (!compute.success)
            {
                return (Vector3.zero, Quaternion.identity, false, compute.errorMessage);
            }

            Debug.Log(compute.validationLog);
            return (
                compute.attachLocalPosition,
                compute.attachLocalRotation,
                true,
                "✓ Ghost Wrist 기준 Wrist Offset 보정");
        }

        static bool TryFindInteractorAttach(
            HandSide handSide,
            XRGrabInteractable grabInteractable,
            out Transform attach,
            out string error)
        {
            return HandAttachWristCorrectionService.TryFindInteractorAttach(
                handSide,
                grabInteractable,
                out attach,
                out error);
        }
    }
}
