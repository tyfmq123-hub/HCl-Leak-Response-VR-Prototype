using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 씬에 종속되지 않고 Left/Right Playback Hand Root Transform을 탐색합니다.
    /// L_* / R_* 26본·SkinnedMeshRenderer·손목 본·이름 힌트·컨트롤러 계층으로 검증합니다.
    /// </summary>
    public static class HandPlaybackHandFinder
    {
        public struct Candidate
        {
            public Transform handRoot;
            public string hierarchyPath;
            public string objectName;
            public bool isActive;
            public bool skeletonValid;
            public bool hasSkinnedMeshRenderer;
            public bool hasWristBone;
            public bool matchesNameHint;
            public bool underControllerHierarchy;
            public int score;
        }

        public struct FindResult
        {
            public bool success;
            public Transform handRoot;
            public string message;
            public List<Candidate> candidates;
        }

        public static FindResult FindPlaybackHand(HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var result = new FindResult
            {
                candidates = new List<Candidate>(),
            };

            var allTransforms = Resources.FindObjectsOfTypeAll<Transform>();
            foreach (var transform in allTransforms)
            {
                if (transform == null || transform.hideFlags != HideFlags.None)
                    continue;

                if (!transform.gameObject.scene.IsValid())
                    continue;

                if (IsGhostHandTransform(transform))
                    continue;

                if (!IsCandidateTransform(transform, handSide, out var candidate))
                    continue;

                result.candidates.Add(candidate);
            }

            if (result.candidates.Count == 0)
            {
                var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
                var preferredName = HandSideUtility.GetPreferredHandRootName(handSide);
                result.message =
                    $"조건을 만족하는 {sideLabel}손 Playback Hand 후보를 찾지 못했습니다.\n" +
                    $"{HandSideUtility.GetBonePrefix(handSide)}* 26본, SkinnedMeshRenderer, {wristBoneName} 본이 필요합니다.\n" +
                    $"이름 힌트: {preferredName} (선택)";
                return result;
            }

            if (result.candidates.Count > 1)
            {
                var sb = new StringBuilder();
                sb.AppendLine(
                    $"{sideLabel}손 Playback Hand 후보가 {result.candidates.Count}개 발견되었습니다. 자동 선택하지 않습니다.");
                foreach (var candidate in result.candidates)
                {
                    sb.Append("• ");
                    sb.Append(candidate.hierarchyPath);
                    if (candidate.matchesNameHint)
                        sb.Append(" [name hint]");
                    if (candidate.underControllerHierarchy)
                        sb.Append(" [controller]");
                    sb.AppendLine();
                }

                result.message = sb.ToString().TrimEnd();
                return result;
            }

            result.success = true;
            result.handRoot = result.candidates[0].handRoot;
            result.message = $"{sideLabel}손 Playback Hand 후보 1개를 선택했습니다: {result.candidates[0].hierarchyPath}";
            return result;
        }

        static bool IsGhostHandTransform(Transform transform)
        {
            if (transform == null)
                return false;

            if (transform.GetComponent<HandGhostPreviewMarker>() != null)
                return true;

            if (transform.name.EndsWith(HandSideUtility.GetGhostSuffix(HandSide.Left), StringComparison.Ordinal)
                || transform.name.EndsWith(HandSideUtility.GetGhostSuffix(HandSide.Right), StringComparison.Ordinal))
            {
                return true;
            }

            var current = transform;
            while (current != null)
            {
                if (string.Equals(current.name, HandGhostPreviewService.GhostsRootName, StringComparison.Ordinal))
                    return true;

                current = current.parent;
            }

            return false;
        }

        static bool IsCandidateTransform(Transform transform, HandSide handSide, out Candidate candidate)
        {
            candidate = default;

            if (transform == null)
                return false;

            var validation = HandSkeletonCatalog.Validate(transform, handSide);
            if (!validation.isValid)
                return false;

            var skinnedMesh = transform.GetComponentInChildren<SkinnedMeshRenderer>(true);
            if (skinnedMesh == null)
                return false;

            var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
            if (!TryFindWristBone(transform, wristBoneName, out _))
                return false;

            var matchesNameHint = MatchesNameHint(transform, handSide);
            var underControllerHierarchy = IsUnderControllerHierarchy(transform, handSide);

            candidate = new Candidate
            {
                handRoot = transform,
                hierarchyPath = HandPoseCaptureService.GetHierarchyPath(transform),
                objectName = transform.name,
                isActive = transform.gameObject.activeInHierarchy,
                skeletonValid = true,
                hasSkinnedMeshRenderer = true,
                hasWristBone = true,
                matchesNameHint = matchesNameHint,
                underControllerHierarchy = underControllerHierarchy,
                score = CalculateScore(matchesNameHint, underControllerHierarchy),
            };

            return candidate.isActive;
        }

        static bool TryFindWristBone(Transform handRoot, string wristBoneName, out Transform wristBone)
        {
            wristBone = null;
            if (handRoot == null)
                return false;

            foreach (var transform in handRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == handRoot)
                    continue;

                if (!string.Equals(transform.name, wristBoneName, StringComparison.Ordinal))
                    continue;

                wristBone = transform;
                return true;
            }

            return false;
        }

        static bool MatchesNameHint(Transform handRoot, HandSide handSide)
        {
            if (handRoot == null)
                return false;

            var preferredName = HandSideUtility.GetPreferredHandRootName(handSide);
            return handRoot.name.IndexOf(preferredName, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        static bool IsUnderControllerHierarchy(Transform handRoot, HandSide handSide)
        {
            if (handRoot == null)
                return false;

            var controllerToken = HandSideUtility.GetControllerNameToken(handSide);
            var current = handRoot.parent;
            while (current != null)
            {
                if (current.name.IndexOf(controllerToken, StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;

                current = current.parent;
            }

            return false;
        }

        static int CalculateScore(bool matchesNameHint, bool underControllerHierarchy)
        {
            var score = 0;
            if (matchesNameHint)
                score += 50;
            if (underControllerHierarchy)
                score += 50;
            return score;
        }
    }
}
