using System;
using System.Globalization;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Controller Hand를 Tracking Hand 기준으로 자동 정렬합니다.
    /// Visual Offset GameObject를 Controller Hand Root 상위에 삽입해 손 방향/위치를 맞춥니다.
    /// Play Mode 계산 결과는 pending으로 저장하고, EnteredEditMode에서 Edit Mode Scene에 적용합니다.
    /// </summary>
    [InitializeOnLoad]
    public static class HandControllerVisualAlignmentService
    {
        const string VisualOffsetPrefix = "VRHandPoseTool_VisualOffset_";
        const string PendingJsonKeyPrefix = "VRHandPoseTool.VisualAlign.PendingJson.";
        const string LastMessageKeyPrefix = "VRHandPoseTool.VisualAlign.LastMessage.";
        const string LastSucceededKeyPrefix = "VRHandPoseTool.VisualAlign.LastSucceeded.";
        const string TargetRoleVisualOffset = "VisualOffset";
        const float TransformEpsilon = 0.0001f;

        // legacy single-key SessionState (migration / clear)
        const string LegacySkBase = "VRHandPoseTool.VisualAlign.";

        public enum AlignMode { PositionAndRotation, RotationOnly }

        public enum PendingApplyStatus
        {
            None = 0,
            PendingWaitingForEditMode = 1,
            ApplyingInEditMode = 2,
            Applied = 3,
            FailedToResolveTarget = 4,
            FailedToApply = 5,
            // legacy aliases
            Pending = PendingWaitingForEditMode,
            Failed = FailedToApply,
        }

        [Serializable]
        public sealed class PendingAlignmentData
        {
            public string applyToken;
            public string scenePath;
            public string handRootGlobalObjectId; // diagnostic / legacy
            public string targetTransformGlobalObjectId; // diagnostic / legacy
            public string visualOffsetLocatorJson;
            public string targetRole;
            public int handSide;
            public int alignMode;
            public float localPosX;
            public float localPosY;
            public float localPosZ;
            public float localRotX;
            public float localRotY;
            public float localRotZ;
            public float localRotW;
            public float localScaleX = 1f;
            public float localScaleY = 1f;
            public float localScaleZ = 1f;
            public float origLocalPosX;
            public float origLocalPosY;
            public float origLocalPosZ;
            public float origLocalRotX;
            public float origLocalRotY;
            public float origLocalRotZ;
            public float origLocalRotW = 1f;
            public string createdAtUtc;
            public bool autoApplyAttempted;
            public string lastFailureReason;
            public int lifecycleStatus;
        }

        public struct AlignReadiness
        {
            public bool canAlign;
            public string blockReason;
            public Transform trackingWrist;
            public Transform controllerWrist;
            public Transform controllerHandRoot;
        }

        public struct AlignResult
        {
            public bool success;
            public string message;
            public Transform visualOffset;
            public Vector3 wristPosInVO;
            public Quaternion wristRotInVO;
            public bool pendingSaved;
        }

        static HandControllerVisualAlignmentService()
        {
            ClearLegacySessionKeys();
            EditorApplication.playModeStateChanged -= OnPlayModeChanged;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.delayCall -= TryApplyAllPendingOnEditMode;
            EditorApplication.delayCall += TryApplyAllPendingOnEditMode;
        }

        // ── 정렬 가능 여부 평가 ─────────────────────────────────────────────

        public static AlignReadiness EvaluateReadiness(
            HandSide handSide,
            Transform trackingHandRoot,
            Transform controllerHandRoot)
        {
            var r = new AlignReadiness();

            if (trackingHandRoot == null)
            { r.blockReason = "Tracking Hand Root가 설정되지 않았습니다."; return r; }

            if (controllerHandRoot == null)
            { r.blockReason = "Controller Hand Root(Playback Hand Root)가 설정되지 않았습니다."; return r; }

            if (controllerHandRoot.GetComponentInParent<HandGhostPreviewMarker>() != null)
            { r.blockReason = "Controller Hand Root로 Ghost Hand가 선택됐습니다."; return r; }

            var wristName = handSide == HandSide.Right ? "R_Wrist" : "L_Wrist";

            r.trackingWrist = FindBoneRecursive(trackingHandRoot, wristName);
            if (r.trackingWrist == null)
            { r.blockReason = $"Tracking Hand Root 하위에서 {wristName} 본을 찾지 못했습니다."; return r; }

            r.controllerWrist = FindBoneRecursive(controllerHandRoot, wristName);
            if (r.controllerWrist == null)
            { r.blockReason = $"Controller Hand Root 하위에서 {wristName} 본을 찾지 못했습니다."; return r; }

            r.controllerHandRoot = controllerHandRoot;
            r.canAlign = true;
            return r;
        }

        // ── 정렬 실행 ──────────────────────────────────────────────────────

        /// <summary>
        /// Play Mode 또는 Edit Mode에서 호출 가능.
        /// Edit Mode: Visual Offset을 Scene에 즉시 적용합니다.
        /// Play Mode: 미리보기만 수행하고 pending alignment를 저장합니다 (Scene 영속화는 Edit Mode 복귀 시).
        /// </summary>
        public static AlignResult TryAlign(
            HandSide handSide,
            Transform trackingHandRoot,
            Transform controllerHandRoot,
            AlignMode mode)
        {
            var ready = EvaluateReadiness(handSide, trackingHandRoot, controllerHandRoot);
            if (!ready.canAlign)
                return new AlignResult { success = false, message = ready.blockReason };

            var trackingWrist = ready.trackingWrist;
            var controllerWrist = ready.controllerWrist;

            Transform vo;
            Vector3 origLocalPos;
            Quaternion origLocalRot;

            if (Application.isPlaying)
            {
                vo = FindVisualOffset(controllerHandRoot, handSide);
                if (vo == null || controllerHandRoot.parent != vo)
                {
                    return new AlignResult
                    {
                        success = false,
                        message =
                            "Play Mode에서는 Visual Offset을 생성/reparent하지 않습니다. " +
                            "Edit Mode에서 Visual Offset을 먼저 준비한 뒤 정렬하세요.",
                    };
                }

                origLocalPos = vo.localPosition;
                origLocalRot = vo.localRotation;
            }
            else
            {
                if (!TryEnsureVisualOffsetInEditMode(controllerHandRoot, handSide, out vo, out var ensureError))
                    return new AlignResult { success = false, message = ensureError };

                origLocalPos = vo.localPosition;
                origLocalRot = vo.localRotation;
            }

            Transform handRoot = controllerHandRoot;

            var wristLocalPos = handRoot.InverseTransformPoint(controllerWrist.position);
            var wristLocalRot = Quaternion.Inverse(handRoot.rotation) * controllerWrist.rotation;

            Quaternion targetHandRootRot;
            Vector3 targetHandRootPos;

            if (mode == AlignMode.PositionAndRotation)
            {
                targetHandRootRot = trackingWrist.rotation * Quaternion.Inverse(wristLocalRot);
                targetHandRootPos = trackingWrist.position - targetHandRootRot * wristLocalPos;
            }
            else
            {
                targetHandRootRot = trackingWrist.rotation * Quaternion.Inverse(wristLocalRot);
                targetHandRootPos = handRoot.position;
            }

            if (Application.isPlaying)
            {
                vo.SetPositionAndRotation(targetHandRootPos, targetHandRootRot);

                if (!TrySavePendingAlignment(
                        handSide,
                        mode,
                        vo.localPosition,
                        vo.localRotation,
                        vo.localScale,
                        origLocalPos,
                        origLocalRot,
                        out var pendingError))
                {
                    return new AlignResult
                    {
                        success = false,
                        message = pendingError,
                        visualOffset = vo,
                        wristPosInVO = wristLocalPos,
                        wristRotInVO = wristLocalRot,
                    };
                }

                return new AlignResult
                {
                    success = true,
                    pendingSaved = true,
                    message =
                        "정렬 결과를 저장했습니다. Play Mode 종료 후 Scene에 자동 적용합니다.",
                    visualOffset = vo,
                    wristPosInVO = wristLocalPos,
                    wristRotInVO = wristLocalRot,
                };
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Align Controller Hand");
            Undo.RecordObject(vo, "Align Controller Hand");
            vo.SetPositionAndRotation(targetHandRootPos, targetHandRootRot);
            EditorUtility.SetDirty(vo);
            if (PrefabUtility.IsPartOfPrefabInstance(vo))
                PrefabUtility.RecordPrefabInstancePropertyModifications(vo);
            if (controllerHandRoot.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(controllerHandRoot.gameObject.scene);
            Undo.CollapseUndoOperations(Undo.GetCurrentGroup());

            ClearPending(handSide);
            SetLastMessage(
                handSide,
                $"정렬 결과가 Scene에 적용되었습니다. Scene을 저장하세요.\n" +
                $"VO={vo.name}  localPos={vo.localPosition:F4}  localRot={vo.localRotation.eulerAngles:F2}",
                succeeded: true);

            return new AlignResult
            {
                success = true,
                message =
                    $"정렬 결과가 Scene에 적용되었습니다. Scene을 저장하세요.\n" +
                    $"VO={vo.name}  localPos={vo.localPosition:F4}  localRot={vo.localRotation.eulerAngles:F2}",
                visualOffset = vo,
                wristPosInVO = wristLocalPos,
                wristRotInVO = wristLocalRot,
            };
        }

        /// <summary>
        /// Edit Mode에서 Visual Offset을 생성하고 Playback Root를 하위로 배치합니다.
        /// Play Mode에서는 호출해도 생성하지 않습니다.
        /// </summary>
        public static bool TryEnsureVisualOffsetInEditMode(
            Transform playbackHandRoot,
            HandSide handSide,
            out Transform visualOffset,
            out string errorMessage)
        {
            visualOffset = null;
            errorMessage = null;

            if (Application.isPlaying || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                errorMessage = "Visual Offset은 Edit Mode에서만 생성할 수 있습니다.";
                return false;
            }

            if (playbackHandRoot == null)
            {
                errorMessage = "Playback Hand Root가 null입니다.";
                return false;
            }

            var (vo, _, _) = GetOrInsertVisualOffset(playbackHandRoot, handSide);
            if (vo == null)
            {
                errorMessage = "Visual Offset 생성 실패";
                return false;
            }

            visualOffset = vo;

            if (!HandSceneObjectLocator.CaptureAndStore(
                    vo,
                    handSide,
                    SceneObjectLocatorRole.VisualOffset,
                    out _,
                    out var locatorError))
            {
                // VO는 생성됐지만 Locator 실패 — Scene 미저장 등
                errorMessage = locatorError;
                return false;
            }

            HandSceneObjectLocator.CaptureAndStore(
                playbackHandRoot,
                handSide,
                SceneObjectLocatorRole.PlaybackHandRoot,
                out _,
                out _);

            if (playbackHandRoot.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);

            return true;
        }

        // ── 원상복구 ──────────────────────────────────────────────────────

        public static bool TryRestore(HandSide handSide, Transform controllerHandRoot)
        {
            if (controllerHandRoot == null) return false;

            var vo = FindVisualOffset(controllerHandRoot, handSide);
            if (vo == null) return false;

            Vector3 origPos = Vector3.zero;
            Quaternion origRot = Quaternion.identity;
            if (TryLoadPending(handSide, out var pending))
            {
                origPos = new Vector3(pending.origLocalPosX, pending.origLocalPosY, pending.origLocalPosZ);
                origRot = new Quaternion(
                    pending.origLocalRotX, pending.origLocalRotY, pending.origLocalRotZ, pending.origLocalRotW);
            }

            if (Application.isPlaying)
            {
                vo.localPosition = origPos;
                vo.localRotation = origRot;
            }
            else
            {
                Undo.IncrementCurrentGroup();
                Undo.SetCurrentGroupName("Restore Controller Hand Alignment");
                Undo.RecordObject(vo, "Restore Alignment");
                vo.localPosition = origPos;
                vo.localRotation = origRot;
                EditorUtility.SetDirty(vo);
                if (PrefabUtility.IsPartOfPrefabInstance(vo))
                    PrefabUtility.RecordPrefabInstancePropertyModifications(vo);
                if (controllerHandRoot.gameObject.scene.IsValid())
                    EditorSceneManager.MarkSceneDirty(controllerHandRoot.gameObject.scene);
                Undo.CollapseUndoOperations(Undo.GetCurrentGroup());
            }

            ClearPending(handSide);
            return true;
        }

        // ── Visual Offset 삽입 (Edit Mode only) ────────────────────────────

        static (Transform vo, Vector3 origLocalPos, Quaternion origLocalRot) GetOrInsertVisualOffset(
            Transform handRoot, HandSide handSide)
        {
            var voName = GetVisualOffsetName(handSide);

            if (handRoot.parent != null && handRoot.parent.name == voName)
                return (handRoot.parent, handRoot.parent.localPosition, handRoot.parent.localRotation);

            if (Application.isPlaying)
                return (null, Vector3.zero, Quaternion.identity);

            var origLocalPos = handRoot.localPosition;
            var origLocalRot = handRoot.localRotation;

            Transform parent = handRoot.parent;
            Transform vo = null;

            if (parent != null)
            {
                for (int i = 0; i < parent.childCount; i++)
                {
                    if (parent.GetChild(i).name == voName)
                    { vo = parent.GetChild(i); break; }
                }
            }

            if (vo == null)
            {
                var voGo = new GameObject(voName);
                Undo.RegisterCreatedObjectUndo(voGo, "Create Visual Offset");
                vo = voGo.transform;
                vo.SetParent(parent, false);
                vo.localPosition = origLocalPos;
                vo.localRotation = origLocalRot;
                vo.localScale = Vector3.one;
            }

            if (handRoot.parent != vo)
            {
                Undo.SetTransformParent(handRoot, vo, "Reparent to Visual Offset");
                handRoot.localPosition = Vector3.zero;
                handRoot.localRotation = Quaternion.identity;
                handRoot.localScale = Vector3.one;
            }

            EditorUtility.SetDirty(handRoot);
            EditorUtility.SetDirty(vo);
            if (PrefabUtility.IsPartOfPrefabInstance(handRoot))
                PrefabUtility.RecordPrefabInstancePropertyModifications(handRoot);
            if (PrefabUtility.IsPartOfPrefabInstance(vo))
                PrefabUtility.RecordPrefabInstancePropertyModifications(vo);

            return (vo, vo.localPosition, vo.localRotation);
        }

        public static Transform FindVisualOffset(Transform controllerHandRoot, HandSide handSide)
        {
            if (controllerHandRoot == null) return null;
            var voName = GetVisualOffsetName(handSide);

            if (controllerHandRoot.parent != null && controllerHandRoot.parent.name == voName)
                return controllerHandRoot.parent;

            var p = controllerHandRoot.parent;
            while (p != null)
            {
                if (p.name == voName) return p;
                p = p.parent;
            }

            return null;
        }

        // ── Play Mode 종료 후 Edit Mode 재적용 ───────────────────────────

        static void OnPlayModeChanged(PlayModeStateChange state)
        {
            if (state != PlayModeStateChange.EnteredEditMode) return;
            EditorApplication.delayCall -= TryApplyAllPendingOnEditMode;
            EditorApplication.delayCall += TryApplyAllPendingOnEditMode;
        }

        static void TryApplyAllPendingOnEditMode()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            TryApplyPending(HandSide.Left, forceRetry: false, out _);
            TryApplyPending(HandSide.Right, forceRetry: false, out _);
        }

        public static bool HasPending(HandSide handSide) => TryLoadPending(handSide, out _);

        public static bool HasAnyPending() =>
            HasPending(HandSide.Left) || HasPending(HandSide.Right);

        /// <summary>하위 호환: 아무 손이든 pending이 있으면 true.</summary>
        public static bool HasSessionData() => HasAnyPending();

        public static PendingApplyStatus GetPendingStatus(HandSide handSide)
        {
            if (TryLoadPending(handSide, out var pending))
            {
                if (pending.lifecycleStatus != 0)
                    return (PendingApplyStatus)pending.lifecycleStatus;
                if (pending.autoApplyAttempted)
                {
                    return (pending.lastFailureReason != null
                            && pending.lastFailureReason.IndexOf("복원", StringComparison.Ordinal) >= 0)
                        ? PendingApplyStatus.FailedToResolveTarget
                        : PendingApplyStatus.FailedToApply;
                }

                return PendingApplyStatus.PendingWaitingForEditMode;
            }

            if (GetLastSucceeded(handSide))
                return PendingApplyStatus.Applied;

            return PendingApplyStatus.None;
        }

        public static string GetLastMessage(HandSide handSide) =>
            SessionState.GetString(LastMessageKey(handSide), string.Empty);

        public static bool GetLastSucceeded(HandSide handSide) =>
            SessionState.GetBool(LastSucceededKey(handSide), false);

        public static string GetPendingUiMessage(HandSide handSide)
        {
            var status = GetPendingStatus(handSide);
            switch (status)
            {
                case PendingApplyStatus.PendingWaitingForEditMode:
                    return "정렬 결과를 저장했습니다. Play Mode 종료 후 Scene에 자동 적용합니다.";
                case PendingApplyStatus.ApplyingInEditMode:
                    return "Edit Mode Scene에 정렬값을 적용하는 중…";
                case PendingApplyStatus.Applied:
                    return string.IsNullOrEmpty(GetLastMessage(handSide))
                        ? "정렬 결과가 Scene에 적용되었습니다. Scene을 저장하세요."
                        : GetLastMessage(handSide);
                case PendingApplyStatus.FailedToResolveTarget:
                    return "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다.";
                case PendingApplyStatus.FailedToApply:
                    return string.IsNullOrEmpty(GetLastMessage(handSide))
                        ? "정렬 pending 적용에 실패했습니다."
                        : GetLastMessage(handSide);
                default:
                    return null;
            }
        }

        public static bool TryApplyPendingNow(HandSide handSide, bool forceRetry = true)
        {
            return TryApplyPending(handSide, forceRetry, out _);
        }

        public static void ClearPending(HandSide handSide)
        {
            SessionState.EraseString(PendingJsonKey(handSide));
        }

        public static void ClearPendingStatus(HandSide handSide)
        {
            ClearPending(handSide);
            SessionState.EraseString(LastMessageKey(handSide));
            SessionState.SetBool(LastSucceededKey(handSide), false);
        }

        public static void SavePendingForTests(HandSide handSide, PendingAlignmentData pending)
        {
            SavePending(handSide, pending);
        }

        public static bool TryLoadPendingForTests(HandSide handSide, out PendingAlignmentData pending)
        {
            return TryLoadPending(handSide, out pending);
        }

        public static bool TryApplyPendingInternalForTests(PendingAlignmentData pending, out string message)
        {
            return TryApplyPendingInternal(pending, out message);
        }

        static bool TryApplyPending(HandSide handSide, bool forceRetry, out string message)
        {
            message = null;

            if (!TryLoadPending(handSide, out var pending))
            {
                message = "적용 대기 중인 정렬이 없습니다.";
                return false;
            }

            if ((HandSide)pending.handSide != handSide)
            {
                message = "Pending handSide가 요청 handSide와 일치하지 않습니다.";
                SetLastMessage(handSide, message, succeeded: false);
                return false;
            }

            var status = (PendingApplyStatus)pending.lifecycleStatus;
            if (pending.autoApplyAttempted
                && !forceRetry
                && (status == PendingApplyStatus.FailedToResolveTarget
                    || status == PendingApplyStatus.FailedToApply
                    || status == 0))
            {
                message = string.IsNullOrEmpty(pending.lastFailureReason)
                    ? GetLastMessage(handSide)
                    : pending.lastFailureReason;
                return false;
            }

            pending.lifecycleStatus = (int)PendingApplyStatus.ApplyingInEditMode;
            SavePending(handSide, pending);

            if (!TryApplyPendingInternal(pending, out message))
            {
                var failStatus = (message != null && message.IndexOf("복원", StringComparison.Ordinal) >= 0)
                    ? PendingApplyStatus.FailedToResolveTarget
                    : PendingApplyStatus.FailedToApply;
                pending.autoApplyAttempted = true;
                pending.lastFailureReason = message;
                pending.lifecycleStatus = (int)failStatus;
                SavePending(handSide, pending);
                SetLastMessage(handSide, message, succeeded: false);
                return false;
            }

            ClearPending(handSide);
            SetLastMessage(handSide, message, succeeded: true);
            return true;
        }

        static bool TryApplyPendingInternal(PendingAlignmentData pending, out string message)
        {
            message = null;

            if (pending == null || string.IsNullOrWhiteSpace(pending.applyToken))
            {
                message = "정렬 적용 실패: pending applyToken이 비어 있습니다.";
                return false;
            }

            var handSide = (HandSide)pending.handSide;
            var locator = HandSceneObjectLocator.FromJson(pending.visualOffsetLocatorJson);
            if (locator == null || !locator.isValid)
            {
                if (!HandSceneObjectLocator.TryGetStored(
                        handSide, SceneObjectLocatorRole.VisualOffset, out locator)
                    || locator == null
                    || !locator.isValid)
                {
                    message =
                        "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다.\n" +
                        "(Visual Offset Edit Mode Locator가 없습니다.)";
                    return false;
                }
            }

            var resolve = HandSceneObjectLocator.Resolve(
                locator,
                handSide,
                SceneObjectLocatorRole.VisualOffset,
                allowPlaybackFinderFallback: false);

            if (!resolve.success || resolve.transform == null)
            {
                message = string.IsNullOrEmpty(resolve.message)
                    ? "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다."
                    : resolve.message;
                return false;
            }

            var vo = resolve.transform;
            var expectedPos = new Vector3(pending.localPosX, pending.localPosY, pending.localPosZ);
            var expectedRot = new Quaternion(
                pending.localRotX, pending.localRotY, pending.localRotZ, pending.localRotW);
            var expectedScale = new Vector3(pending.localScaleX, pending.localScaleY, pending.localScaleZ);

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Apply Controller Alignment from Play Mode");
            Undo.RecordObject(vo, "Apply Alignment");
            vo.localPosition = expectedPos;
            vo.localRotation = expectedRot;
            vo.localScale = expectedScale;
            EditorUtility.SetDirty(vo);
            if (PrefabUtility.IsPartOfPrefabInstance(vo))
                PrefabUtility.RecordPrefabInstancePropertyModifications(vo);
            if (vo.gameObject.scene.IsValid())
                EditorSceneManager.MarkSceneDirty(vo.gameObject.scene);
            Undo.CollapseUndoOperations(Undo.GetCurrentGroup());

            if (!Approximately(vo.localPosition, expectedPos)
                || !Approximately(vo.localRotation, expectedRot)
                || !Approximately(vo.localScale, expectedScale))
            {
                message =
                    "정렬 적용 후 재검증 실패: Visual Offset localPose가 pending 값과 일치하지 않습니다.";
                return false;
            }

            message =
                $"정렬 결과가 Scene에 적용되었습니다. Scene을 저장하세요.\n" +
                $"VO={vo.name}  localPos={vo.localPosition:F4}  eulerRot={vo.localRotation.eulerAngles:F2}";
            return true;
        }

        static bool TrySavePendingAlignment(
            HandSide handSide,
            AlignMode mode,
            Vector3 voLocalPos,
            Quaternion voLocalRot,
            Vector3 voLocalScale,
            Vector3 origLocalPos,
            Quaternion origLocalRot,
            out string errorMessage)
        {
            errorMessage = null;

            if (!HandSceneObjectLocator.TryGetStored(
                    handSide,
                    SceneObjectLocatorRole.VisualOffset,
                    out var locator)
                || locator == null
                || !locator.isValid)
            {
                errorMessage =
                    "Edit Mode Visual Offset Locator가 없습니다. " +
                    "Edit Mode에서 Visual Offset을 준비한 뒤 정렬하세요.";
                return false;
            }

            var pending = new PendingAlignmentData
            {
                applyToken = Guid.NewGuid().ToString("N"),
                scenePath = locator.scenePath,
                handRootGlobalObjectId = string.Empty,
                targetTransformGlobalObjectId = locator.editModeGlobalObjectId ?? string.Empty,
                visualOffsetLocatorJson = HandSceneObjectLocator.ToJson(locator),
                targetRole = TargetRoleVisualOffset,
                handSide = (int)handSide,
                alignMode = (int)mode,
                localPosX = voLocalPos.x,
                localPosY = voLocalPos.y,
                localPosZ = voLocalPos.z,
                localRotX = voLocalRot.x,
                localRotY = voLocalRot.y,
                localRotZ = voLocalRot.z,
                localRotW = voLocalRot.w,
                localScaleX = voLocalScale.x,
                localScaleY = voLocalScale.y,
                localScaleZ = voLocalScale.z,
                origLocalPosX = origLocalPos.x,
                origLocalPosY = origLocalPos.y,
                origLocalPosZ = origLocalPos.z,
                origLocalRotX = origLocalRot.x,
                origLocalRotY = origLocalRot.y,
                origLocalRotZ = origLocalRot.z,
                origLocalRotW = origLocalRot.w,
                createdAtUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture),
                autoApplyAttempted = false,
                lastFailureReason = string.Empty,
                lifecycleStatus = (int)PendingApplyStatus.PendingWaitingForEditMode,
            };

            SavePending(handSide, pending);
            ClearLastMessage(handSide);
            return true;
        }

        static bool TryLoadPending(HandSide handSide, out PendingAlignmentData pending)
        {
            pending = null;
            var json = SessionState.GetString(PendingJsonKey(handSide), string.Empty);
            if (string.IsNullOrWhiteSpace(json))
                return false;

            try
            {
                pending = JsonUtility.FromJson<PendingAlignmentData>(json);
                return pending != null
                    && !string.IsNullOrWhiteSpace(pending.applyToken)
                    && !string.IsNullOrWhiteSpace(pending.scenePath)
                    && (!string.IsNullOrWhiteSpace(pending.visualOffsetLocatorJson)
                        || !string.IsNullOrWhiteSpace(pending.handRootGlobalObjectId))
                    && pending.handSide == (int)handSide;
            }
            catch
            {
                pending = null;
                return false;
            }
        }

        static void SavePending(HandSide handSide, PendingAlignmentData pending)
        {
            SessionState.SetString(PendingJsonKey(handSide), JsonUtility.ToJson(pending));
        }

        static void SetLastMessage(HandSide handSide, string message, bool succeeded)
        {
            SessionState.SetString(LastMessageKey(handSide), message ?? string.Empty);
            SessionState.SetBool(LastSucceededKey(handSide), succeeded);
        }

        static void ClearLastMessage(HandSide handSide)
        {
            SessionState.EraseString(LastMessageKey(handSide));
            SessionState.SetBool(LastSucceededKey(handSide), false);
        }

        static string PendingJsonKey(HandSide handSide) => PendingJsonKeyPrefix + handSide;
        static string LastMessageKey(HandSide handSide) => LastMessageKeyPrefix + handSide;
        static string LastSucceededKey(HandSide handSide) => LastSucceededKeyPrefix + handSide;

        static void ClearLegacySessionKeys()
        {
            SessionState.EraseBool(LegacySkBase + "HasData");
            SessionState.EraseString(LegacySkBase + "HandRootGoid");
            SessionState.EraseString(LegacySkBase + "VoLocalPos");
            SessionState.EraseString(LegacySkBase + "VoLocalRot");
            SessionState.EraseString(LegacySkBase + "OrigLocalPos");
            SessionState.EraseString(LegacySkBase + "OrigLocalRot");
        }

        // ── 유틸리티 ──────────────────────────────────────────────────────

        public static string GetVisualOffsetName(HandSide handSide)
            => VisualOffsetPrefix + (handSide == HandSide.Left ? "Left" : "Right");

        public static (bool hasVO, Vector3 localPos, Quaternion localRot) GetVisualOffsetState(
            HandSide handSide, Transform controllerHandRoot)
        {
            if (controllerHandRoot == null) return (false, Vector3.zero, Quaternion.identity);
            var vo = FindVisualOffset(controllerHandRoot, handSide);
            if (vo == null) return (false, Vector3.zero, Quaternion.identity);
            return (true, vo.localPosition, vo.localRotation);
        }

        /// <summary>
        /// Edit Mode에서 Visual Offset이 최종 적용됐는지 (Play Mode 임시 VO는 pending으로만 인정).
        /// </summary>
        public static bool IsVisualOffsetAuthoredInEditMode(HandSide handSide, Transform controllerHandRoot)
        {
            if (Application.isPlaying)
                return false;
            if (HasPending(handSide))
                return false;
            var (hasVO, _, _) = GetVisualOffsetState(handSide, controllerHandRoot);
            return hasVO;
        }

        static Transform FindBoneRecursive(Transform root, string boneName)
        {
            if (root == null) return null;
            if (root.name == boneName) return root;
            foreach (Transform child in root)
            {
                var found = FindBoneRecursive(child, boneName);
                if (found != null) return found;
            }
            return null;
        }

        static bool TryGetGlobalObjectIdString(
            UnityEngine.Object target,
            out string globalObjectIdString,
            out string errorMessage)
        {
            globalObjectIdString = null;
            errorMessage = null;
            if (target == null)
            {
                errorMessage = "GlobalObjectId 대상이 null입니다.";
                return false;
            }

            try
            {
                var goid = GlobalObjectId.GetGlobalObjectIdSlow(target);
                globalObjectIdString = goid.ToString();
                if (string.IsNullOrWhiteSpace(globalObjectIdString)
                    || globalObjectIdString == "GlobalObjectId_V1-0-00000000000000000000000000000000-0-0")
                {
                    errorMessage = "GlobalObjectId가 유효하지 않습니다.";
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = $"GlobalObjectId를 구하지 못했습니다: {ex.Message}";
                return false;
            }
        }

        static GameObject ResolveGameObject(UnityEngine.Object resolvedObject)
        {
            if (resolvedObject == null) return null;
            if (resolvedObject is GameObject go) return go;
            if (resolvedObject is Component c) return c.gameObject;
            return null;
        }

        static bool Approximately(Vector3 a, Vector3 b) =>
            (a - b).sqrMagnitude <= TransformEpsilon * TransformEpsilon;

        static bool Approximately(Quaternion a, Quaternion b) =>
            Quaternion.Angle(a, b) <= 0.1f;
    }
}
