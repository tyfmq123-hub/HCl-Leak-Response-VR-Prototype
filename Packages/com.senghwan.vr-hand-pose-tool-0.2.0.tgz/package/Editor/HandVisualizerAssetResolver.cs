using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Import된 HandVisualizer Sample.importPath 아래에서
    /// Tracking Prefab / Playback 모델을 동적으로 탐색·검증합니다.
    /// 버전·경로 하드코딩을 사용하지 않습니다.
    /// </summary>
    public static class HandVisualizerAssetResolver
    {
        public struct PrefabCandidate
        {
            public string assetPath;
            public string assetName;
            public int score;
            public bool hasTrackingEvents;
            public bool handednessMatches;
            public bool hasSkeletonDriver;
            public bool skeletonDriverEnabled;
            public int jointReferenceCount;
            public bool hasSkinnedMesh;
            public bool hasMeshController;
            public bool skeletonValid;
            public string failReason;
            public bool isValid;
        }

        public struct ResolveResult
        {
            public bool success;
            public string assetPath;
            public GameObject prefab;
            public List<PrefabCandidate> candidates;
            public List<PrefabCandidate> validCandidates;
            public string importPath;
            public string message;
        }

        public static ResolveResult ResolveTrackingPrefab(HandSide handSide, string importPath)
        {
            var result = new ResolveResult
            {
                importPath = importPath,
                candidates = new List<PrefabCandidate>(),
                validCandidates = new List<PrefabCandidate>(),
            };

            if (!TryResolveAssetImportFolder(
                    importPath,
                    out var assetImportPath,
                    out _,
                    out var folderError))
            {
                result.message = folderError;
                return result;
            }

            result.importPath = assetImportPath;

            var guids = AssetDatabase.FindAssets("t:Prefab", new[] { assetImportPath });
            var expectedHandedness = HandSideUtility.ToHandedness(handSide);
            var sideLabel = HandSideUtility.GetLabel(handSide);

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path))
                    continue;

                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (prefab == null)
                    continue;

                var candidate = EvaluateTrackingPrefab(prefab, path, handSide, expectedHandedness);
                result.candidates.Add(candidate);
                if (candidate.isValid)
                    result.validCandidates.Add(candidate);
            }

            result.validCandidates = result.validCandidates
                .OrderByDescending(c => c.score)
                .ThenBy(c => c.assetPath, StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (result.validCandidates.Count == 0)
            {
                result.message = BuildNoValidTrackingMessage(handSide, assetImportPath, result.candidates);
                return result;
            }

            if (result.validCandidates.Count > 1)
            {
                var sb = new StringBuilder();
                sb.AppendLine(
                    $"{sideLabel} Tracking Prefab 유효 후보가 {result.validCandidates.Count}개입니다. 임의 선택하지 않습니다.");
                foreach (var candidate in result.validCandidates)
                {
                    sb.Append("• ");
                    sb.Append(candidate.assetPath);
                    sb.Append($" (score={candidate.score})");
                    sb.AppendLine();
                }

                result.message = sb.ToString().TrimEnd();
                return result;
            }

            var selected = result.validCandidates[0];
            result.success = true;
            result.assetPath = selected.assetPath;
            result.prefab = AssetDatabase.LoadAssetAtPath<GameObject>(selected.assetPath);
            result.message =
                $"{sideLabel} Tracking Prefab 선택: {selected.assetPath}\n" +
                $"joints={selected.jointReferenceCount}, skeletonOK={selected.skeletonValid}, " +
                $"meshController={selected.hasMeshController}";
            return result;
        }

        public static ResolveResult ResolvePlaybackModel(HandSide handSide, string importPath)
        {
            var result = new ResolveResult
            {
                importPath = importPath,
                candidates = new List<PrefabCandidate>(),
                validCandidates = new List<PrefabCandidate>(),
            };

            if (!TryResolveAssetImportFolder(
                    importPath,
                    out var assetImportPath,
                    out _,
                    out var folderError))
            {
                result.message = folderError;
                return result;
            }

            result.importPath = assetImportPath;

            // Prefab + Model(FBX 등) 모두 탐색
            var guids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var guid in AssetDatabase.FindAssets("t:Prefab", new[] { assetImportPath }))
                guids.Add(guid);
            foreach (var guid in AssetDatabase.FindAssets("t:Model", new[] { assetImportPath }))
                guids.Add(guid);

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path))
                    continue;

                var asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (asset == null)
                    continue;

                var candidate = EvaluatePlaybackModel(asset, path, handSide);
                result.candidates.Add(candidate);
                if (candidate.isValid)
                    result.validCandidates.Add(candidate);
            }

            result.validCandidates = result.validCandidates
                .OrderByDescending(c => c.score)
                .ThenBy(c => c.assetPath, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var sideLabel = HandSideUtility.GetLabel(handSide);
            if (result.validCandidates.Count == 0)
            {
                result.message = BuildNoValidPlaybackMessage(handSide, assetImportPath, result.candidates);
                return result;
            }

            if (result.validCandidates.Count > 1)
            {
                // LeftHand vs LeftHandAndroidXR 등: 이름 점수 최고가 유일할 때만 선택
                var topScore = result.validCandidates[0].score;
                var topTied = result.validCandidates.Where(c => c.score == topScore).ToList();
                if (topTied.Count > 1)
                {
                    var sb = new StringBuilder();
                    sb.AppendLine(
                        $"{sideLabel} Playback 모델 유효 후보가 {result.validCandidates.Count}개이며 " +
                        "최고 점수 동점입니다. 임의 선택하지 않습니다.");
                    foreach (var candidate in result.validCandidates)
                    {
                        sb.Append("• ");
                        sb.Append(candidate.assetPath);
                        sb.Append($" (score={candidate.score})");
                        sb.AppendLine();
                    }

                    result.message = sb.ToString().TrimEnd();
                    return result;
                }
            }

            var selected = result.validCandidates[0];
            result.success = true;
            result.assetPath = selected.assetPath;
            result.prefab = AssetDatabase.LoadAssetAtPath<GameObject>(selected.assetPath);
            result.message =
                $"{sideLabel} Playback 모델 선택: {selected.assetPath}";
            return result;
        }

        static bool TryResolveAssetImportFolder(
            string rawImportPath,
            out string assetImportPath,
            out string physicalImportPath,
            out string errorMessage)
        {
            assetImportPath = null;
            physicalImportPath = null;
            errorMessage = null;

            if (!HandVisualizerSampleImportService.TryResolveSampleImportPaths(
                    rawImportPath,
                    out assetImportPath,
                    out physicalImportPath,
                    out var normalizeFailure))
            {
                errorMessage =
                    "Sample importPath를 Unity Asset 경로로 변환할 수 없습니다.\n" +
                    $"원본: {rawImportPath ?? "(null)"}\n" +
                    $"프로젝트 Assets: {Application.dataPath}\n" +
                    $"이유: {normalizeFailure}";
                return false;
            }

            if (!AssetDatabase.IsValidFolder(assetImportPath))
            {
                var physicalExists = !string.IsNullOrEmpty(physicalImportPath)
                    && Directory.Exists(physicalImportPath);
                errorMessage =
                    "HandVisualizer 폴더를 AssetDatabase에서 찾지 못했습니다.\n" +
                    $"물리 경로: {physicalImportPath ?? "(null)"}" +
                    (physicalExists ? " (존재함)" : " (없음)") + "\n" +
                    $"Asset 경로: {assetImportPath}";
                return false;
            }

            return true;
        }

        public static ResolveResult ResolveTrackingPrefabForImportedSample(HandSide handSide)
        {
            if (!HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var message))
            {
                return new ResolveResult
                {
                    candidates = new List<PrefabCandidate>(),
                    validCandidates = new List<PrefabCandidate>(),
                    message = message,
                };
            }

            return ResolveTrackingPrefab(handSide, sample.assetImportPath ?? sample.importPath);
        }

        public static ResolveResult ResolvePlaybackModelForImportedSample(HandSide handSide)
        {
            if (!HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var message))
            {
                return new ResolveResult
                {
                    candidates = new List<PrefabCandidate>(),
                    validCandidates = new List<PrefabCandidate>(),
                    message = message,
                };
            }

            return ResolvePlaybackModel(handSide, sample.assetImportPath ?? sample.importPath);
        }

        public static PrefabCandidate EvaluateTrackingPrefab(
            GameObject root,
            string assetPath,
            HandSide handSide,
            Handedness expectedHandedness)
        {
            var candidate = new PrefabCandidate
            {
                assetPath = assetPath,
                assetName = string.IsNullOrEmpty(assetPath)
                    ? root != null ? root.name : string.Empty
                    : Path.GetFileNameWithoutExtension(assetPath),
            };

            if (root == null)
            {
                candidate.failReason = "Prefab을 로드할 수 없습니다.";
                return candidate;
            }

            var trackingEvents = root.GetComponent<XRHandTrackingEvents>()
                ?? root.GetComponentInChildren<XRHandTrackingEvents>(true);
            candidate.hasTrackingEvents = trackingEvents != null;
            if (trackingEvents == null)
            {
                candidate.failReason = "XRHandTrackingEvents 없음";
                return candidate;
            }

            candidate.handednessMatches = trackingEvents.handedness == expectedHandedness;
            if (!candidate.handednessMatches)
            {
                candidate.failReason =
                    $"handedness 불일치 (expected={expectedHandedness}, actual={trackingEvents.handedness})";
                return candidate;
            }

            var skeletonDriver = root.GetComponent<XRHandSkeletonDriver>()
                ?? root.GetComponentInChildren<XRHandSkeletonDriver>(true);
            candidate.hasSkeletonDriver = skeletonDriver != null;
            if (skeletonDriver == null)
            {
                candidate.failReason = "XRHandSkeletonDriver 없음";
                return candidate;
            }

            candidate.skeletonDriverEnabled = skeletonDriver.enabled;
            if (!skeletonDriver.enabled)
            {
                candidate.failReason = "XRHandSkeletonDriver disabled";
                return candidate;
            }

            candidate.jointReferenceCount = skeletonDriver.jointTransformReferences?.Count ?? 0;
            if (candidate.jointReferenceCount != HandSkeletonCatalog.RequiredBoneCount)
            {
                candidate.failReason =
                    $"jointTransformReferences {candidate.jointReferenceCount}/{HandSkeletonCatalog.RequiredBoneCount}";
                return candidate;
            }

            var skinnedMesh = root.GetComponentInChildren<SkinnedMeshRenderer>(true);
            candidate.hasSkinnedMesh = skinnedMesh != null;
            if (skinnedMesh == null)
            {
                candidate.failReason = "SkinnedMeshRenderer 없음";
                return candidate;
            }

            var meshController = root.GetComponent<XRHandMeshController>()
                ?? root.GetComponentInChildren<XRHandMeshController>(true);
            candidate.hasMeshController = meshController != null;

            // Skeleton driver root 또는 메시 루트 기준으로 카탈로그 검증
            var skeletonRoot = ResolveSkeletonRoot(root, skeletonDriver);
            var validation = HandSkeletonCatalog.Validate(skeletonRoot, handSide);
            candidate.skeletonValid = validation.isValid;
            if (!validation.isValid)
            {
                candidate.failReason = $"HandSkeletonCatalog 실패: {validation.summary}";
                return candidate;
            }

            candidate.isValid = true;
            candidate.score = ScoreTrackingName(candidate.assetName, handSide);
            if (candidate.hasMeshController)
                candidate.score += 5;
            return candidate;
        }

        public static PrefabCandidate EvaluatePlaybackModel(
            GameObject root,
            string assetPath,
            HandSide handSide)
        {
            var candidate = new PrefabCandidate
            {
                assetPath = assetPath,
                assetName = string.IsNullOrEmpty(assetPath)
                    ? root != null ? root.name : string.Empty
                    : Path.GetFileNameWithoutExtension(assetPath),
            };

            if (root == null)
            {
                candidate.failReason = "모델을 로드할 수 없습니다.";
                return candidate;
            }

            // Tracking Prefab과 혼동 금지
            if (root.GetComponentInChildren<XRHandSkeletonDriver>(true) != null
                || root.GetComponentInChildren<XRHandTrackingEvents>(true) != null)
            {
                candidate.failReason = "Tracking 컴포넌트가 있어 Playback 후보에서 제외";
                candidate.hasSkeletonDriver = root.GetComponentInChildren<XRHandSkeletonDriver>(true) != null;
                candidate.hasTrackingEvents = root.GetComponentInChildren<XRHandTrackingEvents>(true) != null;
                return candidate;
            }

            // 반대 손 이름 강한 배제
            if (NameClearlyOppositeSide(candidate.assetName, handSide))
            {
                candidate.failReason = $"반대 손 모델로 판단됨: {candidate.assetName}";
                return candidate;
            }

            var skinnedMesh = root.GetComponentInChildren<SkinnedMeshRenderer>(true);
            candidate.hasSkinnedMesh = skinnedMesh != null;
            if (skinnedMesh == null)
            {
                candidate.failReason = "SkinnedMeshRenderer 없음";
                return candidate;
            }

            var validation = HandSkeletonCatalog.Validate(root.transform, handSide);
            candidate.skeletonValid = validation.isValid;
            if (!validation.isValid)
            {
                candidate.failReason = $"HandSkeletonCatalog 실패: {validation.summary}";
                return candidate;
            }

            var wristName = HandSideUtility.GetWristBoneName(handSide);
            if (!HasNamedBone(root.transform, wristName))
            {
                candidate.failReason = $"{wristName} 본 없음";
                return candidate;
            }

            candidate.isValid = true;
            candidate.score = ScorePlaybackName(candidate.assetName, assetPath, handSide);
            return candidate;
        }

        static Transform ResolveSkeletonRoot(GameObject root, XRHandSkeletonDriver driver)
        {
            if (driver != null && driver.jointTransformReferences != null)
            {
                foreach (var jointRef in driver.jointTransformReferences)
                {
                    if (jointRef.jointTransform != null)
                        return jointRef.jointTransform.root == root.transform
                            ? root.transform
                            : FindCommonHandRoot(root.transform, jointRef.jointTransform);
                }
            }

            return root.transform;
        }

        static Transform FindCommonHandRoot(Transform prefabRoot, Transform joint)
        {
            var current = joint;
            while (current != null && current.parent != null && current.parent != prefabRoot)
                current = current.parent;
            return prefabRoot;
        }

        static int ScoreTrackingName(string assetName, HandSide handSide)
        {
            var score = 0;
            var normalized = HandVisualizerSampleImportService.NormalizeName(assetName);
            var side = HandSideUtility.GetLabel(handSide).ToLowerInvariant();
            var opposite = HandSideUtility.GetLabel(
                handSide == HandSide.Left ? HandSide.Right : HandSide.Left).ToLowerInvariant();

            if (normalized.Contains("tracking"))
                score += 20;
            if (normalized.Contains("hand") && normalized.Contains(side))
                score += 30;
            else if (normalized.Contains(side))
                score += 15;
            if (normalized.Contains(opposite) && !normalized.Contains(side))
                score -= 50;
            return score;
        }

        static int ScorePlaybackName(string assetName, string assetPath, HandSide handSide)
        {
            var score = 0;
            var normalized = HandVisualizerSampleImportService.NormalizeName(assetName);
            var preferred = HandVisualizerSampleImportService.NormalizeName(
                HandSideUtility.GetPreferredHandRootName(handSide));
            var side = HandSideUtility.GetLabel(handSide).ToLowerInvariant();
            var opposite = HandSideUtility.GetLabel(
                handSide == HandSide.Left ? HandSide.Right : HandSide.Left).ToLowerInvariant();

            if (normalized == preferred)
                score += 40;
            else if (normalized.Contains(preferred))
                score += 25;
            else if (normalized.Contains(side) && normalized.Contains("hand"))
                score += 20;
            else if (normalized.Contains(side))
                score += 10;

            if (normalized.Contains(opposite) && !normalized.Contains(side))
                score -= 50;

            if (!string.IsNullOrEmpty(assetPath)
                && assetPath.IndexOf("Models", StringComparison.OrdinalIgnoreCase) >= 0)
                score += 10;

            if (!string.IsNullOrEmpty(assetPath)
                && assetPath.EndsWith(".fbx", StringComparison.OrdinalIgnoreCase))
                score += 5;

            // AndroidXR 등 변형보다 기본 모델 우선
            if (normalized.Contains("android"))
                score -= 8;

            return score;
        }

        static bool NameClearlyOppositeSide(string assetName, HandSide handSide)
        {
            var normalized = HandVisualizerSampleImportService.NormalizeName(assetName);
            var side = HandSideUtility.GetLabel(handSide).ToLowerInvariant();
            var opposite = HandSideUtility.GetLabel(
                handSide == HandSide.Left ? HandSide.Right : HandSide.Left).ToLowerInvariant();

            return normalized.Contains(opposite) && !normalized.Contains(side);
        }

        static bool HasNamedBone(Transform root, string boneName)
        {
            foreach (var transform in root.GetComponentsInChildren<Transform>(true))
            {
                if (transform == root)
                    continue;
                if (string.Equals(transform.name, boneName, StringComparison.Ordinal))
                    return true;
            }

            return false;
        }

        static string BuildNoValidTrackingMessage(
            HandSide handSide,
            string importPath,
            List<PrefabCandidate> candidates)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var sb = new StringBuilder();
            sb.AppendLine($"{sideLabel} Tracking Prefab 유효 후보가 0개입니다.");
            sb.AppendLine($"탐색 범위: {importPath}");
            sb.AppendLine(
                "필요: XRHandTrackingEvents(handedness), XRHandSkeletonDriver(enabled, 26 joints), " +
                "SkinnedMeshRenderer, HandSkeletonCatalog");
            AppendCandidateFailures(sb, candidates);
            return sb.ToString().TrimEnd();
        }

        static string BuildNoValidPlaybackMessage(
            HandSide handSide,
            string importPath,
            List<PrefabCandidate> candidates)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var sb = new StringBuilder();
            sb.AppendLine($"{sideLabel} Playback 모델 유효 후보가 0개입니다.");
            sb.AppendLine($"탐색 범위: {importPath}");
            sb.AppendLine(
                "필요: SkinnedMeshRenderer, HandSkeletonCatalog, Wrist 본 (Tracking Prefab 제외)");
            AppendCandidateFailures(sb, candidates);
            return sb.ToString().TrimEnd();
        }

        static void AppendCandidateFailures(StringBuilder sb, List<PrefabCandidate> candidates)
        {
            if (candidates == null || candidates.Count == 0)
            {
                sb.AppendLine("• Prefab/Model 후보 없음");
                return;
            }

            var shown = 0;
            foreach (var candidate in candidates)
            {
                if (candidate.isValid)
                    continue;
                sb.Append("• ");
                sb.Append(candidate.assetPath);
                sb.Append(" — ");
                sb.AppendLine(candidate.failReason ?? "검증 실패");
                shown++;
                if (shown >= 12)
                {
                    sb.AppendLine("• ...");
                    break;
                }
            }
        }
    }
}
