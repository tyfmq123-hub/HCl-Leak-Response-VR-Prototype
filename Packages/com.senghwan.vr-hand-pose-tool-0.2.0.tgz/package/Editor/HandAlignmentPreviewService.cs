using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play Mode에서 Controller Hand의 SkinnedMeshRenderer를 Tracking Hand 손목 위치에
    /// 겹쳐 표시하는 "정렬 미리보기" 클론을 관리합니다.
    ///
    /// 동작 원칙
    /// ─────────
    /// · 원본 Controller Hand를 절대 수정하지 않습니다.
    ///   (activeSelf / Renderer / Animator / GripDriver / 입력 시스템 변경 없음)
    /// · controllerHandRoot 계층을 Instantiate → 비시각 컴포넌트를 전부 제거한
    ///   순수 Visual 전용 클론을 만듭니다. (입력·Collider·Interactor 없음)
    /// · 클론의 손목 본(Wrist bone)이 Tracking Hand 손목 위치와 정확히 겹치도록
    ///   매 프레임 클론 Root 위치를 조정합니다.
    ///   클론의 회전은 Controller Hand Root의 회전을 그대로 유지해 방향 차이를 시각적으로 비교합니다.
    /// · Ghost Hand는 미리보기 대상에서 제외합니다.
    /// · EndPreview() / PlayMode 종료 / Window OnDisable 시 클론을 즉시 삭제합니다.
    ///
    /// 수학적 근거 (SyncClonePoses)
    /// ──────────────────────────────
    ///   cloneRoot.rotation = controllerHandRoot.rotation                    … (A)
    ///   복사된 자식 Local transform → 클론 손목 World offset = 원본 손목 World offset
    ///   wristWorldOffset = originalWrist.position − controllerHandRoot.position
    ///   cloneRoot.position = trackingWrist.position − wristWorldOffset      … (B)
    ///   ∴ cloneWrist.world ≡ trackingWrist.world                           □
    /// </summary>
    [InitializeOnLoad]
    public static class HandAlignmentPreviewService
    {
        const string CloneNamePrefix = "VRHandPoseTool_AlignPreview_";

        class PreviewSnapshot
        {
            public HandSide handSide;
            public Transform trackingHandRoot;
            public Transform controllerHandRoot;
            public Transform trackingWrist;    // 캐시 (매 프레임 재탐색 방지)
            public Transform originalWrist;    // 캐시
            public GameObject cloneRootGO;
            public Transform cloneRoot;
            // DFS 순서로 수집한 원본/클론 Transform 배열 (index 0 = root)
            public Transform[] originalTransforms;
            public Transform[] cloneTransforms;
        }

        static PreviewSnapshot s_Current;

        /// <summary>현재 미리보기가 활성 상태인지 여부입니다.</summary>
        public static bool IsPreviewActive => s_Current != null;

        /// <summary>현재 미리보기 중인 HandSide를 반환합니다.</summary>
        public static HandSide ActiveHandSide => s_Current?.handSide ?? HandSide.Left;

        static HandAlignmentPreviewService()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeChanged;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.update -= OnEditorUpdate;
            EditorApplication.update += OnEditorUpdate;
        }

        // ── 미리보기 시작 ─────────────────────────────────────────────────

        /// <summary>
        /// Controller Hand 메시 클론을 생성해 미리보기를 시작합니다.
        /// </summary>
        /// <param name="handSide">Left / Right 구분</param>
        /// <param name="trackingHandRoot">Tracking Hand Root (손목 기준 앵커용)</param>
        /// <param name="controllerHandRoot">클론 소스 Root</param>
        /// <param name="message">결과 메시지</param>
        public static bool TryStartPreview(
            HandSide handSide,
            Transform trackingHandRoot,
            Transform controllerHandRoot,
            out string message)
        {
            if (IsPreviewActive)
            {
                message = "이미 미리보기가 활성 상태입니다. 먼저 '정렬 미리보기 종료'를 누르세요.";
                return false;
            }

            if (trackingHandRoot == null)
            {
                message = "Tracking Hand Root가 지정되지 않았습니다.";
                return false;
            }

            if (controllerHandRoot == null)
            {
                message = "Controller Hand Root(Playback Hand Root)가 지정되지 않았습니다.";
                return false;
            }

            // Ghost Hand 제외
            if (controllerHandRoot.GetComponentInParent<HandGhostPreviewMarker>() != null
                || controllerHandRoot.GetComponent<HandGhostPreviewMarker>() != null)
            {
                message = "Ghost Hand는 미리보기 대상이 될 수 없습니다.";
                return false;
            }

            // 동일 Root 혼동 방지
            if (trackingHandRoot == controllerHandRoot)
            {
                message = "Tracking Hand Root와 Controller Hand Root가 동일한 오브젝트입니다.";
                return false;
            }

            // SkinnedMeshRenderer 유무 확인
            var smrs = controllerHandRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            if (smrs.Length == 0)
            {
                message = "Controller Hand Root 하위에 SkinnedMeshRenderer가 없습니다.";
                return false;
            }

            // 손목 본 탐색 (L_Wrist / R_Wrist)
            var wristName     = HandSideUtility.GetWristBoneName(handSide);
            var trackingWrist = FindBoneRecursive(trackingHandRoot, wristName);
            var originalWrist = FindBoneRecursive(controllerHandRoot, wristName);

            // ── 클론 생성 ──────────────────────────────────────────────────
            // Unity Instantiate: 계층 내부 Transform 참조(SMR.bones 등)를 자동 remapping
            var cloneGO = Object.Instantiate(controllerHandRoot.gameObject);
            cloneGO.name = CloneNamePrefix + HandSideUtility.GetLabel(handSide);
            cloneGO.SetActive(true); // 원본이 inactive여도 클론은 강제 active

            // Visual 전용 정리: Animator, GripDriver, Collider, 기타 MonoBehaviour 제거
            StripNonVisualComponents(cloneGO);

            // DFS 순서 Transform 배열 구성 (Instantiate 이후 구조가 동일함을 보장)
            var origTrans  = CollectTransforms(controllerHandRoot);
            var cloneTrans = CollectTransforms(cloneGO.transform);

            s_Current = new PreviewSnapshot
            {
                handSide           = handSide,
                trackingHandRoot   = trackingHandRoot,
                controllerHandRoot = controllerHandRoot,
                trackingWrist      = trackingWrist,
                originalWrist      = originalWrist,
                cloneRootGO        = cloneGO,
                cloneRoot          = cloneGO.transform,
                originalTransforms = origTrans.ToArray(),
                cloneTransforms    = cloneTrans.ToArray(),
            };

            // 첫 프레임 즉시 동기화
            SyncClonePoses(s_Current);

            var wristStatus = originalWrist != null ? $"'{wristName}' 발견" : $"'{wristName}' 미발견 (Root 기준 정렬)";
            message =
                $"정렬 미리보기 시작 ─ [{HandSideUtility.GetLabel(handSide)}]\n" +
                $"클론: {cloneGO.name}  SMR×{smrs.Length}  Bone×{origTrans.Count}\n" +
                $"Wrist: {wristStatus}";
            return true;
        }

        // ── 미리보기 종료 ─────────────────────────────────────────────────

        /// <summary>
        /// 미리보기를 종료하고 클론 오브젝트를 즉시 삭제합니다.
        /// 원본 Controller Hand와 정렬된 Visual Offset 값은 유지됩니다.
        /// </summary>
        public static void EndPreview()
        {
            if (s_Current == null) return;
            if (s_Current.cloneRootGO != null)
                Object.DestroyImmediate(s_Current.cloneRootGO);
            s_Current = null;
        }

        /// <summary>UI 표시용 상태 요약 문자열을 반환합니다.</summary>
        public static string GetStatusLabel()
        {
            if (s_Current == null) return "비활성";
            var name = s_Current.cloneRootGO != null ? s_Current.cloneRootGO.name : "(null)";
            return $"활성 ─ {name}";
        }

        // ── 프레임 업데이트 ───────────────────────────────────────────────

        static void OnEditorUpdate()
        {
            if (s_Current == null) return;
            if (s_Current.cloneRootGO == null) { s_Current = null; return; }
            SyncClonePoses(s_Current);
        }

        /// <summary>
        /// 매 에디터 프레임 클론의 본 포즈와 위치를 갱신합니다.
        ///
        /// 1) 자식 본 Local Transform → 원본에서 직접 복사 (index 0 = root 제외)
        /// 2) 클론 Root 회전 = Controller Root 회전 (방향 비교 보존)
        /// 3) 클론 Root 위치 = Tracking Wrist − (Original Wrist − Controller Root)
        ///    → 클론 손목이 Tracking 손목에 정확히 겹침
        /// </summary>
        static void SyncClonePoses(PreviewSnapshot snap)
        {
            // ─ 자식 본 Local Transform 복사 ─
            int len = Mathf.Min(snap.originalTransforms.Length, snap.cloneTransforms.Length);
            for (int i = 1; i < len; i++)
            {
                var src = snap.originalTransforms[i];
                var dst = snap.cloneTransforms[i];
                if (src == null || dst == null) continue;
                dst.localPosition = src.localPosition;
                dst.localRotation = src.localRotation;
                dst.localScale    = src.localScale;
            }

            // ─ 클론 Root 배치 ─
            // 회전: Controller 방향 그대로 유지 (정렬 비교 목적)
            snap.cloneRoot.rotation = snap.controllerHandRoot.rotation;

            if (snap.trackingWrist != null && snap.originalWrist != null)
            {
                // 클론 손목 world 오프셋 = 원본 손목 world 오프셋 (같은 local 구조이므로)
                var wristWorldOffset =
                    snap.originalWrist.position - snap.controllerHandRoot.position;
                snap.cloneRoot.position =
                    snap.trackingWrist.position - wristWorldOffset;
            }
            else
            {
                // Wrist 본 미발견 시: Tracking Root 위치에 fallback
                snap.cloneRoot.position = snap.trackingHandRoot.position;
            }
        }

        // ── 컴포넌트 정리 ─────────────────────────────────────────────────

        /// <summary>
        /// Transform · SkinnedMeshRenderer · MeshRenderer · MeshFilter 이외의
        /// 모든 컴포넌트를 즉시 제거합니다.
        /// (Animator, GripDriver, Collider, XR Interactor, MonoBehaviour 등)
        /// </summary>
        static void StripNonVisualComponents(GameObject root)
        {
            // 두 단계로 처리: 목록 수집 → 일괄 삭제 (반복 중 컬렉션 변경 방지)
            var toRemove = new List<Component>();
            foreach (var comp in root.GetComponentsInChildren<Component>(true))
            {
                if (comp == null) continue;
                var t = comp.GetType();
                if (t == typeof(Transform)) continue;
                if (t == typeof(SkinnedMeshRenderer)) continue;
                if (t == typeof(MeshRenderer)) continue;
                if (t == typeof(MeshFilter)) continue;
                toRemove.Add(comp);
            }
            foreach (var comp in toRemove)
            {
                if (comp != null)
                    Object.DestroyImmediate(comp);
            }
        }

        // ── 유틸리티 ─────────────────────────────────────────────────────

        static List<Transform> CollectTransforms(Transform root)
        {
            var list = new List<Transform>();
            CollectRecursive(root, list);
            return list;
        }

        static void CollectRecursive(Transform t, List<Transform> list)
        {
            list.Add(t);
            foreach (Transform child in t)
                CollectRecursive(child, list);
        }

        static Transform FindBoneRecursive(Transform root, string boneName)
        {
            if (root.name == boneName) return root;
            foreach (Transform child in root)
            {
                var found = FindBoneRecursive(child, boneName);
                if (found != null) return found;
            }
            return null;
        }

        // ── Play Mode 종료 자동 정리 ──────────────────────────────────────

        static void OnPlayModeChanged(PlayModeStateChange state)
        {
            // ExitingPlayMode: 오브젝트가 아직 유효한 시점
            if (state == PlayModeStateChange.ExitingPlayMode && s_Current != null)
            {
                if (s_Current.cloneRootGO != null)
                    Object.DestroyImmediate(s_Current.cloneRootGO);
                s_Current = null;
                Debug.Log("[VRHandPoseTool] 정렬 미리보기 클론 자동 삭제 (Play Mode 종료)");
            }
        }
    }
}
