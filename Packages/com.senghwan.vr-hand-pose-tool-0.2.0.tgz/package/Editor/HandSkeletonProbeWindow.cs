using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Step_05 Visual/LeftHand 스켈레톤과 XR Hands 구성을 검증하는 Stage 1 Probe 창입니다.
    /// </summary>
    public class HandSkeletonProbeWindow : EditorWindow
    {
        const string MenuPath = "Tools/VR Hand Tools/Hand Skeleton Probe";
        const int ExpectedJointReferenceCount = HandSkeletonCatalog.RequiredBoneCount;

        [SerializeField]
        Transform m_TrackingHandRoot;

        HandSkeletonValidationResult m_LastValidation;
        Vector2 m_Scroll;

        [MenuItem(MenuPath)]
        public static void ShowWindow()
        {
            var window = GetWindow<HandSkeletonProbeWindow>("Hand Skeleton Probe");
            window.minSize = new Vector2(420f, 520f);
            window.Show();
        }

        void OnEnable()
        {
            EditorApplication.update += OnEditorUpdate;
            RefreshValidation();
        }

        void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
        }

        void OnSelectionChange()
        {
            if (Selection.activeTransform == null)
                return;

            if (IsLikelyLeftHandRoot(Selection.activeTransform))
            {
                m_TrackingHandRoot = Selection.activeTransform;
                RefreshValidation();
                Repaint();
            }
        }

        void OnEditorUpdate()
        {
            if (Application.isPlaying)
                Repaint();
        }

        void OnGUI()
        {
            EditorGUILayout.LabelField("Hand Skeleton Probe (Stage 1)", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Step_05 기준: Left Controller → Visual → LeftHand\n" +
                "Tracking Hand Root에 Visual/LeftHand를 지정한 뒤 Refresh Validation을 누르세요.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            m_TrackingHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Tracking Hand Root",
                m_TrackingHandRoot,
                typeof(Transform),
                true);
            if (EditorGUI.EndChangeCheck())
                RefreshValidation();

            EditorGUILayout.Space(6f);

            if (GUILayout.Button("Refresh Validation"))
                RefreshValidation();

            m_Scroll = EditorGUILayout.BeginScrollView(m_Scroll);
            DrawBasicInfo();
            EditorGUILayout.Space(8f);
            DrawXrHandsSection();
            EditorGUILayout.Space(8f);
            DrawSkeletonValidationSection();
            EditorGUILayout.EndScrollView();
        }

        void DrawBasicInfo()
        {
            EditorGUILayout.LabelField("기본 정보", EditorStyles.boldLabel);

            if (m_TrackingHandRoot == null)
            {
                EditorGUILayout.HelpBox("Tracking Hand Root를 지정하세요.", MessageType.Warning);
                return;
            }

            var totalTransformCount = m_TrackingHandRoot.GetComponentsInChildren<Transform>(true).Length;
            var hasSkinnedMesh = m_TrackingHandRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;

            EditorGUILayout.LabelField("GameObject", m_TrackingHandRoot.name);
            EditorGUILayout.LabelField("Play Mode", EditorApplication.isPlaying ? "Yes" : "No");
            EditorGUILayout.LabelField("Transform 개수 (하위 포함)", totalTransformCount.ToString());
            EditorGUILayout.LabelField("필수 손 본 개수 (기준)", HandSkeletonCatalog.RequiredBoneCount.ToString());
            EditorGUILayout.LabelField("SkinnedMeshRenderer", hasSkinnedMesh ? "있음" : "없음");
        }

        void DrawXrHandsSection()
        {
            EditorGUILayout.LabelField("XR Hands 구성", EditorStyles.boldLabel);

            if (m_TrackingHandRoot == null)
                return;

            var skeletonDriver = m_TrackingHandRoot.GetComponent<XRHandSkeletonDriver>();
            var trackingEvents = m_TrackingHandRoot.GetComponent<XRHandTrackingEvents>();

            EditorGUILayout.LabelField("XRHandSkeletonDriver", skeletonDriver != null ? "있음" : "없음");
            EditorGUILayout.LabelField("XRHandTrackingEvents", trackingEvents != null ? "있음" : "없음");

            if (trackingEvents != null)
                EditorGUILayout.LabelField("Handedness", trackingEvents.handedness.ToString());

            DrawJointReferenceInfo(skeletonDriver);
        }

        static void DrawJointReferenceInfo(XRHandSkeletonDriver skeletonDriver)
        {
            if (skeletonDriver == null)
            {
                EditorGUILayout.LabelField("Joint Transform References", "SkeletonDriver 없음");
                return;
            }

            var references = skeletonDriver.jointTransformReferences;
            if (references == null)
            {
                EditorGUILayout.LabelField("Joint Transform References", "0 (목록 null)");
                EditorGUILayout.LabelField("26개 연결 여부", "아니오");
                return;
            }

            var count = references.Count;
            var mappedCount = 0;
            foreach (var reference in references)
            {
                if (reference.jointTransform != null)
                    mappedCount++;
            }

            EditorGUILayout.LabelField("Joint Transform References", count.ToString());
            EditorGUILayout.LabelField("매핑된 Transform", mappedCount.ToString());
            EditorGUILayout.LabelField(
                "26개 연결 여부",
                count == ExpectedJointReferenceCount ? "예" : $"아니오 (기대 {ExpectedJointReferenceCount})");
        }

        void DrawSkeletonValidationSection()
        {
            EditorGUILayout.LabelField("손 본 검증", EditorStyles.boldLabel);

            if (m_LastValidation == null)
            {
                EditorGUILayout.HelpBox("Refresh Validation을 실행하세요.", MessageType.Info);
                return;
            }

            var skeletonDriver = m_TrackingHandRoot != null
                ? m_TrackingHandRoot.GetComponent<XRHandSkeletonDriver>()
                : null;
            var jointRefCount = skeletonDriver?.jointTransformReferences?.Count ?? 0;
            var xrConfigured =
                skeletonDriver != null
                && m_TrackingHandRoot.GetComponent<XRHandTrackingEvents>() != null
                && jointRefCount == ExpectedJointReferenceCount;

            var readyForNextStage = m_LastValidation.isValid && xrConfigured;

            if (readyForNextStage)
            {
                EditorGUILayout.HelpBox(
                    "Step_05 LeftHand 검증 성공\n" +
                    $"L_* 필수 본: {m_LastValidation.foundBoneCount} / {m_LastValidation.expectedBoneCount}\n" +
                    $"SkeletonDriver Joint References: {jointRefCount}\n" +
                    "캡처 도구 제작 가능",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox(m_LastValidation.summary, MessageType.Error);
                if (m_LastValidation.isValid && !xrConfigured)
                {
                    EditorGUILayout.HelpBox(
                        "본 검증은 통과했지만 XRHandSkeletonDriver / XRHandTrackingEvents / Joint References 26개 구성이 완료되지 않았습니다.",
                        MessageType.Warning);
                }
            }

            EditorGUILayout.LabelField("정상 여부", m_LastValidation.isValid ? "예" : "아니오");
            EditorGUILayout.LabelField(
                "발견한 본 개수",
                $"{m_LastValidation.foundBoneCount} / {m_LastValidation.expectedBoneCount}");

            DrawStringList("누락된 본", m_LastValidation.missingBones);
            DrawStringList("중복된 본", m_LastValidation.duplicateBones);
            DrawStringList("예상하지 않은 L_* 본", m_LastValidation.unexpectedBones);
            DrawStringList("계층 불일치", m_LastValidation.hierarchyMismatches);
            DrawStringList("경고", m_LastValidation.warnings);
        }

        static void DrawStringList(string label, System.Collections.Generic.List<string> items)
        {
            if (items == null || items.Count == 0)
                return;

            EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
            var sb = new StringBuilder();
            foreach (var item in items)
            {
                sb.Append("• ");
                sb.AppendLine(item);
            }

            EditorGUILayout.HelpBox(sb.ToString().TrimEnd(), MessageType.None);
        }

        void RefreshValidation()
        {
            if (m_TrackingHandRoot == null)
            {
                m_LastValidation = new HandSkeletonValidationResult
                {
                    expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                    summary = "Tracking Hand Root가 지정되지 않았습니다.",
                };
                return;
            }

            m_LastValidation = HandSkeletonCatalog.Validate(m_TrackingHandRoot);
        }

        static bool IsLikelyLeftHandRoot(Transform transform)
        {
            return transform != null
                && transform.name == "LeftHand"
                && transform.parent != null
                && transform.parent.name == "Visual";
        }
    }
}
