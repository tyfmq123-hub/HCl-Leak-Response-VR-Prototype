using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Editor 전용 고스트 손 미리보기 생성·갱신·제거 서비스입니다.
    /// </summary>
    public static class HandGhostPreviewService
    {
        public const string GhostsRootName = "VRHandPoseTool_Ghosts";
        public const string DefaultGrabSnapshotPath =
            "Assets/VRHandPoseToolOutput/GrabSnapshots/Left_Grab_Bone.asset";
        public const string LeftHandGhostSuffix = "_LeftHand_Ghost";
        public const string LeftHandSide = "Left";

        public const string GhostsPrefabFolder = "Assets/VRHandPoseToolOutput/Ghosts";

        public struct GhostResult
        {
            public bool success;
            public string message;
            public string summary;
            public GameObject ghostRoot;
            public GameObject targetGrabObject;
            public string attachTransformName;
            public bool usedFallbackAttach;
            public string snapshotPath;
            public int appliedBoneCount;
            public bool wasUpdated;
            public List<string> strippedComponentTypes;
            public int remappedRendererCount;
            public int remappedBoneCount;
            public int originalTransformReferenceCount;
            public string scaleReport;
            public string boundsReport;
            public List<string> validationErrors;
            public string ghostPrefabPath;
            public bool prefabSaved;
        }

        /// <summary>
        /// Target 이름과 손 방향으로 Ghost Prefab의 저장 경로를 반환합니다.
        /// </summary>
        public static string GetGhostPrefabPath(string targetName, HandSide handSide)
        {
            var ghostName = HandSideUtility.BuildGhostName(targetName, handSide);
            return $"{GhostsPrefabFolder}/{ghostName}.prefab";
        }

        public static HandPoseSnapshot TryLoadDefaultGrabSnapshot()
        {
            return TryLoadDefaultGrabSnapshot(HandSide.Left);
        }

        public static HandPoseSnapshot TryLoadDefaultGrabSnapshot(HandSide handSide)
        {
            return AssetDatabase.LoadAssetAtPath<HandPoseSnapshot>(
                HandSideUtility.GetDefaultGrabSnapshotAssetPath(handSide));
        }

        public static GameObject TryResolveSelectionGrabTarget()
        {
            var selected = Selection.activeGameObject;
            if (selected == null)
                return null;

            var grab = selected.GetComponent<XRGrabInteractable>()
                ?? selected.GetComponentInParent<XRGrabInteractable>();
            return grab != null ? grab.gameObject : null;
        }

        public static GhostResult CreateOrUpdateGhost(
            GameObject targetGrabObject,
            Transform playbackHandRoot,
            HandPoseSnapshot grabSnapshot,
            HandGhostAppearanceSettings appearance)
        {
            return CreateOrUpdateGhost(
                targetGrabObject,
                playbackHandRoot,
                grabSnapshot,
                appearance,
                HandSide.Left);
        }

        /// <summary>
        /// HandGrabPoseRecord의 26본 Pose와 HandGrabPoseBinding의 손별 Attach Transform을 사용해
        /// 고스트를 생성하거나 갱신합니다.
        /// </summary>
        public static GhostResult CreateOrUpdateGhostFromRecord(
            GameObject targetGrabObject,
            Transform playbackHandRoot,
            HandGrabPoseRecord record,
            HandGhostAppearanceSettings appearance,
            HandSide handSide)
        {
            var result = new GhostResult
            {
                targetGrabObject = targetGrabObject,
                strippedComponentTypes = new List<string>(),
            };

            if (Application.isPlaying)
            {
                result.message = "고스트는 Play Mode를 종료한 뒤 생성하세요.";
                return result;
            }

            if (targetGrabObject == null)
            {
                result.message = "Target Grab Object가 지정되지 않았습니다.";
                return result;
            }

            if (playbackHandRoot == null)
            {
                result.message = "Playback Hand Root가 지정되지 않았습니다.";
                return result;
            }

            if (record == null || !record.HasBoneData)
            {
                result.message = "HandGrabPoseRecord가 없거나 bone 데이터가 비어 있습니다.";
                return result;
            }

            var attachInfo = ResolveAttachTransformForHandSide(targetGrabObject, handSide);
            result.attachTransformName = attachInfo.attachTransform != null
                ? attachInfo.attachTransform.name
                : targetGrabObject.name;
            result.usedFallbackAttach = attachInfo.usedFallback;
            result.snapshotPath = AssetDatabase.GetAssetPath(record);

            // Ghost 컨테이너를 Target 자식으로 생성/탐색합니다.
            // Target 이동 시 Ghost도 함께 이동하도록 Target의 자식 계층에 배치합니다.
            var ghostsRoot = EnsureGhostsRootForTarget(targetGrabObject);
            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var existingGhost = FindExistingGhost(ghostsRoot, targetGrabObject, handSide);
            result.wasUpdated = existingGhost != null;

            GameObject ghostRoot;
            List<Renderer> renderers;
            var createdNewGhost = existingGhost == null;
            if (existingGhost != null)
            {
                ghostRoot = existingGhost;
                renderers = CollectRenderers(ghostRoot);
                StripNonVisualComponents(ghostRoot, result.strippedComponentTypes);
                result.strippedComponentTypes.Add("(기존 고스트 갱신 — 런타임 컴포넌트 제거)");
            }
            else
            {
                ghostRoot = ClonePlaybackHand(playbackHandRoot, ghostsRoot.transform, targetGrabObject.name, handSide);
                StripNonVisualComponents(ghostRoot, result.strippedComponentTypes);
                AddMarker(ghostRoot, targetGrabObject, sideLabel);
                renderers = CollectRenderers(ghostRoot);

                var createdMaterials = new List<Material>();
                HandGhostMaterialUtility.ApplyGhostMaterials(renderers, appearance, createdMaterials);
                Undo.RegisterCreatedObjectUndo(ghostRoot, "Create Hand Ghost");
            }

            var skinnedRenderers = ghostRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var remapResult = RemapGhostSkinnedMeshes(ghostRoot, playbackHandRoot, skinnedRenderers);
            result.remappedRendererCount = remapResult.remappedRendererCount;
            result.remappedBoneCount = remapResult.remappedBoneCount;
            if (!remapResult.success)
            {
                return FailGhostCreation(
                    result,
                    ghostRoot,
                    createdNewGhost,
                    BuildFailureMessage("SkinnedMeshRenderer bone 재매핑 실패", remapResult.errors));
            }

            // Ghost root를 Target 기준 localPosition/Rotation으로 직접 배치합니다.
            // GhostsRoot 컨테이너가 Target 아래 (0,0,0)에 있으므로 localPosition = Record 상대 좌표입니다.
            // SetPositionAndRotation(world) 방식을 사용하지 않으므로 Target 이동 후에도 Ghost가 올바르게 따라옵니다.
            PositionGhostFromRecord(ghostRoot.transform, targetGrabObject.transform, record);
            AlignGhostWorldScale(ghostRoot.transform, playbackHandRoot);

            // Apply 26-bone pose from record
            result.appliedBoneCount = ApplyGrabPoseFromRecord(ghostRoot.transform, record);
            RefreshGhostLocalBounds(skinnedRenderers);

            if (existingGhost != null)
            {
                Undo.RecordObject(ghostRoot.transform, "Update Hand Ghost");
                HandGhostMaterialUtility.UpdateGhostAppearance(renderers, appearance);
            }

            var validation = ValidateGhostSkinning(playbackHandRoot, ghostRoot.transform);
            result.originalTransformReferenceCount = validation.originalTransformReferenceCount;
            result.scaleReport = validation.scaleReport;
            result.boundsReport = validation.boundsReport;
            result.validationErrors = validation.errors;
            if (!validation.success)
            {
                return FailGhostCreation(
                    result,
                    ghostRoot,
                    createdNewGhost,
                    BuildFailureMessage("고스트 SkinnedMeshRenderer 검증 실패", validation.errors));
            }

            result.ghostRoot = ghostRoot;
            result.success = true;
            result.summary = BuildSummaryFromRecord(result, ghostRoot, attachInfo, remapResult, validation, appearance, handSide, record);
            result.message = result.summary;

            // Ghost Prefab을 Project Asset으로 저장합니다.
            // Play Mode 종료 후 씬이 바뀌어도 Prefab Asset으로 복원 가능합니다.
            if (TrySaveGhostAsPrefab(ghostRoot, targetGrabObject.name, handSide, out var prefabPath))
            {
                result.ghostPrefabPath = prefabPath;
                result.prefabSaved = true;
                result.summary += $"\nGhost Prefab: {prefabPath}";
                result.message = result.summary;
            }

            Selection.activeGameObject = ghostRoot;
            EditorGUIUtility.PingObject(ghostRoot);
            MarkSceneDirtyIfEditing(targetGrabObject.scene);
            SceneView.RepaintAll();

            return result;
        }

        public static GhostResult CreateOrUpdateGhost(
            GameObject targetGrabObject,
            Transform playbackHandRoot,
            HandPoseSnapshot grabSnapshot,
            HandGhostAppearanceSettings appearance,
            HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var result = new GhostResult
            {
                targetGrabObject = targetGrabObject,
                strippedComponentTypes = new List<string>(),
            };

            if (Application.isPlaying)
            {
                result.message = "고스트는 Play Mode를 종료한 뒤 생성하세요.";
                return result;
            }

            if (targetGrabObject == null)
            {
                result.message = "Target Grab Object가 지정되지 않았습니다.";
                return result;
            }

            if (playbackHandRoot == null)
            {
                result.message = "Playback Hand Root가 지정되지 않았습니다.";
                return result;
            }

            if (!HandPoseJointApplier.HasApplicablePoseData(grabSnapshot))
            {
                result.message = "Grab Snapshot에 적용 가능한 bone 데이터가 없습니다.";
                return result;
            }

            if (grabSnapshot.joints != null && grabSnapshot.joints.Count > 0)
            {
                result.message = "Grab Snapshot은 bones-only여야 합니다. joints 데이터가 포함되어 있습니다.";
                return result;
            }

            var attachInfo = ResolveAttachTransformForHandSide(targetGrabObject, handSide);
            result.attachTransformName = attachInfo.attachTransform != null
                ? attachInfo.attachTransform.name
                : targetGrabObject.name;
            result.usedFallbackAttach = attachInfo.usedFallback;
            result.snapshotPath = AssetDatabase.GetAssetPath(grabSnapshot);

            var ghostsRoot = EnsureGhostsRootForTarget(targetGrabObject);
            var existingGhost = FindExistingGhost(ghostsRoot, targetGrabObject, handSide);
            result.wasUpdated = existingGhost != null;

            GameObject ghostRoot;
            List<Renderer> renderers;
            var createdNewGhost = existingGhost == null;
            if (existingGhost != null)
            {
                ghostRoot = existingGhost;
                renderers = CollectRenderers(ghostRoot);
                StripNonVisualComponents(ghostRoot, result.strippedComponentTypes);
                result.strippedComponentTypes.Add("(기존 고스트 갱신 — 런타임 컴포넌트 제거)");
            }
            else
            {
                ghostRoot = ClonePlaybackHand(playbackHandRoot, ghostsRoot.transform, targetGrabObject.name, handSide);
                StripNonVisualComponents(ghostRoot, result.strippedComponentTypes);
                AddMarker(ghostRoot, targetGrabObject, sideLabel);
                renderers = CollectRenderers(ghostRoot);

                var createdMaterials = new List<Material>();
                HandGhostMaterialUtility.ApplyGhostMaterials(renderers, appearance, createdMaterials);
                Undo.RegisterCreatedObjectUndo(ghostRoot, "Create Hand Ghost");
            }

            var skinnedRenderers = ghostRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var remapResult = RemapGhostSkinnedMeshes(ghostRoot, playbackHandRoot, skinnedRenderers);
            result.remappedRendererCount = remapResult.remappedRendererCount;
            result.remappedBoneCount = remapResult.remappedBoneCount;
            if (!remapResult.success)
            {
                return FailGhostCreation(
                    result,
                    ghostRoot,
                    createdNewGhost,
                    BuildFailureMessage("SkinnedMeshRenderer bone 재매핑 실패", remapResult.errors));
            }

            PositionGhostAtAttach(ghostRoot.transform, attachInfo.attachTransform);
            AlignGhostWorldScale(ghostRoot.transform, playbackHandRoot);
            result.appliedBoneCount = ApplyGrabPose(ghostRoot.transform, grabSnapshot);
            RefreshGhostLocalBounds(skinnedRenderers);

            if (existingGhost != null)
            {
                Undo.RecordObject(ghostRoot.transform, "Update Hand Ghost");
                HandGhostMaterialUtility.UpdateGhostAppearance(renderers, appearance);
            }

            var validation = ValidateGhostSkinning(playbackHandRoot, ghostRoot.transform);
            result.originalTransformReferenceCount = validation.originalTransformReferenceCount;
            result.scaleReport = validation.scaleReport;
            result.boundsReport = validation.boundsReport;
            result.validationErrors = validation.errors;
            if (!validation.success)
            {
                return FailGhostCreation(
                    result,
                    ghostRoot,
                    createdNewGhost,
                    BuildFailureMessage("고스트 SkinnedMeshRenderer 검증 실패", validation.errors));
            }

            result.ghostRoot = ghostRoot;
            result.success = true;
            result.summary = BuildSummary(result, ghostRoot, attachInfo, remapResult, validation, appearance, handSide);
            result.message = result.summary;

            Selection.activeGameObject = ghostRoot;
            EditorGUIUtility.PingObject(ghostRoot);
            MarkSceneDirtyIfEditing(targetGrabObject.scene);
            SceneView.RepaintAll();

            return result;
        }

        public static GhostResult RemoveGhost(GameObject targetGrabObject)
        {
            return RemoveGhost(targetGrabObject, HandSide.Left);
        }

        public static GhostResult RemoveGhost(GameObject targetGrabObject, HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var result = new GhostResult
            {
                targetGrabObject = targetGrabObject,
            };

            if (targetGrabObject == null)
            {
                result.message = "Target Grab Object가 지정되지 않았습니다.";
                return result;
            }

            if (Application.isPlaying)
            {
                result.message = "고스트는 Play Mode를 종료한 뒤 제거하세요.";
                return result;
            }

            if (!targetGrabObject.scene.IsValid())
            {
                result.message = "씬에 있는 Target Grab Object를 지정하세요.";
                return result;
            }

            // Target 자식 아래에서 먼저 탐색 (신규 구조), 없으면 씬 루트 fallback (기존 구조)
            var ghostsRoot = FindGhostsRootUnder(targetGrabObject.transform)
                ?? FindGhostsRoot(targetGrabObject.scene);
            if (ghostsRoot == null)
            {
                result.message = $"제거할 고스트가 없습니다. ({GhostsRootName} 없음)";
                return result;
            }

            var ghost = FindExistingGhost(ghostsRoot, targetGrabObject, handSide);
            if (ghost == null)
            {
                result.message = $"'{targetGrabObject.name}'에 연결된 {sideLabel} Hand 고스트가 없습니다.";
                return result;
            }

            DestroyGhostMaterials(ghost);
            Undo.DestroyObjectImmediate(ghost);
            CleanupGhostsRoot(ghostsRoot);

            result.success = true;
            result.message = $"'{targetGrabObject.name}' 고스트를 제거했습니다.";
            result.summary = result.message;
            MarkSceneDirtyIfEditing(targetGrabObject.scene);
            SceneView.RepaintAll();
            return result;
        }

        static void MarkSceneDirtyIfEditing(UnityEngine.SceneManagement.Scene scene)
        {
            if (Application.isPlaying || !scene.IsValid())
                return;

            EditorSceneManager.MarkSceneDirty(scene);
        }

        static AttachInfo ResolveAttachTransformForHandSide(GameObject targetGrabObject, HandSide handSide)
        {
            // Prefer HandGrabPoseBinding handed attach (per-hand accurate point)
            var binding = targetGrabObject.GetComponent<HandGrabPoseBinding>();
            if (binding != null
                && binding.TryGetAttachTransform(handSide, out var handedAttach)
                && handedAttach != null)
            {
                return new AttachInfo { attachTransform = handedAttach, usedFallback = false };
            }

            // Fall back to generic XRGrabInteractable.attachTransform
            var grab = targetGrabObject.GetComponent<XRGrabInteractable>();
            if (grab != null && grab.attachTransform != null)
            {
                return new AttachInfo { attachTransform = grab.attachTransform, usedFallback = false };
            }

            return new AttachInfo { attachTransform = targetGrabObject.transform, usedFallback = true };
        }

        static AttachInfo ResolveAttachTransform(GameObject targetGrabObject)
        {
            var grab = targetGrabObject.GetComponent<XRGrabInteractable>();
            if (grab != null && grab.attachTransform != null)
            {
                return new AttachInfo
                {
                    attachTransform = grab.attachTransform,
                    usedFallback = false,
                };
            }

            return new AttachInfo
            {
                attachTransform = targetGrabObject.transform,
                usedFallback = true,
            };
        }

        /// <summary>
        /// Target Grab Object 아래에 VRHandPoseTool_Ghosts 컨테이너를 생성하거나 기존 것을 반환합니다.
        /// Ghost가 Target의 자식이 되므로 Rifle 등을 이동·회전해도 Ghost가 함께 따라옵니다.
        /// </summary>
        static GameObject EnsureGhostsRootForTarget(GameObject targetGrabObject)
        {
            var existing = FindGhostsRootUnder(targetGrabObject.transform);
            if (existing != null)
                return existing;

            var root = new GameObject(GhostsRootName);
            Undo.RegisterCreatedObjectUndo(root, "Create Hand Ghost Root");
            Undo.SetTransformParent(root.transform, targetGrabObject.transform, "Parent Ghost Root to Target");
            root.transform.localPosition = Vector3.zero;
            root.transform.localRotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;
            return root;
        }

        /// <summary>targetTransform의 직계 자식 중 GhostsRootName과 일치하는 오브젝트를 반환합니다.</summary>
        static GameObject FindGhostsRootUnder(Transform targetTransform)
        {
            if (targetTransform == null)
                return null;

            for (var i = 0; i < targetTransform.childCount; i++)
            {
                var child = targetTransform.GetChild(i);
                if (child.name == GhostsRootName)
                    return child.gameObject;
            }

            return null;
        }

        // 하위 호환: 씬 루트에서 GhostsRoot를 찾습니다 (기존 Ghost 제거 시 fallback으로 사용).
        static GameObject FindGhostsRoot(UnityEngine.SceneManagement.Scene scene)
        {
            if (!scene.IsValid())
                return null;

            var roots = scene.GetRootGameObjects();
            for (var i = 0; i < roots.Length; i++)
            {
                if (roots[i].name == GhostsRootName)
                    return roots[i];
            }

            return null;
        }

        static GameObject FindExistingGhost(
            GameObject ghostsRoot,
            GameObject targetGrabObject,
            HandSide handSide)
        {
            if (ghostsRoot == null || targetGrabObject == null)
                return null;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var targetId = targetGrabObject.GetInstanceID();
            var markers = ghostsRoot.GetComponentsInChildren<HandGhostPreviewMarker>(true);
            foreach (var marker in markers)
            {
                if (marker == null)
                    continue;

                if (marker.TargetGrabObjectInstanceId == targetId
                    && string.Equals(marker.HandSide, sideLabel, StringComparison.Ordinal))
                {
                    return marker.gameObject;
                }
            }

            var expectedName = HandSideUtility.BuildGhostName(targetGrabObject.name, handSide);
            var namedChild = ghostsRoot.transform.Find(expectedName);
            return namedChild != null ? namedChild.gameObject : null;
        }

        static GameObject ClonePlaybackHand(
            Transform playbackHandRoot,
            Transform ghostsRoot,
            string targetGrabObjectName,
            HandSide handSide)
        {
            var ghostObject = UnityEngine.Object.Instantiate(
                playbackHandRoot.gameObject,
                ghostsRoot,
                false);
            ghostObject.name = HandSideUtility.BuildGhostName(targetGrabObjectName, handSide);
            return ghostObject;
        }

        static void StripNonVisualComponents(GameObject ghostRoot, List<string> strippedTypes)
        {
            foreach (var animator in ghostRoot.GetComponentsInChildren<Animator>(true))
            {
                if (animator == null)
                    continue;

                animator.enabled = false;
                animator.runtimeAnimatorController = null;
            }

            var components = ghostRoot.GetComponentsInChildren<Component>(true);
            for (var i = components.Length - 1; i >= 0; i--)
            {
                var component = components[i];
                if (component == null || IsGhostVisualComponent(component))
                    continue;

                strippedTypes.Add(component.GetType().FullName ?? component.GetType().Name);
                UnityEngine.Object.DestroyImmediate(component);
            }
        }

        static bool IsGhostVisualComponent(Component component)
        {
            return component is Transform
                || component is Renderer
                || component is MeshFilter
                || component is HandGhostPreviewMarker;
        }

        static void AddMarker(GameObject ghostRoot, GameObject targetGrabObject, string handSideLabel)
        {
            var marker = ghostRoot.GetComponent<HandGhostPreviewMarker>();
            if (marker == null)
                marker = Undo.AddComponent<HandGhostPreviewMarker>(ghostRoot);

            marker.Initialize(targetGrabObject, handSideLabel);
        }

        static void PositionGhostAtAttach(Transform ghostRoot, Transform attachTransform)
        {
            ghostRoot.SetPositionAndRotation(attachTransform.position, attachTransform.rotation);
        }

        /// <summary>
        /// Record에 저장된 targetTransform 기준 상대 Pose를 Ghost Root의 localPosition/Rotation으로 직접 설정합니다.
        /// Ghost 컨테이너(VRHandPoseTool_Ghosts)가 targetTransform의 직계 자식으로 identity 배치되므로,
        /// ghostRoot.localPosition == targetTransform 기준 상대 좌표 == record.HandRootLocalPosition입니다.
        /// 이 방식은 세계 좌표를 사용하지 않아 Target 이동·회전 후에도 Ghost가 올바른 상대 위치를 유지합니다.
        /// </summary>
        static void PositionGhostFromRecord(
            Transform ghostRoot,
            Transform targetTransform,
            HandGrabPoseRecord record)
        {
            if (ghostRoot == null || targetTransform == null || record == null)
                return;

            // ghostRoot의 부모(VRHandPoseTool_Ghosts)는 targetTransform 아래 localPosition=(0,0,0)이므로
            // record에 저장된 targetTransform 기준 상대 좌표를 localPosition에 직접 적용할 수 있습니다.
            ghostRoot.localPosition = record.HandRootLocalPosition;
            ghostRoot.localRotation = record.HandRootLocalRotation;
        }

        static void AlignGhostWorldScale(Transform ghostRoot, Transform playbackHandRoot)
        {
            HandGhostSkinnedMeshUtility.AlignGhostWorldScale(ghostRoot, playbackHandRoot);
        }

        static HandGhostSkinnedMeshUtility.RemapResult RemapGhostSkinnedMeshes(
            GameObject ghostRoot,
            Transform playbackHandRoot,
            SkinnedMeshRenderer[] skinnedRenderers)
        {
            Undo.RecordObjects(
                skinnedRenderers.Where(renderer => renderer != null).Cast<UnityEngine.Object>().ToArray(),
                "Remap Hand Ghost Bones");

            return HandGhostSkinnedMeshUtility.RemapSkinnedMeshRenderers(
                playbackHandRoot,
                ghostRoot.transform);
        }

        static HandGhostSkinnedMeshUtility.ValidationResult ValidateGhostSkinning(
            Transform playbackHandRoot,
            Transform ghostHandRoot)
        {
            return HandGhostSkinnedMeshUtility.Validate(playbackHandRoot, ghostHandRoot);
        }

        static void RefreshGhostLocalBounds(SkinnedMeshRenderer[] skinnedRenderers)
        {
            HandGhostSkinnedMeshUtility.RefreshLocalBounds(skinnedRenderers);
        }

        static GhostResult FailGhostCreation(
            GhostResult result,
            GameObject ghostRoot,
            bool destroyGhostRoot,
            string message)
        {
            if (destroyGhostRoot && ghostRoot != null)
            {
                DestroyGhostMaterials(ghostRoot);
                Undo.DestroyObjectImmediate(ghostRoot);
                result.ghostRoot = null;
            }

            result.success = false;
            result.message = message;
            result.summary = message;
            Debug.LogError("[HandGhostPreview] " + message);
            return result;
        }

        static string BuildFailureMessage(string title, List<string> errors)
        {
            if (errors == null || errors.Count == 0)
                return title;

            var sb = new StringBuilder();
            sb.AppendLine(title);
            foreach (var error in errors)
                sb.AppendLine("• " + error);

            return sb.ToString().TrimEnd();
        }

        static int ApplyGrabPose(Transform ghostHandRoot, HandPoseSnapshot grabSnapshot)
        {
            var boneMap = HandPoseJointApplier.BuildBoneNameMap(ghostHandRoot);
            var beforeCount = CountAppliedBones(grabSnapshot, boneMap, skipWrist: true);
            HandPoseJointApplier.ApplySnapshotBones(grabSnapshot, boneMap, skipWrist: true);
            return beforeCount;
        }

        static int ApplyGrabPoseFromRecord(Transform ghostHandRoot, HandGrabPoseRecord record)
        {
            if (record == null || !record.HasBoneData)
                return 0;

            // Build name→Transform map for the ghost hierarchy
            var boneMap = new Dictionary<string, Transform>(System.StringComparer.Ordinal);
            foreach (var t in ghostHandRoot.GetComponentsInChildren<Transform>(true))
            {
                if (!boneMap.ContainsKey(t.name))
                    boneMap[t.name] = t;
            }

            var count = 0;
            foreach (var bone in record.Bones)
            {
                if (bone == null || string.IsNullOrEmpty(bone.boneName))
                    continue;

                if (!boneMap.TryGetValue(bone.boneName, out var boneTransform) || boneTransform == null)
                    continue;

                boneTransform.localPosition = bone.localPosition;
                boneTransform.localRotation = bone.localRotation;
                if (bone.localScale.sqrMagnitude > 0.0001f)
                    boneTransform.localScale = bone.localScale;

                count++;
            }

            return count;
        }

        static int CountAppliedBones(
            HandPoseSnapshot snapshot,
            IReadOnlyDictionary<string, Transform> boneMap,
            bool skipWrist)
        {
            if (snapshot?.bones == null)
                return 0;

            var count = 0;
            foreach (var record in snapshot.bones)
            {
                if (skipWrist && HandPoseRigUtility.ShouldSkipWristBone(record.boneName))
                    continue;

                if (boneMap.ContainsKey(record.boneName))
                    count++;
            }

            return count;
        }

        static List<Renderer> CollectRenderers(GameObject ghostRoot)
        {
            return ghostRoot.GetComponentsInChildren<Renderer>(true)
                .Where(renderer => renderer is MeshRenderer || renderer is SkinnedMeshRenderer)
                .ToList();
        }

        static void DestroyGhostMaterials(GameObject ghostRoot)
        {
            foreach (var renderer in CollectRenderers(ghostRoot))
            {
                var materials = renderer.sharedMaterials;
                for (var i = 0; i < materials.Length; i++)
                {
                    // Project Asset으로 저장된 Material은 파괴하지 않습니다.
                    // HideAndDontSave 임시 인스턴스(현재 미사용)만 파괴합니다.
                    if (materials[i] != null
                        && !UnityEditor.AssetDatabase.Contains(materials[i]))
                    {
                        UnityEngine.Object.DestroyImmediate(materials[i]);
                    }
                }
            }
        }

        static void CleanupGhostsRoot(GameObject ghostsRoot)
        {
            if (ghostsRoot == null || ghostsRoot.transform.childCount > 0)
                return;

            Undo.DestroyObjectImmediate(ghostsRoot);
        }

        static string BuildSummaryFromRecord(
            GhostResult result,
            GameObject ghostRoot,
            AttachInfo attachInfo,
            HandGhostSkinnedMeshUtility.RemapResult remapResult,
            HandGhostSkinnedMeshUtility.ValidationResult validation,
            HandGhostAppearanceSettings appearance,
            HandSide handSide,
            HandGrabPoseRecord record)
        {
            var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
            var handRootName = HandSideUtility.GetPreferredHandRootName(handSide);
            var sb = new StringBuilder();
            sb.AppendLine(result.wasUpdated ? "고스트 갱신 완료 (Record 기반)" : "고스트 생성 완료 (Record 기반)");
            sb.AppendLine($"Target: {result.targetGrabObject.name}");
            sb.AppendLine($"Ghost: {ghostRoot.name} · parent={GhostsRootName}");
            sb.AppendLine($"Ghost 기준: targetTransform ({result.targetGrabObject.transform.name}) 기준 HandRootLocalPosition/Rotation 복원");
            sb.AppendLine($"Record: {AssetDatabase.GetAssetPath(record)}");
            sb.AppendLine($"적용 bone 수: {result.appliedBoneCount} / {record.BoneCount}");
            sb.AppendLine(
                $"Ghost Material: HandGhostFresnel · baseAlpha={appearance.baseAlpha:F2} · " +
                $"rimIntensity={appearance.rimIntensity:F1} · pulseSpeed={appearance.pulseSpeed:F1}");
            sb.AppendLine(
                $"Bone 재매핑: renderer={remapResult.remappedRendererCount}, bones={remapResult.remappedBoneCount}");
            sb.AppendLine(HandGhostSkinnedMeshUtility.BuildValidationReport(validation));

            if (result.strippedComponentTypes != null && result.strippedComponentTypes.Count > 0)
            {
                var uniqueTypes = result.strippedComponentTypes
                    .Distinct(StringComparer.Ordinal)
                    .OrderBy(type => type, StringComparer.Ordinal)
                    .ToList();
                sb.AppendLine($"제거·비활성 컴포넌트: {uniqueTypes.Count}종");
                foreach (var typeName in uniqueTypes)
                    sb.AppendLine("• " + typeName);
            }

            return sb.ToString().TrimEnd();
        }

        static string BuildSummary(
            GhostResult result,
            GameObject ghostRoot,
            AttachInfo attachInfo,
            HandGhostSkinnedMeshUtility.RemapResult remapResult,
            HandGhostSkinnedMeshUtility.ValidationResult validation,
            HandGhostAppearanceSettings appearance,
            HandSide handSide)
        {
            var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
            var handRootName = HandSideUtility.GetPreferredHandRootName(handSide);
            var sb = new StringBuilder();
            sb.AppendLine(result.wasUpdated ? "고스트 갱신 완료" : "고스트 생성 완료");
            sb.AppendLine($"Target: {result.targetGrabObject.name}");
            sb.AppendLine($"Ghost: {ghostRoot.name} · parent={GhostsRootName}");
            sb.AppendLine(
                attachInfo.usedFallback
                    ? $"Attach 기준: {result.attachTransformName} (물체 Transform fallback — AttachPoint 설정 권장)"
                    : $"Attach 기준: {result.attachTransformName} (XR Grab Interactable.attachTransform)");
            sb.AppendLine($"Snapshot: {result.snapshotPath}");
            sb.AppendLine($"적용 bone 수: {result.appliedBoneCount} ({wristBoneName} skip, {handRootName} 루트 미적용)");
            sb.AppendLine(
                $"Ghost Material: HandGhostFresnel · baseAlpha={appearance.baseAlpha:F2} · " +
                $"rimIntensity={appearance.rimIntensity:F1} · pulseSpeed={appearance.pulseSpeed:F1}");
            sb.AppendLine(
                $"Bone 재매핑: renderer={remapResult.remappedRendererCount}, bones={remapResult.remappedBoneCount}");
            sb.AppendLine(HandGhostSkinnedMeshUtility.BuildValidationReport(validation));

            if (result.strippedComponentTypes != null && result.strippedComponentTypes.Count > 0)
            {
                var uniqueTypes = result.strippedComponentTypes
                    .Distinct(StringComparer.Ordinal)
                    .OrderBy(type => type, StringComparer.Ordinal)
                    .ToList();
                sb.AppendLine($"제거·비활성 컴포넌트: {uniqueTypes.Count}종");
                foreach (var typeName in uniqueTypes)
                    sb.AppendLine("• " + typeName);
            }

            return sb.ToString().TrimEnd();
        }

        struct AttachInfo
        {
            public Transform attachTransform;
            public bool usedFallback;
        }

        // ── Ghost Prefab 저장 ──────────────────────────────────────────────────

        /// <summary>
        /// Ghost GameObject를 Project Asset으로 Prefab 저장합니다.
        /// Scene 인스턴스는 해당 Prefab에 연결됩니다.
        /// </summary>
        static bool TrySaveGhostAsPrefab(
            GameObject ghostRoot,
            string targetName,
            HandSide handSide,
            out string prefabPath)
        {
            prefabPath = null;
            if (ghostRoot == null)
                return false;

            try
            {
                EnsureGhostPrefabFolder();
                prefabPath = GetGhostPrefabPath(targetName, handSide);

                PrefabUtility.SaveAsPrefabAssetAndConnect(
                    ghostRoot,
                    prefabPath,
                    InteractionMode.AutomatedAction,
                    out var success);

                if (!success)
                {
                    prefabPath = null;
                    return false;
                }

                AssetDatabase.Refresh();
                return true;
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[VRHandPoseTool] Ghost Prefab 저장 실패: {e.Message}");
                prefabPath = null;
                return false;
            }
        }

        static void EnsureGhostPrefabFolder()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");
            if (!AssetDatabase.IsValidFolder(GhostsPrefabFolder))
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "Ghosts");
        }
    }
}
