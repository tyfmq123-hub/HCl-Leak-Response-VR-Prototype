using System.Collections.Generic;
using UnityEngine;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Hand Root 기준 Transform 상대 경로 탐색 유틸리티입니다.
    /// </summary>
    static class HandGhostTransformPathUtility
    {
        public static string GetRelativePath(Transform root, Transform target)
        {
            if (root == null || target == null)
                return null;

            if (target == root)
                return string.Empty;

            var parts = new List<string>();
            var current = target;
            while (current != null && current != root)
            {
                parts.Add(current.name);
                current = current.parent;
            }

            if (current != root)
                return null;

            parts.Reverse();
            return string.Join("/", parts);
        }

        public static bool TryFindByRelativePath(Transform root, string relativePath, out Transform found)
        {
            found = root;
            if (root == null)
            {
                found = null;
                return false;
            }

            if (string.IsNullOrEmpty(relativePath))
                return true;

            var parts = relativePath.Split('/');
            for (var i = 0; i < parts.Length; i++)
            {
                var part = parts[i];
                if (string.IsNullOrEmpty(part))
                    continue;

                Transform next = null;
                for (var c = 0; c < found.childCount; c++)
                {
                    var child = found.GetChild(c);
                    if (child.name == part)
                    {
                        next = child;
                        break;
                    }
                }

                if (next == null)
                {
                    found = null;
                    return false;
                }

                found = next;
            }

            return true;
        }

        public static bool IsUnderTransform(Transform target, Transform root)
        {
            if (target == null || root == null)
                return false;

            var current = target;
            while (current != null)
            {
                if (current == root)
                    return true;
                current = current.parent;
            }

            return false;
        }
    }
}
