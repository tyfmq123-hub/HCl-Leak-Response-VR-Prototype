using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Interaction.Toolkit.Inputs;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    public enum HandGripControlMode
    {
        ToolDefault = 0,
        ProjectLegacy = 1,
    }

    /// <summary>
    /// Step_05 Playback Hand에 Animator·ControllerHandGripAnimator·InputActionManager를 연결합니다.
    /// Animator Controller 내부(Blend Tree 등)는 수정하지 않습니다.
    /// </summary>
    public static class HandPoseControllerHandSetupService
    {
        public const string RecommendedGripActionPath =
            "Assets/Samples/XR Interaction Toolkit/3.4.1/Starter Assets/XRI Default Input Actions.inputactions";

        public const string RecommendedGripActionMap = "XRI Left Interaction";
        public const string RecommendedGripActionName = "Select Value";
        public const string RecommendedGripBinding = "<XRController>{LeftHand}/{Grip}";

        public static string GetRecommendedGripActionMap(HandSide handSide = HandSide.Left)
        {
            return HandSideUtility.GetXriInteractionActionMap(handSide);
        }

        public static string GetRecommendedGripBinding(HandSide handSide = HandSide.Left)
        {
            return HandSideUtility.GetRecommendedGripBinding(handSide);
        }

        public static string GetRecommendedGripReferenceAssetPath(HandSide handSide = HandSide.Left)
        {
            return HandSideUtility.GetGripReferenceAssetPath(handSide);
        }

        public struct Readiness
        {
            public bool canApply;
            public string playbackHandName;
            public string playbackHandHierarchyPath;
            public int boneCount;
            public int expectedBoneCount;
            public bool skeletonValid;
            public bool hasSkinnedMeshRenderer;
            public bool hasSkeletonDriver;
            public bool hasTrackingEvents;
            public bool controllerAssigned;
            public bool controllerHasGripFloat;
            public bool controllerHasBlendTreeState;
            public bool gripActionAssigned;
            public string gripActionPath;
            public string gripActionType;
            public string gripActionExpectedControlType;
            public List<string> blockers;
            public List<string> warnings;
        }

        public struct ApplyResult
        {
            public bool success;
            public string message;
            public string summary;
        }

        /// <summary>
        /// 선택된 Playback Hand Root의 Grip Driver·InputActionManager 상태.
        /// Driver 존재 여부는 선택 Root만 검사하고, InputActionManager는 계층에서 검색합니다.
        /// </summary>
        public struct GripDriverStatus
        {
            public bool hasDriverOnRoot;
            public bool isEnabled;
            public bool handAnimatorMatches;
            public bool animatorControllerMatches;
            public bool gripParameterMatches;
            public bool gripActionMatches;
            public bool noDuplicateOnSelectedHand;
            public bool hasInputActionManager;
            public bool gripActionAssetRegistered;
            public bool isValid;
            public string failureReason;
            public ControllerHandGripAnimator driver;
            public int driverCountOnSelectedHand;
            public InputActionManager inputActionManager;
            public InputActionAsset gripActionAsset;
            public string inputActionManagerHierarchyPath;
        }

        public static Readiness EvaluateReadiness(
            Transform playbackHandRoot,
            RuntimeAnimatorController animatorController,
            InputActionReference gripActionReference,
            string gripParameterName,
            HandSide handSide = HandSide.Left,
            HandGripControlMode gripControlMode = HandGripControlMode.ToolDefault)
        {
            var bonePrefix = HandSideUtility.GetBonePrefix(handSide);
            var readiness = new Readiness
            {
                expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                blockers = new List<string>(),
                warnings = new List<string>(),
            };

            if (playbackHandRoot == null)
            {
                readiness.blockers.Add("Playback Hand Root가 지정되지 않았습니다.");
                return readiness;
            }

            readiness.playbackHandName = playbackHandRoot.name;
            readiness.playbackHandHierarchyPath = HandPoseCaptureService.GetHierarchyPath(playbackHandRoot);

            var validation = HandSkeletonCatalog.Validate(playbackHandRoot, handSide);
            readiness.skeletonValid = validation.isValid;
            readiness.boneCount = validation.foundBoneCount;

            if (!validation.isValid)
            {
                readiness.blockers.Add($"{bonePrefix}* 본 26개 검증 실패.");
            }

            readiness.hasSkinnedMeshRenderer =
                playbackHandRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;
            if (!readiness.hasSkinnedMeshRenderer)
            {
                readiness.blockers.Add("SkinnedMeshRenderer를 찾을 수 없습니다.");
            }

            readiness.hasSkeletonDriver = playbackHandRoot.GetComponent<XRHandSkeletonDriver>() != null;
            readiness.hasTrackingEvents = playbackHandRoot.GetComponent<XRHandTrackingEvents>() != null;

            if (readiness.hasSkeletonDriver)
            {
                readiness.warnings.Add(
                    "XRHandSkeletonDriver가 있습니다. Play 중 핸드트래킹이 본 Transform을 덮어쓸 수 있습니다.");
            }

            if (readiness.hasTrackingEvents)
            {
                readiness.warnings.Add(
                    "XRHandTrackingEvents가 있습니다. Play 중 추적 데이터가 본 Transform을 갱신할 수 있습니다.");
            }

            var usesToolGrip = gripControlMode == HandGripControlMode.ToolDefault;
            var existingGripAnimator = playbackHandRoot.GetComponent<ControllerHandGripAnimator>();

            if (usesToolGrip)
            {
                if (existingGripAnimator != null && !existingGripAnimator.enabled)
                {
                    readiness.warnings.Add(
                        "ControllerHandGripAnimator가 비활성 상태입니다. [컨트롤러 손 설정 적용]으로 다시 활성화할 수 있습니다.");
                }
            }
            else
            {
                readiness.warnings.Add(
                    "기존 프로젝트의 Grip 제어 스크립트를 사용합니다. " +
                    "같은 Animator의 Grip 값을 제어하는 스크립트가 중복되지 않는지 확인하세요.");
                if (existingGripAnimator != null && existingGripAnimator.enabled)
                {
                    readiness.warnings.Add(
                        "ControllerHandGripAnimator가 활성 상태입니다. " +
                        "기존 프로젝트 방식 사용 시 Inspector에서 ControllerHandGripAnimator를 비활성화하거나 제거하세요.");
                }
                else if (existingGripAnimator != null)
                {
                    readiness.warnings.Add(
                        "ControllerHandGripAnimator가 붙어 있지만 비활성입니다. " +
                        "기존 프로젝트 Grip 스크립트만 사용할 경우 제거를 권장합니다.");
                }
            }

            if (animatorController == null)
            {
                readiness.blockers.Add("Animator Controller가 지정되지 않았습니다.");
            }
            else
            {
                readiness.controllerAssigned = true;
                if (TryGetAnimatorControllerAsset(animatorController, out var controllerAsset, out var controllerError))
                {
                    readiness.controllerHasGripFloat = HasFloatParameter(
                        controllerAsset,
                        gripParameterName,
                        out _);

                    if (!readiness.controllerHasGripFloat)
                    {
                        readiness.blockers.Add(
                            $"Animator Controller에 Float 파라미터 '{gripParameterName}'이 없습니다.");
                    }

                    readiness.controllerHasBlendTreeState = ControllerHasStates(controllerAsset);
                    if (!readiness.controllerHasBlendTreeState)
                    {
                        readiness.warnings.Add("Animator Controller에 상태/모션이 없습니다.");
                    }
                }
                else
                {
                    readiness.blockers.Add(controllerError);
                }
            }

            if (usesToolGrip)
            {
                EvaluateGripAction(gripActionReference, readiness);
            }

            if (string.IsNullOrWhiteSpace(gripParameterName))
            {
                readiness.blockers.Add("Grip Parameter Name이 비어 있습니다.");
            }

            readiness.canApply = readiness.blockers.Count == 0;
            return readiness;
        }

        public static ApplyResult ApplySetup(
            Transform playbackHandRoot,
            RuntimeAnimatorController animatorController,
            InputActionReference gripActionReference,
            string gripParameterName,
            bool useSmoothing,
            float smoothingSpeed,
            HandSide handSide = HandSide.Left,
            HandGripControlMode gripControlMode = HandGripControlMode.ToolDefault)
        {
            var readiness = EvaluateReadiness(
                playbackHandRoot,
                animatorController,
                gripActionReference,
                gripParameterName,
                handSide,
                gripControlMode);

            if (!readiness.canApply)
            {
                var sb = new StringBuilder("컨트롤러 손 설정을 적용할 수 없습니다.");
                foreach (var blocker in readiness.blockers)
                    sb.AppendLine().Append("• ").Append(blocker);
                return new ApplyResult { message = sb.ToString() };
            }

            var usesToolGrip = gripControlMode == HandGripControlMode.ToolDefault;
            if (usesToolGrip
                && !TryGetGripInputActionAsset(gripActionReference, out _, out var gripAssetPrecheckError))
            {
                return new ApplyResult
                {
                    success = false,
                    message = gripAssetPrecheckError,
                };
            }

            Undo.SetCurrentGroupName("Controller Hand Setup");
            var undoGroup = Undo.GetCurrentGroup();

            var animator = playbackHandRoot.GetComponent<Animator>();
            if (animator == null)
            {
                animator = Undo.AddComponent<Animator>(playbackHandRoot.gameObject);
            }
            else
            {
                Undo.RecordObject(animator, "Assign Animator Controller");
            }

            animator.runtimeAnimatorController = animatorController;

            var existingGripAnimator = playbackHandRoot.GetComponent<ControllerHandGripAnimator>();

            if (!usesToolGrip)
            {
                EditorUtility.SetDirty(animator);
                if (!Application.isPlaying && playbackHandRoot.gameObject.scene.IsValid())
                {
                    EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);
                }

                Undo.CollapseUndoOperations(undoGroup);

                var legacySummary = new StringBuilder();
                legacySummary.AppendLine($"Playback Hand: {playbackHandRoot.name}");
                legacySummary.AppendLine($"Bones: {readiness.boneCount} / {readiness.expectedBoneCount}");
                legacySummary.AppendLine("Animator: 연결됨");
                legacySummary.AppendLine(
                    "기존 프로젝트의 Grip 제어 스크립트를 사용합니다. " +
                    "같은 Animator의 Grip 값을 제어하는 스크립트가 중복되지 않는지 확인하세요.");
                legacySummary.AppendLine("ControllerHandGripAnimator는 추가하지 않았습니다.");
                if (existingGripAnimator != null)
                {
                    legacySummary.AppendLine(
                        "ControllerHandGripAnimator가 이미 붙어 있습니다. " +
                        "기존 프로젝트 방식 사용 시 Inspector에서 비활성화하거나 제거하세요.");
                }

                legacySummary.Append("설정 완료");

                return new ApplyResult
                {
                    success = true,
                    message = "컨트롤러 손 설정이 적용되었습니다. (기존 프로젝트 Grip 제어)",
                    summary = legacySummary.ToString(),
                };
            }

            var gripAnimator = existingGripAnimator;
            if (gripAnimator == null)
            {
                gripAnimator = Undo.AddComponent<ControllerHandGripAnimator>(playbackHandRoot.gameObject);
            }
            else
            {
                Undo.RecordObject(gripAnimator, "Configure Controller Hand Grip Animator");
                if (!gripAnimator.enabled)
                {
                    gripAnimator.enabled = true;
                }
            }

            var serializedGripAnimator = new SerializedObject(gripAnimator);
            var handAnimatorProperty = serializedGripAnimator.FindProperty("handAnimator");
            var gripActionProperty = serializedGripAnimator.FindProperty("gripAction");
            var gripParameterProperty = serializedGripAnimator.FindProperty("gripParameterName");
            var useSmoothingProperty = serializedGripAnimator.FindProperty("useSmoothing");
            var smoothingSpeedProperty = serializedGripAnimator.FindProperty("smoothingSpeed");

            if (handAnimatorProperty == null
                || gripActionProperty == null
                || gripParameterProperty == null
                || useSmoothingProperty == null
                || smoothingSpeedProperty == null)
            {
                return new ApplyResult
                {
                    success = false,
                    message =
                        "ControllerHandGripAnimator 직렬화 필드를 찾을 수 없습니다. " +
                        "런타임 스크립트 필드명(handAnimator/gripAction/gripParameterName)이 변경됐는지 확인하세요.",
                };
            }

            handAnimatorProperty.objectReferenceValue = animator;
            SetInputActionReference(gripActionProperty, gripActionReference);
            gripParameterProperty.stringValue = gripParameterName;
            useSmoothingProperty.boolValue = useSmoothing;
            smoothingSpeedProperty.floatValue = smoothingSpeed;
            serializedGripAnimator.ApplyModifiedPropertiesWithoutUndo();

            if (!TryEnsureInputActionManagerForGrip(
                    playbackHandRoot,
                    gripActionReference,
                    out var inputActionManager,
                    out var gripActionAsset,
                    out var inputActionManagerError))
            {
                return new ApplyResult
                {
                    success = false,
                    message = inputActionManagerError,
                };
            }

            EditorUtility.SetDirty(animator);
            EditorUtility.SetDirty(gripAnimator);
            EditorUtility.SetDirty(inputActionManager);
            if (!Application.isPlaying && playbackHandRoot.gameObject.scene.IsValid())
            {
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);
            }

            if (!Application.isPlaying && PrefabUtility.IsPartOfPrefabInstance(playbackHandRoot.gameObject))
            {
                PrefabUtility.RecordPrefabInstancePropertyModifications(playbackHandRoot.gameObject);
                PrefabUtility.RecordPrefabInstancePropertyModifications(animator);
                PrefabUtility.RecordPrefabInstancePropertyModifications(gripAnimator);
                PrefabUtility.RecordPrefabInstancePropertyModifications(inputActionManager);
            }

            Undo.CollapseUndoOperations(undoGroup);

            var verify = EvaluateGripDriverOnPlaybackRoot(
                playbackHandRoot,
                animatorController,
                gripActionReference,
                gripParameterName);

            if (!verify.isValid)
            {
                return new ApplyResult
                {
                    success = false,
                    message =
                        "컨트롤러 손 설정을 적용했지만 검증에 실패했습니다.\n" +
                        (verify.failureReason ?? "알 수 없는 검증 실패"),
                };
            }

            var summary = new StringBuilder();
            summary.AppendLine($"Playback Hand: {playbackHandRoot.name}");
            summary.AppendLine($"Bones: {readiness.boneCount} / {readiness.expectedBoneCount}");
            summary.AppendLine("Animator: 연결됨");
            summary.AppendLine("Controller: 연결됨");
            summary.AppendLine($"Grip Parameter: {gripParameterName} (Float)");
            summary.AppendLine("Grip Action: 연결됨");
            summary.AppendLine("ControllerHandGripAnimator: 연결됨");
            summary.AppendLine(
                $"InputActionManager: {verify.inputActionManagerHierarchyPath ?? inputActionManager.name}");
            summary.AppendLine(
                $"Grip Action Asset 등록: {gripActionAsset.name}");
            summary.Append("설정 완료");

            return new ApplyResult
            {
                success = true,
                message = "컨트롤러 손 설정이 적용되었습니다.",
                summary = summary.ToString(),
            };
        }

        /// <summary>
        /// 현재 선택된 Playback Hand Root에 Grip Driver가 올바르게 연결됐는지 검사합니다.
        /// XR Origin(transform.root) 전체 검색을 하지 않습니다.
        /// </summary>
        public static GripDriverStatus EvaluateGripDriverOnPlaybackRoot(
            Transform playbackHandRoot,
            RuntimeAnimatorController expectedAnimatorController,
            InputActionReference expectedGripAction,
            string expectedGripParameterName)
        {
            var status = new GripDriverStatus
            {
                noDuplicateOnSelectedHand = true,
            };

            if (playbackHandRoot == null)
            {
                status.failureReason = "Playback Hand Root가 지정되지 않았습니다.";
                return status;
            }

            var driversOnSelectedHand =
                playbackHandRoot.GetComponentsInChildren<ControllerHandGripAnimator>(true);
            status.driverCountOnSelectedHand = driversOnSelectedHand.Length;
            status.noDuplicateOnSelectedHand = driversOnSelectedHand.Length <= 1;

            var driver = playbackHandRoot.GetComponent<ControllerHandGripAnimator>();
            status.driver = driver;
            status.hasDriverOnRoot = driver != null;

            if (driver == null)
            {
                if (driversOnSelectedHand.Length > 0)
                {
                    status.failureReason =
                        "현재 선택 손 Root에는 Grip Driver가 없습니다. " +
                        "하위 오브젝트에만 Driver가 있습니다.";
                }
                else
                {
                    status.failureReason = "현재 선택 손 Root에는 Grip Driver가 없습니다.";
                }

                return status;
            }

            if (driversOnSelectedHand.Length > 1)
            {
                status.failureReason =
                    $"선택 손 계층에 Grip Driver가 {driversOnSelectedHand.Length}개 있습니다 (중복).";
                return status;
            }

            status.isEnabled = driver.enabled;
            if (!driver.enabled)
            {
                status.failureReason = "Grip Driver가 비활성(disabled) 상태입니다.";
                return status;
            }

            var rootAnimator = playbackHandRoot.GetComponent<Animator>();
            var so = new SerializedObject(driver);
            var handAnimatorProp = so.FindProperty("handAnimator");
            var gripParameterProp = so.FindProperty("gripParameterName");
            var gripActionProp = so.FindProperty("gripAction");

            var boundAnimator = handAnimatorProp != null
                ? handAnimatorProp.objectReferenceValue as Animator
                : null;
            status.handAnimatorMatches =
                rootAnimator != null
                && boundAnimator != null
                && boundAnimator == rootAnimator;

            if (!status.handAnimatorMatches)
            {
                status.failureReason =
                    "Grip Driver의 handAnimator가 현재 Playback Hand Root의 Animator와 일치하지 않습니다.";
                return status;
            }

            status.animatorControllerMatches =
                rootAnimator.runtimeAnimatorController != null
                && expectedAnimatorController != null
                && rootAnimator.runtimeAnimatorController == expectedAnimatorController;

            if (!status.animatorControllerMatches)
            {
                status.failureReason =
                    "Animator의 Controller가 현재 선택된 AnimatorController와 일치하지 않습니다.";
                return status;
            }

            var actualParameterName = gripParameterProp != null
                ? gripParameterProp.stringValue
                : null;
            status.gripParameterMatches =
                !string.IsNullOrWhiteSpace(expectedGripParameterName)
                && string.Equals(actualParameterName, expectedGripParameterName, StringComparison.Ordinal);

            if (!status.gripParameterMatches)
            {
                status.failureReason =
                    $"Grip 파라미터 이름이 일치하지 않습니다 (기대: '{expectedGripParameterName}', 실제: '{actualParameterName}').";
                return status;
            }

            InputActionReference actualGripAction = null;
            if (gripActionProp != null)
            {
                var referenceProp = gripActionProp.FindPropertyRelative("m_Reference");
                if (referenceProp != null)
                    actualGripAction = referenceProp.objectReferenceValue as InputActionReference;
            }

            status.gripActionMatches = AreSameGripAction(expectedGripAction, actualGripAction);
            if (!status.gripActionMatches)
            {
                status.failureReason =
                    "Grip InputActionReference가 현재 선택된 값과 일치하지 않습니다.";
                return status;
            }

            if (!TryGetGripInputActionAsset(expectedGripAction, out var gripActionAsset, out var assetError))
            {
                status.failureReason = assetError;
                return status;
            }

            status.gripActionAsset = gripActionAsset;

            var manager = FindInputActionManagerForPlaybackHand(playbackHandRoot);
            status.inputActionManager = manager;
            status.hasInputActionManager = manager != null;
            if (manager == null)
            {
                status.failureReason =
                    "InputActionManager가 없습니다. Play Mode에서 Grip Action이 활성화되지 않습니다.";
                return status;
            }

            status.inputActionManagerHierarchyPath =
                HandPoseCaptureService.GetHierarchyPath(manager.transform);
            status.gripActionAssetRegistered =
                IsActionAssetRegisteredOnManager(manager, gripActionAsset)
                || IsActionAssetRegisteredInHierarchy(playbackHandRoot, gripActionAsset);

            if (!status.gripActionAssetRegistered)
            {
                status.failureReason =
                    $"InputActionManager에 Grip Action Asset('{gripActionAsset.name}')이 등록되어 있지 않습니다.";
                return status;
            }

            // 등록된 Manager를 재조회해 표시용으로 유지
            if (!IsActionAssetRegisteredOnManager(manager, gripActionAsset))
            {
                status.inputActionManager =
                    FindInputActionManagerContainingAsset(playbackHandRoot, gripActionAsset)
                    ?? manager;
                status.inputActionManagerHierarchyPath =
                    HandPoseCaptureService.GetHierarchyPath(status.inputActionManager.transform);
            }

            status.isValid = true;
            status.failureReason = null;
            return status;
        }

        public static bool AreSameGripAction(
            InputActionReference expected,
            InputActionReference actual)
        {
            if (expected == null && actual == null)
                return true;
            if (expected == null || actual == null)
                return false;
            if (expected == actual)
                return true;

            var expectedAction = expected.action;
            var actualAction = actual.action;
            if (expectedAction == null || actualAction == null)
                return false;

            return expectedAction.id == actualAction.id;
        }

        public static bool TryGetGripInputActionAsset(
            InputActionReference gripActionReference,
            out InputActionAsset actionAsset,
            out string errorMessage)
        {
            actionAsset = null;
            errorMessage = null;

            if (gripActionReference == null)
            {
                errorMessage = "Grip InputActionReference가 지정되지 않았습니다.";
                return false;
            }

            var action = gripActionReference.action;
            if (action == null)
            {
                errorMessage = "Grip InputActionReference에서 action을 가져올 수 없습니다.";
                return false;
            }

            var actionMap = action.actionMap;
            if (actionMap == null)
            {
                errorMessage = "Grip Action의 Action Map을 가져올 수 없습니다.";
                return false;
            }

            actionAsset = actionMap.asset;
            if (actionAsset == null)
            {
                errorMessage = "Grip Action이 속한 InputActionAsset을 가져올 수 없습니다.";
                return false;
            }

            return true;
        }

        public static InputActionManager FindInputActionManagerForPlaybackHand(Transform playbackHandRoot)
        {
            if (playbackHandRoot == null)
                return null;

            var inParents = playbackHandRoot.GetComponentsInParent<InputActionManager>(true);
            if (inParents != null && inParents.Length > 0)
                return inParents[0];

            var root = playbackHandRoot.root;
            if (root == null)
                return null;

            return root.GetComponentInChildren<InputActionManager>(true);
        }

        public static InputActionManager FindInputActionManagerContainingAsset(
            Transform playbackHandRoot,
            InputActionAsset actionAsset)
        {
            if (playbackHandRoot == null || actionAsset == null)
                return null;

            foreach (var manager in EnumerateInputActionManagers(playbackHandRoot))
            {
                if (IsActionAssetRegisteredOnManager(manager, actionAsset))
                    return manager;
            }

            return null;
        }

        public static bool IsActionAssetRegisteredInHierarchy(
            Transform playbackHandRoot,
            InputActionAsset actionAsset)
        {
            return FindInputActionManagerContainingAsset(playbackHandRoot, actionAsset) != null;
        }

        public static bool IsActionAssetRegisteredOnManager(
            InputActionManager manager,
            InputActionAsset actionAsset)
        {
            if (manager == null || actionAsset == null || manager.actionAssets == null)
                return false;

            for (var i = 0; i < manager.actionAssets.Count; i++)
            {
                if (manager.actionAssets[i] == actionAsset)
                    return true;
            }

            return false;
        }

        public static bool TryEnsureInputActionManagerForGrip(
            Transform playbackHandRoot,
            InputActionReference gripActionReference,
            out InputActionManager manager,
            out InputActionAsset actionAsset,
            out string errorMessage)
        {
            manager = null;
            actionAsset = null;
            errorMessage = null;

            if (playbackHandRoot == null)
            {
                errorMessage = "Playback Hand Root가 지정되지 않았습니다.";
                return false;
            }

            if (!TryGetGripInputActionAsset(gripActionReference, out actionAsset, out errorMessage))
                return false;

            // 이미 계층의 어떤 Manager가 같은 Asset을 갖고 있으면 재사용만 하고 중복 등록하지 않음
            var existingWithAsset = FindInputActionManagerContainingAsset(playbackHandRoot, actionAsset);
            if (existingWithAsset != null)
            {
                manager = existingWithAsset;
                return true;
            }

            manager = FindInputActionManagerForPlaybackHand(playbackHandRoot);
            if (manager == null)
            {
                var rootObject = playbackHandRoot.root.gameObject;
                manager = Undo.AddComponent<InputActionManager>(rootObject);
            }

            if (!TryRegisterActionAsset(manager, actionAsset, out errorMessage))
                return false;

            if (!IsActionAssetRegisteredOnManager(manager, actionAsset))
            {
                errorMessage =
                    $"InputActionManager에 Grip Action Asset('{actionAsset.name}') 등록 검증에 실패했습니다.";
                return false;
            }

            if (!Application.isPlaying && playbackHandRoot.gameObject.scene.IsValid())
            {
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);
            }

            return true;
        }

        static bool TryRegisterActionAsset(
            InputActionManager manager,
            InputActionAsset actionAsset,
            out string errorMessage)
        {
            errorMessage = null;
            if (manager == null)
            {
                errorMessage = "InputActionManager가 null입니다.";
                return false;
            }

            if (actionAsset == null)
            {
                errorMessage = "등록할 InputActionAsset이 null입니다.";
                return false;
            }

            if (IsActionAssetRegisteredOnManager(manager, actionAsset))
                return true;

            Undo.RecordObject(manager, "Register Grip Input Action Asset");

            var serializedManager = new SerializedObject(manager);
            var actionAssetsProperty = serializedManager.FindProperty("m_ActionAssets");
            if (actionAssetsProperty == null || !actionAssetsProperty.isArray)
            {
                // public List API fallback
                var list = manager.actionAssets ?? new List<InputActionAsset>();
                list.Add(actionAsset);
                manager.actionAssets = list;
                EditorUtility.SetDirty(manager);
                return true;
            }

            var insertIndex = actionAssetsProperty.arraySize;
            actionAssetsProperty.arraySize = insertIndex + 1;
            actionAssetsProperty.GetArrayElementAtIndex(insertIndex).objectReferenceValue = actionAsset;
            serializedManager.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(manager);
            return true;
        }

        static IEnumerable<InputActionManager> EnumerateInputActionManagers(Transform playbackHandRoot)
        {
            if (playbackHandRoot == null)
                yield break;

            var seen = new HashSet<InputActionManager>();
            var inParents = playbackHandRoot.GetComponentsInParent<InputActionManager>(true);
            if (inParents != null)
            {
                foreach (var manager in inParents)
                {
                    if (manager == null || !seen.Add(manager))
                        continue;
                    yield return manager;
                }
            }

            var root = playbackHandRoot.root;
            if (root == null)
                yield break;

            var underRoot = root.GetComponentsInChildren<InputActionManager>(true);
            if (underRoot == null)
                yield break;

            foreach (var manager in underRoot)
            {
                if (manager == null || !seen.Add(manager))
                    continue;
                yield return manager;
            }
        }

        static void EvaluateGripAction(InputActionReference gripActionReference, Readiness readiness)
        {
            if (gripActionReference == null)
            {
                readiness.warnings.Add(
                    "Grip Input Action이 비어 있습니다. [왼손 Grip 자동 찾기] 또는 [컨트롤러 손 설정 적용] 시 자동 탐색합니다.");
                return;
            }

            readiness.gripActionAssigned = true;
            readiness.gripActionPath = AssetDatabase.GetAssetPath(gripActionReference);

            var action = gripActionReference.action;
            if (action == null)
            {
                readiness.blockers.Add("Grip Input Action Reference에서 action을 가져올 수 없습니다.");
                return;
            }

            readiness.gripActionType = action.type.ToString();
            readiness.gripActionExpectedControlType = action.expectedControlType ?? "(none)";

            if (action.type != InputActionType.Value && action.type != InputActionType.Button)
            {
                readiness.blockers.Add(
                    $"Grip Action 타입이 float 입력에 적합하지 않습니다 (현재: {action.type}).");
            }
            else if (action.type == InputActionType.Value
                     && !string.IsNullOrEmpty(action.expectedControlType)
                     && action.expectedControlType != "Axis"
                     && action.expectedControlType != "Button")
            {
                readiness.warnings.Add(
                    $"Grip Action expectedControlType={action.expectedControlType}. Axis(float) 입력을 권장합니다.");
            }
        }

        static bool TryGetAnimatorControllerAsset(
            RuntimeAnimatorController controller,
            out AnimatorController animatorController,
            out string errorMessage)
        {
            animatorController = controller as AnimatorController;
            if (animatorController != null)
            {
                errorMessage = null;
                return true;
            }

            var path = AssetDatabase.GetAssetPath(controller);
            animatorController = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            if (animatorController != null)
            {
                errorMessage = null;
                return true;
            }

            errorMessage = "Animator Controller 에셋을 읽을 수 없습니다.";
            return false;
        }

        static bool HasFloatParameter(
            AnimatorController controller,
            string parameterName,
            out AnimatorControllerParameterType actualType)
        {
            actualType = default;
            foreach (var parameter in controller.parameters)
            {
                if (parameter.name != parameterName)
                    continue;

                actualType = parameter.type;
                return parameter.type == AnimatorControllerParameterType.Float;
            }

            return false;
        }

        static bool ControllerHasStates(AnimatorController controller)
        {
            if (controller.layers == null || controller.layers.Length == 0)
                return false;

            var stateMachine = controller.layers[0].stateMachine;
            return stateMachine != null
                && (stateMachine.states.Length > 0 || stateMachine.stateMachines.Length > 0);
        }

        public static void SetInputActionReferencePublic(
            SerializedProperty inputActionProperty,
            InputActionReference reference)
        {
            SetInputActionReference(inputActionProperty, reference);
        }

        static void SetInputActionReference(SerializedProperty inputActionProperty, InputActionReference reference)
        {
            var useReferenceProperty = inputActionProperty.FindPropertyRelative("m_UseReference");
            var referenceProperty = inputActionProperty.FindPropertyRelative("m_Reference");

            if (useReferenceProperty != null)
                useReferenceProperty.boolValue = true;
            if (referenceProperty != null)
                referenceProperty.objectReferenceValue = reference;
        }
    }
}
