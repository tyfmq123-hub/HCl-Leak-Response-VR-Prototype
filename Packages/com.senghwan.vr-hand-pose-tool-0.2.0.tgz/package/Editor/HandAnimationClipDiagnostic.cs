using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Hand AnimationClip에 손가락 외 Transform 곡선(루트/손목/손바닥 등)이 포함됐는지 진단합니다.
    /// Clip 내용은 수정하지 않습니다.
    /// </summary>
    public static class HandAnimationClipDiagnostic
    {
        public const string DefaultOpenClipPath =
            HandPoseAnimationClipExporter.OutputFolder + "/Left_Open.anim";

        public const string DefaultGrabClipPath =
            HandPoseAnimationClipExporter.OutputFolder + "/Left_Grab.anim";

        public struct BindingInfo
        {
            public string path;
            public string propertyName;
            public bool isFinger;
            public bool isRisky;
        }

        public struct DiagnosticResult
        {
            public bool success;
            public string message;
            public string clipName;
            public string clipPath;
            public int totalTransformBindingCount;
            public int fingerTransformBindingCount;
            public int nonFingerTransformBindingCount;
            public int riskyBindingCount;
            public List<BindingInfo> transformBindings;
            public List<BindingInfo> riskyBindings;
            public List<string> riskyPathCandidates;
            public bool isHealthy;
            public string summary;
        }

        public static AnimationClip TryLoadDefaultOpenClip()
        {
            return AssetDatabase.LoadAssetAtPath<AnimationClip>(DefaultOpenClipPath);
        }

        public static AnimationClip TryLoadDefaultGrabClip()
        {
            return AssetDatabase.LoadAssetAtPath<AnimationClip>(DefaultGrabClipPath);
        }

        public static DiagnosticResult Diagnose(AnimationClip clip)
        {
            return Diagnose(clip, HandSide.Left);
        }

        public static DiagnosticResult Diagnose(AnimationClip clip, HandSide handSide)
        {
            if (clip == null)
            {
                return new DiagnosticResult
                {
                    success = false,
                    message = "AnimationClip이 지정되지 않았습니다.",
                    summary = "AnimationClip이 지정되지 않았습니다.",
                };
            }

            var clipPath = AssetDatabase.GetAssetPath(clip);
            var transformBindings = CollectTransformBindings(clip, handSide);
            var riskyBindings = transformBindings.Where(b => b.isRisky).ToList();
            var fingerCount = transformBindings.Count(b => b.isFinger);
            var nonFingerCount = transformBindings.Count(b => !b.isFinger);

            var riskyPathCandidates = riskyBindings
                .Select(b => FormatBindingLabel(b.path, b.propertyName))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(s => s, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var result = new DiagnosticResult
            {
                success = true,
                clipName = clip.name,
                clipPath = clipPath,
                totalTransformBindingCount = transformBindings.Count,
                fingerTransformBindingCount = fingerCount,
                nonFingerTransformBindingCount = nonFingerCount,
                riskyBindingCount = riskyBindings.Count,
                transformBindings = transformBindings,
                riskyBindings = riskyBindings,
                riskyPathCandidates = riskyPathCandidates,
                isHealthy = riskyBindings.Count == 0
                    && transformBindings.Count > 0
                    && transformBindings.All(b => b.isFinger),
            };

            result.summary = BuildSummary(result);
            result.message = result.summary;
            return result;
        }

        public static void LogToConsole(DiagnosticResult result)
        {
            if (!result.success)
            {
                Debug.LogWarning($"[HandAnimationClipDiagnostic] {result.message}");
                return;
            }

            var prefix = result.isHealthy ? "정상" : "경고";
            Debug.Log(
                $"[HandAnimationClipDiagnostic] {prefix} · {result.clipName}\n{result.summary}");
        }

        static List<BindingInfo> CollectTransformBindings(AnimationClip clip, HandSide handSide)
        {
            var bindings = new List<BindingInfo>();
            var seen = new HashSet<string>(StringComparer.Ordinal);

            foreach (var binding in AnimationUtility.GetCurveBindings(clip))
            {
                if (binding.type != typeof(Transform))
                    continue;

                if (!IsTransformProperty(binding.propertyName))
                    continue;

                var key = $"{binding.path}|{binding.propertyName}";
                if (!seen.Add(key))
                    continue;

                var isFinger = IsFingerPath(binding.path, handSide);
                var isRisky = IsRiskyNonFingerTransform(binding.path, binding.propertyName, isFinger);

                bindings.Add(new BindingInfo
                {
                    path = binding.path,
                    propertyName = binding.propertyName,
                    isFinger = isFinger,
                    isRisky = isRisky,
                });
            }

            return bindings
                .OrderBy(b => b.path, StringComparer.OrdinalIgnoreCase)
                .ThenBy(b => b.propertyName, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        static bool IsTransformProperty(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
                return false;

            if (propertyName.StartsWith("m_LocalPosition", StringComparison.Ordinal)
                || propertyName.StartsWith("localPosition", StringComparison.Ordinal)
                || propertyName.StartsWith("m_LocalRotation", StringComparison.Ordinal)
                || propertyName.StartsWith("localRotation", StringComparison.Ordinal)
                || propertyName.StartsWith("m_LocalEulerAngles", StringComparison.Ordinal)
                || propertyName.StartsWith("localEulerAngles", StringComparison.Ordinal)
                || propertyName.StartsWith("m_LocalScale", StringComparison.Ordinal)
                || propertyName.StartsWith("localScale", StringComparison.Ordinal))
            {
                return true;
            }

            return false;
        }

        static bool IsFingerPath(string path, HandSide handSide)
        {
            if (string.IsNullOrEmpty(path))
                return false;

            var leaf = GetLeafBoneName(path);
            if (HandSkeletonCatalog.GetFingerAnimationBoneNames(handSide).Contains(leaf))
                return true;

            if (HandSideUtility.ContainsOppositeHandBonePrefix(leaf, handSide))
                return false;

            return ContainsFingerKeyword(leaf);
        }

        static bool IsRiskyNonFingerTransform(string path, string propertyName, bool isFinger)
        {
            if (!IsTransformProperty(propertyName))
                return false;

            if (isFinger)
                return false;

            if (string.IsNullOrEmpty(path))
                return true;

            var leaf = GetLeafBoneName(path);
            if (ContainsFingerKeyword(leaf))
                return false;

            return IsRiskyBoneName(leaf);
        }

        static bool IsRiskyBoneName(string boneName)
        {
            if (string.IsNullOrEmpty(boneName))
                return true;

            var lower = boneName.ToLowerInvariant();

            if (lower is "lefthand" or "righthand" or "hand")
                return true;

            if (lower.Contains("palm"))
                return true;

            if (lower.Contains("forearm"))
                return true;

            if (lower.EndsWith("wrist") || lower == "wrist" || lower.Contains("_wrist"))
                return true;

            if (lower.Contains("arm") && !lower.Contains("metacarpal") && !ContainsFingerKeyword(boneName))
                return true;

            if (lower.Contains("hand") && !ContainsFingerKeyword(boneName))
                return true;

            return false;
        }

        static bool ContainsFingerKeyword(string name)
        {
            if (string.IsNullOrEmpty(name))
                return false;

            var lower = name.ToLowerInvariant();
            return lower.Contains("thumb")
                || lower.Contains("index")
                || lower.Contains("middle")
                || lower.Contains("ring")
                || lower.Contains("little")
                || lower.Contains("pinky")
                || lower.Contains("finger")
                || lower.Contains("metacarpal")
                || lower.Contains("proximal")
                || lower.Contains("intermediate")
                || lower.Contains("distal")
                || lower.Contains("tip");
        }

        static string GetLeafBoneName(string path)
        {
            if (string.IsNullOrEmpty(path))
                return string.Empty;

            var lastSlash = path.LastIndexOf('/');
            return lastSlash >= 0 ? path.Substring(lastSlash + 1) : path;
        }

        static string FormatBindingLabel(string path, string propertyName)
        {
            var displayPath = string.IsNullOrEmpty(path) ? "(root / empty path)" : path;
            return $"{displayPath} · {propertyName}";
        }

        static string BuildSummary(DiagnosticResult result)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Clip: {result.clipName}");
            if (!string.IsNullOrEmpty(result.clipPath))
                sb.AppendLine($"Path: {result.clipPath}");
            sb.AppendLine($"Transform binding 수: {result.totalTransformBindingCount}");
            sb.AppendLine($"손가락 Transform binding 수: {result.fingerTransformBindingCount}");
            sb.AppendLine($"비손가락 Transform binding 수: {result.nonFingerTransformBindingCount}");
            sb.AppendLine($"위험 후보 binding 수: {result.riskyBindingCount}");

            if (result.transformBindings != null && result.transformBindings.Count > 0)
            {
                sb.AppendLine("Transform bindings:");
                foreach (var binding in result.transformBindings)
                {
                    sb.Append("  • ");
                    sb.Append(FormatBindingLabel(binding.path, binding.propertyName));
                    sb.Append(binding.isRisky ? " [위험]" : binding.isFinger ? " [손가락]" : " [기타]");
                    sb.AppendLine();
                }
            }

            if (result.riskyPathCandidates != null && result.riskyPathCandidates.Count > 0)
            {
                sb.AppendLine("위험 후보 경로:");
                foreach (var candidate in result.riskyPathCandidates)
                {
                    sb.Append("  • ");
                    sb.AppendLine(candidate);
                }

                sb.AppendLine("판정: 경고 — 손 루트/손목/손바닥 등 비손가락 Transform 곡선이 포함되어 있습니다.");
            }
            else if (result.totalTransformBindingCount == 0)
            {
                sb.AppendLine("판정: Transform binding이 없습니다.");
            }
            else
            {
                sb.AppendLine("판정: 정상 — 손가락 Transform 곡선만 포함되어 있습니다.");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
