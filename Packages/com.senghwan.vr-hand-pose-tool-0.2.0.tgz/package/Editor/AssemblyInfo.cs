using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Senghwan.VRHandPoseTool.Editor.Tests")]
