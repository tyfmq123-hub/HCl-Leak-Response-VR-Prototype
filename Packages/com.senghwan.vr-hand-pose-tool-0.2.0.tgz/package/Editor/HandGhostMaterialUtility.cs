using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Ghost 손용 HandGhostFresnel Material을 Project Asset으로 저장하고 관리합니다.
    /// HideAndDontSave 임시 인스턴스를 사용하지 않으므로, 씬 저장/도메인 리로드/Play Mode
    /// 전환 후에도 renderer.sharedMaterials 참조가 유효하며 Game 뷰에서 마젠타가 발생하지 않습니다.
    /// </summary>
    public static class HandGhostMaterialUtility
    {
        public const string GhostFresnelShaderName = "VRHandPoseTool/HandGhostFresnel";
        public const string GhostMaterialAssetPath =
            "Assets/VRHandPoseToolOutput/Materials/HandGhostFresnel.mat";

        static readonly int BaseAlphaId = Shader.PropertyToID("_BaseAlpha");
        static readonly int RimColorId = Shader.PropertyToID("_RimColor");
        static readonly int RimPowerId = Shader.PropertyToID("_RimPower");
        static readonly int RimIntensityId = Shader.PropertyToID("_RimIntensity");
        static readonly int PulseSpeedId = Shader.PropertyToID("_PulseSpeed");
        static readonly int PulseAmountId = Shader.PropertyToID("_PulseAmount");

        /// <summary>
        /// Ghost Material Asset을 로드하거나 없으면 새로 생성해 Asset으로 저장합니다.
        /// HideAndDontSave를 사용하지 않으므로 Play Mode 전환 후에도 참조가 유지됩니다.
        /// </summary>
        public static Material GetOrCreateGhostMaterialAsset(HandGhostAppearanceSettings appearance)
        {
            EnsureMaterialOutputFolder();

            var material = AssetDatabase.LoadAssetAtPath<Material>(GhostMaterialAssetPath);
            if (material == null)
            {
                var shader = FindGhostShader();
                material = new Material(shader) { name = "HandGhostFresnel" };
                ApplyAppearance(material, appearance);
                AssetDatabase.CreateAsset(material, GhostMaterialAssetPath);
                AssetDatabase.SaveAssets();
            }
            else
            {
                ApplyAppearance(material, appearance);
                EditorUtility.SetDirty(material);
                AssetDatabase.SaveAssets();
            }

            return material;
        }

        public static void ApplyGhostMaterials(
            IReadOnlyList<Renderer> renderers,
            HandGhostAppearanceSettings appearance,
            IList<Material> createdInstances)
        {
            if (renderers == null)
                return;

            // Asset으로 저장된 단일 Material을 모든 슬롯에 공유 적용합니다.
            var ghostMat = GetOrCreateGhostMaterialAsset(appearance);

            foreach (var renderer in renderers)
            {
                if (renderer == null)
                    continue;

                ConfigureRenderer(renderer);

                var slotCount = Mathf.Max(1, renderer.sharedMaterials.Length);
                var ghostMaterials = new Material[slotCount];
                for (var i = 0; i < slotCount; i++)
                    ghostMaterials[i] = ghostMat;

                renderer.sharedMaterials = ghostMaterials;
            }
        }

        public static void UpdateGhostAppearance(
            IReadOnlyList<Renderer> renderers,
            HandGhostAppearanceSettings appearance)
        {
            if (renderers == null)
                return;

            // Appearance 변경 시 Asset을 업데이트하고 모든 슬롯에 재적용합니다.
            var ghostMat = GetOrCreateGhostMaterialAsset(appearance);

            foreach (var renderer in renderers)
            {
                if (renderer == null)
                    continue;

                ConfigureRenderer(renderer);

                var slotCount = Mathf.Max(1, renderer.sharedMaterials.Length);
                var ghostMaterials = new Material[slotCount];
                for (var i = 0; i < slotCount; i++)
                    ghostMaterials[i] = ghostMat;

                renderer.sharedMaterials = ghostMaterials;
            }
        }

        public static bool UsesGhostFresnelShader(Material material)
        {
            return material != null
                && material.shader != null
                && material.shader.name == GhostFresnelShaderName;
        }

        public static void ApplyAppearance(Material material, HandGhostAppearanceSettings appearance)
        {
            if (material == null)
                return;

            material.SetFloat(BaseAlphaId, Mathf.Clamp(appearance.baseAlpha, 0.03f, 0.08f));
            material.SetColor(RimColorId, appearance.rimColor);
            material.SetFloat(RimPowerId, Mathf.Clamp(appearance.rimPower, 2f, 4f));
            material.SetFloat(RimIntensityId, Mathf.Clamp(appearance.rimIntensity, 1.5f, 3f));
            material.SetFloat(PulseSpeedId, appearance.pulseSpeed);
            material.SetFloat(PulseAmountId, Mathf.Clamp(appearance.pulseAmount, 0.15f, 0.3f));
        }

        static Shader FindGhostShader()
        {
            var shader = Shader.Find(GhostFresnelShaderName);
            if (shader == null)
                throw new System.InvalidOperationException(
                    $"고스트 셰이더를 찾지 못했습니다: {GhostFresnelShaderName}");

            return shader;
        }

        static void EnsureMaterialOutputFolder()
        {
            const string root = "Assets/VRHandPoseToolOutput";
            const string subFolder = "Assets/VRHandPoseToolOutput/Materials";

            if (!AssetDatabase.IsValidFolder(root))
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");

            if (!AssetDatabase.IsValidFolder(subFolder))
                AssetDatabase.CreateFolder(root, "Materials");
        }

        static void ConfigureRenderer(Renderer renderer)
        {
            renderer.shadowCastingMode = ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            renderer.motionVectorGenerationMode = MotionVectorGenerationMode.ForceNoMotion;
        }
    }
}
