using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// HandVisualizer 런타임 손 포즈 캡처, XRHandPoseAsset 저장, AnimationClip 내보내기 UI입니다.
    /// </summary>
    public class HandPoseCaptureWindow : EditorWindow
    {
        const string MenuPath = "Tools/VR Hand Tools/Hand Pose Capture";
        const int StepCount = 5;

        static readonly string[] StepTitles =
        {
            "손 준비",
            "포즈 캡처",
            "애니메이션 만들기",
            "잡기 설정",
            "고스트 미리보기",
        };

        static readonly string[] StepNavLabels =
        {
            "① 손 준비",
            "② 포즈 캡처",
            "③ 애니메이션",
            "④ 잡기 설정",
            "⑤ 고스트",
        };

        // ── 1차 / 2차 작업 모드 ──────────────────────────────────────────────
        public enum WorkMode { Mode1_Animation = 0, Mode2_GrabPose = 1 }

        static readonly string[] Mode1StepNavLabels =
        {
            "① 손 준비",
            "② Open·Grip 캡처",
            "③ Clip·Blend Tree",
            "④ Controller 연결",
            "⑤ 1차 완료",
        };

        static readonly string[] Mode2StepNavLabels =
        {
            "① Target 설정",
            "② Grab Pose 캡처",
            "③ Ghost 생성",
            "④ Binding 적용",
            "⑤ 2차 완료",
        };

        [SerializeField]
        HandSide m_HandSide = HandSide.Left;

        [SerializeField]
        Transform m_TrackingHandRoot;

        [SerializeField]
        Transform m_TargetTransform;

        [SerializeField]
        string m_PoseName = "Left_Current";

        [SerializeField]
        XRHandPoseAsset m_CapturedOpenPoseAsset;

        [SerializeField]
        XRHandPoseAsset m_CapturedGrabPoseAsset;

        [SerializeField]
        Transform m_PlaybackSetupPlacementParent;

        [SerializeField]
        Transform m_PlaybackHandRoot;

        [SerializeField]
        RuntimeAnimatorController m_AnimatorController;

        [SerializeField]
        InputActionReference m_GripInputAction;

        [SerializeField]
        string m_GripParameterName = "Grip";

        [SerializeField]
        bool m_UseSmoothing = true;

        [SerializeField]
        float m_SmoothingSpeed = 12f;

        [SerializeField]
        HandGripControlMode m_GripControlMode = HandGripControlMode.ToolDefault;

        [SerializeField]
        AnimationClip m_OpenAnimationClip;

        [SerializeField]
        AnimationClip m_GrabAnimationClip;

        [SerializeField]
        XRHandPoseAsset m_GrabSnapshotSourceAsset;

        [SerializeField]
        string m_GrabSnapshotOutputName = HandGrabSnapshotExporter.DefaultOutputName;

        [SerializeField]
        GameObject m_GhostTargetGrabObject;

        [SerializeField]
        HandPoseSnapshot m_GhostGrabSnapshot;

        [SerializeField]
        Color m_GhostRimColor = new Color(0.35f, 0.85f, 1f, 1f);

        [SerializeField]
        float m_GhostBaseAlpha = 0.05f;

        [SerializeField]
        float m_GhostRimIntensity = 2f;

        [SerializeField]
        float m_GhostPulseSpeed = 1.2f;

        Vector2 m_Scroll;
        string m_LastSavedAssetPath;
        string m_LastResultSummary;
        MessageType m_LastResultMessageType = MessageType.Info;
        string m_LastControllerSetupSummary;
        MessageType m_LastControllerSetupMessageType = MessageType.Info;
        string m_LastGripFindSummary;
        MessageType m_LastGripFindMessageType = MessageType.Info;
        List<HandGripInputActionFinder.CandidateInfo> m_PendingGripCandidates;
        List<HandPlaybackHandFinder.Candidate> m_PendingPlaybackCandidates;
        List<HandPoseTrackedHandFinder.Candidate> m_PendingTrackedCandidates;
        List<HandInteractorFinder.Candidate> m_InteractorCandidates;
        Component m_InteractorCandidate;
        string m_LastOpenClipDiagnosticSummary;
        MessageType m_LastOpenClipDiagnosticMessageType = MessageType.Info;
        string m_LastGrabClipDiagnosticSummary;
        MessageType m_LastGrabClipDiagnosticMessageType = MessageType.Info;
        string m_LastGrabDiagnosticSetupSummary;
        MessageType m_LastGrabDiagnosticSetupMessageType = MessageType.Info;
        string m_LastGrabSnapshotExportSummary;
        MessageType m_LastGrabSnapshotExportMessageType = MessageType.Info;
        string m_LastGrabSnapshotExportPath;
        string m_LastGhostPreviewSummary;
        MessageType m_LastGhostPreviewMessageType = MessageType.Info;
        string m_LastGrabPoseRecordSummary;
        MessageType m_LastGrabPoseRecordMessageType = MessageType.Info;
        string m_LastGrabPoseRecordPath;
        string m_LastGrabMigrationSummary;
        MessageType m_LastGrabMigrationMessageType = MessageType.Info;
        string m_LastInteractorSideSummary;
        MessageType m_LastInteractorSideMessageType = MessageType.Info;
        string m_LastPlaybackSetupSummary;
        MessageType m_LastPlaybackSetupMessageType = MessageType.Info;
        HandPlaybackSetupService.SceneProbeSummary m_PlaybackSetupProbe;

        // ── ① 선택 손 전체 준비 ──
        string m_LastFullPrepSummary;
        MessageType m_LastFullPrepMessageType = MessageType.Info;
        string m_FullPrepStatusMessage;
        bool m_FullPrepImportInProgress;
        HandSelectedHandFullPrepService.Checklist m_FullPrepChecklist;

        // ── Controller 손 정렬 ──
        string m_LastAlignmentMessage;
        MessageType m_LastAlignmentMessageType = MessageType.Info;
        HandControllerVisualAlignmentService.AlignMode m_AlignMode =
            HandControllerVisualAlignmentService.AlignMode.PositionAndRotation;

        // ── 정렬 미리보기 ──
        string m_LastPreviewMessage;
        MessageType m_LastPreviewMessageType = MessageType.Info;

        [SerializeField]
        int m_CurrentStep = 1;

        [SerializeField]
        WorkMode m_WorkMode = WorkMode.Mode1_Animation;

        [SerializeField]
        int m_Mode1Step = 1;

        [SerializeField]
        int m_Mode2Step = 1;

        bool m_FoldMode1QuickConnect;
        bool m_FoldMode2ControllerCapture;

        [SerializeField]
        bool m_Mode2DeviceVerified;

        bool m_FoldStep1SetupDetails;
        bool m_FoldStep1SetupResult;
        bool m_FoldStep2CaptureDiagnostic;
        bool m_FoldStep2ControllerCapture;
        bool m_Step2AutoSearchDone;
        bool m_FoldStep3ExportHelp;
        bool m_FoldStep3ClipDiagnostic;
        bool m_FoldStep4Details;
        bool m_FoldStep5GrabSnapshotHelp;
        bool m_FoldStep5GrabSnapshotResult;
        bool m_FoldStep5GrabPoseCaptureHelp;
        bool m_FoldStep5GhostHelp;
        bool m_FoldStep5GhostResult;

        // ── 상태 저장·복원·삭제 UI ──────────────────────────────────────────
        bool m_FoldDeleteResults;
        bool m_FoldMode2SideReset;
        string m_LastMode2SideResetSummary;
        MessageType m_LastMode2SideResetMessageType = MessageType.Info;
        string m_RestoreLog;           // OnEnable 시 복원 경고 메시지
        bool m_ShowRestoreLog;         // 복원 로그 표시 여부

        // EditorPrefs 키 상수
        const string PK = "VRHandPoseTool.";
        const string PkMode      = PK + "Mode";
        const string PkM1Step    = PK + "M1Step";
        const string PkM2Step    = PK + "M2Step";
        const string PkHandSide  = PK + "HandSide";
        const string PkDevVer    = PK + "DevVerified";
        const string PkOpenPose  = PK + "OpenPoseGuid";
        const string PkGripPose  = PK + "GripPoseGuid";
        const string PkOpenClip  = PK + "OpenClipGuid";
        const string PkGrabClip  = PK + "GrabClipGuid";
        const string PkAnimCtrl  = PK + "AnimCtrlGuid";
        const string PkGripAct   = PK + "GripActGuid";
        const string PkPlayback  = PK + "PlaybackGoid";
        const string PkTarget    = PK + "TargetGoid";
        const string PkInteract  = PK + "InteractGoid";

        [MenuItem(MenuPath)]
        public static void ShowWindow()
        {
            var window = GetWindow<HandPoseCaptureWindow>("Hand Pose Capture");
            window.minSize = new Vector2(500f, 480f);
            window.Show();
        }

        /// <summary>
        /// Sample Import 후 Domain Reload 재개용. Hand Side를 맞추고 ① 단계에서 구성을 이어갑니다.
        /// </summary>
        public static void ShowWindowAndResumeFullPrep(HandSide handSide)
        {
            var window = GetWindow<HandPoseCaptureWindow>("Hand Pose Capture");
            window.minSize = new Vector2(500f, 480f);
            window.m_WorkMode = WorkMode.Mode1_Animation;
            window.m_Mode1Step = 1;
            if (window.m_HandSide != handSide)
            {
                window.ApplyHandSideDefaults(window.m_HandSide, handSide);
                window.m_HandSide = handSide;
            }

            window.Show();
            window.Focus();
            EditorApplication.delayCall += () =>
            {
                if (window == null)
                    return;
                window.ExecuteSelectedHandFullPrep(resumeAfterImport: true);
            };
        }

        void OnEnable()
        {
            EditorApplication.update += OnEditorUpdate;
            Selection.selectionChanged += OnSelectionChanged;
            EditorApplication.playModeStateChanged -= OnWindowPlayModeStateChanged;
            EditorApplication.playModeStateChanged += OnWindowPlayModeStateChanged;
            LoadWindowState();
            TryAssignDefaultDiagnosticClips();
            TryAssignDefaultGrabSnapshotSource();
            TryAssignDefaultGhostGrabSnapshot();
            CapturePlaybackHandLocatorIfPossible();
        }

        void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
            Selection.selectionChanged -= OnSelectionChanged;
            EditorApplication.playModeStateChanged -= OnWindowPlayModeStateChanged;
            HandAlignmentPreviewService.EndPreview();
            SaveWindowState();
        }

        void OnWindowPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.ExitingEditMode)
                CapturePlaybackHandLocatorIfPossible();
        }

        /// <summary>
        /// Edit Mode Scene의 Playback Hand / Visual Offset Locator를 갱신합니다.
        /// Play Mode에서는 호출해도 저장하지 않습니다.
        /// </summary>
        void CapturePlaybackHandLocatorIfPossible()
        {
            if (Application.isPlaying || EditorApplication.isPlayingOrWillChangePlaymode)
                return;
            if (m_PlaybackHandRoot == null)
                return;

            HandSceneObjectLocator.CaptureAndStore(
                m_PlaybackHandRoot,
                m_HandSide,
                SceneObjectLocatorRole.PlaybackHandRoot,
                out _,
                out _);

            var vo = HandControllerVisualAlignmentService.FindVisualOffset(m_PlaybackHandRoot, m_HandSide);
            if (vo != null)
            {
                HandSceneObjectLocator.CaptureAndStore(
                    vo,
                    m_HandSide,
                    SceneObjectLocatorRole.VisualOffset,
                    out _,
                    out _);
            }
        }

        void SetPlaybackHandRoot(Transform root)
        {
            m_PlaybackHandRoot = root;
            CapturePlaybackHandLocatorIfPossible();
        }

        void OnSelectionChanged()
        {
            if (m_GhostTargetGrabObject == null)
            {
                var selectionTarget = HandGhostPreviewService.TryResolveSelectionGrabTarget();
                if (selectionTarget != null)
                {
                    m_GhostTargetGrabObject = selectionTarget;
                    Repaint();
                }
            }
        }

        void OnEditorUpdate()
        {
            if (Application.isPlaying)
                Repaint();
        }

        void OnGUI()
        {
            DrawWizardHeader();

            m_Scroll = EditorGUILayout.BeginScrollView(m_Scroll);
            if (m_WorkMode == WorkMode.Mode1_Animation)
                DrawMode1Step(m_Mode1Step);
            else
                DrawMode2Step(m_Mode2Step);
            EditorGUILayout.EndScrollView();

            DrawFooterToolbar();
        }

        void DrawWizardHeader()
        {
            EditorGUILayout.LabelField("VR Hand Pose Tool", EditorStyles.boldLabel);

            // ── 작업 모드 선택 카드 ──
            EditorGUILayout.BeginHorizontal();
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = m_WorkMode == WorkMode.Mode1_Animation
                ? new Color(0.4f, 0.75f, 1f)
                : new Color(0.82f, 0.82f, 0.82f);
            if (GUILayout.Button("1차 · 기본 손 애니메이션 만들기", GUILayout.Height(30f)))
                m_WorkMode = WorkMode.Mode1_Animation;
            GUI.backgroundColor = m_WorkMode == WorkMode.Mode2_GrabPose
                ? new Color(0.45f, 1f, 0.65f)
                : new Color(0.82f, 0.82f, 0.82f);
            if (GUILayout.Button("2차 · 물체 전용 잡기 자세 만들기", GUILayout.Height(30f)))
                m_WorkMode = WorkMode.Mode2_GrabPose;
            GUI.backgroundColor = prevBg;
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(4f);

            EditorGUI.BeginChangeCheck();
            var newHandSide = (HandSide)EditorGUILayout.EnumPopup("Hand Side", m_HandSide);
            if (EditorGUI.EndChangeCheck() && newHandSide != m_HandSide)
            {
                ApplyHandSideDefaults(m_HandSide, newHandSide);
                m_HandSide = newHandSide;
                m_CurrentStep = 1;
                m_Mode1Step = 1;
                m_Mode2Step = 1;
                m_LastResultSummary = null;
                m_LastSavedAssetPath = null;
                m_LastPlaybackSetupSummary = null;
            }

            DrawHandSideContextBox();
            EditorGUILayout.Space(4f);
            DrawStepNavigationBar();
            EditorGUILayout.Space(2f);
            DrawStepNavigationButtons();
        }

        void DrawStepNavigationBar()
        {
            var labels = m_WorkMode == WorkMode.Mode1_Animation ? Mode1StepNavLabels : Mode2StepNavLabels;
            var currentStep = m_WorkMode == WorkMode.Mode1_Animation ? m_Mode1Step : m_Mode2Step;

            EditorGUILayout.BeginHorizontal();
            for (var i = 0; i < labels.Length; i++)
            {
                var step = i + 1;
                if (i > 0)
                    GUILayout.Label("→", GUILayout.Width(14f));

                var isCurrent = currentStep == step;
                var isComplete = IsStepCompleteForMode(step);
                var displayLabel = isComplete ? $"✓ {labels[i]}" : labels[i];

                var prevBg = GUI.backgroundColor;
                if (isCurrent)
                    GUI.backgroundColor = new Color(0.45f, 0.72f, 1f);

                if (GUILayout.Button(displayLabel, EditorStyles.miniButton))
                {
                    if (m_WorkMode == WorkMode.Mode1_Animation) m_Mode1Step = step;
                    else m_Mode2Step = step;
                }

                GUI.backgroundColor = prevBg;
            }
            EditorGUILayout.EndHorizontal();
        }

        // Legacy nav button — kept for backward compat with DrawStep* helpers that may be called directly
        void DrawStepNavButton(int step, string label)
        {
            var isCurrent = m_CurrentStep == step;
            var isComplete = IsStepComplete(step);
            var displayLabel = isComplete ? $"✓ {label}" : label;

            var previousColor = GUI.backgroundColor;
            if (isCurrent)
                GUI.backgroundColor = new Color(0.45f, 0.72f, 1f);

            if (GUILayout.Button(displayLabel, EditorStyles.miniButton))
                m_CurrentStep = step;

            GUI.backgroundColor = previousColor;
        }

        void DrawStepNavigationButtons()
        {
            var labels = m_WorkMode == WorkMode.Mode1_Animation ? Mode1StepNavLabels : Mode2StepNavLabels;
            var currentStep = m_WorkMode == WorkMode.Mode1_Animation ? m_Mode1Step : m_Mode2Step;
            var stepCount = labels.Length;

            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(currentStep <= 1))
            {
                if (GUILayout.Button("◀ 이전", GUILayout.Width(72f)))
                {
                    if (m_WorkMode == WorkMode.Mode1_Animation) m_Mode1Step--;
                    else m_Mode2Step--;
                }
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField(
                $"{currentStep} / {stepCount} · {labels[currentStep - 1]}",
                EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();

            using (new EditorGUI.DisabledScope(currentStep >= stepCount))
            {
                if (GUILayout.Button("다음 ▶", GUILayout.Width(72f)))
                {
                    if (m_WorkMode == WorkMode.Mode1_Animation) m_Mode1Step++;
                    else m_Mode2Step++;
                }
            }

            EditorGUILayout.EndHorizontal();
        }

        void DrawStep1HandPreparation()
        {
            EditorGUILayout.LabelField("1단계: 손 준비", EditorStyles.boldLabel);
            DrawPlaybackHandMinimalSetupSection(foldDetails: true);
            EditorGUILayout.Space(6f);
            DrawStep1PlaybackHandAndGripFields();
            EditorGUILayout.Space(6f);
            DrawStep1ReadinessSummary();

            if (IsStep1Complete())
            {
                EditorGUILayout.Space(6f);
                EditorGUILayout.HelpBox("손 준비 완료", MessageType.Info);
                if (GUILayout.Button("다음: 포즈 캡처"))
                {
                    m_CurrentStep = 2;
                }
            }
        }

        void DrawStep1PlaybackHandAndGripFields()
        {
            EditorGUI.BeginChangeCheck();
            m_PlaybackHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Playback Hand Root",
                m_PlaybackHandRoot,
                typeof(Transform),
                true);
            m_GripInputAction = (InputActionReference)EditorGUILayout.ObjectField(
                "Grip Input Action",
                m_GripInputAction,
                typeof(InputActionReference),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastControllerSetupSummary = null;
                CapturePlaybackHandLocatorIfPossible();
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button($"현재 씬 {HandSideUtility.GetLabel(m_HandSide)} Playback Hand 찾기"))
            {
                TryFindPlaybackHand();
            }

            if (GUILayout.Button("Use Selection as Playback Hand") && Selection.activeTransform != null)
            {
                SetPlaybackHandRoot(Selection.activeTransform);
            }
            EditorGUILayout.EndHorizontal();

            DrawPlaybackHandCandidates();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("선택 손 Grip 자동 찾기"))
            {
                AutoFindGrip();
            }
            EditorGUILayout.EndHorizontal();

            DrawGripCandidateSelection(showSummaryInFoldout: false);
        }

        void DrawStep1ReadinessSummary()
        {
            EditorGUILayout.LabelField("준비 상태 요약", EditorStyles.boldLabel);

            var skeletonValid = false;
            var boneCount = 0;
            var hasSkinnedMesh = false;
            string skeletonFailReason = null;

            if (m_PlaybackHandRoot != null)
            {
                var validation = HandSkeletonCatalog.Validate(m_PlaybackHandRoot, m_HandSide);
                skeletonValid = validation.isValid;
                boneCount = validation.foundBoneCount;
                hasSkinnedMesh =
                    m_PlaybackHandRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;

                if (!skeletonValid)
                {
                    // Provide specific failure reason
                    if (HandSideUtility.ContainsOppositeHandBonePrefix(m_PlaybackHandRoot.name, m_HandSide))
                        skeletonFailReason = $"반대 손 Root가 선택됨 ({m_PlaybackHandRoot.name})";
                    else if (!HandSideUtility.MatchesHandSide(m_PlaybackHandRoot, m_HandSide))
                        skeletonFailReason = $"선택한 손({HandSideUtility.GetLabel(m_HandSide)})과 이름 불일치";
                    else if (boneCount == 0)
                        skeletonFailReason = "Play Mode에서 생성되는 손이 아직 없음 — Play를 시작하세요";
                    else if (boneCount < HandSkeletonCatalog.RequiredBoneCount)
                        skeletonFailReason = $"필요한 본이 부족함 ({boneCount}/{HandSkeletonCatalog.RequiredBoneCount})";
                    else if (!hasSkinnedMesh)
                        skeletonFailReason = "SkinnedMeshRenderer가 없음";
                    else
                        skeletonFailReason = validation.summary;
                }
            }

            EditorGUILayout.LabelField(
                "Playback Hand Root",
                m_PlaybackHandRoot != null ? $"{m_PlaybackHandRoot.name}" : "(없음)");
            EditorGUILayout.LabelField(
                "본 검증",
                m_PlaybackHandRoot != null
                    ? $"{boneCount} / {HandSkeletonCatalog.RequiredBoneCount} {(skeletonValid ? "(OK)" : "(FAIL)")}"
                    : "(none)");
            if (!skeletonValid && skeletonFailReason != null)
            {
                EditorGUILayout.HelpBox(skeletonFailReason, MessageType.Warning);
            }
            EditorGUILayout.LabelField(
                "SkinnedMeshRenderer",
                hasSkinnedMesh ? "있음" : "없음");
            EditorGUILayout.LabelField(
                "Grip Input Action",
                m_GripInputAction != null ? $"{m_GripInputAction.name}" : "(없음)");
        }

        void DrawStep2PoseCapture()
        {
            EditorGUILayout.LabelField("2단계: Grab Pose 캡처", EditorStyles.boldLabel);

            // ── 현재 컨텍스트 요약 ──
            DrawStep2ContextSummary();
            EditorGUILayout.Space(4f);

            // ── 메인: Hand Tracking 손 모양 캡처 ──
            EditorGUILayout.LabelField("Hand Tracking 손 모양 캡처", EditorStyles.miniBoldLabel);
            DrawHandTrackingCaptureSectionMain();

            EditorGUILayout.Space(6f);

            // ── 고급: Controller 기반 캡처 ──
            m_FoldStep2ControllerCapture = EditorGUILayout.Foldout(
                m_FoldStep2ControllerCapture,
                "고급: Controller 기반 캡처");
            if (m_FoldStep2ControllerCapture)
            {
                EditorGUI.indentLevel++;
                DrawControllerGrabPoseCaptureSection();
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space(4f);

            // ── 고급: XRHandPoseAsset 캡처 (애니메이션 클립용) ──
            m_FoldStep2CaptureDiagnostic = EditorGUILayout.Foldout(
                m_FoldStep2CaptureDiagnostic,
                "고급: XRHandPoseAsset 캡처 (애니메이션 클립 생성용)");
            if (m_FoldStep2CaptureDiagnostic)
            {
                DrawXRHandPoseAssetCaptureSection();
            }

            EditorGUILayout.Space(6f);
            DrawLastResultSection();
        }

        void DrawStep2ContextSummary()
        {
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var trackingLabel = m_TrackingHandRoot != null
                ? m_TrackingHandRoot.name
                : "(없음 — 아래에서 자동 탐색)";
            var sb = new StringBuilder();
            sb.Append($"Hand: {sideLabel}  |  Tracking Root: {trackingLabel}");
            EditorGUILayout.HelpBox(sb.ToString(), MessageType.None);
        }

        void DrawHandTrackingCaptureSectionMain()
        {
            EditorGUILayout.HelpBox(
                "실제 손으로 원하는 잡기 모양을 만든 뒤 현재 손 모양을 저장하세요.\n" +
                "XRHandSkeletonDriver가 구동하는 Tracking Hand의 본 Pose를 HandGrabPoseRecord로 저장합니다.\n" +
                "Play 종료 후 Target에 Attach·Binding이 자동 적용됩니다.",
                MessageType.Info);

            // Target Grab Object
            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabPoseRecordSummary = null;
                m_LastGrabPoseRecordPath = null;
            }

            // Tracking Hand Root (읽기 전용 + 수동 지정 필드)
            EditorGUI.BeginChangeCheck();
            m_TrackingHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Tracking Hand Root",
                m_TrackingHandRoot,
                typeof(Transform),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_Step2AutoSearchDone = false;
                m_LastGrabPoseRecordSummary = null;
            }

            // 자동 탐색 버튼
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Tracking Hand 자동 탐색", GUILayout.Height(22f)))
            {
                m_Step2AutoSearchDone = false;
                TryAutoFindTrackingHandForStep2();
            }
            EditorGUILayout.EndHorizontal();

            // Play Mode 진입 시 자동 탐색 (1회)
            if (EditorApplication.isPlaying && !m_Step2AutoSearchDone && m_TrackingHandRoot == null)
                TryAutoFindTrackingHandForStep2();

            DrawTrackedHandCandidates();

            // 상태 표시
            var trackingReadiness = HandGrabPoseCaptureService.EvaluateTrackingReadiness(
                m_HandSide,
                m_TrackingHandRoot,
                m_GhostTargetGrabObject);

            using (new EditorGUI.IndentLevelScope(1))
            {
                EditorGUILayout.LabelField(
                    "XR Hand Subsystem",
                    trackingReadiness.subsystemRunning ? "실행 중" : "없음");
                EditorGUILayout.LabelField(
                    $"{HandSideUtility.GetLabel(m_HandSide)} 손 추적",
                    trackingReadiness.handTracked ? "Yes" : "No");
                EditorGUILayout.LabelField(
                    "Tracking Hand Root",
                    m_TrackingHandRoot != null
                        ? HandPoseCaptureService.GetHierarchyPath(m_TrackingHandRoot)
                        : "(없음)");
                EditorGUILayout.LabelField(
                    "연결된 본",
                    trackingReadiness.boneCount > 0
                        ? $"{trackingReadiness.boneCount}개"
                        : "(unknown)");
            }

            if (!trackingReadiness.canCapture
                && trackingReadiness.blockers != null
                && trackingReadiness.blockers.Count > 0)
            {
                var blockerSb = new StringBuilder();
                foreach (var blocker in trackingReadiness.blockers)
                    blockerSb.AppendLine("• " + blocker);
                EditorGUILayout.HelpBox(blockerSb.ToString().TrimEnd(), MessageType.Warning);
            }

            if (trackingReadiness.warnings != null && trackingReadiness.warnings.Count > 0)
            {
                var warnSb = new StringBuilder();
                foreach (var w in trackingReadiness.warnings) warnSb.AppendLine("• " + w);
                EditorGUILayout.HelpBox(warnSb.ToString().TrimEnd(), MessageType.Warning);
            }

            using (new EditorGUI.DisabledScope(!trackingReadiness.canCapture))
            {
                if (GUILayout.Button("현재 Hand Tracking Pose 저장", GUILayout.Height(28f)))
                    CaptureGrabPoseRecordFromTracking();
            }

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordPath))
                EditorGUILayout.LabelField("저장 경로", m_LastGrabPoseRecordPath);

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordSummary))
                EditorGUILayout.HelpBox(m_LastGrabPoseRecordSummary, m_LastGrabPoseRecordMessageType);

            DrawPendingApplySection();
        }

        void TryAutoFindTrackingHandForStep2()
        {
            m_Step2AutoSearchDone = true;
            if (!EditorApplication.isPlaying)
                return;

            var findResult = HandPoseTrackedHandFinder.FindTrackedHand(m_HandSide);
            if (findResult.success)
            {
                m_TrackingHandRoot = findResult.handRoot;
                m_PendingTrackedCandidates = null;
                Repaint();
            }
            else if (findResult.candidates != null && findResult.candidates.Count > 1)
            {
                m_PendingTrackedCandidates = findResult.candidates;
                Repaint();
            }
            // 후보 없으면 사용자가 수동 지정하도록 조용히 유지
        }

        void CaptureGrabPoseRecordFromTracking()
        {
            var result = HandGrabPoseCaptureService.CaptureAndSaveFromTrackingHand(
                m_HandSide,
                m_TrackingHandRoot,
                m_GhostTargetGrabObject);

            if (result.success)
            {
                m_LastGrabPoseRecordPath = result.saveResult.assetPath;
                m_LastGrabPoseRecordMessageType =
                    result.pendingApplyRegistered || string.IsNullOrEmpty(result.pendingApplyMessage)
                        ? MessageType.Info
                        : MessageType.Warning;
                m_LastGrabPoseRecordSummary = result.message;
                Debug.Log($"[HandTrackingCapture] {result.message}");
            }
            else
            {
                m_LastGrabPoseRecordPath = null;
                m_LastGrabPoseRecordMessageType = MessageType.Error;
                var sb = new StringBuilder();
                sb.AppendLine(result.message);
                foreach (var error in result.errors)
                    sb.AppendLine("• " + error);
                m_LastGrabPoseRecordSummary = sb.ToString().TrimEnd();
                Debug.LogError($"[HandTrackingCapture] {m_LastGrabPoseRecordSummary}");
            }

            Repaint();
        }

        void DrawStep1ContextSummary()
        {
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var sb = new StringBuilder();
            sb.Append($"Hand: {sideLabel}  |  ");
            sb.Append(m_PlaybackHandRoot != null
                ? $"Root: {m_PlaybackHandRoot.name}"
                : "Root: (없음 — 1단계에서 지정)");
            sb.Append("  |  ");
            sb.Append(m_GripInputAction != null
                ? $"Grip: {m_GripInputAction.name}"
                : "Grip: (없음)");
            EditorGUILayout.HelpBox(sb.ToString(), MessageType.None);
        }

        void DrawControllerGrabPoseCaptureSection()
        {
            EditorGUILayout.HelpBox(
                "Play Mode에서 손 모델의 손가락을 원하는 모양으로 조정한 뒤 현재 손 모양을 저장하세요.\n" +
                "물체를 실제로 잡고 있지 않아도 캡처할 수 있습니다.\n" +
                "Play 종료 후 Target에 Attach·Binding이 자동 적용됩니다.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabPoseRecordSummary = null;
                m_LastGrabPoseRecordPath = null;
            }

            // 1단계에서 지정한 Playback Hand Root (읽기 전용)
            EditorGUILayout.LabelField(
                "Playback Hand Root",
                m_PlaybackHandRoot != null
                    ? HandPoseCaptureService.GetHierarchyPath(m_PlaybackHandRoot)
                    : "(없음 — 1단계에서 지정)");

            // 캡처 가능 조건: Play Mode + playbackHandRoot + 26본 + Target
            var grabReadiness = HandGrabPoseCaptureService.EvaluateReadiness(
                m_HandSide,
                m_PlaybackHandRoot,
                m_GhostTargetGrabObject);

            EditorGUILayout.LabelField("Play Mode", grabReadiness.isPlaying ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Bone 수",
                grabReadiness.playbackHandRoot != null
                    ? $"{grabReadiness.boneCount} / {grabReadiness.expectedBoneCount}"
                    : "(unknown)");

            if (!grabReadiness.canCapture && grabReadiness.blockers != null && grabReadiness.blockers.Count > 0)
            {
                var blockerSb = new StringBuilder();
                foreach (var blocker in grabReadiness.blockers)
                    blockerSb.AppendLine("• " + blocker);
                EditorGUILayout.HelpBox(blockerSb.ToString().TrimEnd(), MessageType.Info);
            }

            if (grabReadiness.warnings != null && grabReadiness.warnings.Count > 0)
            {
                var warnSb = new StringBuilder();
                foreach (var w in grabReadiness.warnings) warnSb.AppendLine("• " + w);
                EditorGUILayout.HelpBox(warnSb.ToString().TrimEnd(), MessageType.Warning);
            }

            using (new EditorGUI.DisabledScope(!grabReadiness.canCapture))
            {
                if (GUILayout.Button("현재 손 모양 저장", GUILayout.Height(26f)))
                    CaptureGrabPoseRecord();
            }

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordPath))
                EditorGUILayout.LabelField("저장 경로", m_LastGrabPoseRecordPath);

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordSummary))
                EditorGUILayout.HelpBox(m_LastGrabPoseRecordSummary, m_LastGrabPoseRecordMessageType);

            DrawPendingApplySection();
        }

        void DrawXRHandPoseAssetCaptureSection()
        {
            EditorGUILayout.HelpBox(
                "XR Hand Tracking이 연결된 경우 Tracking Hand Root를 사용해 XRHandPoseAsset을 캡처합니다.\n" +
                "3단계 AnimationClip 생성에 필요합니다. Controller 기반 시험에서는 사용하지 않아도 됩니다.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            m_TrackingHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Tracking Hand Root",
                m_TrackingHandRoot,
                typeof(Transform),
                true);
            m_TargetTransform = (Transform)EditorGUILayout.ObjectField(
                "Target Transform",
                m_TargetTransform,
                typeof(Transform),
                true);
            m_PoseName = EditorGUILayout.TextField("Pose Name", m_PoseName);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastResultSummary = null;
                m_LastSavedAssetPath = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Find Tracked Hand (Play)"))
                FindTrackedHand();
            if (GUILayout.Button("Use Selection as Hand Root") && Selection.activeTransform != null)
                m_TrackingHandRoot = Selection.activeTransform;
            EditorGUILayout.EndHorizontal();

            DrawTrackedHandCandidates();

            var readiness = HandPoseCaptureService.EvaluateReadiness(
                m_TrackingHandRoot,
                m_TargetTransform,
                m_HandSide);

            DrawCaptureButtons(readiness);
            DrawCaptureReadinessSummary(readiness);
        }

        void DrawCaptureReadinessSummary(HandPoseCaptureService.Readiness readiness)
        {
            EditorGUILayout.LabelField("Play Mode", readiness.isPlaying ? "Yes" : "No");
            EditorGUILayout.LabelField(
                $"{HandSideUtility.GetLabel(m_HandSide)} Hand tracked",
                readiness.handTracked ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Bone 수",
                $"{readiness.boneCount} / {readiness.expectedBoneCount}");
            EditorGUILayout.LabelField(
                "캡처 가능",
                readiness.canCapture ? "Yes" : "No");

            if (readiness.blockers != null && readiness.blockers.Count > 0)
            {
                var sb = new StringBuilder();
                foreach (var blocker in readiness.blockers)
                {
                    sb.Append("• ");
                    sb.AppendLine(blocker);
                }

                EditorGUILayout.HelpBox(sb.ToString().TrimEnd(), MessageType.Warning);
            }
        }

        void DrawStep3Animation()
        {
            EditorGUILayout.LabelField("3단계: 애니메이션 만들기", EditorStyles.boldLabel);

            // Quick-connect 섹션: 기존 AnimatorController 자동 탐색·연결
            DrawQuickControllerSetupSection();

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("고급: AnimationClip 기반 Controller 생성", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();
            m_CapturedOpenPoseAsset = (XRHandPoseAsset)EditorGUILayout.ObjectField(
                "Captured Open Pose Asset",
                m_CapturedOpenPoseAsset,
                typeof(XRHandPoseAsset),
                false);
            m_CapturedGrabPoseAsset = (XRHandPoseAsset)EditorGUILayout.ObjectField(
                "Captured Grab Pose Asset",
                m_CapturedGrabPoseAsset,
                typeof(XRHandPoseAsset),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastResultSummary = null;
                m_LastSavedAssetPath = null;
            }

            EditorGUILayout.Space(4f);
            DrawExportButtons(foldHelp: true);

            EditorGUI.BeginChangeCheck();
            m_AnimatorController = (RuntimeAnimatorController)EditorGUILayout.ObjectField(
                "Animator Controller",
                m_AnimatorController,
                typeof(RuntimeAnimatorController),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastControllerSetupSummary = null;
            }

            EditorGUILayout.Space(6f);
            DrawAnimationClipDiagnosticSection(foldDetails: true);
            EditorGUILayout.Space(4f);
            DrawAnimatorControllerSetupSection();
            EditorGUILayout.Space(6f);
            DrawLastResultSection();
        }

        void DrawQuickControllerSetupSection()
        {
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);

            // 현재 연결 상태 표시
            var animator = m_PlaybackHandRoot != null
                ? m_PlaybackHandRoot.GetComponent<Animator>()
                : null;
            var currentCtrl = animator != null ? animator.runtimeAnimatorController : null;

            if (currentCtrl != null)
            {
                EditorGUILayout.HelpBox(
                    $"현재 Animator Controller: {currentCtrl.name}\n경로: {AssetDatabase.GetAssetPath(currentCtrl)}",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    $"{sideLabel}손 Animator에 Controller가 연결되지 않았습니다.\n" +
                    "아래 버튼으로 프로젝트의 기존 Open/Grip Controller를 자동으로 탐색하고 연결합니다.",
                    MessageType.Warning);
            }

            using (new EditorGUI.DisabledScope(m_PlaybackHandRoot == null))
            {
                if (GUILayout.Button($"선택한 손 Controller 애니메이션 자동 설정 ({sideLabel})"))
                    QuickSetupControllerAnimation();
            }

            if (m_PlaybackHandRoot == null)
            {
                EditorGUILayout.HelpBox(
                    "Playback Hand Root가 지정되지 않았습니다. 4단계의 Controller Hand Root 탐색을 먼저 실행하세요.",
                    MessageType.Info);
            }
        }

        void QuickSetupControllerAnimation()
        {
            var result = HandAnimatorControllerSetupService.QuickConnectExistingController(
                m_HandSide,
                m_PlaybackHandRoot);

            if (!result.success)
            {
                m_LastControllerSetupMessageType = MessageType.Warning;
                m_LastControllerSetupSummary = result.message;
                Repaint();
                return;
            }

            m_LastControllerSetupMessageType = MessageType.Info;
            m_LastControllerSetupSummary =
                $"✓ {result.message}\n" +
                $"Animator: {result.animatorStatus}\n" +
                $"Grip Parameter: {result.gripParameterStatus}\n" +
                $"Grip Driver: {result.gripDriverStatus}";
            Repaint();
        }

        void DrawAnimatorControllerSetupSection()
        {
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var canSetup = HandAnimatorControllerSetupService.CanSetup(
                m_HandSide,
                m_PlaybackHandRoot,
                m_OpenAnimationClip,
                m_GrabAnimationClip,
                out var setupBlocker);

            using (new EditorGUI.DisabledScope(!canSetup))
            {
                if (GUILayout.Button($"{sideLabel}손 Animator Controller 만들기/연결"))
                    SetupAnimatorController();
            }

            if (!canSetup && !string.IsNullOrEmpty(setupBlocker))
            {
                EditorGUILayout.HelpBox(setupBlocker, MessageType.Info);
            }
        }

        void SetupAnimatorController()
        {
            var result = HandAnimatorControllerSetupService.CreateOrConnect(
                m_HandSide,
                m_PlaybackHandRoot,
                m_OpenAnimationClip,
                m_GrabAnimationClip);

            if (!result.success)
            {
                m_LastResultMessageType = MessageType.Error;
                m_LastResultSummary = result.message;
                return;
            }

            m_AnimatorController = result.controller;
            m_LastSavedAssetPath = result.controllerPath;
            m_LastResultMessageType = MessageType.Info;
            m_LastResultSummary = result.summary;
            Repaint();
        }

        void DrawStep4GrabSetup()
        {
            EditorGUILayout.LabelField("4단계: 잡기 설정", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "런타임 Grip 애니메이션(Open↔Grab) 설정입니다. Grab Snapshot·고스트와는 별개이며 Grip Input Action은 애니메이션 전용입니다.",
                MessageType.Info);
            DrawControllerHandSetupSection(foldDetails: true);
            EditorGUILayout.Space(6f);
            DrawHandSideAttachRuntimeSection(showWristAttachRecalculate: false);
        }

        void DrawHandSideAttachRuntimeSection(bool showWristAttachRecalculate = false)
        {
            EditorGUILayout.LabelField("손별 Attach 런타임 적용", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "HandGrabPoseBinding의 손별 Attach Transform을 XRI Grab 계산에 사용하려면 " +
                "XRGrabInteractable을 HandSideAwareGrabInteractable로 전환하세요.\n" +
                "HandInteractorSide Marker는 Grab 시 Left/Right Attach 선택을 안정화합니다.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabMigrationSummary = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Use Selection as Target Grab Object")
                && HandGhostPreviewService.TryResolveSelectionGrabTarget() != null)
            {
                m_GhostTargetGrabObject = HandGhostPreviewService.TryResolveSelectionGrabTarget();
            }

            EditorGUILayout.EndHorizontal();

            var migrationReadiness = HandSideAwareGrabInteractableMigrationService.EvaluateReadiness(
                m_GhostTargetGrabObject);

            EditorGUILayout.LabelField(
                "Target",
                m_GhostTargetGrabObject != null ? m_GhostTargetGrabObject.name : "(none)");
            EditorGUILayout.LabelField("Grab Interactable Type", migrationReadiness.grabTypeName);
            EditorGUILayout.LabelField(
                "HandGrabPoseBinding",
                migrationReadiness.binding != null ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Left Record / Attach",
                FormatHandSlotState(migrationReadiness.binding, HandSide.Left, migrationReadiness.hasLeftSlot));
            EditorGUILayout.LabelField(
                "Right Record / Attach",
                FormatHandSlotState(migrationReadiness.binding, HandSide.Right, migrationReadiness.hasRightSlot));
            EditorGUILayout.LabelField(
                "Dynamic Attach",
                migrationReadiness.existingGrab != null
                    ? migrationReadiness.useDynamicAttach ? "true (전환 불가)" : "false"
                    : "(unknown)");

            // ── Interactor 지정 ──
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("Interactor 지정", EditorStyles.miniBoldLabel);

            // Hierarchy Selection에서 XRBaseInteractor 감지
            var selGo = Selection.activeGameObject;
            var selInteractor = selGo != null ? selGo.GetComponent<XRBaseInteractor>() : null;
            bool selSideMismatch = false;
            if (selInteractor != null)
            {
                var existingHis = selGo.GetComponentInParent<HandInteractorSide>(true);
                if (existingHis != null && existingHis.HandSide != m_HandSide)
                    selSideMismatch = true;
            }

            // Editable ObjectField — Drag-drop 또는 직접 지정 가능
            EditorGUI.BeginChangeCheck();
            var newCandidate = (Component)EditorGUILayout.ObjectField(
                "Interactor Candidate",
                m_InteractorCandidate,
                typeof(Component),
                true);
            if (EditorGUI.EndChangeCheck())
                m_InteractorCandidate = newCandidate;

            // 선택/탐색 버튼 행
            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(selInteractor == null || selSideMismatch))
            {
                if (GUILayout.Button("현재 선택한 Interactor 사용"))
                {
                    m_InteractorCandidate = selInteractor;
                    Repaint();
                }
            }
            if (GUILayout.Button("Interactor 후보 자동 탐색"))
                RefreshInteractorCandidates();
            EditorGUILayout.EndHorizontal();

            // Selection 상태 피드백
            if (selGo != null && selInteractor == null)
                EditorGUILayout.HelpBox(
                    $"선택된 '{selGo.name}'에 XRBaseInteractor 컴포넌트가 없습니다.",
                    MessageType.Info);
            else if (selSideMismatch && selGo != null)
                EditorGUILayout.HelpBox(
                    $"'{selGo.name}'의 HandInteractorSide가 현재 HandSide " +
                    $"({HandSideUtility.GetLabel(m_HandSide)})와 다릅니다.",
                    MessageType.Warning);

            // ── Interactor HandSide Marker 상태 ──
            EditorGUILayout.Space(4f);
            var interactor = m_InteractorCandidate as XRBaseInteractor;
            EditorGUILayout.LabelField(
                "Interactor HandSide Marker",
                HandInteractorSideSetupService.DescribeMarkerState(
                    interactor != null ? interactor.transform : null,
                    m_HandSide));

            if (migrationReadiness.existingHandSideAware != null)
            {
                EditorGUILayout.HelpBox("HandSideAwareGrabInteractable 적용됨", MessageType.Info);
            }
            else if (migrationReadiness.blockers != null && migrationReadiness.blockers.Count > 0)
            {
                var blockerSb = new StringBuilder();
                foreach (var blocker in migrationReadiness.blockers)
                    blockerSb.AppendLine("• " + blocker);
                EditorGUILayout.HelpBox(blockerSb.ToString().TrimEnd(), MessageType.Info);
            }

            var canMigrate = migrationReadiness.canMigrate;
            var markerReadiness = HandInteractorSideSetupService
                .EvaluateReadiness(interactor != null ? interactor.transform : null, m_HandSide);
            var canAddMarker = markerReadiness.canApply;

            using (new EditorGUI.DisabledScope(!canMigrate))
            {
                if (GUILayout.Button("손별 Grab Interactable로 전환"))
                    ApplyHandSideGrabInteractableMigration();
            }

            using (new EditorGUI.DisabledScope(!canAddMarker))
            {
                if (GUILayout.Button("선택 Interactor에 HandSide 표시 추가"))
                    ApplyHandInteractorSideMarker();
            }

            // 버튼이 비활성화된 이유 표시
            if (!canAddMarker && interactor != null && !string.IsNullOrEmpty(markerReadiness.blocker))
                EditorGUILayout.HelpBox(
                    $"HandSide 표시 추가 불가: {markerReadiness.blocker}",
                    MessageType.Warning);
            else if (!canAddMarker && interactor == null)
                EditorGUILayout.HelpBox(
                    "Interactor Candidate를 지정하거나 Hierarchy에서 Interactor를 선택 후 " +
                    "'현재 선택한 Interactor 사용' 버튼을 누르세요.",
                    MessageType.Warning);

            if (showWristAttachRecalculate)
                DrawWristAttachRecalculateSection();

            if (!string.IsNullOrEmpty(m_LastGrabMigrationSummary))
                EditorGUILayout.HelpBox(m_LastGrabMigrationSummary, m_LastGrabMigrationMessageType);

            if (!string.IsNullOrEmpty(m_LastInteractorSideSummary))
                EditorGUILayout.HelpBox(m_LastInteractorSideSummary, m_LastInteractorSideMessageType);
        }

        static string FormatHandSlotState(
            HandGrabPoseBinding binding,
            HandSide handSide,
            bool hasCompleteSlot)
        {
            if (binding == null)
                return "(no binding)";

            binding.TryGetRecord(handSide, out var record);
            binding.TryGetAttachTransform(handSide, out var attach);

            var recordLabel = record != null ? record.name : "(none)";
            var attachLabel = attach != null ? attach.name : "(none)";
            var status = hasCompleteSlot ? "ready" : "incomplete";
            return $"{recordLabel} / {attachLabel} ({status})";
        }

        void ApplyHandSideGrabInteractableMigration()
        {
            var result = HandSideAwareGrabInteractableMigrationService.TryMigrate(m_GhostTargetGrabObject);
            m_LastGrabMigrationMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastGrabMigrationSummary = result.message;

            if (result.success)
                Debug.Log($"[HandGrabMigration] {result.message}", result.migratedComponent);
            else
                Debug.LogError($"[HandGrabMigration] {result.message}");

            Repaint();
        }

        void ApplyHandInteractorSideMarker()
        {
            var interactor = m_InteractorCandidate as XRBaseInteractor;
            var result = HandInteractorSideSetupService.TryAddHandInteractorSide(
                interactor != null ? interactor.transform : null,
                m_HandSide);

            m_LastInteractorSideMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastInteractorSideSummary = result.message;

            if (result.success)
                Debug.Log($"[HandInteractorSide] {result.message}", result.marker);
            else
                Debug.LogError($"[HandInteractorSide] {result.message}");

            Repaint();
        }

        void DrawStep5GhostPreview()
        {
            EditorGUILayout.LabelField("5단계: 고스트", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "2단계에서 저장한 HandGrabPoseRecord를 사용해 고스트를 생성합니다.\n" +
                "Record가 없으면 Grab Snapshot 기반 고스트도 사용할 수 있습니다.",
                MessageType.Info);

            // Step 1 context
            DrawStep1ContextSummary();

            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("Record 기반 고스트 (권장)", EditorStyles.miniBoldLabel);
            DrawRecordBasedGhostSection();

            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("Grab Snapshot 내보내기", EditorStyles.miniBoldLabel);
            DrawGrabSnapshotExportSection(foldHelp: true);
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("Snapshot 기반 고스트 (레거시)", EditorStyles.miniBoldLabel);
            DrawGhostPreviewSection(foldHelp: true);
        }

        void DrawRecordBasedGhostSection()
        {
            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGhostPreviewSummary = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Selection 사용")
                && HandGhostPreviewService.TryResolveSelectionGrabTarget() != null)
            {
                m_GhostTargetGrabObject = HandGhostPreviewService.TryResolveSelectionGrabTarget();
            }
            EditorGUILayout.EndHorizontal();

            // Display current Record from Binding
            HandGrabPoseRecord recordForGhost = null;
            var binding = m_GhostTargetGrabObject != null
                ? m_GhostTargetGrabObject.GetComponent<HandGrabPoseBinding>()
                : null;

            if (binding != null)
            {
                binding.TryGetRecord(m_HandSide, out recordForGhost);
                var attachState = binding.TryGetAttachTransform(m_HandSide, out var attachT)
                    ? attachT.name
                    : "(없음)";
                EditorGUILayout.LabelField("Record", recordForGhost != null ? recordForGhost.name : "(없음)");
                EditorGUILayout.LabelField("Attach", attachState);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "Target에 HandGrabPoseBinding이 없습니다. 2단계에서 캡처하거나 4단계에서 직접 설정하세요.",
                    MessageType.Info);
            }

            m_GhostBaseAlpha = EditorGUILayout.Slider("Ghost Base Alpha", m_GhostBaseAlpha, 0.03f, 0.08f);
            m_GhostRimColor = EditorGUILayout.ColorField("Ghost Rim Color", m_GhostRimColor);
            m_GhostRimIntensity = EditorGUILayout.Slider("Ghost Rim Intensity", m_GhostRimIntensity, 1.5f, 3f);
            m_GhostPulseSpeed = EditorGUILayout.Slider("Ghost Pulse Speed", m_GhostPulseSpeed, 0.5f, 2f);

            var canCreateFromRecord = !Application.isPlaying
                && m_GhostTargetGrabObject != null
                && m_PlaybackHandRoot != null
                && recordForGhost != null;

            using (new EditorGUI.DisabledScope(!canCreateFromRecord))
            {
                if (GUILayout.Button("Record 기반 고스트 생성"))
                    CreateOrUpdateGhostFromRecord(recordForGhost);
            }

            if (!canCreateFromRecord && m_GhostTargetGrabObject != null)
            {
                if (Application.isPlaying)
                    EditorGUILayout.HelpBox("Play Mode 종료 후 생성하세요.", MessageType.Info);
                else if (m_PlaybackHandRoot == null)
                    EditorGUILayout.HelpBox("1단계에서 Playback Hand Root를 지정하세요.", MessageType.Info);
                else if (recordForGhost == null)
                    EditorGUILayout.HelpBox("2단계에서 Grab Pose Record를 먼저 캡처하세요.", MessageType.Info);
            }

            using (new EditorGUI.DisabledScope(m_GhostTargetGrabObject == null || Application.isPlaying))
            {
                if (GUILayout.Button("고스트 제거"))
                    RemoveGhostPreview();
            }

            if (!string.IsNullOrEmpty(m_LastGhostPreviewSummary))
            {
                EditorGUILayout.HelpBox(m_LastGhostPreviewSummary, m_LastGhostPreviewMessageType);
            }
        }

        void CreateOrUpdateGhostFromRecord(HandGrabPoseRecord record)
        {
            if (Application.isPlaying)
            {
                m_LastGhostPreviewMessageType = MessageType.Warning;
                m_LastGhostPreviewSummary = "고스트는 Play Mode를 종료한 뒤 생성하세요.";
                return;
            }

            try
            {
                var result = HandGhostPreviewService.CreateOrUpdateGhostFromRecord(
                    m_GhostTargetGrabObject,
                    m_PlaybackHandRoot,
                    record,
                    BuildGhostAppearanceSettings(),
                    m_HandSide);

                m_LastGhostPreviewMessageType = result.success ? MessageType.Info : MessageType.Error;
                m_LastGhostPreviewSummary = result.success ? result.summary : result.message;

                if (result.success)
                {
                    Debug.Log(
                        $"[HandGhostPreview] Record 기반 {(result.wasUpdated ? "Update" : "Create")} OK · " +
                        $"target={result.targetGrabObject.name} · bones={result.appliedBoneCount}",
                        result.ghostRoot);
                }
                else
                {
                    Debug.LogError($"[HandGhostPreview] Record 기반 실패: {result.message}");
                }
            }
            catch (Exception ex)
            {
                m_LastGhostPreviewMessageType = MessageType.Error;
                m_LastGhostPreviewSummary = ex.Message;
                Debug.LogException(ex);
            }
        }

        bool IsStep1Complete()
        {
            RefreshFullPrepChecklist();
            if (m_FullPrepChecklist.isComplete)
                return true;

            // 수동 경로 호환: Tracking이 없어도 Playback+Grip만으로 기존 완료를 허용하지 않음.
            // 전체 준비 체크리스트의 핵심 조건이 모두 맞아야 완료.
            return false;
        }

        bool IsStepComplete(int step)
        {
            switch (step)
            {
                case 1:
                    return IsStep1Complete();
                case 2:
                    // Complete if a Grab Pose Record was captured this session OR XRHandPoseAssets are ready
                    return !string.IsNullOrEmpty(m_LastGrabPoseRecordPath)
                        || HandGrabPosePendingApplyBridge.LastApplySucceeded
                        || (IsExportReady(m_CapturedOpenPoseAsset) && IsExportReady(m_CapturedGrabPoseAsset));
                case 3:
                    return m_OpenAnimationClip != null
                        && m_GrabAnimationClip != null
                        && m_AnimatorController != null;
                case 4:
                    var readiness = HandPoseControllerHandSetupService.EvaluateReadiness(
                        m_PlaybackHandRoot,
                        m_AnimatorController,
                        m_GripInputAction,
                        m_GripParameterName,
                        m_HandSide,
                        m_GripControlMode);
                    return readiness.canApply;
                case 5:
                    return IsGhostCreateReady(out _)
                        && m_GhostTargetGrabObject != null
                        && m_GhostGrabSnapshot != null
                        && HandPoseJointApplier.HasApplicablePoseData(m_GhostGrabSnapshot);
                default:
                    return false;
            }
        }

        void DrawGripCandidateSelection(bool showSummaryInFoldout)
        {
            if (m_PendingGripCandidates != null && m_PendingGripCandidates.Count > 0)
            {
                EditorGUILayout.HelpBox(
                    "동점 후보가 여러 개입니다. 아래에서 하나를 선택하세요.",
                    MessageType.Warning);
                foreach (var candidate in m_PendingGripCandidates)
                {
                    if (GUILayout.Button(HandGripInputActionFinder.FormatCandidateLabel(candidate)))
                    {
                        SelectGripCandidate(candidate);
                    }
                }
            }

            if (!showSummaryInFoldout && !string.IsNullOrEmpty(m_LastGripFindSummary))
            {
                EditorGUILayout.HelpBox(m_LastGripFindSummary, m_LastGripFindMessageType);
            }
        }

        void DrawReadinessSection(HandPoseCaptureService.Readiness readiness)
        {
            EditorGUILayout.LabelField("캡처 준비 상태", EditorStyles.boldLabel);

            EditorGUILayout.LabelField("Play Mode", readiness.isPlaying ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "XRHandSubsystem",
                readiness.subsystemRunning ? "running" : "없음 / not running");
            EditorGUILayout.LabelField(
                $"{HandSideUtility.GetLabel(m_HandSide)} Hand tracked",
                readiness.handTracked ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Tracking Hand Root",
                string.IsNullOrEmpty(readiness.trackingHandRootName)
                    ? "(none)"
                    : readiness.trackingHandRootName);
            EditorGUILayout.LabelField(
                "Hierarchy Path",
                string.IsNullOrEmpty(readiness.trackingHandRootHierarchyPath)
                    ? "(none)"
                    : readiness.trackingHandRootHierarchyPath);
            EditorGUILayout.LabelField(
                "Bone 수",
                $"{readiness.boneCount} / {readiness.expectedBoneCount}");
            EditorGUILayout.LabelField(
                "유효 Joint Pose 수",
                $"{readiness.validJointPoseCount} / {readiness.totalJointCount}");
            EditorGUILayout.LabelField(
                "SkinnedMeshRenderer",
                readiness.hasSkinnedMeshRenderer ? "있음" : "없음");

            if (readiness.isPlaying && readiness.distanceToMainCamera > 0f)
            {
                EditorGUILayout.LabelField(
                    "Main Camera ↔ Hand 거리",
                    readiness.distanceToMainCamera.ToString("F3"));
            }

            EditorGUILayout.LabelField("Target", readiness.targetName);

            if (readiness.distanceToTarget > 0f || m_TargetTransform != null)
            {
                EditorGUILayout.LabelField(
                    "Target ↔ Hand 거리",
                    readiness.distanceToTarget.ToString("F3"));
            }

            if (readiness.hasTargetRelativePreview)
            {
                EditorGUILayout.LabelField(
                    "Target 상대 위치",
                    readiness.targetRelativePositionPreview.ToString("F4"));
                EditorGUILayout.LabelField(
                    "Target 상대 회전",
                    readiness.targetRelativeRotationPreview.eulerAngles.ToString("F2"));
            }
            else
            {
                EditorGUILayout.LabelField("Target 상대 pose", "저장 안 함 (Target null)");
            }

            EditorGUILayout.LabelField(
                "캡처 가능",
                readiness.canCapture ? "Yes" : "No");

            if (readiness.skeletonValid)
            {
                EditorGUILayout.HelpBox(readiness.skeletonSummary, MessageType.Info);
            }
            else if (!string.IsNullOrEmpty(readiness.skeletonSummary))
            {
                EditorGUILayout.HelpBox(readiness.skeletonSummary, MessageType.Warning);
            }

            EditorGUILayout.LabelField(
                "XRHandSkeletonDriver",
                readiness.skeletonDriverPresent
                    ? (readiness.skeletonDriverEnabled ? "있음 (활성)" : "있음 (비활성)")
                    : "없음");
            EditorGUILayout.LabelField(
                "XRHandTrackingEvents",
                readiness.trackingEventsPresent ? $"있음 ({readiness.handedness})" : "없음");

            if (readiness.blockers != null && readiness.blockers.Count > 0)
            {
                var sb = new StringBuilder();
                foreach (var blocker in readiness.blockers)
                {
                    sb.Append("• ");
                    sb.AppendLine(blocker);
                }

                EditorGUILayout.HelpBox(sb.ToString().TrimEnd(), MessageType.Warning);
            }
        }

        void DrawCaptureButtons(HandPoseCaptureService.Readiness readiness)
        {
            EditorGUILayout.LabelField("포즈 캡처", EditorStyles.boldLabel);

            using (new EditorGUI.DisabledScope(!readiness.canCapture))
            {
                if (GUILayout.Button("Capture Open Pose"))
                    CaptureAndSave(HandSideUtility.GetOpenPoseName(m_HandSide), assignOpenAsset: true);

                if (GUILayout.Button("Capture Grab Pose"))
                    CaptureAndSave(HandSideUtility.GetGrabPoseName(m_HandSide), assignGrabAsset: true);

                if (GUILayout.Button("Capture Current Pose"))
                {
                    if (string.IsNullOrWhiteSpace(m_PoseName))
                    {
                        ShowFailure("Pose Name이 비어 있습니다. Current Pose 저장을 위해 Pose Name을 입력하세요.");
                    }
                    else
                    {
                        CaptureAndSave(m_PoseName.Trim());
                    }
                }
            }

            if (!readiness.canCapture)
            {
                EditorGUILayout.HelpBox(
                    $"HandVisualizer Play + {HandSideUtility.GetLabel(m_HandSide)} Hand tracked + " +
                    $"{HandSideUtility.GetBonePrefix(m_HandSide)}* 26/26 검증 통과 시 Capture 버튼이 활성화됩니다.",
                    MessageType.Info);
            }
        }

        void DrawPlaybackHandMinimalSetupSection(bool foldDetails = false)
        {
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var controllerName = HandSideUtility.GetControllerNameToken(m_HandSide);
            var handRootName = HandSideUtility.GetPreferredHandRootName(m_HandSide);
            var xriMap = HandSideUtility.GetXriTrackingActionMap(m_HandSide);

            EditorGUILayout.LabelField("Playback Hand 최소 설정", EditorStyles.boldLabel);

            if (foldDetails)
            {
                m_FoldStep1SetupDetails = EditorGUILayout.Foldout(
                    m_FoldStep1SetupDetails,
                    "설정 안내 및 배치 부모 상세");
                if (m_FoldStep1SetupDetails)
                {
                    EditorGUILayout.HelpBox(
                        $"배치 부모 Transform 아래에 {controllerName} / Visual / {handRootName}.fbx 최소 계층을 구성합니다.\n" +
                        $"TrackedPoseDriver: {xriMap} Position / Rotation / Tracking State\n" +
                        "Scene GameObject만 허용됩니다. Project Asset, Prefab Asset, Prefab Stage, 다른 씬 오브젝트는 거부됩니다.",
                        MessageType.Info);
                    DrawPlaybackSetupProbeSummary();
                    DrawPlaybackSetupResolvedPathPreview();
                }
            }
            else
            {
                EditorGUILayout.HelpBox(
                    $"배치 부모 Transform 아래에 {controllerName} / Visual / {handRootName}.fbx 최소 계층을 구성합니다.\n" +
                    $"TrackedPoseDriver: {xriMap} Position / Rotation / Tracking State\n" +
                    "Scene GameObject만 허용됩니다. Project Asset, Prefab Asset, Prefab Stage, 다른 씬 오브젝트는 거부됩니다.",
                    MessageType.Info);
                DrawPlaybackSetupProbeSummary();
                DrawPlaybackSetupResolvedPathPreview();
            }

            EditorGUI.BeginChangeCheck();
            m_PlaybackSetupPlacementParent = (Transform)EditorGUILayout.ObjectField(
                "배치 부모",
                m_PlaybackSetupPlacementParent,
                typeof(Transform),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                ValidatePlaybackSetupPlacementParent(showDialog: false);
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("선택한 오브젝트 사용"))
                TryApplyPlaybackSetupHierarchySelection(silent: false);
            if (GUILayout.Button("XR Origin 자동 찾기"))
                TryApplyPlaybackSetupXROriginParent();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(4f);
            using (new EditorGUI.DisabledScope(!CanExecutePlaybackHandSetup()))
            {
                if (GUILayout.Button(
                        $"{sideLabel}손 Playback Hand 최소 설정",
                        GUILayout.Height(28f)))
                {
                    ExecutePlaybackHandSetupWithConfirmation();
                }
            }

            if (!string.IsNullOrEmpty(m_LastPlaybackSetupSummary)
                && m_LastPlaybackSetupMessageType == MessageType.Error)
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(m_LastPlaybackSetupSummary, m_LastPlaybackSetupMessageType);
            }
            else if (!string.IsNullOrEmpty(m_LastPlaybackSetupSummary)
                     && m_LastPlaybackSetupMessageType != MessageType.Error)
            {
                m_FoldStep1SetupResult = EditorGUILayout.Foldout(
                    m_FoldStep1SetupResult,
                    "Playback Hand 설정 결과");
                if (m_FoldStep1SetupResult)
                {
                    EditorGUILayout.HelpBox(m_LastPlaybackSetupSummary, m_LastPlaybackSetupMessageType);
                }
            }
        }

        void DrawPlaybackSetupProbeSummary()
        {
            RefreshPlaybackSetupProbeSummary();
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("활성 씬 탐색 요약", EditorStyles.miniBoldLabel);
            EditorGUILayout.LabelField("XROrigin", m_PlaybackSetupProbe.xrOriginCount.ToString());
            EditorGUILayout.LabelField("TrackedPoseDriver", m_PlaybackSetupProbe.trackedPoseDriverCount.ToString());
            EditorGUILayout.LabelField(
                "TrackedPoseDriver 공통 부모 후보",
                m_PlaybackSetupProbe.trackedPoseDriverSharedParentCount.ToString());
            EditorGUILayout.LabelField("MainCamera 태그 카메라", m_PlaybackSetupProbe.mainCameraTaggedCount.ToString());
        }

        void DrawPlaybackSetupResolvedPathPreview()
        {
            var scene = SceneManager.GetActiveScene();
            var resolve = HandPlaybackSetupService.ResolvePlacementParent(scene, m_PlaybackSetupPlacementParent);
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("현재 결정된 배치 부모", EditorStyles.miniBoldLabel);

            if (resolve.success)
            {
                EditorGUILayout.LabelField("출처", resolve.sourceLabel);
                EditorGUILayout.SelectableLabel(resolve.path, EditorStyles.textField, GUILayout.Height(18f));
            }
            else
            {
                EditorGUILayout.LabelField("출처", "(미결정)");
                EditorGUILayout.HelpBox(resolve.message, MessageType.Warning);
            }
        }

        void RefreshPlaybackSetupProbeSummary()
        {
            m_PlaybackSetupProbe = HandPlaybackSetupService.ProbeActiveScene(SceneManager.GetActiveScene());
        }

        bool CanExecutePlaybackHandSetup()
        {
            var scene = SceneManager.GetActiveScene();
            var resolve = HandPlaybackSetupService.ResolvePlacementParent(scene, m_PlaybackSetupPlacementParent);
            return resolve.success;
        }

        void TryApplyPlaybackSetupHierarchySelection(bool silent)
        {
            RefreshPlaybackSetupProbeSummary();
            var scene = SceneManager.GetActiveScene();
            var selected = Selection.activeTransform;
            if (!HandPlaybackSetupService.IsValidActiveSceneTransform(selected, scene))
            {
                if (!silent)
                {
                    m_LastPlaybackSetupMessageType = MessageType.Warning;
                    m_LastPlaybackSetupSummary =
                        "Hierarchy에서 활성 씬의 GameObject를 선택하세요.\n" +
                        "Project Asset, Prefab Asset, Prefab Stage, 다른 씬 오브젝트는 사용할 수 없습니다.";
                }

                return;
            }

            m_PlaybackSetupPlacementParent = selected;
            m_LastPlaybackSetupMessageType = MessageType.Info;
            m_LastPlaybackSetupSummary =
                $"선택한 오브젝트를 배치 부모로 지정했습니다.\n{HandPoseCaptureService.GetHierarchyPath(selected)}";
        }

        void TryApplyPlaybackSetupXROriginParent()
        {
            RefreshPlaybackSetupProbeSummary();
            var scene = SceneManager.GetActiveScene();
            var resolve = HandPlaybackSetupService.ResolveFromXROriginOnly(scene);
            if (!resolve.success)
            {
                m_LastPlaybackSetupMessageType = MessageType.Error;
                m_LastPlaybackSetupSummary = resolve.message;
                EditorUtility.DisplayDialog("XR Origin 자동 찾기", resolve.message, "OK");
                return;
            }

            m_PlaybackSetupPlacementParent = resolve.parent;
            m_LastPlaybackSetupMessageType = MessageType.Info;
            m_LastPlaybackSetupSummary =
                $"XR Origin CameraFloorOffsetObject를 배치 부모로 지정했습니다.\n{resolve.path}";
        }

        void ValidatePlaybackSetupPlacementParent(bool showDialog)
        {
            RefreshPlaybackSetupProbeSummary();
            var scene = SceneManager.GetActiveScene();
            if (m_PlaybackSetupPlacementParent == null)
                return;

            if (HandPlaybackSetupService.IsValidActiveSceneTransform(m_PlaybackSetupPlacementParent, scene))
            {
                m_LastPlaybackSetupMessageType = MessageType.Info;
                m_LastPlaybackSetupSummary =
                    $"배치 부모: {HandPoseCaptureService.GetHierarchyPath(m_PlaybackSetupPlacementParent)}";
                return;
            }

            m_LastPlaybackSetupMessageType = MessageType.Error;
            m_LastPlaybackSetupSummary =
                "배치 부모는 활성 씬의 Scene GameObject만 사용할 수 있습니다.";
            if (showDialog)
                EditorUtility.DisplayDialog("배치 부모 오류", m_LastPlaybackSetupSummary, "OK");
        }

        void ExecutePlaybackHandSetupWithConfirmation()
        {
            RefreshPlaybackSetupProbeSummary();
            var scene = SceneManager.GetActiveScene();
            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var controllerName = HandSideUtility.GetControllerNameToken(m_HandSide);
            var handRootName = HandSideUtility.GetPreferredHandRootName(m_HandSide);
            var xriMap = HandSideUtility.GetXriTrackingActionMap(m_HandSide);

            var resolve = HandPlaybackSetupService.ResolvePlacementParent(scene, m_PlaybackSetupPlacementParent);
            if (!resolve.success)
            {
                m_LastPlaybackSetupMessageType = MessageType.Error;
                m_LastPlaybackSetupSummary = resolve.message;
                EditorUtility.DisplayDialog($"{sideLabel}손 Playback Hand 최소 설정", resolve.message, "OK");
                return;
            }

            var confirmMessage = new StringBuilder();
            confirmMessage.AppendLine($"다음 배치 부모 아래에 {sideLabel} Playback Hand 최소 계층을 생성합니다.");
            confirmMessage.AppendLine();
            confirmMessage.AppendLine($"출처: {resolve.sourceLabel}");
            confirmMessage.AppendLine($"경로: {resolve.path}");
            confirmMessage.AppendLine();
            confirmMessage.AppendLine("생성/재사용 대상:");
            confirmMessage.AppendLine($"• {controllerName} (TrackedPoseDriver + {xriMap})");
            confirmMessage.AppendLine("• Visual");
            confirmMessage.AppendLine($"• {handRootName}.fbx 인스턴스");
            confirmMessage.AppendLine();
            confirmMessage.Append("계속하시겠습니까?");

            if (!EditorUtility.DisplayDialog(
                    $"{sideLabel}손 Playback Hand 최소 설정",
                    confirmMessage.ToString(),
                    "생성",
                    "취소"))
            {
                m_LastPlaybackSetupMessageType = MessageType.Info;
                m_LastPlaybackSetupSummary = "사용자가 생성을 취소했습니다.";
                return;
            }

            var setupResult = HandPlaybackSetupService.SetupPlaybackHand(m_HandSide, resolve.parent);
            if (!setupResult.success)
            {
                m_LastPlaybackSetupMessageType = MessageType.Error;
                m_LastPlaybackSetupSummary = setupResult.message;
                Debug.LogError($"[HandPlaybackSetupService] {setupResult.message}");
                return;
            }

            m_LastPlaybackSetupMessageType = MessageType.Info;
            m_LastPlaybackSetupSummary = setupResult.message;
            SetPlaybackHandRoot(setupResult.handRoot);
            HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                setupResult.handRoot, m_HandSide, out _, out _);
            Debug.Log($"[HandPlaybackSetupService] {setupResult.message}", setupResult.handRoot);
        }

        void DrawControllerHandSetupSection(bool foldDetails = false)
        {
            DrawGripControlModeSelector();

            var usesToolGrip = m_GripControlMode == HandGripControlMode.ToolDefault;

            EditorGUI.BeginChangeCheck();
            m_PlaybackHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Playback Hand Root",
                m_PlaybackHandRoot,
                typeof(Transform),
                true);
            m_AnimatorController = (RuntimeAnimatorController)EditorGUILayout.ObjectField(
                "Animator Controller",
                m_AnimatorController,
                typeof(RuntimeAnimatorController),
                false);
            using (new EditorGUI.DisabledScope(!usesToolGrip))
            {
                m_GripInputAction = (InputActionReference)EditorGUILayout.ObjectField(
                    "Grip Input Action",
                    m_GripInputAction,
                    typeof(InputActionReference),
                    false);
            }

            m_GripParameterName = EditorGUILayout.TextField("Grip Parameter Name", m_GripParameterName);
            using (new EditorGUI.DisabledScope(!usesToolGrip))
            {
                m_UseSmoothing = EditorGUILayout.Toggle("Use Smoothing", m_UseSmoothing);
                m_SmoothingSpeed = EditorGUILayout.FloatField("Smoothing Speed", m_SmoothingSpeed);
            }

            if (EditorGUI.EndChangeCheck())
            {
                m_LastControllerSetupSummary = null;
                CapturePlaybackHandLocatorIfPossible();
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button($"현재 씬 {HandSideUtility.GetLabel(m_HandSide)} Playback Hand 찾기"))
                TryFindPlaybackHand();
            if (GUILayout.Button("Use Selection as Playback Hand") && Selection.activeTransform != null)
                SetPlaybackHandRoot(Selection.activeTransform);
            EditorGUILayout.EndHorizontal();

            DrawPlaybackHandCandidates();

            using (new EditorGUI.DisabledScope(!usesToolGrip))
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("선택 손 Grip 자동 찾기"))
                    AutoFindGrip();
                EditorGUILayout.EndHorizontal();

                DrawGripCandidateSelection(showSummaryInFoldout: foldDetails);
            }

            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("Interactor (준비)", EditorStyles.miniBoldLabel);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Interactor 후보 탐색"))
                RefreshInteractorCandidates();
            EditorGUILayout.EndHorizontal();
            using (new EditorGUI.DisabledScope(true))
            {
                m_InteractorCandidate = (Component)EditorGUILayout.ObjectField(
                    "Interactor Candidate",
                    m_InteractorCandidate,
                    typeof(Component),
                    true);
            }
            DrawInteractorCandidates();

            var readiness = HandPoseControllerHandSetupService.EvaluateReadiness(
                m_PlaybackHandRoot,
                m_AnimatorController,
                m_GripInputAction,
                m_GripParameterName,
                m_HandSide,
                m_GripControlMode);

            if (!readiness.canApply && readiness.blockers != null && readiness.blockers.Count > 0)
            {
                var blockerText = new StringBuilder();
                foreach (var blocker in readiness.blockers)
                {
                    blockerText.Append("• ");
                    blockerText.AppendLine(blocker);
                }

                EditorGUILayout.HelpBox(blockerText.ToString().TrimEnd(), MessageType.Warning);
            }

            using (new EditorGUI.DisabledScope(!readiness.canApply))
            {
                if (GUILayout.Button("컨트롤러 손 설정 적용"))
                    ApplyControllerHandSetup();
            }

            if (foldDetails)
            {
                m_FoldStep4Details = EditorGUILayout.Foldout(m_FoldStep4Details, "상세 정보");
                if (m_FoldStep4Details)
                {
                    DrawControllerHandSetupDetails(readiness);
                }
            }
            else
            {
                DrawControllerHandSetupDetails(readiness);
            }
        }

        void DrawGripControlModeSelector()
        {
            EditorGUILayout.LabelField("Grip 제어 방식", EditorStyles.boldLabel);

            var labels = new[]
            {
                "VR Hand Pose Tool 기본 방식",
                "기존 프로젝트 방식",
            };

            EditorGUI.BeginChangeCheck();
            var selected = (int)m_GripControlMode;
            var newSelected = EditorGUILayout.Popup("Grip 제어 방식", selected, labels);
            if (EditorGUI.EndChangeCheck())
            {
                m_GripControlMode = (HandGripControlMode)newSelected;
                m_LastControllerSetupSummary = null;
            }

            if (m_GripControlMode == HandGripControlMode.ProjectLegacy)
            {
                EditorGUILayout.HelpBox(
                    "기존 프로젝트의 Grip 제어 스크립트를 사용합니다. " +
                    "같은 Animator의 Grip 값을 제어하는 스크립트가 중복되지 않는지 확인하세요.",
                    MessageType.Info);
            }

            EditorGUILayout.Space(4f);
        }

        void DrawControllerHandSetupDetails(HandPoseControllerHandSetupService.Readiness readiness)
        {
            EditorGUILayout.HelpBox(
                "1. Open/Grab 포즈 캡처\n" +
                "2. AnimationClip 내보내기\n" +
                "3. Playback Hand Root 지정\n" +
                "4. Animator Controller 지정\n" +
                "5. [선택 손 Grip 자동 찾기] 또는 Grip Input Action 수동 지정\n" +
                "6. [컨트롤러 손 설정 적용]\n" +
                "7. Play 테스트\n\n" +
                "자동 탐색 대상 (선택 Hand Side 기준):\n" +
                $"{HandPoseControllerHandSetupService.RecommendedGripActionPath}\n" +
                $"Action Map: {HandPoseControllerHandSetupService.GetRecommendedGripActionMap(m_HandSide)}\n" +
                $"Action: {HandPoseControllerHandSetupService.RecommendedGripActionName}\n" +
                $"Binding: {HandPoseControllerHandSetupService.GetRecommendedGripBinding(m_HandSide)}\n" +
                "타입: Value · expectedControlType: Axis",
                MessageType.Info);

            EditorGUILayout.LabelField(
                "Playback Hand",
                string.IsNullOrEmpty(readiness.playbackHandName)
                    ? "(none)"
                    : readiness.playbackHandName);
            EditorGUILayout.LabelField(
                "Hierarchy Path",
                string.IsNullOrEmpty(readiness.playbackHandHierarchyPath)
                    ? "(none)"
                    : readiness.playbackHandHierarchyPath);
            EditorGUILayout.LabelField(
                "Bones",
                $"{readiness.boneCount} / {readiness.expectedBoneCount}");
            EditorGUILayout.LabelField(
                "SkinnedMeshRenderer",
                readiness.hasSkinnedMeshRenderer ? "있음" : "없음");
            EditorGUILayout.LabelField(
                "Animator Controller",
                readiness.controllerAssigned ? "지정됨" : "없음");
            EditorGUILayout.LabelField(
                "Grip Float Parameter",
                readiness.controllerHasGripFloat ? m_GripParameterName : "없음 / 불일치");
            EditorGUILayout.LabelField(
                "Blend Tree / State",
                readiness.controllerHasBlendTreeState ? "있음" : "없음");
            EditorGUILayout.LabelField(
                "Grip Action",
                readiness.gripActionAssigned ? "지정됨" : "없음");

            if (readiness.gripActionAssigned)
            {
                EditorGUILayout.LabelField("Grip Action Asset", readiness.gripActionPath);
                EditorGUILayout.LabelField(
                    "Grip Action Type",
                    $"{readiness.gripActionType} · {readiness.gripActionExpectedControlType}");
            }

            if (readiness.warnings != null && readiness.warnings.Count > 0)
            {
                var warningText = new StringBuilder();
                foreach (var warning in readiness.warnings)
                {
                    warningText.Append("• ");
                    warningText.AppendLine(warning);
                }

                EditorGUILayout.HelpBox(warningText.ToString().TrimEnd(), MessageType.Warning);
            }

            if (!string.IsNullOrEmpty(m_LastControllerSetupSummary))
            {
                EditorGUILayout.HelpBox(m_LastControllerSetupSummary, m_LastControllerSetupMessageType);
            }

            if (!string.IsNullOrEmpty(m_LastGripFindSummary))
            {
                EditorGUILayout.HelpBox(m_LastGripFindSummary, m_LastGripFindMessageType);
            }

            EditorGUILayout.Space(4f);
            if (GUILayout.Button("잡기 Transform 진단 추가"))
                ApplyGrabTransformDiagnostic();

            if (!string.IsNullOrEmpty(m_LastGrabDiagnosticSetupSummary))
            {
                EditorGUILayout.HelpBox(m_LastGrabDiagnosticSetupSummary, m_LastGrabDiagnosticSetupMessageType);
            }
        }

        void ApplyGrabTransformDiagnostic()
        {
            if (m_PlaybackHandRoot == null)
            {
                m_LastGrabDiagnosticSetupMessageType = MessageType.Error;
                m_LastGrabDiagnosticSetupSummary = "Playback Hand Root를 먼저 지정하세요.";
                return;
            }

            if (m_GripInputAction == null && !TryEnsureGripInputAction(out _))
            {
                // Grip action is optional for diagnostic but recommended; continue without blocking.
            }

            var result = HandGrabTransformDiagnosticSetupService.ApplyDiagnostic(
                m_PlaybackHandRoot,
                m_GripInputAction);

            m_LastGrabDiagnosticSetupMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastGrabDiagnosticSetupSummary = result.success ? result.summary : result.message;
        }

        void ApplyControllerHandSetup()
        {
            if (m_GripControlMode == HandGripControlMode.ToolDefault)
            {
                if (!TryEnsureGripInputAction(out var gripError))
                {
                    m_LastControllerSetupMessageType = MessageType.Error;
                    m_LastControllerSetupSummary = gripError;
                    return;
                }
            }

            // Play Mode Scene 변경은 종료 시 복원되므로 pending 후 Edit Mode에서 영구 적용한다.
            if (EditorApplication.isPlaying)
            {
                var pending = HandPoseControllerHandPendingSetupBridge.TryRegisterAndExitPlayMode(
                    m_HandSide,
                    m_PlaybackHandRoot,
                    m_AnimatorController,
                    m_GripInputAction,
                    m_GripParameterName,
                    m_UseSmoothing,
                    m_SmoothingSpeed,
                    m_GripControlMode);

                m_LastControllerSetupMessageType = pending.success ? MessageType.Info : MessageType.Error;
                m_LastControllerSetupSummary = pending.message;
                return;
            }

            var result = HandPoseControllerHandSetupService.ApplySetup(
                m_PlaybackHandRoot,
                m_AnimatorController,
                m_GripInputAction,
                m_GripParameterName,
                m_UseSmoothing,
                m_SmoothingSpeed,
                m_HandSide,
                m_GripControlMode);

            if (result.success && m_PlaybackHandRoot != null)
            {
                if (PrefabUtility.IsPartOfPrefabInstance(m_PlaybackHandRoot.gameObject))
                {
                    PrefabUtility.RecordPrefabInstancePropertyModifications(m_PlaybackHandRoot.gameObject);
                    foreach (var behaviour in m_PlaybackHandRoot.GetComponents<MonoBehaviour>())
                    {
                        if (behaviour != null)
                            PrefabUtility.RecordPrefabInstancePropertyModifications(behaviour);
                    }
                }
            }

            if (result.success && m_GripControlMode == HandGripControlMode.ToolDefault)
            {
                var verify = HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                    m_PlaybackHandRoot,
                    m_AnimatorController,
                    m_GripInputAction,
                    m_GripParameterName);
                if (!verify.isValid
                    || !verify.hasInputActionManager
                    || !verify.gripActionAssetRegistered)
                {
                    m_LastControllerSetupMessageType = MessageType.Error;
                    m_LastControllerSetupSummary =
                        "적용 후 검증 실패: " + (verify.failureReason ?? "Grip Driver/InputActionManager 연결을 확인할 수 없습니다.");
                    return;
                }
            }

            m_LastControllerSetupMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastControllerSetupSummary = result.success ? result.summary : result.message;
        }

        void AutoFindGrip()
        {
            m_PendingGripCandidates = null;
            var findResult = HandGripInputActionFinder.FindAndResolveReference(m_HandSide);
            HandleGripFindResult(findResult);
        }

        void SelectGripCandidate(HandGripInputActionFinder.CandidateInfo candidate)
        {
            var findResult = HandGripInputActionFinder.FindAndResolveReference(m_HandSide, candidate);
            HandleGripFindResult(findResult);
        }

        void HandleGripFindResult(HandGripInputActionFinder.FindResult findResult)
        {
            if (findResult.requiresUserSelection)
            {
                m_PendingGripCandidates = findResult.tiedCandidates;
                m_LastGripFindMessageType = MessageType.Warning;

                var sb = new StringBuilder(findResult.failureReason);
                if (findResult.tiedCandidates != null)
                {
                    sb.AppendLine();
                    sb.AppendLine("후보:");
                    foreach (var candidate in findResult.tiedCandidates)
                    {
                        sb.Append("• ");
                        sb.AppendLine(HandGripInputActionFinder.FormatCandidateLabel(candidate));
                    }
                }

                m_LastGripFindSummary = sb.ToString().TrimEnd();
                Repaint();
                return;
            }

            if (!findResult.success)
            {
                m_PendingGripCandidates = null;
                m_LastGripFindMessageType = MessageType.Error;
                m_LastGripFindSummary = findResult.displaySummary;
                Repaint();
                return;
            }

            m_PendingGripCandidates = null;
            m_GripInputAction = findResult.inputActionReference;
            m_LastGripFindMessageType = MessageType.Info;
            m_LastGripFindSummary = findResult.displaySummary;
            Repaint();
        }

        bool TryEnsureGripInputAction(out string errorMessage)
        {
            errorMessage = null;
            if (m_GripInputAction != null)
                return true;

            var findResult = HandGripInputActionFinder.FindAndResolveReference(m_HandSide);
            if (findResult.requiresUserSelection)
            {
                m_PendingGripCandidates = findResult.tiedCandidates;
                m_LastGripFindMessageType = MessageType.Warning;
                m_LastGripFindSummary = findResult.failureReason;
                errorMessage =
                    findResult.failureReason + "\n[선택 손 Grip 자동 찾기]에서 후보를 선택하세요.";
                return false;
            }

            if (!findResult.success)
            {
                m_LastGripFindMessageType = MessageType.Error;
                m_LastGripFindSummary = findResult.displaySummary;
                errorMessage = findResult.displaySummary;
                return false;
            }

            m_GripInputAction = findResult.inputActionReference;
            m_LastGripFindMessageType = MessageType.Info;
            m_LastGripFindSummary = findResult.displaySummary;
            return true;
        }

        void TryFindPlaybackHand()
        {
            m_PendingPlaybackCandidates = null;
            var findResult = HandPlaybackHandFinder.FindPlaybackHand(m_HandSide);
            if (findResult.success)
            {
                SetPlaybackHandRoot(findResult.handRoot);
                m_LastControllerSetupMessageType = MessageType.Info;
                m_LastControllerSetupSummary = findResult.message;
                Repaint();
                return;
            }

            if (findResult.candidates != null && findResult.candidates.Count > 1)
            {
                m_PendingPlaybackCandidates = findResult.candidates;
                m_LastControllerSetupMessageType = MessageType.Warning;
                m_LastControllerSetupSummary = findResult.message;
                Repaint();
                return;
            }

            EditorUtility.DisplayDialog(
                "Playback Hand",
                findResult.message,
                "OK");
        }

        void TryAssignDefaultGrabSnapshotSource()
        {
            if (m_GrabSnapshotSourceAsset == null)
                m_GrabSnapshotSourceAsset = HandGrabSnapshotExporter.TryLoadDefaultSourcePose(m_HandSide);

            if (string.IsNullOrWhiteSpace(m_GrabSnapshotOutputName))
                m_GrabSnapshotOutputName = HandGrabSnapshotExporter.GetDefaultOutputName(m_HandSide);
        }

        void TryAssignDefaultGhostGrabSnapshot()
        {
            if (m_GhostGrabSnapshot == null)
                m_GhostGrabSnapshot = HandGhostPreviewService.TryLoadDefaultGrabSnapshot(m_HandSide);
        }

        void DrawPlayModeGrabPoseCaptureSection()
        {
            m_FoldStep5GrabPoseCaptureHelp = EditorGUILayout.Foldout(
                m_FoldStep5GrabPoseCaptureHelp,
                "Playback Hand Grab Pose 캡처 안내");
            if (m_FoldStep5GrabPoseCaptureHelp)
            {
                EditorGUILayout.HelpBox(
                    "Play Mode Grab Pose 캡처\n\n" +
                    "컨트롤러 Grip으로 만든 현재 Playback Hand 자세와\n" +
                    "물체 기준 손·Attach 위치를 Record Asset으로 저장합니다.\n\n" +
                    "Step 2 Tracking Hand 캡처와 다릅니다. Target을 실제로 잡은 상태에서만 저장됩니다.",
                    MessageType.Info);
            }

            EditorGUILayout.LabelField("Hand Side", HandSideUtility.GetLabel(m_HandSide));

            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabPoseRecordSummary = null;
                m_LastGrabPoseRecordPath = null;
            }

            EditorGUILayout.LabelField(
                "Playback Hand Root",
                m_PlaybackHandRoot != null
                    ? HandPoseCaptureService.GetHierarchyPath(m_PlaybackHandRoot)
                    : "(none — 1단계에서 지정)");

            if (Application.isPlaying && m_InteractorCandidates == null)
                RefreshInteractorCandidates();

            var interactor = m_InteractorCandidate as XRBaseInteractor;
            EditorGUILayout.LabelField(
                "Interactor",
                interactor != null
                    ? HandPoseCaptureService.GetHierarchyPath(interactor.transform)
                    : "(none — 4단계에서 지정 또는 후보 선택)");

            var readiness = HandGrabPoseCaptureService.EvaluateReadiness(
                m_HandSide,
                m_PlaybackHandRoot,
                m_GhostTargetGrabObject,
                interactor);

            EditorGUILayout.LabelField("Play Mode", readiness.isPlaying ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Target Grabbed",
                readiness.isTargetGrabbed ? "Yes" : "No");
            EditorGUILayout.LabelField(
                "Bone Count",
                readiness.playbackHandRoot != null
                    ? $"{readiness.boneCount} / {readiness.expectedBoneCount}"
                    : "(unknown)");

            if (readiness.warnings != null && readiness.warnings.Count > 0)
            {
                var warningSb = new StringBuilder();
                foreach (var warning in readiness.warnings)
                    warningSb.AppendLine("• " + warning);
                EditorGUILayout.HelpBox(warningSb.ToString().TrimEnd(), MessageType.Warning);
            }

            if (!readiness.canCapture && readiness.blockers != null && readiness.blockers.Count > 0)
            {
                var blockerSb = new StringBuilder();
                foreach (var blocker in readiness.blockers)
                    blockerSb.AppendLine("• " + blocker);
                EditorGUILayout.HelpBox(blockerSb.ToString().TrimEnd(), MessageType.Info);
            }

            using (new EditorGUI.DisabledScope(!readiness.canCapture))
            {
                if (GUILayout.Button("현재 Grab Pose Record 저장"))
                    CaptureGrabPoseRecord();
            }

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordPath))
                EditorGUILayout.LabelField("Last Grab Pose Record", m_LastGrabPoseRecordPath);

            if (!string.IsNullOrEmpty(m_LastGrabPoseRecordSummary))
                EditorGUILayout.HelpBox(m_LastGrabPoseRecordSummary, m_LastGrabPoseRecordMessageType);

            DrawPendingApplySection();
        }

        void DrawPendingApplySection()
        {
            if (HandGrabPosePendingApplyBridge.HasPendingApply)
            {
                var pendingSummary = HandGrabPosePendingApplyBridge.GetPendingSummary();
                EditorGUILayout.HelpBox(
                    $"적용 대기:\n{pendingSummary.targetDisplayName} / {HandSideUtility.GetLabel(pendingSummary.handSide)}\n\n" +
                    "Play Mode를 종료하면\nAttach와 Binding이 Scene에 적용됩니다.",
                    MessageType.Info);
            }

            var lastApplyMessage = HandGrabPosePendingApplyBridge.LastApplyMessage;
            if (!string.IsNullOrEmpty(lastApplyMessage))
            {
                var applyMessageType = HandGrabPosePendingApplyBridge.LastApplySucceeded
                    ? MessageType.Info
                    : MessageType.Warning;
                EditorGUILayout.HelpBox(lastApplyMessage, applyMessageType);
            }

            if (HandGrabPosePendingApplyBridge.HasPendingApply)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("적용 다시 시도"))
                {
                    HandGrabPosePendingApplyBridge.TryApplyPendingNow();
                    Repaint();
                }

                if (GUILayout.Button("적용 대기 삭제"))
                {
                    HandGrabPosePendingApplyBridge.ClearPending();
                    Repaint();
                }

                EditorGUILayout.EndHorizontal();
            }
        }

        void CaptureGrabPoseRecord()
        {
            var result = HandGrabPoseCaptureService.CaptureAndSave(
                m_HandSide,
                m_PlaybackHandRoot,
                m_GhostTargetGrabObject);

            if (result.success)
            {
                m_LastGrabPoseRecordPath = result.saveResult.assetPath;
                m_LastGrabPoseRecordMessageType = result.pendingApplyRegistered || string.IsNullOrEmpty(result.pendingApplyMessage)
                    ? MessageType.Info
                    : MessageType.Warning;
                m_LastGrabPoseRecordSummary = result.message;
                Debug.Log($"[HandGrabPoseCapture] {result.message}");
            }
            else
            {
                m_LastGrabPoseRecordPath = null;
                m_LastGrabPoseRecordMessageType = MessageType.Error;
                var sb = new StringBuilder();
                sb.AppendLine(result.message);
                foreach (var error in result.errors)
                    sb.AppendLine("• " + error);
                m_LastGrabPoseRecordSummary = sb.ToString().TrimEnd();
                Debug.LogError($"[HandGrabPoseCapture] {m_LastGrabPoseRecordSummary}");
            }

            Repaint();
        }

        void DrawGhostPreviewSection(bool foldHelp = false)
        {
            if (foldHelp)
            {
                m_FoldStep5GhostHelp = EditorGUILayout.Foldout(m_FoldStep5GhostHelp, "고스트 미리보기 안내");
                if (m_FoldStep5GhostHelp)
                {
                    EditorGUILayout.HelpBox(
                        $"선택한 물체의 Attach Transform 위치에 Fresnel Rim {HandSideUtility.GetLabel(m_HandSide)}Hand 고스트를 배치합니다.\n" +
                        "실제 Playback Hand는 이동하지 않으며, Editor 버튼으로만 생성·갱신·제거합니다.\n" +
                        "고스트는 Play Mode 종료 후 Edit Mode에서만 생성하세요.\n" +
                        $"고스트 루트: {HandGhostPreviewService.GhostsRootName}",
                        MessageType.Info);
                }
            }
            else
            {
                EditorGUILayout.LabelField("고스트 손 미리보기", EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(
                    $"선택한 물체의 Attach Transform 위치에 Fresnel Rim {HandSideUtility.GetLabel(m_HandSide)}Hand 고스트를 배치합니다.\n" +
                    "실제 Playback Hand는 이동하지 않으며, Editor 버튼으로만 생성·갱신·제거합니다.\n" +
                    $"고스트 루트: {HandGhostPreviewService.GhostsRootName}",
                    MessageType.Info);
            }

            TryAssignDefaultGhostGrabSnapshot();

            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            m_GhostGrabSnapshot = (HandPoseSnapshot)EditorGUILayout.ObjectField(
                "Grab Snapshot",
                m_GhostGrabSnapshot,
                typeof(HandPoseSnapshot),
                false);
            m_GhostBaseAlpha = EditorGUILayout.Slider("Ghost Base Alpha", m_GhostBaseAlpha, 0.03f, 0.08f);
            m_GhostRimColor = EditorGUILayout.ColorField("Ghost Rim Color", m_GhostRimColor);
            m_GhostRimIntensity = EditorGUILayout.Slider("Ghost Rim Intensity", m_GhostRimIntensity, 1.5f, 3f);
            m_GhostPulseSpeed = EditorGUILayout.Slider("Ghost Pulse Speed", m_GhostPulseSpeed, 0.5f, 2f);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGhostPreviewSummary = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Use Selection as Target Grab Object")
                && HandGhostPreviewService.TryResolveSelectionGrabTarget() != null)
            {
                m_GhostTargetGrabObject = HandGhostPreviewService.TryResolveSelectionGrabTarget();
            }
            EditorGUILayout.EndHorizontal();

            if (!IsGhostCreateReady(out var ghostBlocker))
            {
                EditorGUILayout.HelpBox(ghostBlocker, MessageType.Info);
            }

            var ghostActionReady = IsGhostCreateReady(out _);
            var attachTransform = m_GhostTargetGrabObject != null
                ? m_GhostTargetGrabObject.GetComponent<XRGrabInteractable>()?.attachTransform
                : null;
            if (m_GhostTargetGrabObject != null && attachTransform == null)
            {
                EditorGUILayout.HelpBox(
                    "XR Grab Interactable.attachTransform이 비어 있습니다. " +
                    "물체 Transform을 기준으로 임시 배치하며 AttachPoint 설정을 권장합니다.",
                    MessageType.Warning);
            }

            using (new EditorGUI.DisabledScope(!ghostActionReady))
            {
                if (GUILayout.Button("선택 물체에 고스트 생성"))
                    CreateOrUpdateGhostPreview();
            }

            using (new EditorGUI.DisabledScope(m_GhostTargetGrabObject == null || Application.isPlaying))
            {
                if (GUILayout.Button("고스트 제거"))
                    RemoveGhostPreview();
            }

            if (!string.IsNullOrEmpty(m_LastGhostPreviewSummary)
                && m_LastGhostPreviewMessageType == MessageType.Error)
            {
                EditorGUILayout.HelpBox(m_LastGhostPreviewSummary, m_LastGhostPreviewMessageType);
            }
            else if (!string.IsNullOrEmpty(m_LastGhostPreviewSummary))
            {
                m_FoldStep5GhostResult = EditorGUILayout.Foldout(m_FoldStep5GhostResult, "고스트 미리보기 결과");
                if (m_FoldStep5GhostResult)
                {
                    EditorGUILayout.HelpBox(m_LastGhostPreviewSummary, m_LastGhostPreviewMessageType);
                }
            }
        }

        HandGhostAppearanceSettings BuildGhostAppearanceSettings()
        {
            var settings = HandGhostAppearanceSettings.Default;
            settings.baseAlpha = m_GhostBaseAlpha;
            settings.rimColor = m_GhostRimColor;
            settings.rimIntensity = m_GhostRimIntensity;
            settings.pulseSpeed = m_GhostPulseSpeed;
            return settings;
        }

        void CreateOrUpdateGhostPreview()
        {
            if (Application.isPlaying)
            {
                m_LastGhostPreviewMessageType = MessageType.Warning;
                m_LastGhostPreviewSummary = "고스트는 Play Mode를 종료한 뒤 생성하세요.";
                return;
            }

            try
            {
                var result = HandGhostPreviewService.CreateOrUpdateGhost(
                    m_GhostTargetGrabObject,
                    m_PlaybackHandRoot,
                    m_GhostGrabSnapshot,
                    BuildGhostAppearanceSettings(),
                    m_HandSide);

                m_LastGhostPreviewMessageType = result.success ? MessageType.Info : MessageType.Error;
                m_LastGhostPreviewSummary = result.success ? result.summary : result.message;

                if (result.success)
                {
                    Debug.Log(
                        $"[HandGhostPreview] {(result.wasUpdated ? "Update" : "Create")} OK · " +
                        $"target={result.targetGrabObject.name} · bones={result.appliedBoneCount} · " +
                        $"attach={(result.usedFallbackAttach ? "fallback" : result.attachTransformName)}",
                        result.ghostRoot);
                }
                else
                {
                    Debug.LogError($"[HandGhostPreview] Failed: {result.message}");
                }
            }
            catch (Exception ex)
            {
                m_LastGhostPreviewMessageType = MessageType.Error;
                m_LastGhostPreviewSummary = ex.Message;
                Debug.LogException(ex);
            }
        }

        void RemoveGhostPreview()
        {
            if (Application.isPlaying)
            {
                m_LastGhostPreviewMessageType = MessageType.Warning;
                m_LastGhostPreviewSummary = "고스트는 Play Mode를 종료한 뒤 제거하세요.";
                return;
            }

            try
            {
                var result = HandGhostPreviewService.RemoveGhost(m_GhostTargetGrabObject, m_HandSide);
                m_LastGhostPreviewMessageType = result.success ? MessageType.Info : MessageType.Warning;
                m_LastGhostPreviewSummary = result.success ? result.summary : result.message;

                if (result.success)
                    Debug.Log($"[HandGhostPreview] Removed ghost for {m_GhostTargetGrabObject.name}");
                else
                    Debug.LogWarning($"[HandGhostPreview] Remove: {result.message}");
            }
            catch (Exception ex)
            {
                m_LastGhostPreviewMessageType = MessageType.Error;
                m_LastGhostPreviewSummary = ex.Message;
                Debug.LogException(ex);
            }
        }

        bool IsGrabSnapshotExportReady(out string blockerMessage)
        {
            blockerMessage = null;

            if (m_GrabSnapshotSourceAsset == null)
            {
                blockerMessage = "Source Pose Asset을 지정하세요.";
                return false;
            }

            if (m_GrabSnapshotSourceAsset.bones == null || m_GrabSnapshotSourceAsset.bones.Count == 0)
            {
                blockerMessage = "Source Pose Asset에 bone 데이터가 없습니다.";
                return false;
            }

            if (!HandSideUtility.TryInferHandSideFromBoneNames(
                    m_GrabSnapshotSourceAsset.bones.Select(b => b.boneName),
                    out var assetHandSide,
                    out var inferError))
            {
                blockerMessage = inferError;
                return false;
            }

            if (assetHandSide != m_HandSide)
            {
                blockerMessage =
                    $"Source Pose Asset이 {HandSideUtility.GetLabel(m_HandSide)} 손 " +
                    $"({HandSideUtility.GetBonePrefix(m_HandSide)}*) 기준이 아닙니다.";
                return false;
            }

            if (m_PlaybackHandRoot == null)
            {
                blockerMessage = "Playback Hand Root를 지정하세요.";
                return false;
            }

            var validation = HandSkeletonCatalog.Validate(m_PlaybackHandRoot, m_HandSide);
            if (!validation.isValid)
            {
                blockerMessage = validation.summary;
                return false;
            }

            return true;
        }

        bool IsGhostCreateReady(out string blockerMessage)
        {
            blockerMessage = null;

            if (Application.isPlaying)
            {
                blockerMessage = "고스트는 Play Mode를 종료한 뒤 생성하세요.";
                return false;
            }

            if (m_GhostTargetGrabObject == null)
            {
                blockerMessage = "Target Grab Object를 지정하세요.";
                return false;
            }

            if (m_PlaybackHandRoot == null)
            {
                blockerMessage = "Playback Hand Root를 지정하세요. (Grab Snapshot 내보내기 섹션)";
                return false;
            }

            if (m_GhostGrabSnapshot == null)
            {
                blockerMessage = "Grab Snapshot을 지정하세요.";
                return false;
            }

            if (!HandPoseJointApplier.HasApplicablePoseData(m_GhostGrabSnapshot))
            {
                blockerMessage = "Grab Snapshot에 적용 가능한 bone pose 데이터가 없습니다.";
                return false;
            }

            if (!SnapshotMatchesHandSide(m_GhostGrabSnapshot, m_HandSide))
            {
                blockerMessage =
                    $"Grab Snapshot Hand Side가 {HandSideUtility.GetLabel(m_HandSide)}와 일치하지 않습니다.";
                return false;
            }

            return true;
        }

        static bool SnapshotMatchesHandSide(HandPoseSnapshot snapshot, HandSide handSide)
        {
            if (snapshot == null || string.IsNullOrWhiteSpace(snapshot.handSide))
                return true;

            return string.Equals(
                snapshot.handSide,
                HandSideUtility.GetHandSideLabelForMarker(handSide),
                StringComparison.OrdinalIgnoreCase);
        }

        void DrawGrabSnapshotExportSection(bool foldHelp = false)
        {
            if (foldHelp)
            {
                m_FoldStep5GrabSnapshotHelp = EditorGUILayout.Foldout(
                    m_FoldStep5GrabSnapshotHelp,
                    "Grab Snapshot 내보내기 안내");
                if (m_FoldStep5GrabSnapshotHelp)
                {
                    EditorGUILayout.HelpBox(
                        "XRHandPoseAsset의 bone localRotation을 legacy HandPoseSnapshot(bones-only)으로 변환합니다.\n" +
                        "joints는 비우며 ControllerGrabHandPose / HandPoseJointApplier.ApplySnapshotBones 경로용입니다.\n" +
                        $"저장 위치: {HandGrabSnapshotExporter.OutputFolder}/",
                        MessageType.Info);
                }
            }
            else
            {
                EditorGUILayout.LabelField("잡기용 Bone Pose Snapshot", EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(
                    "XRHandPoseAsset의 bone localRotation을 legacy HandPoseSnapshot(bones-only)으로 변환합니다.\n" +
                    "joints는 비우며 ControllerGrabHandPose / HandPoseJointApplier.ApplySnapshotBones 경로용입니다.\n" +
                    $"저장 위치: {HandGrabSnapshotExporter.OutputFolder}/",
                    MessageType.Info);
            }

            TryAssignDefaultGrabSnapshotSource();

            EditorGUI.BeginChangeCheck();
            m_GrabSnapshotSourceAsset = (XRHandPoseAsset)EditorGUILayout.ObjectField(
                "Source Pose Asset",
                m_GrabSnapshotSourceAsset,
                typeof(XRHandPoseAsset),
                false);
            m_PlaybackHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Playback Hand Root",
                m_PlaybackHandRoot,
                typeof(Transform),
                true);
            m_GrabSnapshotOutputName = EditorGUILayout.TextField(
                "Output Name",
                m_GrabSnapshotOutputName);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabSnapshotExportSummary = null;
                m_LastGrabSnapshotExportPath = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button($"현재 씬 {HandSideUtility.GetLabel(m_HandSide)} Playback Hand 찾기"))
                TryFindPlaybackHand();
            if (GUILayout.Button($"Load Default {HandSideUtility.GetGrabPoseName(m_HandSide)} Source"))
                m_GrabSnapshotSourceAsset = HandGrabSnapshotExporter.TryLoadDefaultSourcePose(m_HandSide);
            EditorGUILayout.EndHorizontal();

            if (!IsGrabSnapshotExportReady(out var exportBlocker))
            {
                EditorGUILayout.HelpBox(exportBlocker, MessageType.Info);
            }

            using (new EditorGUI.DisabledScope(!IsGrabSnapshotExportReady(out _)))
            {
                if (GUILayout.Button("Grab Snapshot 내보내기"))
                    ExportGrabSnapshot();
            }

            if (!string.IsNullOrEmpty(m_LastGrabSnapshotExportSummary)
                && m_LastGrabSnapshotExportMessageType == MessageType.Error)
            {
                EditorGUILayout.HelpBox(m_LastGrabSnapshotExportSummary, m_LastGrabSnapshotExportMessageType);
            }
            else if (!string.IsNullOrEmpty(m_LastGrabSnapshotExportSummary))
            {
                m_FoldStep5GrabSnapshotResult = EditorGUILayout.Foldout(
                    m_FoldStep5GrabSnapshotResult,
                    "Grab Snapshot 내보내기 결과");
                if (m_FoldStep5GrabSnapshotResult)
                {
                    EditorGUILayout.HelpBox(m_LastGrabSnapshotExportSummary, m_LastGrabSnapshotExportMessageType);
                }
            }

            if (!string.IsNullOrEmpty(m_LastGrabSnapshotExportPath))
            {
                EditorGUILayout.LabelField("Last Grab Snapshot", m_LastGrabSnapshotExportPath);
            }
        }

        void ExportGrabSnapshot()
        {
            var result = HandGrabSnapshotExporter.Export(
                m_GrabSnapshotSourceAsset,
                m_PlaybackHandRoot,
                m_GrabSnapshotOutputName,
                m_HandSide);

            m_LastGrabSnapshotExportMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastGrabSnapshotExportPath = result.success ? result.assetPath : null;

            if (result.success)
            {
                m_GhostGrabSnapshot = result.asset;

                var summary = new StringBuilder();
                summary.AppendLine(result.message);
                if (!string.IsNullOrEmpty(result.validationSummary))
                    summary.AppendLine(result.validationSummary);
                summary.AppendLine($"bone 식별: {result.boneIdentifierMode}");
                m_LastGrabSnapshotExportSummary = summary.ToString().TrimEnd();

                Debug.Log(
                    $"[HandGrabSnapshotExporter] Export OK · path={result.assetPath} · " +
                    $"bones={result.boneCount} · joints={result.jointCount}",
                    result.asset);
            }
            else
            {
                m_LastGrabSnapshotExportSummary = result.message;
                Debug.LogError($"[HandGrabSnapshotExporter] Export failed: {result.message}");
            }
        }

        void DrawExportButtons(bool foldHelp = false)
        {
            if (foldHelp)
            {
                m_FoldStep3ExportHelp = EditorGUILayout.Foldout(m_FoldStep3ExportHelp, "AnimationClip 내보내기 안내");
                if (m_FoldStep3ExportHelp)
                {
                    EditorGUILayout.HelpBox(
                        "손가락 localRotation(m_LocalRotation.x/y/z/w)만 1프레임 클립으로 저장합니다.\n" +
                        "손 루트·Wrist·Target·XR Origin 위치 커브는 포함하지 않습니다.",
                        MessageType.None);
                }
            }
            else
            {
                EditorGUILayout.LabelField("AnimationClip 내보내기", EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(
                    "손가락 localRotation(m_LocalRotation.x/y/z/w)만 1프레임 클립으로 저장합니다.\n" +
                    "손 루트·Wrist·Target·XR Origin 위치 커브는 포함하지 않습니다.",
                    MessageType.None);
            }

            var openReady = IsExportReady(m_CapturedOpenPoseAsset);
            var grabReady = IsExportReady(m_CapturedGrabPoseAsset);

            using (new EditorGUI.DisabledScope(!openReady))
            {
                if (GUILayout.Button("Export Open Pose To AnimationClip"))
                    ExportAnimationClip(m_CapturedOpenPoseAsset, HandSideUtility.GetOpenPoseName(m_HandSide));
            }

            using (new EditorGUI.DisabledScope(!grabReady))
            {
                if (GUILayout.Button("Export Grab Pose To AnimationClip"))
                    ExportAnimationClip(m_CapturedGrabPoseAsset, HandSideUtility.GetGrabPoseName(m_HandSide));
            }

            using (new EditorGUI.DisabledScope(!openReady || !grabReady))
            {
                if (GUILayout.Button("Export Open / Grab AnimationClips"))
                    ExportBothAnimationClips();
            }
        }

        void TryAssignDefaultDiagnosticClips()
        {
            if (m_OpenAnimationClip == null)
            {
                m_OpenAnimationClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(
                    HandSideUtility.GetDefaultOpenAnimationClipPath(m_HandSide));
            }

            if (m_GrabAnimationClip == null)
            {
                m_GrabAnimationClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(
                    HandSideUtility.GetDefaultGrabAnimationClipPath(m_HandSide));
            }
        }

        void DrawAnimationClipDiagnosticSection(bool foldDetails = false)
        {
            TryAssignDefaultDiagnosticClips();

            EditorGUI.BeginChangeCheck();
            m_OpenAnimationClip = (AnimationClip)EditorGUILayout.ObjectField(
                "Open AnimationClip",
                m_OpenAnimationClip,
                typeof(AnimationClip),
                false);
            m_GrabAnimationClip = (AnimationClip)EditorGUILayout.ObjectField(
                "Grab AnimationClip",
                m_GrabAnimationClip,
                typeof(AnimationClip),
                false);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastOpenClipDiagnosticSummary = null;
                m_LastGrabClipDiagnosticSummary = null;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Open Clip 검사"))
                DiagnoseOpenClip();
            if (GUILayout.Button("Grab Clip 검사"))
                DiagnoseGrabClip();
            EditorGUILayout.EndHorizontal();

            if (foldDetails)
            {
                DrawClipDiagnosticResult(
                    "Open Clip 진단 결과",
                    m_LastOpenClipDiagnosticSummary,
                    m_LastOpenClipDiagnosticMessageType,
                    infoInFoldoutOnly: true);
                DrawClipDiagnosticResult(
                    "Grab Clip 진단 결과",
                    m_LastGrabClipDiagnosticSummary,
                    m_LastGrabClipDiagnosticMessageType,
                    infoInFoldoutOnly: true);

                m_FoldStep3ClipDiagnostic = EditorGUILayout.Foldout(
                    m_FoldStep3ClipDiagnostic,
                    "Clip 진단 상세");
                if (m_FoldStep3ClipDiagnostic)
                {
                    EditorGUILayout.HelpBox(
                        $"{HandSideUtility.GetOpenPoseName(m_HandSide)}.anim / {HandSideUtility.GetGrabPoseName(m_HandSide)}.anim에 손가락 외 Transform 곡선(루트/손목/손바닥 등)이 포함됐는지 검사합니다.\n" +
                        "Clip 내용은 수정하지 않으며 결과만 표시합니다.",
                        MessageType.Info);
                    if (!string.IsNullOrEmpty(m_LastOpenClipDiagnosticSummary)
                        && m_LastOpenClipDiagnosticMessageType == MessageType.Info)
                    {
                        DrawClipDiagnosticResult(
                            "Open Clip 진단 결과",
                            m_LastOpenClipDiagnosticSummary,
                            m_LastOpenClipDiagnosticMessageType,
                            infoInFoldoutOnly: false);
                    }

                    if (!string.IsNullOrEmpty(m_LastGrabClipDiagnosticSummary)
                        && m_LastGrabClipDiagnosticMessageType == MessageType.Info)
                    {
                        DrawClipDiagnosticResult(
                            "Grab Clip 진단 결과",
                            m_LastGrabClipDiagnosticSummary,
                            m_LastGrabClipDiagnosticMessageType,
                            infoInFoldoutOnly: false);
                    }
                }
            }
            else
            {
                EditorGUILayout.LabelField("AnimationClip 진단", EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(
                    $"{HandSideUtility.GetOpenPoseName(m_HandSide)}.anim / {HandSideUtility.GetGrabPoseName(m_HandSide)}.anim에 손가락 외 Transform 곡선(루트/손목/손바닥 등)이 포함됐는지 검사합니다.\n" +
                    "Clip 내용은 수정하지 않으며 결과만 표시합니다.",
                    MessageType.Info);
                DrawClipDiagnosticResult(
                    "Open Clip 진단 결과",
                    m_LastOpenClipDiagnosticSummary,
                    m_LastOpenClipDiagnosticMessageType,
                    infoInFoldoutOnly: false);
                DrawClipDiagnosticResult(
                    "Grab Clip 진단 결과",
                    m_LastGrabClipDiagnosticSummary,
                    m_LastGrabClipDiagnosticMessageType,
                    infoInFoldoutOnly: false);
            }
        }

        void DrawClipDiagnosticResult(
            string label,
            string summary,
            MessageType messageType,
            bool infoInFoldoutOnly)
        {
            if (string.IsNullOrEmpty(summary))
            {
                return;
            }

            if (infoInFoldoutOnly && messageType == MessageType.Info)
            {
                return;
            }

            EditorGUILayout.LabelField(label, EditorStyles.miniBoldLabel);
            EditorGUILayout.HelpBox(summary, messageType);
        }

        void DiagnoseOpenClip()
        {
            var result = HandAnimationClipDiagnostic.Diagnose(m_OpenAnimationClip, m_HandSide);
            HandAnimationClipDiagnostic.LogToConsole(result);
            m_LastOpenClipDiagnosticMessageType =
                result.success && result.isHealthy ? MessageType.Info : MessageType.Warning;
            m_LastOpenClipDiagnosticSummary = result.summary;
        }

        void DiagnoseGrabClip()
        {
            var result = HandAnimationClipDiagnostic.Diagnose(m_GrabAnimationClip, m_HandSide);
            HandAnimationClipDiagnostic.LogToConsole(result);
            m_LastGrabClipDiagnosticMessageType =
                result.success && result.isHealthy ? MessageType.Info : MessageType.Warning;
            m_LastGrabClipDiagnosticSummary = result.summary;
        }

        void DrawLastResultSection()
        {
            if (string.IsNullOrEmpty(m_LastResultSummary) && string.IsNullOrEmpty(m_LastSavedAssetPath))
                return;

            EditorGUILayout.LabelField("마지막 결과", EditorStyles.boldLabel);

            if (!string.IsNullOrEmpty(m_LastSavedAssetPath))
                EditorGUILayout.LabelField("저장 경로", m_LastSavedAssetPath);

            if (!string.IsNullOrEmpty(m_LastResultSummary))
                EditorGUILayout.HelpBox(m_LastResultSummary, m_LastResultMessageType);
        }

        void CaptureAndSave(string poseName, bool assignOpenAsset = false, bool assignGrabAsset = false)
        {
            if (m_TrackingHandRoot == null)
            {
                ShowFailure("Tracking Hand Root가 지정되지 않았습니다.");
                return;
            }

            var skeletonDriver = m_TrackingHandRoot.GetComponent<XRHandSkeletonDriver>();
            var trackingEvents = m_TrackingHandRoot.GetComponent<XRHandTrackingEvents>();

            var captureResult = HandPoseCaptureService.Capture(
                m_TrackingHandRoot,
                skeletonDriver,
                trackingEvents,
                m_TargetTransform,
                poseName,
                m_HandSide);

            if (!captureResult.success)
            {
                var sb = new StringBuilder();
                sb.AppendLine(captureResult.message);
                foreach (var error in captureResult.errors)
                    sb.AppendLine("• " + error);
                ShowFailure(sb.ToString().TrimEnd());
                return;
            }

            var saveResult = HandPoseAssetFactory.SavePoseAsset(captureResult, poseName);
            if (!saveResult.success)
            {
                ShowFailure(saveResult.message);
                return;
            }

            if (assignOpenAsset)
                m_CapturedOpenPoseAsset = saveResult.asset;
            if (assignGrabAsset)
                m_CapturedGrabPoseAsset = saveResult.asset;

            m_LastSavedAssetPath = saveResult.assetPath;
            m_LastResultMessageType = MessageType.Info;

            var summary = new StringBuilder();
            summary.AppendLine(saveResult.message);
            summary.AppendLine(captureResult.message);
            summary.AppendLine(
                $"Bone {saveResult.asset.capturedBoneCount}, Joint {saveResult.asset.capturedJointCount} " +
                $"(valid pose {saveResult.asset.validJointPoseCount})");
            summary.AppendLine(
                saveResult.asset.hasTargetRelativePose
                    ? $"Target relative: pos={saveResult.asset.targetRelativePosition}, rot={saveResult.asset.targetRelativeRotation.eulerAngles}"
                    : "Target relative: (none) — 위치 복원 불가");
            summary.AppendLine("Joint rotation = tracking-space (Bone localRotation과 분리).");

            if (captureResult.warnings.Count > 0)
            {
                summary.AppendLine("경고:");
                foreach (var warning in captureResult.warnings)
                    summary.AppendLine("• " + warning);
            }

            m_LastResultSummary = summary.ToString().TrimEnd();
        }

        void ExportAnimationClip(XRHandPoseAsset poseAsset, string clipBaseName)
        {
            var exportResult = HandPoseAnimationClipExporter.ExportPoseAsset(poseAsset, clipBaseName);
            if (!exportResult.success)
            {
                var sb = new StringBuilder(exportResult.message);
                foreach (var error in exportResult.errors)
                    sb.AppendLine("• " + error);
                ShowFailure(sb.ToString().TrimEnd());
                return;
            }

            m_LastSavedAssetPath = exportResult.clipPath;
            m_LastResultMessageType = MessageType.Info;
            m_LastResultSummary =
                $"{exportResult.message}\n" +
                $"Loop Time={exportResult.loopTime}, Legacy={exportResult.legacy}, " +
                $"길이={exportResult.clipLength:F4}s, frameRate={exportResult.frameRate}";

            AssignExportedAnimationClip(clipBaseName, exportResult.clip);
        }

        void AssignExportedAnimationClip(string clipBaseName, AnimationClip clip)
        {
            if (clip == null || string.IsNullOrWhiteSpace(clipBaseName))
                return;

            if (string.Equals(
                    clipBaseName,
                    HandSideUtility.GetOpenPoseName(m_HandSide),
                    StringComparison.Ordinal))
            {
                m_OpenAnimationClip = clip;
            }
            else if (string.Equals(
                         clipBaseName,
                         HandSideUtility.GetGrabPoseName(m_HandSide),
                         StringComparison.Ordinal))
            {
                m_GrabAnimationClip = clip;
            }
        }

        void ExportBothAnimationClips()
        {
            var openResult = HandPoseAnimationClipExporter.ExportPoseAsset(
                m_CapturedOpenPoseAsset,
                HandSideUtility.GetOpenPoseName(m_HandSide));
            if (!openResult.success)
            {
                ShowFailure(openResult.message);
                return;
            }

            var grabResult = HandPoseAnimationClipExporter.ExportPoseAsset(
                m_CapturedGrabPoseAsset,
                HandSideUtility.GetGrabPoseName(m_HandSide));
            if (!grabResult.success)
            {
                ShowFailure($"Open 클립은 저장됨 ({openResult.clipPath}). Grab 실패: {grabResult.message}");
                return;
            }

            m_LastSavedAssetPath = $"{openResult.clipPath}\n{grabResult.clipPath}";
            m_LastResultMessageType = MessageType.Info;
            m_LastResultSummary =
                $"Open: {openResult.clipPath} (본 {openResult.animatedBoneCount}, 커브 {openResult.curveCount})\n" +
                $"Grab: {grabResult.clipPath} (본 {grabResult.animatedBoneCount}, 커브 {grabResult.curveCount})\n" +
                $"Loop Time={openResult.loopTime}, Legacy={openResult.legacy}, frameRate={openResult.frameRate}";

            m_OpenAnimationClip = openResult.clip;
            m_GrabAnimationClip = grabResult.clip;
        }

        static bool IsExportReady(XRHandPoseAsset asset)
        {
            return asset != null
                && asset.bones != null
                && asset.bones.Count == HandSkeletonCatalog.RequiredBoneCount;
        }

        void FindTrackedHand()
        {
            m_PendingTrackedCandidates = null;
            var findResult = HandPoseTrackedHandFinder.FindTrackedHand(m_HandSide);
            if (!findResult.success)
            {
                if (findResult.candidates != null && findResult.candidates.Count > 1)
                {
                    m_PendingTrackedCandidates = findResult.candidates;
                    m_LastResultMessageType = MessageType.Warning;
                    m_LastResultSummary = findResult.message;
                    Repaint();
                    return;
                }

                ShowFailure(findResult.message);
                return;
            }

            m_TrackingHandRoot = findResult.handRoot;
            m_LastResultMessageType = MessageType.Info;
            m_LastResultSummary = findResult.message;
            Repaint();
        }

        void DrawHandSideContextBox()
        {
            var gripLabel = m_GripInputAction != null
                ? AssetDatabase.GetAssetPath(m_GripInputAction)
                : "(none)";
            var trackingLabel = m_TrackingHandRoot != null
                ? HandPoseCaptureService.GetHierarchyPath(m_TrackingHandRoot)
                : "(none)";
            var playbackLabel = m_PlaybackHandRoot != null
                ? HandPoseCaptureService.GetHierarchyPath(m_PlaybackHandRoot)
                : "(none)";

            EditorGUILayout.HelpBox(
                $"현재 작업 손: {HandSideUtility.GetLabel(m_HandSide)}\n" +
                $"Tracking Root: {trackingLabel}\n" +
                $"Playback Root: {playbackLabel}\n" +
                $"Grip Action: {gripLabel}",
                MessageType.None);
        }

        void ApplyHandSideDefaults(HandSide oldSide, HandSide newSide)
        {
            m_PendingGripCandidates = null;
            m_PendingPlaybackCandidates = null;
            m_PendingTrackedCandidates = null;
            m_InteractorCandidates = null;
            m_InteractorCandidate = null;
            m_Step2AutoSearchDone = false;
            m_LastGripFindSummary = null;

            if (m_TrackingHandRoot != null && !HandSideUtility.MatchesHandSide(m_TrackingHandRoot, newSide))
                m_TrackingHandRoot = null;

            if (m_PlaybackHandRoot != null && !HandSideUtility.MatchesHandSide(m_PlaybackHandRoot, newSide))
                m_PlaybackHandRoot = null;

            if (m_GripInputAction != null)
            {
                var gripPath = AssetDatabase.GetAssetPath(m_GripInputAction);
                var oldDefaultPath = HandSideUtility.GetGripReferenceAssetPath(oldSide);
                if (string.Equals(gripPath, oldDefaultPath, StringComparison.OrdinalIgnoreCase))
                    m_GripInputAction = null;
            }

            if (HandSideUtility.IsDefaultCurrentPoseName(m_PoseName, oldSide))
                m_PoseName = HandSideUtility.GetCurrentPoseDefaultName(newSide);

            if (HandSideUtility.IsDefaultGrabSnapshotOutputName(m_GrabSnapshotOutputName, oldSide))
                m_GrabSnapshotOutputName = HandSideUtility.GetGrabSnapshotOutputName(newSide);

            if (IsAssetAtPath(
                    m_CapturedOpenPoseAsset,
                    $"{HandSideUtility.PosesOutputFolder}/{HandSideUtility.GetOpenPoseName(oldSide)}.asset"))
            {
                m_CapturedOpenPoseAsset = LoadPoseAssetIfExists(
                    $"{HandSideUtility.PosesOutputFolder}/{HandSideUtility.GetOpenPoseName(newSide)}.asset");
            }

            if (IsAssetAtPath(m_CapturedGrabPoseAsset, HandSideUtility.GetDefaultGrabPoseAssetPath(oldSide)))
                m_CapturedGrabPoseAsset = HandGrabSnapshotExporter.TryLoadDefaultSourcePose(newSide);

            if (IsAssetAtPath(m_GrabSnapshotSourceAsset, HandSideUtility.GetDefaultGrabPoseAssetPath(oldSide)))
                m_GrabSnapshotSourceAsset = HandGrabSnapshotExporter.TryLoadDefaultSourcePose(newSide);

            if (IsAssetAtPath(m_GhostGrabSnapshot, HandSideUtility.GetDefaultGrabSnapshotAssetPath(oldSide)))
                m_GhostGrabSnapshot = HandGhostPreviewService.TryLoadDefaultGrabSnapshot(newSide);

            if (IsAssetAtPath(m_OpenAnimationClip, HandSideUtility.GetDefaultOpenAnimationClipPath(oldSide)))
                m_OpenAnimationClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(
                    HandSideUtility.GetDefaultOpenAnimationClipPath(newSide));

            if (IsAssetAtPath(m_GrabAnimationClip, HandSideUtility.GetDefaultGrabAnimationClipPath(oldSide)))
                m_GrabAnimationClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(
                    HandSideUtility.GetDefaultGrabAnimationClipPath(newSide));

            if (IsAssetAtPath(m_AnimatorController, HandSideUtility.GetAnimatorControllerPath(oldSide)))
            {
                m_AnimatorController = HandSideUtility.TryLoadDefaultAnimatorController(newSide);
            }

            if (HandSideUtility.IsDefaultOpenPoseName(m_PoseName, oldSide))
                m_PoseName = HandSideUtility.GetOpenPoseName(newSide);
            else if (HandSideUtility.IsDefaultGrabPoseName(m_PoseName, oldSide))
                m_PoseName = HandSideUtility.GetGrabPoseName(newSide);
        }

        static bool IsAssetAtPath(UnityEngine.Object asset, string assetPath)
        {
            if (asset == null || string.IsNullOrEmpty(assetPath))
                return false;

            return string.Equals(AssetDatabase.GetAssetPath(asset), assetPath, StringComparison.OrdinalIgnoreCase);
        }

        static XRHandPoseAsset LoadPoseAssetIfExists(string assetPath)
        {
            return AssetDatabase.LoadAssetAtPath<XRHandPoseAsset>(assetPath);
        }

        void DrawTrackedHandCandidates()
        {
            if (m_PendingTrackedCandidates == null || m_PendingTrackedCandidates.Count == 0)
                return;

            EditorGUILayout.HelpBox(
                "Tracking Hand 후보가 여러 개입니다. 하나를 선택하세요.",
                MessageType.Warning);
            foreach (var candidate in m_PendingTrackedCandidates)
            {
                if (GUILayout.Button(candidate.hierarchyPath))
                {
                    m_TrackingHandRoot = candidate.handRoot;
                    m_PendingTrackedCandidates = null;
                    m_LastResultMessageType = MessageType.Info;
                    m_LastResultSummary = $"Tracking Hand 선택: {candidate.hierarchyPath}";
                    Repaint();
                }
            }
        }

        void DrawPlaybackHandCandidates()
        {
            if (m_PendingPlaybackCandidates == null || m_PendingPlaybackCandidates.Count == 0)
                return;

            EditorGUILayout.HelpBox(
                "Playback Hand 후보가 여러 개입니다. 하나를 선택하세요.",
                MessageType.Warning);
            foreach (var candidate in m_PendingPlaybackCandidates)
            {
                var label = candidate.hierarchyPath;
                if (candidate.matchesNameHint)
                    label += " [name]";
                if (candidate.underControllerHierarchy)
                    label += " [controller]";

                if (GUILayout.Button(label))
                {
                    SetPlaybackHandRoot(candidate.handRoot);
                    m_PendingPlaybackCandidates = null;
                    m_LastControllerSetupMessageType = MessageType.Info;
                    m_LastControllerSetupSummary = $"Playback Hand 선택: {candidate.hierarchyPath}";
                    Repaint();
                }
            }
        }

        void RefreshInteractorCandidates()
        {
            m_InteractorCandidates = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            m_InteractorCandidate = m_InteractorCandidates.Count == 1
                ? m_InteractorCandidates[0].interactor
                : null;
        }

        void DrawInteractorCandidates()
        {
            if (m_InteractorCandidates == null || m_InteractorCandidates.Count <= 1)
                return;

            EditorGUILayout.HelpBox(
                "Interactor 후보가 여러 개입니다. 하나를 선택하세요.",
                MessageType.None);
            foreach (var candidate in m_InteractorCandidates)
            {
                var label = $"{candidate.objectName} ({candidate.componentTypeName})\n{candidate.hierarchyPath}";
                if (GUILayout.Button(label))
                {
                    m_InteractorCandidate = candidate.interactor;
                    Repaint();
                }
            }
        }

        void ShowFailure(string message)
        {
            m_LastSavedAssetPath = null;
            m_LastResultMessageType = MessageType.Error;
            m_LastResultSummary = message;
        }

        // ════════════════════════════════════════════════════════════════════
        //  1차 / 2차 모드별 완료 판정
        // ════════════════════════════════════════════════════════════════════

        bool IsStepCompleteForMode(int step)
        {
            return m_WorkMode == WorkMode.Mode1_Animation
                ? IsMode1StepComplete(step)
                : IsMode2StepComplete(step);
        }

        bool IsMode1StepComplete(int step)
        {
            switch (step)
            {
                case 1: return IsStep1Complete();
                case 2: return IsExportReady(m_CapturedOpenPoseAsset) && IsExportReady(m_CapturedGrabPoseAsset);
                case 3: return m_OpenAnimationClip != null
                             && m_GrabAnimationClip != null
                             && m_AnimatorController != null;
                case 4:
                    if (m_GripControlMode == HandGripControlMode.ProjectLegacy)
                    {
                        return HandPoseControllerHandSetupService.EvaluateReadiness(
                            m_PlaybackHandRoot, m_AnimatorController,
                            m_GripInputAction, m_GripParameterName,
                            m_HandSide, m_GripControlMode).canApply;
                    }

                    return HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                        m_PlaybackHandRoot,
                        m_AnimatorController,
                        m_GripInputAction,
                        m_GripParameterName).isValid;
                case 5: return IsMode1StepComplete(1) && IsMode1StepComplete(2) && IsMode1StepComplete(3)
                               && IsMode1StepComplete(4);
                default: return false;
            }
        }

        bool IsMode2StepComplete(int step)
        {
            if (m_GhostTargetGrabObject == null && step > 1) return false;
            switch (step)
            {
                case 1: return m_GhostTargetGrabObject != null;
                case 2:
                    var b2 = m_GhostTargetGrabObject?.GetComponent<HandGrabPoseBinding>();
                    return b2 != null && b2.TryGetRecord(m_HandSide, out _);
                case 3:
                    if (m_GhostTargetGrabObject == null) return false;
                    for (int ci = 0; ci < m_GhostTargetGrabObject.transform.childCount; ci++)
                        if (m_GhostTargetGrabObject.transform.GetChild(ci).name == HandGhostPreviewService.GhostsRootName)
                            return true;
                    return false;
                case 4:
                    return HandSideAwareGrabInteractableMigrationService
                        .EvaluateReadiness(m_GhostTargetGrabObject).existingHandSideAware != null;
                case 5:
                {
                    if (!IsMode2StepComplete(1) || !IsMode2StepComplete(2) || !IsMode2StepComplete(3))
                        return false;
                    var b5 = m_GhostTargetGrabObject?.GetComponent<HandGrabPoseBinding>();
                    return b5 != null && b5.IsWristCorrectionApplied(m_HandSide);
                }
                default: return false;
            }
        }

        // ════════════════════════════════════════════════════════════════════
        //  1차 · 기본 손 애니메이션 만들기
        // ════════════════════════════════════════════════════════════════════

        void DrawMode1Step(int step)
        {
            switch (step)
            {
                case 1: DrawMode1Step1_HandPrep(); break;
                case 2: DrawMode1Step2_OpenGripCapture(); break;
                case 3: DrawMode1Step3_ClipBlendTree(); break;
                case 4: DrawMode1Step4_ControllerSetup(); break;
                case 5: DrawMode1Step5_Complete(); break;
            }
        }

        void DrawMode1Step1_HandPrep()
        {
            EditorGUILayout.LabelField("① 손 준비", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "XR Hands HandVisualizer Sample을 공식 Import하고,\n" +
                "선택 손 Tracking Hand · Playback Hand · Grip을 한 번에 구성합니다.\n" +
                "HandVisualizer 자산은 패키지에 복사하지 않습니다.",
                MessageType.Info);

            DrawSelectedHandFullPrepSection();
            EditorGUILayout.Space(8f);

            m_FoldStep1SetupDetails = EditorGUILayout.Foldout(
                m_FoldStep1SetupDetails,
                "세부: Playback Hand 최소 설정 / 수동 지정",
                true);
            if (m_FoldStep1SetupDetails)
            {
                EditorGUI.indentLevel++;
                DrawPlaybackHandMinimalSetupSection(foldDetails: true);
                EditorGUILayout.Space(6f);
                DrawStep1PlaybackHandAndGripFields();
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space(6f);
            DrawStep1TrackingHandField();
            EditorGUILayout.Space(6f);
            DrawStep1ReadinessSummary();
            DrawFullPrepChecklistSummary();

            if (IsStep1Complete())
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox("손 준비 완료 — 다음 단계로 이동하세요.", MessageType.Info);
                if (GUILayout.Button("다음: Open·Grip Pose 캡처 ▶"))
                    m_Mode1Step = 2;
            }
        }

        void DrawSelectedHandFullPrepSection()
        {
            EditorGUILayout.LabelField("선택 손 전체 준비", EditorStyles.boldLabel);

            if (m_FullPrepImportInProgress
                || (!string.IsNullOrEmpty(HandVisualizerSampleImportService.LastStatusMessage)
                    && HandVisualizerSampleImportService.HasPendingSetup
                    && !HandVisualizerSampleImportService.TryGetImportedSample(out _, out _)))
            {
                EditorGUILayout.HelpBox(
                    string.IsNullOrEmpty(m_FullPrepStatusMessage)
                        ? HandSelectedHandFullPrepService.ImportProgressMessage
                        : m_FullPrepStatusMessage,
                    MessageType.Info);
            }
            else if (HandVisualizerSampleImportService.NeedsManualContinue)
            {
                EditorGUILayout.HelpBox(
                    HandVisualizerSampleImportService.LastStatusMessage,
                    MessageType.Warning);
            }

            var buttonLabel = HandSelectedHandFullPrepService.GetPrimaryButtonLabel();
            using (new EditorGUI.DisabledScope(m_FullPrepImportInProgress && !HandVisualizerSampleImportService.NeedsManualContinue))
            {
                if (GUILayout.Button(buttonLabel, GUILayout.Height(32f)))
                {
                    ExecuteSelectedHandFullPrep(resumeAfterImport: false);
                }
            }

            if (!string.IsNullOrEmpty(m_LastFullPrepSummary))
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(m_LastFullPrepSummary, m_LastFullPrepMessageType);
            }
        }

        void DrawStep1TrackingHandField()
        {
            EditorGUI.BeginChangeCheck();
            m_TrackingHandRoot = (Transform)EditorGUILayout.ObjectField(
                "Tracking Hand Root",
                m_TrackingHandRoot,
                typeof(Transform),
                true);
            if (EditorGUI.EndChangeCheck())
                RefreshFullPrepChecklist();
        }

        void DrawFullPrepChecklistSummary()
        {
            RefreshFullPrepChecklist();
            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("전체 준비 체크리스트", EditorStyles.boldLabel);
            DrawMode1StatusRow("XR Hands 패키지 설치됨", m_FullPrepChecklist.xrHandsInstalled);
            DrawMode1StatusRow("HandVisualizer Sample Import됨", m_FullPrepChecklist.sampleImported);
            DrawMode1StatusRow("선택 손 Tracking Prefab 확인됨", m_FullPrepChecklist.trackingPrefabResolved);
            DrawMode1StatusRow("Tracking Hand 생성/재사용됨", m_FullPrepChecklist.trackingHandReady);
            DrawMode1StatusRow("Tracking 26 Joint 검증됨", m_FullPrepChecklist.trackingJointsValid);
            DrawMode1StatusRow("Playback Hand 생성/재사용됨", m_FullPrepChecklist.playbackHandReady);
            DrawMode1StatusRow("Grip Input Action 연결됨", m_FullPrepChecklist.gripConnected);
        }

        void RefreshFullPrepChecklist()
        {
            m_FullPrepChecklist = HandSelectedHandFullPrepService.EvaluateChecklist(
                m_HandSide,
                m_TrackingHandRoot,
                m_PlaybackHandRoot,
                m_GripInputAction);
        }

        void ExecuteSelectedHandFullPrep(bool resumeAfterImport)
        {
            m_FullPrepImportInProgress = false;
            m_LastFullPrepSummary = null;

            var result = resumeAfterImport
                ? HandSelectedHandFullPrepService.ContinueAfterSampleReady(
                    m_HandSide,
                    m_PlaybackSetupPlacementParent)
                : HandSelectedHandFullPrepService.RunFullPrep(
                    m_HandSide,
                    m_PlaybackSetupPlacementParent);

            ApplyFullPrepResult(result);
        }

        void ApplyFullPrepResult(HandSelectedHandFullPrepService.PrepResult result)
        {
            m_FullPrepChecklist = result.checklist;
            m_FullPrepStatusMessage = result.statusMessage;
            m_FullPrepImportInProgress = result.importInProgress;

            if (result.trackingHandRoot != null)
                m_TrackingHandRoot = result.trackingHandRoot;
            if (result.playbackHandRoot != null)
            {
                SetPlaybackHandRoot(result.playbackHandRoot);
                HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                    result.playbackHandRoot, m_HandSide, out _, out _);
            }
            if (result.gripInputAction != null)
                m_GripInputAction = result.gripInputAction;

            if (result.importInProgress)
            {
                m_LastFullPrepMessageType = MessageType.Info;
                m_LastFullPrepSummary = result.message;
                Repaint();
                return;
            }

            if (result.needsManualContinue)
            {
                m_LastFullPrepMessageType = MessageType.Warning;
                m_LastFullPrepSummary = result.message;
                Repaint();
                return;
            }

            if (!result.success)
            {
                m_LastFullPrepMessageType = MessageType.Error;
                m_LastFullPrepSummary = result.message;
                Debug.LogError($"[HandSelectedHandFullPrep] {result.message}");
                Repaint();
                return;
            }

            m_LastFullPrepMessageType = MessageType.Info;
            m_LastFullPrepSummary = result.message;
            Debug.Log($"[HandSelectedHandFullPrep] {result.message}", result.trackingHandRoot);
            SaveWindowState();
            Repaint();
        }

        void DrawMode1Step2_OpenGripCapture()
        {
            EditorGUILayout.LabelField("② Hand Tracking Open·Grip Pose 캡처 (1차: Grip 애니메이션용)", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Play Mode에서 Hand Tracking 손으로 Open / Grip 모양을 각각 만들고 캡처합니다.\n" +
                "캡처한 Pose Asset 두 개가 다음 단계에서 AnimationClip으로 변환됩니다.\n" +
                "여기서 말하는 'Grip Pose'는 물체를 잡는 자세가 아닌 손의 기본 Grip 형태입니다.",
                MessageType.Info);
            DrawStep2ContextSummary();
            EditorGUILayout.Space(4f);
            DrawXRHandPoseAssetCaptureSection();
            EditorGUILayout.Space(6f);
            DrawLastResultSection();
        }

        void DrawMode1Step3_ClipBlendTree()
        {
            EditorGUILayout.LabelField("③ Open·Grip Clip 및 Blend Tree 생성", EditorStyles.boldLabel);

            // Pose Asset 참조 확인
            EditorGUI.BeginChangeCheck();
            m_CapturedOpenPoseAsset = (XRHandPoseAsset)EditorGUILayout.ObjectField(
                "Open Pose Asset", m_CapturedOpenPoseAsset, typeof(XRHandPoseAsset), false);
            m_CapturedGrabPoseAsset = (XRHandPoseAsset)EditorGUILayout.ObjectField(
                "Grip Pose Asset", m_CapturedGrabPoseAsset, typeof(XRHandPoseAsset), false);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastResultSummary = null;
                m_LastSavedAssetPath = null;
            }

            EditorGUILayout.Space(4f);
            // 주 경로: Open·Grip → AnimationClip 생성
            EditorGUILayout.LabelField("Step A  AnimationClip 생성", EditorStyles.miniBoldLabel);
            DrawExportButtons(foldHelp: false);
            EditorGUILayout.Space(4f);

            // Open/Grip Clip 참조 필드
            DrawAnimationClipDiagnosticSection(foldDetails: true);
            EditorGUILayout.Space(6f);

            // 주 경로: Blend Tree + AnimatorController 생성
            EditorGUILayout.LabelField("Step B  Blend Tree + AnimatorController 생성", EditorStyles.miniBoldLabel);
            EditorGUILayout.HelpBox(
                "캡처한 Open·Grip Clip으로 Grip float 기반 1D Blend Tree를 만들고 AnimatorController를 저장합니다.",
                MessageType.None);
            DrawAnimatorControllerSetupSection();

            EditorGUILayout.Space(6f);

            // 보조 경로: 기존 Controller 연결
            m_FoldMode1QuickConnect = EditorGUILayout.Foldout(
                m_FoldMode1QuickConnect, "보조: 기존 Controller 찾아 연결");
            if (m_FoldMode1QuickConnect)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.HelpBox(
                    "이미 OculusHand_R.controller 같은 Controller가 있다면 여기서 바로 연결할 수 있습니다.",
                    MessageType.None);
                DrawQuickControllerSetupSection();
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space(4f);
            DrawLastResultSection();
        }

        void DrawMode1Step4_ControllerSetup()
        {
            EditorGUILayout.LabelField("④ Controller Hand 연결 및 Grip 버튼 설정", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Playback Hand의 Animator에 Controller를 연결하고 Grip 입력 드라이버를 설정합니다.\n" +
                "Edit Mode에서는 Scene에 즉시 적용되고, Play Mode에서는 종료 후 Scene에 자동 적용됩니다.",
                MessageType.Info);

            var setupStatus = HandPoseControllerHandPendingSetupBridge.GetStatus(m_HandSide);
            var setupUi = HandPoseControllerHandPendingSetupBridge.GetStatusUiMessage(m_HandSide);
            if (!string.IsNullOrEmpty(setupUi))
            {
                var msgType = setupStatus == HandPoseControllerHandPendingSetupBridge.PendingLifecycleStatus.FailedToResolveTarget
                              || setupStatus == HandPoseControllerHandPendingSetupBridge.PendingLifecycleStatus.FailedToApply
                    ? MessageType.Error
                    : setupStatus == HandPoseControllerHandPendingSetupBridge.PendingLifecycleStatus.PendingWaitingForEditMode
                        ? MessageType.Warning
                        : MessageType.Info;
                EditorGUILayout.HelpBox(setupUi, msgType);
            }

            if (!Application.isPlaying)
            {
                EditorGUILayout.Space(4f);
                using (new EditorGUI.DisabledScope(m_PlaybackHandRoot == null))
                {
                    if (GUILayout.Button("현재 Edit Mode Scene에 Controller 설정 재적용", GUILayout.Height(28f)))
                        ReapplyControllerSetupInEditMode();
                }

                EditorGUILayout.HelpBox(
                    "Play Mode 없이 현재 Playback Hand Root에 Animator·Driver·IAM을 바로 적용합니다.\n" +
                    "복원 실패 pending이 있어도 설정값을 재사용해 Edit Mode Root에 적용할 수 있습니다.",
                    MessageType.None);
            }

            DrawControllerHandSetupSection(foldDetails: true);
            if (!string.IsNullOrEmpty(m_LastControllerSetupSummary))
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(m_LastControllerSetupSummary, m_LastControllerSetupMessageType);
            }

            EditorGUILayout.Space(10f);
            DrawControllerAlignmentSection();
        }

        void ReapplyControllerSetupInEditMode()
        {
            CapturePlaybackHandLocatorIfPossible();
            HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                m_PlaybackHandRoot, m_HandSide, out _, out _);

            var result = HandPoseControllerHandPendingSetupBridge.TryReapplyInEditMode(
                m_HandSide,
                m_PlaybackHandRoot,
                m_AnimatorController,
                m_GripInputAction,
                m_GripParameterName,
                m_UseSmoothing,
                m_SmoothingSpeed,
                m_GripControlMode);

            m_LastControllerSetupMessageType = result.success ? MessageType.Info : MessageType.Error;
            m_LastControllerSetupSummary = result.message;
            Repaint();
        }

        // ── Controller 손 방향 자동 정렬 섹션 ────────────────────────────────

        void DrawControllerAlignmentSection()
        {
            EditorGUILayout.LabelField("Controller 손 방향 자동 정렬", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Hand Tracking 손을 자연스럽게 편 상태에서 버튼을 누르면\n" +
                "Controller 손이 같은 위치와 방향으로 정렬됩니다.\n" +
                "Play Mode에서 계산한 정렬값은 종료 후 Edit Mode Scene에 자동 적용됩니다.\n" +
                "(Play Mode Transform 변경만으로는 저장되지 않습니다.)\n\n" +
                "[정렬 미리보기 모드]\n" +
                "Controller Hand 메시 클론을 Tracking Hand 손목 위치에 겹쳐 표시합니다.\n" +
                "원본 오브젝트는 수정하지 않으며, 클론에는 입력·Interactor가 없습니다.",
                MessageType.Info);

            // ─ 현재 상태 표시 ─
            var ready = HandControllerVisualAlignmentService.EvaluateReadiness(
                m_HandSide, m_TrackingHandRoot, m_PlaybackHandRoot);

            var (hasVO, voLocalPos, voLocalRot) =
                HandControllerVisualAlignmentService.GetVisualOffsetState(m_HandSide, m_PlaybackHandRoot);
            var hasAlignPending = HandControllerVisualAlignmentService.GetPendingStatus(m_HandSide)
                == HandControllerVisualAlignmentService.PendingApplyStatus.PendingWaitingForEditMode
                || HandControllerVisualAlignmentService.GetPendingStatus(m_HandSide)
                == HandControllerVisualAlignmentService.PendingApplyStatus.ApplyingInEditMode;
            var voAuthored = HandControllerVisualAlignmentService.IsVisualOffsetAuthoredInEditMode(
                m_HandSide, m_PlaybackHandRoot);

            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("상태", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("Tracking Hand Root 설정", m_TrackingHandRoot != null);
            DrawMode1StatusRow("Controller Hand Root 설정", m_PlaybackHandRoot != null);
            DrawMode1StatusRow("Tracking Wrist 발견", ready.trackingWrist != null);
            DrawMode1StatusRow("Controller Wrist 발견", ready.controllerWrist != null);
            if (hasAlignPending)
            {
                DrawMode1StatusRow("Visual Offset 적용됨", false);
            }
            else
            {
                DrawMode1StatusRow("Visual Offset 적용됨", voAuthored || (!Application.isPlaying && hasVO));
            }

            if (hasVO && !hasAlignPending)
            {
                EditorGUILayout.HelpBox(
                    $"Visual Offset: {HandControllerVisualAlignmentService.GetVisualOffsetName(m_HandSide)}\n" +
                    $"localPos={voLocalPos:F4}  eulerRot={voLocalRot.eulerAngles:F2}",
                    MessageType.None);
            }

            var alignUiMessage = HandControllerVisualAlignmentService.GetPendingUiMessage(m_HandSide);
            if (!string.IsNullOrEmpty(alignUiMessage))
            {
                var alignStatus = HandControllerVisualAlignmentService.GetPendingStatus(m_HandSide);
                var alignMsgType = alignStatus == HandControllerVisualAlignmentService.PendingApplyStatus.Failed
                    ? MessageType.Error
                    : MessageType.Info;
                EditorGUILayout.HelpBox(alignUiMessage, alignMsgType);
            }

            // ══════════════════════════════════════════════════════════════
            // ── 정렬 미리보기 모드 ──────────────────────────────────────
            // ══════════════════════════════════════════════════════════════

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("정렬 미리보기 모드", EditorStyles.miniBoldLabel);

            bool isPreviewActive = HandAlignmentPreviewService.IsPreviewActive;

            // 미리보기 상태 표시
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = isPreviewActive
                ? new Color(0.3f, 1f, 0.5f)
                : new Color(0.85f, 0.85f, 0.85f);
            EditorGUILayout.LabelField(
                $"미리보기: {HandAlignmentPreviewService.GetStatusLabel()}",
                EditorStyles.helpBox);
            GUI.backgroundColor = prevBg;

            EditorGUILayout.Space(4f);

            if (!isPreviewActive)
            {
                // 미리보기 시작 버튼
                bool hasTracking    = m_TrackingHandRoot != null;
                bool hasController  = m_PlaybackHandRoot != null;
                bool canStart       = hasTracking && hasController;

                EditorGUI.BeginDisabledGroup(!canStart);
                if (GUILayout.Button("정렬 미리보기 시작", GUILayout.Height(28f)))
                    ExecuteStartPreview();
                EditorGUI.EndDisabledGroup();

                if (!hasTracking)
                    EditorGUILayout.HelpBox(
                        "Tracking Hand Root를 먼저 지정하세요 (① 손 준비 단계).",
                        MessageType.Warning);
                else if (!hasController)
                    EditorGUILayout.HelpBox(
                        "Controller Hand Root(Playback Hand Root)를 먼저 지정하세요.",
                        MessageType.Warning);
            }
            else
            {
                // 미리보기 종료 버튼
                var prevBg2 = GUI.backgroundColor;
                GUI.backgroundColor = new Color(1f, 0.6f, 0.4f);
                if (GUILayout.Button("정렬 미리보기 종료", GUILayout.Height(28f)))
                    ExecuteEndPreview();
                GUI.backgroundColor = prevBg2;
            }

            // 미리보기 메시지
            if (!string.IsNullOrEmpty(m_LastPreviewMessage))
            {
                EditorGUILayout.Space(2f);
                EditorGUILayout.HelpBox(m_LastPreviewMessage, m_LastPreviewMessageType);
            }

            // ══════════════════════════════════════════════════════════════
            // ── 정렬 실행 ───────────────────────────────────────────────
            // ══════════════════════════════════════════════════════════════

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("정렬 실행", EditorStyles.miniBoldLabel);

            bool canAlign = ready.canAlign;
            EditorGUI.BeginDisabledGroup(!canAlign);

            if (GUILayout.Button("Tracking Hand 기준 위치·회전 정렬", GUILayout.Height(28f)))
                ExecuteAlignment(HandControllerVisualAlignmentService.AlignMode.PositionAndRotation);

            if (GUILayout.Button("Tracking Hand 기준 회전만 정렬", GUILayout.Height(28f)))
                ExecuteAlignment(HandControllerVisualAlignmentService.AlignMode.RotationOnly);

            EditorGUI.EndDisabledGroup();

            if (!canAlign && !string.IsNullOrEmpty(ready.blockReason))
            {
                EditorGUILayout.HelpBox(ready.blockReason, MessageType.Warning);
            }

            if (hasVO)
            {
                EditorGUILayout.Space(4f);
                if (GUILayout.Button("정렬값 원래대로 복구"))
                    ExecuteAlignmentRestore();
            }

            // ─ 정렬 결과 메시지 ─
            if (!string.IsNullOrEmpty(m_LastAlignmentMessage))
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(m_LastAlignmentMessage, m_LastAlignmentMessageType);
            }
        }

        void ExecuteStartPreview()
        {
            if (!Application.isPlaying
                && m_PlaybackHandRoot != null
                && !HandControllerVisualAlignmentService.TryEnsureVisualOffsetInEditMode(
                    m_PlaybackHandRoot, m_HandSide, out _, out var voError))
            {
                m_LastPreviewMessage = "Visual Offset 준비 실패: " + voError;
                m_LastPreviewMessageType = MessageType.Warning;
                Repaint();
                return;
            }

            CapturePlaybackHandLocatorIfPossible();

            var ok = HandAlignmentPreviewService.TryStartPreview(
                m_HandSide, m_TrackingHandRoot, m_PlaybackHandRoot, out var msg);

            m_LastPreviewMessage = msg;
            m_LastPreviewMessageType = ok ? MessageType.Info : MessageType.Warning;

            if (ok)
                Debug.Log($"[VRHandPoseTool] {msg}");
            else
                Debug.LogWarning($"[VRHandPoseTool] 미리보기 시작 실패: {msg}");

            Repaint();
        }

        void ExecuteEndPreview()
        {
            HandAlignmentPreviewService.EndPreview();
            m_LastPreviewMessage = "정렬 미리보기가 종료됐습니다. 정렬된 Visual Offset 값은 유지됩니다.";
            m_LastPreviewMessageType = MessageType.Info;
            Repaint();
        }

        void ExecuteAlignment(HandControllerVisualAlignmentService.AlignMode mode)
        {
            m_AlignMode = mode;
            var result = HandControllerVisualAlignmentService.TryAlign(
                m_HandSide, m_TrackingHandRoot, m_PlaybackHandRoot, mode);

            m_LastAlignmentMessage = result.message;
            m_LastAlignmentMessageType = result.success ? MessageType.Info : MessageType.Warning;

            if (result.success)
                Debug.Log($"[VRHandPoseTool] {result.message}");
            else
                Debug.LogWarning($"[VRHandPoseTool] 정렬 실패: {result.message}");

            Repaint();
        }

        void ExecuteAlignmentRestore()
        {
            var restored = HandControllerVisualAlignmentService.TryRestore(m_HandSide, m_PlaybackHandRoot);
            m_LastAlignmentMessage = restored
                ? "정렬값이 원래대로 복구됐습니다."
                : "복구 실패 — Visual Offset을 찾지 못했습니다.";
            m_LastAlignmentMessageType = restored ? MessageType.Info : MessageType.Warning;
            Repaint();
        }

        void DrawMode1Step5_Complete()
        {
            EditorGUILayout.LabelField("⑤ 1차 완료 상태", EditorStyles.boldLabel);
            EditorGUILayout.Space(4f);
            DrawMode1CompletionStatus();
        }

        void DrawMode1CompletionStatus()
        {
            var openPose   = IsExportReady(m_CapturedOpenPoseAsset);
            var gripPose   = IsExportReady(m_CapturedGrabPoseAsset);
            var openClip   = m_OpenAnimationClip != null;
            var grabClip   = m_GrabAnimationClip != null;
            var controller = m_AnimatorController != null;

            // Blend Tree / Grip 파라미터 검사 (AnimatorController가 있을 때만)
            bool hasBlendTree = false;
            bool hasGripParam = false;
            bool animatorConnected = false;
            if (m_AnimatorController != null)
            {
                var ac = m_AnimatorController as UnityEditor.Animations.AnimatorController;
                if (ac != null)
                {
                    foreach (var p in ac.parameters)
                    {
                        if (p.name == m_GripParameterName &&
                            p.type == AnimatorControllerParameterType.Float)
                        { hasGripParam = true; break; }
                    }
                    foreach (var layer in ac.layers)
                    {
                        foreach (var s in layer.stateMachine.states)
                        {
                            if (s.state.motion is UnityEditor.Animations.BlendTree)
                            { hasBlendTree = true; break; }
                        }
                        if (hasBlendTree) break;
                    }
                }

                if (m_PlaybackHandRoot != null)
                {
                    var anim = m_PlaybackHandRoot.GetComponent<Animator>()
                               ?? m_PlaybackHandRoot.GetComponentInParent<Animator>();
                    animatorConnected = anim != null && anim.runtimeAnimatorController == m_AnimatorController;
                }
            }

            var setupPending = HandPoseControllerHandPendingSetupBridge.IsWaitingForEditMode(m_HandSide);
            var setupFailed = HandPoseControllerHandPendingSetupBridge.HasFailedPending(m_HandSide);
            var alignStatus = HandControllerVisualAlignmentService.GetPendingStatus(m_HandSide);
            var alignPending = alignStatus == HandControllerVisualAlignmentService.PendingApplyStatus.PendingWaitingForEditMode
                               || alignStatus == HandControllerVisualAlignmentService.PendingApplyStatus.ApplyingInEditMode;
            var authoringBlockedByPending = setupPending || alignPending;

            // Grip Driver / InputActionManager — 선택 Playback Hand Root 기준 (반대 손 Driver로 완료 처리 금지)
            // Play Mode pending 중에는 임시 컴포넌트를 Authoring 완료로 보지 않는다.
            var gripDriverStatus = authoringBlockedByPending
                ? default
                : HandPoseControllerHandSetupService.EvaluateGripDriverOnPlaybackRoot(
                    m_PlaybackHandRoot,
                    m_AnimatorController,
                    m_GripInputAction,
                    m_GripParameterName);

            bool animatorConnectedExact = !authoringBlockedByPending
                && m_PlaybackHandRoot != null
                && m_PlaybackHandRoot.GetComponent<Animator>() != null
                && m_PlaybackHandRoot.GetComponent<Animator>().runtimeAnimatorController == m_AnimatorController;
            bool hasGripDriver = !authoringBlockedByPending
                                 && gripDriverStatus.hasDriverOnRoot
                                 && gripDriverStatus.isEnabled
                                 && gripDriverStatus.handAnimatorMatches
                                 && gripDriverStatus.gripParameterMatches;
            bool gripActionConnected = !authoringBlockedByPending
                                       && gripDriverStatus.gripActionMatches
                                       && m_GripInputAction != null;
            bool hasInputActionManager = !authoringBlockedByPending && gripDriverStatus.hasInputActionManager;
            bool gripActionAssetRegistered = !authoringBlockedByPending && gripDriverStatus.gripActionAssetRegistered;
            bool noDuplicateGripDriver = authoringBlockedByPending || gripDriverStatus.noDuplicateOnSelectedHand;
            bool visualOffsetAuthored =
                HandControllerVisualAlignmentService.IsVisualOffsetAuthoredInEditMode(
                    m_HandSide, m_PlaybackHandRoot)
                || (!Application.isPlaying
                    && !alignPending
                    && HandControllerVisualAlignmentService.GetVisualOffsetState(m_HandSide, m_PlaybackHandRoot).hasVO);

            // -- 표시 --
            EditorGUILayout.LabelField("Pose Asset & Clip", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("Open Pose Asset",      openPose);
            DrawMode1StatusRow("Grip Pose Asset",      gripPose);
            DrawMode1StatusRow("Open AnimationClip",   openClip);
            DrawMode1StatusRow("Grip AnimationClip",   grabClip);
            EditorGUILayout.Space(2f);

            EditorGUILayout.LabelField("AnimatorController", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("AnimatorController 존재",               controller);
            DrawMode1StatusRow($"Grip float 파라미터 ({m_GripParameterName})", hasGripParam);
            DrawMode1StatusRow("1D Blend Tree 상태 존재",                hasBlendTree);
            EditorGUILayout.Space(2f);

            EditorGUILayout.LabelField("Authoring 연결 (Edit Mode Scene)", EditorStyles.miniBoldLabel);
            if (setupPending || alignPending)
            {
                EditorGUILayout.HelpBox(
                    "Play Mode 종료 후 Scene 적용 대기 중",
                    MessageType.Warning);
            }
            else if (setupFailed
                     || alignStatus == HandControllerVisualAlignmentService.PendingApplyStatus.FailedToResolveTarget
                     || alignStatus == HandControllerVisualAlignmentService.PendingApplyStatus.FailedToApply)
            {
                EditorGUILayout.HelpBox(
                    "Scene 대상 복원 실패 · Edit Mode에서 다시 적용할 수 있습니다.",
                    MessageType.Error);
            }

            DrawMode1StatusRow("Animator 연결됨",            animatorConnectedExact || (!authoringBlockedByPending && animatorConnected));
            DrawMode1StatusRow("Grip Driver 연결됨",         hasGripDriver);
            DrawMode1StatusRow("Grip Action 연결됨",         gripActionConnected);
            DrawMode1StatusRow("InputActionManager 존재",    hasInputActionManager);
            DrawMode1StatusRow("Grip Action Asset 등록됨",   gripActionAssetRegistered);
            DrawMode1StatusRow("선택 손 Root의 Driver 중복 없음", noDuplicateGripDriver);
            DrawMode1StatusRow("Visual Offset 적용됨",       visualOffsetAuthored);

            if (!authoringBlockedByPending
                && m_PlaybackHandRoot != null
                && !gripDriverStatus.isValid
                && !string.IsNullOrEmpty(gripDriverStatus.failureReason))
            {
                EditorGUILayout.HelpBox(gripDriverStatus.failureReason, MessageType.Warning);
            }

            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("Runtime 확인 (Play Mode)", EditorStyles.miniBoldLabel);
            var runtimeGripActive = false;
            var runtimeGripAnimChanging = false;
            if (Application.isPlaying && m_PlaybackHandRoot != null && !setupPending)
            {
                var driver = m_PlaybackHandRoot.GetComponent<ControllerHandGripAnimator>();
                var anim = m_PlaybackHandRoot.GetComponent<Animator>();
                runtimeGripActive = driver != null && driver.enabled && driver.isActiveAndEnabled;
                if (anim != null && anim.isInitialized && !string.IsNullOrEmpty(m_GripParameterName))
                {
                    try
                    {
                        var gripValue = anim.GetFloat(m_GripParameterName);
                        runtimeGripAnimChanging = gripValue >= 0f;
                    }
                    catch
                    {
                        runtimeGripAnimChanging = false;
                    }
                }
            }

            DrawMode1StatusRow("Grip 입력 활성 (Driver)", runtimeGripActive);
            DrawMode1StatusRow("Animator Grip 파라미터 조회 가능", runtimeGripAnimChanging);
            EditorGUILayout.HelpBox(
                "Runtime 확인은 Authoring이 Scene에 영구 적용된 뒤 Play Mode에서 Grip 입력·손 Open/Grab 동작을 확인하세요.",
                MessageType.None);

            EditorGUILayout.Space(4f);
            var authoringDone = openPose && gripPose && openClip && grabClip
                          && controller && hasBlendTree && hasGripParam
                          && !authoringBlockedByPending
                          && (animatorConnectedExact || animatorConnected)
                          && hasGripDriver && gripActionConnected
                          && hasInputActionManager && gripActionAssetRegistered
                          && noDuplicateGripDriver
                          && gripDriverStatus.isValid;
            EditorGUILayout.HelpBox(
                authoringDone
                    ? "1차 기본 손 애니메이션 Authoring 완료! Scene을 저장하고 Play Mode에서 Runtime을 확인하세요."
                    : authoringBlockedByPending
                        ? "Play Mode 종료 후 Scene 적용이 끝나면 Authoring 완료로 표시됩니다."
                        : "위 Authoring 항목을 완료하면 1차 작업이 완성됩니다.",
                authoringDone ? MessageType.Info : MessageType.Warning);
        }

        // ════════════════════════════════════════════════════════════════════
        //  2차 · 물체 전용 잡기 자세 만들기
        // ════════════════════════════════════════════════════════════════════

        void DrawMode2Step(int step)
        {
            switch (step)
            {
                case 1: DrawMode2Step1_TargetSetup(); break;
                case 2: DrawMode2Step2_GrabPoseCapture(); break;
                case 3: DrawMode2Step3_GhostSetup(); break;
                case 4: DrawMode2Step4_BindingSetup(); break;
                case 5: DrawMode2Step5_Complete(); break;
            }
        }

        void DrawMode2Step1_TargetSetup()
        {
            EditorGUILayout.LabelField("① 대상 물체와 손 방향 설정", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "잡기 자세를 만들 대상 물체를 선택하세요.\n" +
                "손 방향(Right/Left)은 화면 상단의 Hand Side 드롭다운으로 설정합니다.",
                MessageType.Info);

            EditorGUI.BeginChangeCheck();
            m_GhostTargetGrabObject = (GameObject)EditorGUILayout.ObjectField(
                "Target Grab Object",
                m_GhostTargetGrabObject,
                typeof(GameObject),
                true);
            if (EditorGUI.EndChangeCheck())
            {
                m_LastGrabPoseRecordSummary = null;
                m_LastGrabPoseRecordPath = null;
                m_LastGhostPreviewSummary = null;
                m_LastGrabMigrationSummary = null;
            }

            if (GUILayout.Button("Selection을 Target으로 사용"))
            {
                var resolved = HandGhostPreviewService.TryResolveSelectionGrabTarget();
                if (resolved != null)
                    m_GhostTargetGrabObject = resolved;
            }

            EditorGUILayout.Space(4f);
            EditorGUILayout.LabelField("Hand Side", HandSideUtility.GetLabel(m_HandSide));
            EditorGUILayout.HelpBox(
                "손 방향을 바꾸려면 화면 상단의 Hand Side 드롭다운을 사용하세요.",
                MessageType.None);

            if (m_GhostTargetGrabObject != null)
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(
                    $"Target: {m_GhostTargetGrabObject.name}  |  Side: {HandSideUtility.GetLabel(m_HandSide)}",
                    MessageType.None);
                if (GUILayout.Button("다음: Grab Pose 캡처 ▶"))
                    m_Mode2Step = 2;
            }
            else
            {
                EditorGUILayout.HelpBox("Target Grab Object를 지정하세요.", MessageType.Warning);
            }
        }

        void DrawMode2Step2_GrabPoseCapture()
        {
            EditorGUILayout.LabelField("② Hand Tracking Grab Pose 캡처", EditorStyles.boldLabel);
            DrawStep2ContextSummary();
            EditorGUILayout.Space(4f);
            DrawHandTrackingCaptureSectionMain();

            m_FoldMode2ControllerCapture = EditorGUILayout.Foldout(
                m_FoldMode2ControllerCapture, "고급: Controller 기반 캡처");
            if (m_FoldMode2ControllerCapture)
            {
                EditorGUI.indentLevel++;
                DrawControllerGrabPoseCaptureSection();
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space(4f);
            DrawLastResultSection();
        }

        void DrawMode2Step3_GhostSetup()
        {
            EditorGUILayout.LabelField("③ Ghost 생성 및 Prefab 저장", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Record 기반으로 Ghost를 생성합니다.\n" +
                "Ghost는 Target 물체의 자식으로 배치되어 이동 시 함께 따라옵니다.\n" +
                "Ghost Prefab은 Assets/VRHandPoseToolOutput/Ghosts/ 에 자동 저장됩니다.",
                MessageType.Info);
            DrawRecordBasedGhostSection();
            if (!string.IsNullOrEmpty(m_LastGhostPreviewSummary))
                EditorGUILayout.HelpBox(m_LastGhostPreviewSummary, m_LastGhostPreviewMessageType);
        }

        void DrawMode2Step4_BindingSetup()
        {
            EditorGUILayout.LabelField("④ Wrist 기준 Attach + Binding 적용", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Wrist 기준 Attach Transform이 자동 생성됩니다. (Play Mode 종료 시 자동 적용)\n" +
                "HandSideAwareGrabInteractable · HandGrabPosePlayer를 연결해 런타임 Pose를 완성합니다.",
                MessageType.Info);
            DrawHandSideAttachRuntimeSection(showWristAttachRecalculate: true);

            // ── Wrist 기준 Attach 생성 상태 ──
            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("Attach 생성 상태", EditorStyles.miniBoldLabel);

            // 1. Tracking Wrist 기준 캡처 여부
            HandGrabPoseBinding step4Binding = null;
            bool hasCapturedRecord = false;
            if (m_GhostTargetGrabObject != null)
            {
                step4Binding = m_GhostTargetGrabObject.GetComponent<HandGrabPoseBinding>();
                hasCapturedRecord = step4Binding != null && step4Binding.TryGetRecord(m_HandSide, out _);
            }
            DrawMode1StatusRow("Tracking Wrist 기준 캡처", hasCapturedRecord);

            // 2. Controller Wrist 본 발견 여부 (Ghost L_Wrist 제외, PlaybackHandRoot 우선)
            var wristName = m_HandSide == HandSide.Right ? "R_Wrist" : "L_Wrist";
            var wristBone = FindControllerWristBoneInScene(m_HandSide, m_PlaybackHandRoot);
            DrawMode1StatusRow($"Controller Wrist 본 확인 ({wristName})", wristBone != null);

            // 3. Interactor Attach 발견 여부
            var interactorCandidates2 = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            var interactorFound = interactorCandidates2.Count > 0
                                  && interactorCandidates2[0].interactor != null;
            DrawMode1StatusRow("Interactor Attach 확인", interactorFound);

            // 4. Attach 존재 + 보정 여부
            bool hasAttach = step4Binding != null && step4Binding.TryGetAttachTransform(m_HandSide, out _);
            bool wristCorrectedStep4 = hasAttach && step4Binding != null
                                       && step4Binding.IsWristCorrectionApplied(m_HandSide);

            if (hasAttach && !wristCorrectedStep4)
                DrawMode1StatusRowWarning("Attach 생성됨 (임시 — Controller Wrist 보정 필요)");
            else
                DrawMode1StatusRow("보정된 Object Attach 생성", wristCorrectedStep4);

            if (hasCapturedRecord && !hasAttach)
            {
                EditorGUILayout.HelpBox(
                    "Play Mode를 실행한 뒤 종료하면 Attach가 자동 생성됩니다.\n" +
                    $"이때 {wristName} 본과 Interactor가 씬에 있으면 보정이 자동 적용됩니다.",
                    MessageType.Info);
            }
            else if (hasAttach && wristCorrectedStep4)
            {
                EditorGUILayout.HelpBox(
                    "✓ Controller Wrist Offset 보정 플래그가 설정된 Attach입니다.\n" +
                    "위 'Controller Wrist 기준 Attach 다시 계산' 버튼으로 값을 다시 적용할 수 있습니다.",
                    MessageType.Info);
            }
        }

        /// <summary>
        /// 2차 ④ 단계 — Target·HandSide의 Attach Transform에 Controller Wrist Offset 보정 UI.
        /// </summary>
        void DrawWristAttachRecalculateSection()
        {
            if (m_GhostTargetGrabObject == null)
                return;

            var binding = m_GhostTargetGrabObject.GetComponent<HandGrabPoseBinding>();
            if (binding == null || !binding.TryGetAttachTransform(m_HandSide, out var attachTransform))
                return;

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("Controller Wrist Attach 보정", EditorStyles.miniBoldLabel);

            var wristName = m_HandSide == HandSide.Right ? "R_Wrist" : "L_Wrist";
            var wristBone = FindControllerWristBoneInScene(m_HandSide, m_PlaybackHandRoot);
            var interactorCandidates = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            var interactorFound = interactorCandidates.Count > 0
                                  && interactorCandidates[0].interactor != null;
            var wristCorrected = binding.IsWristCorrectionApplied(m_HandSide);

            if (wristCorrected)
            {
                EditorGUILayout.HelpBox(
                    "WristCorrectionApplied=true 이지만 Attach 값이 맞지 않으면 아래 버튼으로 다시 계산하세요.",
                    MessageType.None);
            }

            EditorGUILayout.LabelField(
                "Attach",
                $"{attachTransform.name}  localPos={attachTransform.localPosition:F3}  " +
                $"localRot={attachTransform.localRotation.eulerAngles:F1}");

            bool canRecalc = wristBone != null && interactorFound;
            EditorGUI.BeginDisabledGroup(!canRecalc);
            if (GUILayout.Button("Controller Wrist 기준 Attach 다시 계산", GUILayout.Height(28f)))
                RecalculateWristAttach();
            EditorGUI.EndDisabledGroup();

            if (!canRecalc)
            {
                var missing = new System.Collections.Generic.List<string>();
                if (wristBone == null) missing.Add($"Wrist 본({wristName})");
                if (!interactorFound) missing.Add("Interactor");
                EditorGUILayout.HelpBox(
                    $"재계산 불가 — 누락: {string.Join(", ", missing)}\n" +
                    "1차 손 준비 단계(Playback Hand Root 설정)를 먼저 완료하세요.",
                    MessageType.Warning);
            }
        }

        /// <summary>
        /// 현재 씬에서 Controller Wrist 본과 Interactor Attach를 찾아
        /// 선택 HandSide의 Object Attach Transform에 Wrist Offset 보정을 적용합니다.
        /// </summary>
        void RecalculateWristAttach()
        {
            if (m_GhostTargetGrabObject == null) return;
            var binding = m_GhostTargetGrabObject.GetComponent<HandGrabPoseBinding>();
            if (binding == null) { Debug.LogWarning("[VRHandPoseTool] HandGrabPoseBinding이 없습니다."); return; }
            if (!binding.TryGetAttachTransform(m_HandSide, out var attachTransform))
            { Debug.LogWarning("[VRHandPoseTool] Attach Transform이 없습니다."); return; }

            var previousSelection = Selection.objects;
            var previousActive = Selection.activeGameObject;

            var grabInteractable = m_GhostTargetGrabObject.GetComponent<XRGrabInteractable>();
            var wristBone = FindControllerWristBoneInScene(m_HandSide, m_PlaybackHandRoot);
            var interactorCandidates = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            var interactor = interactorCandidates.Count > 0 ? interactorCandidates[0].interactor : null;

            Debug.Log(
                "[VRHandPoseTool] Attach 재계산 경로\n" +
                $"  Target: {m_GhostTargetGrabObject.name} ({m_GhostTargetGrabObject.GetInstanceID()})\n" +
                $"  HandSide: {HandSideUtility.GetLabel(m_HandSide)}\n" +
                $"  Attach: {attachTransform.name} (before localPos={attachTransform.localPosition:F4})\n" +
                $"  Controller Wrist: {(wristBone != null ? wristBone.name : "(missing)")}\n" +
                $"  Interactor: {(interactor != null ? interactor.name : "(missing)")}\n" +
                $"  Formula: GhostWrist(Target local) × inverse(ControllerWrist in Interactor Attach)",
                m_GhostTargetGrabObject);

            var compute = HandAttachWristCorrectionService.TryComputeAttachLocalPose(
                m_GhostTargetGrabObject.transform,
                m_HandSide,
                grabInteractable);

            if (!compute.success)
            {
                Debug.LogWarning($"[VRHandPoseTool] Attach 재계산 실패: {compute.errorMessage}", m_GhostTargetGrabObject);
                Selection.objects = previousSelection;
                Selection.activeGameObject = previousActive;
                return;
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Recalculate Wrist Attach");
            Undo.RecordObject(attachTransform, "Recalculate Wrist Attach");
            attachTransform.localPosition = compute.attachLocalPosition;
            attachTransform.localRotation = compute.attachLocalRotation;
            attachTransform.localScale    = Vector3.one;

            Undo.RecordObject(binding, "Recalculate Wrist Attach");
            binding.SetWristCorrectionApplied(m_HandSide, true);
            EditorUtility.SetDirty(binding);
            EditorUtility.SetDirty(attachTransform);
            if (attachTransform.gameObject != null)
                EditorUtility.SetDirty(attachTransform.gameObject);
            EditorSceneManager.MarkAllScenesDirty();
            Undo.CollapseUndoOperations(Undo.GetCurrentGroup());

            Selection.objects = previousSelection;
            Selection.activeGameObject = previousActive;

            Debug.Log(compute.validationLog, attachTransform);
            Debug.Log(
                $"[VRHandPoseTool] Attach 재계산 완료 — {attachTransform.name} " +
                $"localPos={attachTransform.localPosition:F4} localRot={attachTransform.localRotation.eulerAngles:F2}",
                attachTransform);
            Repaint();
        }

        void DrawMode2Step5_Complete()
        {
            EditorGUILayout.LabelField("⑤ 2차 완료 상태", EditorStyles.boldLabel);
            EditorGUILayout.Space(4f);
            DrawMode2CompletionStatus();

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("실기기 검증", EditorStyles.miniBoldLabel);
            EditorGUILayout.HelpBox(
                "아래 항목들은 실제 VR 기기에서만 검증할 수 있습니다.\n" +
                "기기 테스트가 완료되면 아래 버튼으로 검증 완료를 표시하세요.",
                MessageType.Info);

            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = m_Mode2DeviceVerified
                ? new Color(0.3f, 0.9f, 0.4f)
                : new Color(0.9f, 0.9f, 0.9f);
            if (GUILayout.Button(
                m_Mode2DeviceVerified ? "✓  실기기 검증 완료 (클릭하면 해제)" : "□  실기기 검증 완료 표시",
                GUILayout.Height(28f)))
                m_Mode2DeviceVerified = !m_Mode2DeviceVerified;
            GUI.backgroundColor = prevBg;

            if (m_Mode2DeviceVerified)
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(
                    "2차 물체 전용 잡기 자세 — 설정 완료 + 실기기 검증 완료",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.LabelField("기기 검증 체크리스트", EditorStyles.miniBoldLabel);
                DrawMode1StatusRow("Grab 시 Pose 적용 · Ghost 숨김",              false);
                DrawMode1StatusRow("Release 시 Animator 복귀 · Ghost 재표시",      false);
                DrawMode1StatusRow("Rifle 이동 후 Ghost 위치 유지",                false);
                DrawMode1StatusRow("Controller Wrist가 Ghost Wrist 위치에 일치",   false);
            }
        }

        void DrawMode2CompletionStatus()
        {
            if (m_GhostTargetGrabObject == null)
            {
                EditorGUILayout.HelpBox("Target Grab Object가 지정되지 않았습니다.", MessageType.Warning);
                return;
            }

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(m_HandSide);

            // ── Grab Pose Record ──
            var binding  = m_GhostTargetGrabObject.GetComponent<HandGrabPoseBinding>();
            var hasBinding = binding != null;
            HandGrabPoseRecord record = null;
            var hasRecord      = hasBinding && binding.TryGetRecord(m_HandSide, out record);
            var recordSideOk   = hasRecord && record != null && record.MatchesHandSide(m_HandSide);
            var hasAttach        = hasBinding && binding.TryGetAttachTransform(m_HandSide, out _);
            var wristCorrected   = hasAttach && hasBinding && binding.IsWristCorrectionApplied(m_HandSide);
            var slotsConnected   = hasRecord && hasAttach;

            // ── Ghost ──
            bool ghostsRootExists = false;
            HandGhostPreviewMarker ghostMarker = null;
            for (int ci = 0; ci < m_GhostTargetGrabObject.transform.childCount; ci++)
            {
                var child = m_GhostTargetGrabObject.transform.GetChild(ci);
                if (child.name == HandGhostPreviewService.GhostsRootName)
                {
                    ghostsRootExists = true;
                    ghostMarker = child.GetComponentInChildren<HandGhostPreviewMarker>(true);
                    break;
                }
            }
            var ghostHasMarker  = ghostMarker != null;
            var ghostSideOk     = ghostMarker != null &&
                string.Equals(ghostMarker.HandSide, sideLabel, StringComparison.Ordinal);

            var ghostPrefabPath = HandGhostPreviewService.GetGhostPrefabPath(
                m_GhostTargetGrabObject.name, m_HandSide);
            var hasPrefab = !string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(ghostPrefabPath));

            // ── Runtime 컴포넌트 ──
            var mig = HandSideAwareGrabInteractableMigrationService.EvaluateReadiness(m_GhostTargetGrabObject);
            var hasHandSideAware = mig.existingHandSideAware != null;
            var hasPlayer = m_GhostTargetGrabObject.GetComponentInChildren<HandGrabPosePlayer>(true) != null;

            // ── Interactor HandInteractorSide ──
            bool hasInteractorSide = false;
            var interactorCandidates = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            if (interactorCandidates.Count > 0 && interactorCandidates[0].interactor != null)
            {
                var his = interactorCandidates[0].interactor.GetComponent<HandInteractorSide>();
                hasInteractorSide = his != null && his.Matches(m_HandSide);
            }

            // -- 표시 --
            EditorGUILayout.LabelField("Target & HandSide", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("Target Grab Object 지정", m_GhostTargetGrabObject != null);
            DrawMode1StatusRow("HandSide 지정", true);

            EditorGUILayout.Space(2f);
            EditorGUILayout.LabelField("Grab Pose Record", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("Record 존재",                   hasRecord);
            DrawMode1StatusRow("Record HandSide 일치",          recordSideOk);

            EditorGUILayout.Space(2f);
            EditorGUILayout.LabelField("Ghost", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("Ghost Scene Instance (Target 자식)", ghostsRootExists);
            DrawMode1StatusRow("HandGhostPreviewMarker 존재",        ghostHasMarker);
            DrawMode1StatusRow("Ghost HandSide 일치",                ghostSideOk);
            DrawMode1StatusRow("Ghost Prefab Asset",                  hasPrefab);

            EditorGUILayout.Space(2f);
            EditorGUILayout.LabelField("Attach & Binding", EditorStyles.miniBoldLabel);
            if (hasAttach && !wristCorrected)
                DrawMode1StatusRowWarning("Attach 존재 (임시 — Controller Wrist 보정 필요)");
            else
                DrawMode1StatusRow("Wrist 기준 Attach 존재", hasAttach);
            DrawMode1StatusRow("Wrist Offset 보정 완료",          wristCorrected);
            DrawMode1StatusRow("HandGrabPoseBinding 존재",        hasBinding);
            DrawMode1StatusRow("Record+Attach 슬롯 연결됨",       slotsConnected);

            EditorGUILayout.Space(2f);
            EditorGUILayout.LabelField("Runtime 컴포넌트", EditorStyles.miniBoldLabel);
            DrawMode1StatusRow("HandSideAwareGrabInteractable", hasHandSideAware);
            DrawMode1StatusRow("HandGrabPosePlayer",            hasPlayer);
            DrawMode1StatusRow("HandInteractorSide (Interactor)", hasInteractorSide);

            EditorGUILayout.Space(4f);
            bool baseSetupDone = hasRecord && recordSideOk && ghostsRootExists && ghostHasMarker
                                 && ghostSideOk && hasAttach && hasBinding && slotsConnected
                                 && hasHandSideAware && hasPlayer;
            var setupDone = baseSetupDone && wristCorrected;

            if (!hasPrefab)
                EditorGUILayout.HelpBox(
                    "Ghost Prefab Asset이 없습니다. ③ Ghost 생성 단계에서 Ghost를 다시 만들어 Prefab을 저장하세요.",
                    MessageType.Warning);

            if (baseSetupDone && !wristCorrected)
                EditorGUILayout.HelpBox(
                    "부분 완료 — Controller Wrist Offset 보정이 아직 적용되지 않았습니다.\n" +
                    "④ 단계에서 '1차 손 설정 완료 후 [Controller Wrist 기준 Attach 다시 계산]' 버튼을 실행하세요.\n" +
                    "보정 전까지는 실제 Grab 시 Ghost와 손 위치가 어긋날 수 있습니다.",
                    MessageType.Warning);
            else
                EditorGUILayout.HelpBox(
                    setupDone ? "설정 완료 (실기기 검증 미확인)" : "위 항목을 완료하면 2차 작업이 완성됩니다.",
                    setupDone ? MessageType.Info : MessageType.Warning);

            if (!string.IsNullOrEmpty(ghostPrefabPath) && hasPrefab)
                EditorGUILayout.LabelField("Ghost Prefab", ghostPrefabPath, EditorStyles.miniLabel);
        }

        void DrawMode1StatusRow(string label, bool ok)
        {
            var prevColor = GUI.contentColor;
            GUI.contentColor = ok ? new Color(0.25f, 0.82f, 0.35f) : new Color(0.9f, 0.3f, 0.3f);
            EditorGUILayout.LabelField(ok ? $"✓  {label}" : $"✗  {label}");
            GUI.contentColor = prevColor;
        }

        // 경고(노란색) 상태 행 — 보정 필요 임시 Attach 등에 사용
        void DrawMode1StatusRowWarning(string label)
        {
            var prevColor = GUI.contentColor;
            GUI.contentColor = new Color(1f, 0.78f, 0.1f);
            EditorGUILayout.LabelField($"⚠  {label}");
            GUI.contentColor = prevColor;
        }

        // ════════════════════════════════════════════════════════════════
        //  상태 저장 / 복원 (EditorPrefs)
        // ════════════════════════════════════════════════════════════════

        void SaveWindowState()
        {
            EditorPrefs.SetInt(PkMode,     (int)m_WorkMode);
            EditorPrefs.SetInt(PkM1Step,   m_Mode1Step);
            EditorPrefs.SetInt(PkM2Step,   m_Mode2Step);
            EditorPrefs.SetInt(PkHandSide, (int)m_HandSide);
            EditorPrefs.SetInt(PkDevVer,   m_Mode2DeviceVerified ? 1 : 0);

            EditorPrefs.SetString(PkOpenPose, WsAssetGuid(m_CapturedOpenPoseAsset));
            EditorPrefs.SetString(PkGripPose, WsAssetGuid(m_CapturedGrabPoseAsset));
            EditorPrefs.SetString(PkOpenClip, WsAssetGuid(m_OpenAnimationClip));
            EditorPrefs.SetString(PkGrabClip, WsAssetGuid(m_GrabAnimationClip));
            EditorPrefs.SetString(PkAnimCtrl, WsAssetGuid(m_AnimatorController));
            EditorPrefs.SetString(PkGripAct,  WsAssetGuid(m_GripInputAction));

            EditorPrefs.SetString(PkPlayback, WsSceneGoid(m_PlaybackHandRoot));
            EditorPrefs.SetString(PkTarget,   WsSceneGoid(m_GhostTargetGrabObject));
            EditorPrefs.SetString(PkInteract, WsSceneGoid(m_InteractorCandidate));
        }

        void LoadWindowState()
        {
            if (!EditorPrefs.HasKey(PkMode)) return;   // 첫 실행 — 저장 데이터 없음

            var sb = new StringBuilder();

            m_WorkMode            = (WorkMode)EditorPrefs.GetInt(PkMode, 0);
            m_Mode1Step           = Mathf.Clamp(EditorPrefs.GetInt(PkM1Step, 1), 1, 5);
            m_Mode2Step           = Mathf.Clamp(EditorPrefs.GetInt(PkM2Step, 1), 1, 5);
            m_HandSide            = (HandSide)EditorPrefs.GetInt(PkHandSide, 0);
            m_Mode2DeviceVerified = EditorPrefs.GetInt(PkDevVer, 0) == 1;

            m_CapturedOpenPoseAsset  = RsAssetRef<XRHandPoseAsset>(PkOpenPose, "Open Pose Asset", sb);
            m_CapturedGrabPoseAsset  = RsAssetRef<XRHandPoseAsset>(PkGripPose, "Grip Pose Asset", sb);
            m_OpenAnimationClip      = RsAssetRef<AnimationClip>(PkOpenClip, "Open Animation Clip", sb);
            m_GrabAnimationClip      = RsAssetRef<AnimationClip>(PkGrabClip, "Grab Animation Clip", sb);
            m_AnimatorController     = RsAssetRef<RuntimeAnimatorController>(PkAnimCtrl, "Animator Controller", sb);
            m_GripInputAction        = RsAssetRef<InputActionReference>(PkGripAct, "Grip Input Action", sb);

            m_PlaybackHandRoot       = RsSceneRef<Transform>(PkPlayback, "Playback Hand Root",
                                           () => AutoFindPlaybackHandRoot(), sb);
            m_GhostTargetGrabObject  = RsSceneRef<GameObject>(PkTarget, "Target Grab Object",
                                           () => HandGhostPreviewService.TryResolveSelectionGrabTarget(), sb);
            m_InteractorCandidate    = RsSceneRef<Component>(PkInteract, "Interactor Candidate",
                                           () => AutoFindInteractorComponent(), sb);

            m_RestoreLog  = sb.Length > 0 ? sb.ToString().TrimEnd() : null;
            m_ShowRestoreLog = m_RestoreLog != null;
        }

        // ── 자동 탐색 헬퍼 ──────────────────────────────────────────────────
        Transform AutoFindPlaybackHandRoot()
        {
            var result = HandPlaybackHandFinder.FindPlaybackHand(m_HandSide);
            return result.candidates.Count > 0 ? result.candidates[0].handRoot : null;
        }

        Component AutoFindInteractorComponent()
        {
            var candidates = HandInteractorFinder.FindInteractorCandidates(m_HandSide);
            return candidates.Count > 0 ? candidates[0].interactor : null;
        }

        /// <summary>
        /// Ghost L_Wrist를 제외하고 Controller Hand의 Wrist 본을 탐색합니다.
        /// preferRoot 하위를 먼저 탐색하고, 없으면 HandPlaybackHandFinder → Ghost 제외 전역 탐색 순서로 진행합니다.
        /// </summary>
        static Transform FindControllerWristBoneInScene(HandSide handSide, Transform preferRoot = null)
        {
            var wristName = handSide == HandSide.Right ? "R_Wrist" : "L_Wrist";

            // 1순위: 직접 제공된 PlaybackHandRoot 하위
            if (preferRoot != null)
            {
                var found = FindBoneInHierarchyRecursive(preferRoot, wristName);
                if (found != null) return found;
            }

            // 2순위: HandPlaybackHandFinder로 Controller Hand Root를 찾아 그 하위 탐색
            var findResult = HandPlaybackHandFinder.FindPlaybackHand(handSide);
            if (findResult.success && findResult.candidates.Count > 0)
            {
                var ctrlRoot = findResult.candidates[0].handRoot;
                if (ctrlRoot != null)
                {
                    var found = FindBoneInHierarchyRecursive(ctrlRoot, wristName);
                    if (found != null) return found;
                }
            }

            // 3순위: Ghost 제외 전역 탐색 (Resources.FindObjectsOfTypeAll은 inactive 포함)
            foreach (var t in Resources.FindObjectsOfTypeAll<Transform>())
            {
                if (t == null || t.name != wristName || !t.gameObject.scene.IsValid()) continue;
                if (t.GetComponentInParent<HandGhostPreviewMarker>() != null) continue;
                return t;
            }
            return null;
        }

        static Transform FindBoneInHierarchyRecursive(Transform root, string boneName)
        {
            if (root == null) return null;
            if (root.name == boneName) return root;
            foreach (Transform child in root)
            {
                var found = FindBoneInHierarchyRecursive(child, boneName);
                if (found != null) return found;
            }
            return null;
        }

        static string GetTransformPath(Transform t)
        {
            if (t == null) return "null";
            var parts = new System.Collections.Generic.List<string>();
            var cur = t;
            while (cur != null) { parts.Insert(0, cur.name); cur = cur.parent; }
            return string.Join("/", parts);
        }

        // ── 작업 상태 초기화 ────────────────────────────────────────────────
        void ResetWorkState()
        {
            // Pose Asset / AnimationClip / AnimatorController / Playback 참조는 유지.
            // pending setup/alignment 상태만 초기화한다.
            HandPoseControllerHandPendingSetupBridge.ClearAllPendingStatuses();
            HandSceneObjectLocator.ClearAllStored(HandSide.Left);
            HandSceneObjectLocator.ClearAllStored(HandSide.Right);

            m_LastControllerSetupSummary = null;
            m_LastAlignmentMessage = null;
            m_LastPreviewMessage = null;
            CapturePlaybackHandLocatorIfPossible();
            SaveWindowState();
        }

        // ── EditorPrefs 저장 헬퍼 ───────────────────────────────────────────
        static string WsAssetGuid(UnityEngine.Object obj)
        {
            if (obj == null) return "";
            var path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) return "";
            return AssetDatabase.AssetPathToGUID(path);
        }

        static string WsSceneGoid(UnityEngine.Object obj)
        {
            if (obj == null) return "";
            return GlobalObjectId.GetGlobalObjectIdSlow(obj).ToString();
        }

        // ── EditorPrefs 복원 헬퍼 ───────────────────────────────────────────
        static T RsAssetRef<T>(string prefKey, string label, StringBuilder log)
            where T : UnityEngine.Object
        {
            var guid = EditorPrefs.GetString(prefKey, "");
            if (string.IsNullOrEmpty(guid)) return null;

            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (string.IsNullOrEmpty(path))
            {
                log.AppendLine($"⚠ {label} — 에셋을 찾을 수 없습니다 (삭제되었거나 이동됨)");
                return null;
            }

            var asset = AssetDatabase.LoadAssetAtPath<T>(path);
            if (asset == null)
                log.AppendLine($"⚠ {label} — 경로에서 로드 실패: {path}");
            return asset;
        }

        static T RsSceneRef<T>(string prefKey, string label,
                               Func<T> autoSearch, StringBuilder log)
            where T : UnityEngine.Object
        {
            var goidStr = EditorPrefs.GetString(prefKey, "");
            if (!string.IsNullOrEmpty(goidStr)
                && GlobalObjectId.TryParse(goidStr, out var goid))
            {
                var found = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(goid) as T;
                if (found != null) return found;
            }

            // GlobalObjectId 복원 실패 → 자동 탐색 시도
            if (!string.IsNullOrEmpty(goidStr))
            {
                var fallback = autoSearch?.Invoke();
                if (fallback != null)
                {
                    log.AppendLine($"↺ {label} — GlobalObjectId 복원 실패, 자동 탐색으로 대체");
                    return fallback;
                }
                log.AppendLine($"⚠ {label} — 복원 실패 (다른 씬이거나 삭제됨)");
            }
            return null;
        }

        // ════════════════════════════════════════════════════════════════
        //  하단 툴바 — 작업 상태 초기화 / 생성 결과 삭제
        // ════════════════════════════════════════════════════════════════

        void DrawFooterToolbar()
        {
            // 복원 로그가 있으면 상단에 표시
            if (m_ShowRestoreLog && !string.IsNullOrEmpty(m_RestoreLog))
            {
                EditorGUILayout.Space(2f);
                EditorGUILayout.HelpBox("복원 결과 (일부 항목 주의):\n" + m_RestoreLog, MessageType.Warning);
                if (GUILayout.Button("확인 (닫기)", EditorStyles.miniButton))
                    m_ShowRestoreLog = false;
            }

            EditorGUILayout.Space(4f);
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();

            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(1f, 0.85f, 0.5f);
            if (GUILayout.Button("작업 상태 초기화", GUILayout.Width(110f), GUILayout.Height(22f)))
            {
                if (EditorUtility.DisplayDialog(
                    "작업 상태 초기화",
                    "pending Controller 설정/정렬 상태만 초기화합니다.\n" +
                    "Pose Asset / AnimationClip / AnimatorController / Playback Hand 참조는 유지됩니다.\n\n" +
                    "계속하시겠습니까?",
                    "초기화", "취소"))
                {
                    ResetWorkState();
                    Repaint();
                }
            }
            GUI.backgroundColor = prevBg;
            EditorGUILayout.EndHorizontal();

            // 2차 결과 초기화 (Mode 2 전용)
            if (m_WorkMode == WorkMode.Mode2_GrabPose)
            {
                EditorGUILayout.Space(2f);
                m_FoldMode2SideReset = EditorGUILayout.Foldout(
                    m_FoldMode2SideReset,
                    "고급: 2차 결과 초기화",
                    true,
                    EditorStyles.foldout);
                if (m_FoldMode2SideReset)
                    DrawMode2SideResetSection();
            }

            // 생성 결과 삭제 고급 Foldout
            EditorGUILayout.Space(2f);
            m_FoldDeleteResults = EditorGUILayout.Foldout(m_FoldDeleteResults,
                "⚠ 생성 결과 삭제 (고급)", true, EditorStyles.foldout);
            if (m_FoldDeleteResults)
                DrawAdvancedDeleteFoldout();

            EditorGUILayout.Space(4f);
        }

        void DrawMode2SideResetSection()
        {
            EditorGUILayout.HelpBox(
                "현재 Target과 선택 Hand Side의 2차 Grab Pose 결과만 초기화합니다.\n" +
                "1차 Open/Grip 애니메이션, 반대 손, Target의 XRGrabInteractable / HandGrabPosePlayer / " +
                "HandSideAwareGrabInteractable은 유지됩니다.",
                MessageType.Info);

            var sideLabel = HandSideUtility.GetLabel(m_HandSide);
            var targetName = m_GhostTargetGrabObject != null ? m_GhostTargetGrabObject.name : "(미지정)";
            EditorGUILayout.LabelField("대상", $"{targetName}  ·  {sideLabel}", EditorStyles.miniLabel);

            var plan = HandGrabPoseSideResetService.BuildPlan(m_GhostTargetGrabObject, m_HandSide);
            if (!plan.canExecute)
            {
                if (!string.IsNullOrEmpty(plan.blockReason))
                    EditorGUILayout.HelpBox(plan.blockReason, MessageType.Warning);
            }
            else if (plan.items.Count > 0)
            {
                EditorGUILayout.LabelField("초기화 예정 항목", EditorStyles.miniBoldLabel);
                foreach (var item in plan.items)
                    EditorGUILayout.LabelField($"• {item.label}", item.detail, EditorStyles.miniLabel);
            }

            EditorGUILayout.Space(4f);
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(1f, 0.55f, 0.45f);
            EditorGUI.BeginDisabledGroup(!plan.canExecute);
            if (GUILayout.Button("현재 Target의 선택 손 2차 결과 초기화", GUILayout.Height(26f)))
                ExecuteMode2SideReset();
            EditorGUI.EndDisabledGroup();
            GUI.backgroundColor = prevBg;

            if (!string.IsNullOrEmpty(m_LastMode2SideResetSummary))
            {
                EditorGUILayout.Space(4f);
                EditorGUILayout.HelpBox(m_LastMode2SideResetSummary, m_LastMode2SideResetMessageType);
            }
        }

        void ExecuteMode2SideReset()
        {
            var plan = HandGrabPoseSideResetService.BuildPlan(m_GhostTargetGrabObject, m_HandSide);
            if (!plan.canExecute)
            {
                m_LastMode2SideResetSummary = plan.blockReason ?? "초기화할 수 없습니다.";
                m_LastMode2SideResetMessageType = MessageType.Warning;
                Repaint();
                return;
            }

            if (!EditorUtility.DisplayDialog(
                    "2차 결과 초기화 확인",
                    HandGrabPoseSideResetService.FormatPlanDialogMessage(plan),
                    "초기화",
                    "취소"))
            {
                return;
            }

            var resetResult = HandGrabPoseSideResetService.TryExecute(plan);

            m_Mode2Step = 1;
            m_Mode2DeviceVerified = false;
            m_LastGrabPoseRecordSummary = null;
            m_LastGrabPoseRecordPath = null;
            m_LastGhostPreviewSummary = null;
            m_LastGrabMigrationSummary = null;

            m_LastMode2SideResetSummary = resetResult.message;
            m_LastMode2SideResetMessageType = resetResult.success ? MessageType.Info : MessageType.Warning;

            if (resetResult.success)
                Debug.Log($"[VRHandPoseTool] {resetResult.message}");
            else
                Debug.LogWarning($"[VRHandPoseTool] {resetResult.message}");

            SaveWindowState();
            Repaint();
        }

        void DrawAdvancedDeleteFoldout()
        {
            EditorGUILayout.HelpBox(
                "아래 항목은 이 툴이 생성한 에셋입니다.\n" +
                "삭제하면 되돌릴 수 없습니다. 신중하게 선택하세요.",
                MessageType.Warning);

            // 삭제 가능한 에셋 수집
            var deletable = new List<(string label, string path)>();
            void TryAdd(UnityEngine.Object obj, string label)
            {
                if (obj == null) return;
                var p = AssetDatabase.GetAssetPath(obj);
                if (!string.IsNullOrEmpty(p)) deletable.Add((label, p));
            }

            TryAdd(m_CapturedOpenPoseAsset,  "Open Pose Asset");
            TryAdd(m_CapturedGrabPoseAsset,  "Grip Pose Asset");
            TryAdd(m_OpenAnimationClip,       "Open Animation Clip");
            TryAdd(m_GrabAnimationClip,       "Grab Animation Clip");
            TryAdd(m_AnimatorController,      "Animator Controller");

            // Ghost Prefab
            if (m_GhostTargetGrabObject != null)
            {
                var ghostPath = HandGhostPreviewService.GetGhostPrefabPath(
                    m_GhostTargetGrabObject.name, m_HandSide);
                if (!string.IsNullOrEmpty(ghostPath)
                    && !string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(ghostPath)))
                    deletable.Add(("Ghost Prefab", ghostPath));
            }

            if (deletable.Count == 0)
            {
                EditorGUILayout.LabelField("삭제 가능한 에셋이 없습니다.", EditorStyles.miniLabel);
                return;
            }

            EditorGUILayout.LabelField("삭제 대상 목록", EditorStyles.miniBoldLabel);
            foreach (var (label, path) in deletable)
                EditorGUILayout.LabelField($"• {label}", path, EditorStyles.miniLabel);

            EditorGUILayout.Space(4f);
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
            if (GUILayout.Button($"위 {deletable.Count}개 에셋 삭제", GUILayout.Height(24f)))
            {
                var listText = string.Join("\n", deletable.Select(d => $"• {d.label}: {d.path}"));
                if (EditorUtility.DisplayDialog(
                    "생성 결과 삭제 확인",
                    $"다음 에셋을 영구 삭제합니다:\n\n{listText}\n\n" +
                    "이 작업은 되돌릴 수 없습니다. 계속하시겠습니까?",
                    "삭제", "취소"))
                {
                    ExecuteDeleteGeneratedAssets(deletable);
                }
            }
            GUI.backgroundColor = prevBg;
        }

        void ExecuteDeleteGeneratedAssets(List<(string label, string path)> targets)
        {
            int deleted = 0;
            var errors = new StringBuilder();

            foreach (var (label, path) in targets)
            {
                bool ok = AssetDatabase.DeleteAsset(path);
                if (ok)
                {
                    deleted++;
                    Debug.Log($"[VRHandPoseTool] 삭제: {label} ({path})");
                }
                else
                {
                    errors.AppendLine($"삭제 실패: {label} ({path})");
                }
            }

            // 삭제된 에셋을 참조하는 필드 null 처리
            void NullIfDeleted(ref XRHandPoseAsset f)        { if (f != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(f))) f = null; }
            void NullIfDeletedAC(ref RuntimeAnimatorController f) { if (f != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(f))) f = null; }
            void NullIfDeletedClip(ref AnimationClip f)      { if (f != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(f))) f = null; }

            NullIfDeleted(ref m_CapturedOpenPoseAsset);
            NullIfDeleted(ref m_CapturedGrabPoseAsset);
            NullIfDeletedClip(ref m_OpenAnimationClip);
            NullIfDeletedClip(ref m_GrabAnimationClip);
            NullIfDeletedAC(ref m_AnimatorController);

            AssetDatabase.Refresh();
            SaveWindowState();

            var msg = deleted > 0 ? $"{deleted}개 에셋 삭제 완료." : "삭제된 항목 없음.";
            if (errors.Length > 0) msg += "\n" + errors.ToString().TrimEnd();
            EditorUtility.DisplayDialog("삭제 완료", msg, "확인");
            Repaint();
        }
    }
}
