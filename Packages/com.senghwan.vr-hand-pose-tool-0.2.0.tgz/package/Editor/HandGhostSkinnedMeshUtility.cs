using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 고스트 SkinnedMeshRenderer bone 재매핑 및 검증입니다.
    /// </summary>
    static class HandGhostSkinnedMeshUtility
    {
        const float BoundsScaleTolerance = 5f;
        const float MinScaleComponent = 1e-4f;
        const float MaxScaleComponent = 1000f;

        public class RemapResult
        {
            public bool success;
            public List<string> errors = new();
            public int remappedRendererCount;
            public int remappedBoneCount;
        }

        public class ValidationResult
        {
            public bool success;
            public List<string> errors = new();
            public int originalTransformReferenceCount;
            public int ghostBoneReferenceCount;
            public int rendererCount;
            public string scaleReport;
            public string boundsReport;
        }

        public static RemapResult RemapSkinnedMeshRenderers(
            Transform playbackHandRoot,
            Transform ghostHandRoot)
        {
            var result = new RemapResult();

            if (playbackHandRoot == null)
            {
                result.errors.Add("Playback Hand Root가 null입니다.");
                return result;
            }

            if (ghostHandRoot == null)
            {
                result.errors.Add("Ghost Hand Root가 null입니다.");
                return result;
            }

            var playbackRenderers = playbackHandRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            if (playbackRenderers == null || playbackRenderers.Length == 0)
            {
                result.errors.Add("Playback Hand Root 하위 SkinnedMeshRenderer를 찾지 못했습니다.");
                return result;
            }

            for (var r = 0; r < playbackRenderers.Length; r++)
            {
                var playbackRenderer = playbackRenderers[r];
                if (playbackRenderer == null)
                    continue;

                var rendererPath = HandGhostTransformPathUtility.GetRelativePath(
                    playbackHandRoot,
                    playbackRenderer.transform);
                if (rendererPath == null)
                {
                    result.errors.Add(
                        $"Playback SkinnedMeshRenderer '{playbackRenderer.name}' 경로를 Hand Root 기준으로 만들 수 없습니다.");
                    continue;
                }

                if (!HandGhostTransformPathUtility.TryFindByRelativePath(
                        ghostHandRoot,
                        rendererPath,
                        out var ghostRendererTransform)
                    || ghostRendererTransform == null)
                {
                    result.errors.Add(
                        $"Ghost SkinnedMeshRenderer를 찾지 못했습니다. 경로='{rendererPath}'");
                    continue;
                }

                var ghostRenderer = ghostRendererTransform.GetComponent<SkinnedMeshRenderer>();
                if (ghostRenderer == null)
                {
                    result.errors.Add(
                        $"Ghost 경로 '{rendererPath}'에 SkinnedMeshRenderer가 없습니다.");
                    continue;
                }

                if (!TryRemapRendererBones(
                        playbackHandRoot,
                        ghostHandRoot,
                        playbackRenderer,
                        ghostRenderer,
                        result.errors,
                        out var remappedBoneCount))
                {
                    continue;
                }

                result.remappedRendererCount++;
                result.remappedBoneCount += remappedBoneCount;
            }

            result.success = result.errors.Count == 0 && result.remappedRendererCount > 0;
            return result;
        }

        public static ValidationResult Validate(
            Transform playbackHandRoot,
            Transform ghostHandRoot)
        {
            var result = new ValidationResult();

            if (ghostHandRoot == null)
            {
                result.errors.Add("Ghost Hand Root가 null입니다.");
                return result;
            }

            ValidateGhostRootScale(ghostHandRoot, result);

            var ghostRenderers = ghostHandRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            result.rendererCount = ghostRenderers.Length;
            if (ghostRenderers.Length == 0)
            {
                result.errors.Add("Ghost Hand Root 하위 SkinnedMeshRenderer가 없습니다.");
                return result;
            }

            var playbackRenderers = playbackHandRoot != null
                ? playbackHandRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true)
                : System.Array.Empty<SkinnedMeshRenderer>();

            var boundsLines = new List<string>();
            for (var r = 0; r < ghostRenderers.Length; r++)
            {
                var ghostRenderer = ghostRenderers[r];
                if (ghostRenderer == null)
                    continue;

                ValidateRenderer(
                    playbackHandRoot,
                    ghostHandRoot,
                    playbackRenderers,
                    ghostRenderer,
                    boundsLines,
                    result);
            }

            if (result.originalTransformReferenceCount > 0)
            {
                result.errors.Add(
                    $"원본 Playback Hand Root 하위 Transform 참조가 {result.originalTransformReferenceCount}개 남아 있습니다.");
            }

            result.boundsReport = boundsLines.Count > 0
                ? string.Join("\n", boundsLines)
                : "(bounds 검사 대상 없음)";
            result.success = result.errors.Count == 0;
            return result;
        }

        public static void RefreshLocalBounds(IReadOnlyList<SkinnedMeshRenderer> renderers)
        {
            if (renderers == null)
                return;

            for (var i = 0; i < renderers.Count; i++)
            {
                var renderer = renderers[i];
                if (renderer == null || renderer.sharedMesh == null)
                    continue;

                renderer.localBounds = renderer.sharedMesh.bounds;
            }
        }

        public static void AlignGhostWorldScale(Transform ghostHandRoot, Transform playbackHandRoot)
        {
            if (ghostHandRoot == null || playbackHandRoot == null)
                return;

            var parentLossy = ghostHandRoot.parent != null
                ? ghostHandRoot.parent.lossyScale
                : Vector3.one;
            var targetLossy = playbackHandRoot.lossyScale;

            ghostHandRoot.localScale = new Vector3(
                SafeDivide(targetLossy.x, parentLossy.x),
                SafeDivide(targetLossy.y, parentLossy.y),
                SafeDivide(targetLossy.z, parentLossy.z));
        }

        public static string BuildValidationReport(ValidationResult validation)
        {
            var sb = new StringBuilder();

            sb.AppendLine($"Scale: {validation.scaleReport}");
            sb.AppendLine($"Bounds: {validation.boundsReport}");
            sb.AppendLine(
                $"원본 Transform 참조: {validation.originalTransformReferenceCount} · " +
                $"Ghost bone 참조: {validation.ghostBoneReferenceCount}");

            if (validation.errors != null && validation.errors.Count > 0)
            {
                sb.AppendLine("검증 실패:");
                foreach (var error in validation.errors)
                    sb.AppendLine("• " + error);
            }
            else
            {
                sb.AppendLine("SkinnedMeshRenderer 검증 통과");
            }

            return sb.ToString().TrimEnd();
        }

        static bool TryRemapRendererBones(
            Transform playbackHandRoot,
            Transform ghostHandRoot,
            SkinnedMeshRenderer playbackRenderer,
            SkinnedMeshRenderer ghostRenderer,
            List<string> errors,
            out int remappedBoneCount)
        {
            remappedBoneCount = 0;
            var sourceBones = playbackRenderer.bones;
            if (sourceBones == null || sourceBones.Length == 0)
            {
                errors.Add($"Playback SkinnedMeshRenderer '{playbackRenderer.name}' bones[]가 비어 있습니다.");
                return false;
            }

            var remappedBones = new Transform[sourceBones.Length];
            for (var i = 0; i < sourceBones.Length; i++)
            {
                var sourceBone = sourceBones[i];
                var bonePath = HandGhostTransformPathUtility.GetRelativePath(playbackHandRoot, sourceBone);
                if (bonePath == null)
                {
                    errors.Add(
                        $"bone[{i}] '{sourceBone?.name ?? "(null)"}' — Playback Hand Root 기준 상대 경로를 만들 수 없습니다.");
                    return false;
                }

                if (!HandGhostTransformPathUtility.TryFindByRelativePath(
                        ghostHandRoot,
                        bonePath,
                        out var ghostBone)
                    || ghostBone == null)
                {
                    errors.Add(
                        $"bone[{i}] '{sourceBone.name}' — Ghost 경로 '{bonePath}' Transform을 찾지 못했습니다.");
                    return false;
                }

                remappedBones[i] = ghostBone;
                remappedBoneCount++;
            }

            var rootPath = HandGhostTransformPathUtility.GetRelativePath(
                playbackHandRoot,
                playbackRenderer.rootBone);
            if (rootPath == null)
            {
                errors.Add(
                    $"rootBone '{playbackRenderer.rootBone?.name ?? "(null)"}' — Playback Hand Root 기준 상대 경로를 만들 수 없습니다.");
                return false;
            }

            if (!HandGhostTransformPathUtility.TryFindByRelativePath(
                    ghostHandRoot,
                    rootPath,
                    out var ghostRootBone)
                || ghostRootBone == null)
            {
                errors.Add($"rootBone — Ghost 경로 '{rootPath}' Transform을 찾지 못했습니다.");
                return false;
            }

            ghostRenderer.bones = remappedBones;
            ghostRenderer.rootBone = ghostRootBone;
            return true;
        }

        static void ValidateGhostRootScale(Transform ghostHandRoot, ValidationResult result)
        {
            var localScale = ghostHandRoot.localScale;
            var lossyScale = ghostHandRoot.lossyScale;

            result.scaleReport =
                $"Ghost localScale={FormatVector3(localScale)} · lossyScale={FormatVector3(lossyScale)}";

            if (HasInvalidScale(localScale) || HasInvalidScale(lossyScale))
            {
                result.errors.Add(
                    $"Ghost Root scale이 비정상입니다. local={FormatVector3(localScale)}, lossy={FormatVector3(lossyScale)}");
            }
        }

        static void ValidateRenderer(
            Transform playbackHandRoot,
            Transform ghostHandRoot,
            SkinnedMeshRenderer[] playbackRenderers,
            SkinnedMeshRenderer ghostRenderer,
            List<string> boundsLines,
            ValidationResult result)
        {
            var rendererPath = HandGhostTransformPathUtility.GetRelativePath(
                ghostHandRoot,
                ghostRenderer.transform);
            var label = string.IsNullOrEmpty(rendererPath)
                ? ghostRenderer.name
                : rendererPath;

            if (ghostRenderer.sharedMesh == null)
                result.errors.Add($"SkinnedMeshRenderer '{label}' sharedMesh가 null입니다.");

            var playbackRenderer = FindMatchingPlaybackRenderer(
                playbackHandRoot,
                playbackRenderers,
                ghostHandRoot,
                ghostRenderer.transform);
            if (playbackRenderer != null
                && ghostRenderer.bones != null
                && playbackRenderer.bones != null
                && ghostRenderer.bones.Length != playbackRenderer.bones.Length)
            {
                result.errors.Add(
                    $"SkinnedMeshRenderer '{label}' bones 개수 불일치: ghost={ghostRenderer.bones.Length}, playback={playbackRenderer.bones.Length}");
            }

            if (ghostRenderer.rootBone == null)
            {
                result.errors.Add($"SkinnedMeshRenderer '{label}' rootBone이 null입니다.");
            }
            else if (!HandGhostTransformPathUtility.IsUnderTransform(ghostRenderer.rootBone, ghostHandRoot))
            {
                result.errors.Add(
                    $"SkinnedMeshRenderer '{label}' rootBone '{ghostRenderer.rootBone.name}'이 Ghost Root 하위가 아닙니다.");
            }
            else
            {
                result.ghostBoneReferenceCount++;
            }

            CountBoneReferences(
                ghostRenderer.bones,
                playbackHandRoot,
                ghostHandRoot,
                result);

            if (ghostRenderer.sharedMesh != null && IsBoundsAbnormal(ghostRenderer))
            {
                result.errors.Add(
                    $"SkinnedMeshRenderer '{label}' bounds가 비정상적으로 큽니다. " +
                    $"localBounds={FormatVector3(ghostRenderer.localBounds.size)}, " +
                    $"meshBounds={FormatVector3(ghostRenderer.sharedMesh.bounds.size)}");
            }

            boundsLines.Add(
                $"{label}: localBounds={FormatVector3(ghostRenderer.localBounds.size)}, " +
                $"worldBounds={FormatVector3(ghostRenderer.bounds.size)}");
        }

        static SkinnedMeshRenderer FindMatchingPlaybackRenderer(
            Transform playbackHandRoot,
            SkinnedMeshRenderer[] playbackRenderers,
            Transform ghostHandRoot,
            Transform ghostRendererTransform)
        {
            if (playbackHandRoot == null || playbackRenderers == null)
                return null;

            var ghostRendererPath = HandGhostTransformPathUtility.GetRelativePath(
                ghostHandRoot,
                ghostRendererTransform);
            if (ghostRendererPath == null)
                return null;

            for (var i = 0; i < playbackRenderers.Length; i++)
            {
                var playbackRenderer = playbackRenderers[i];
                if (playbackRenderer == null)
                    continue;

                var playbackPath = HandGhostTransformPathUtility.GetRelativePath(
                    playbackHandRoot,
                    playbackRenderer.transform);
                if (playbackPath == ghostRendererPath)
                    return playbackRenderer;
            }

            return null;
        }

        static void CountBoneReferences(
            Transform[] bones,
            Transform playbackHandRoot,
            Transform ghostHandRoot,
            ValidationResult result)
        {
            if (bones == null)
                return;

            for (var i = 0; i < bones.Length; i++)
            {
                var bone = bones[i];
                if (bone == null)
                {
                    result.errors.Add($"bones[{i}]가 null입니다.");
                    continue;
                }

                if (playbackHandRoot != null
                    && HandGhostTransformPathUtility.IsUnderTransform(bone, playbackHandRoot))
                {
                    result.originalTransformReferenceCount++;
                    var path = HandGhostTransformPathUtility.GetRelativePath(playbackHandRoot, bone);
                    result.errors.Add(
                        $"bones[{i}] '{bone.name}' — 원본 Playback Hand 참조 잔존 (경로='{path ?? bone.name}')");
                    continue;
                }

                if (HandGhostTransformPathUtility.IsUnderTransform(bone, ghostHandRoot))
                {
                    result.ghostBoneReferenceCount++;
                }
                else
                {
                    result.errors.Add(
                        $"bones[{i}] '{bone.name}' — Ghost Root/Playback Root 모두에 속하지 않습니다.");
                }
            }
        }

        static bool IsBoundsAbnormal(SkinnedMeshRenderer renderer)
        {
            var mesh = renderer.sharedMesh;
            if (mesh == null)
                return true;

            var meshSize = mesh.bounds.size;
            var localSize = renderer.localBounds.size;
            var maxMesh = Mathf.Max(meshSize.x, meshSize.y, meshSize.z);
            var maxLocal = Mathf.Max(localSize.x, localSize.y, localSize.z);

            if (maxMesh <= MinScaleComponent)
                return true;

            var lossy = renderer.transform.lossyScale;
            var scaleFactor = Mathf.Max(Mathf.Abs(lossy.x), Mathf.Abs(lossy.y), Mathf.Abs(lossy.z), 1f);
            return maxLocal > maxMesh * BoundsScaleTolerance * scaleFactor;
        }

        static bool HasInvalidScale(Vector3 scale)
        {
            if (float.IsNaN(scale.x) || float.IsNaN(scale.y) || float.IsNaN(scale.z))
                return true;
            if (float.IsInfinity(scale.x) || float.IsInfinity(scale.y) || float.IsInfinity(scale.z))
                return true;

            return Mathf.Abs(scale.x) < MinScaleComponent
                || Mathf.Abs(scale.y) < MinScaleComponent
                || Mathf.Abs(scale.z) < MinScaleComponent
                || Mathf.Abs(scale.x) > MaxScaleComponent
                || Mathf.Abs(scale.y) > MaxScaleComponent
                || Mathf.Abs(scale.z) > MaxScaleComponent;
        }

        static float SafeDivide(float numerator, float denominator)
        {
            if (Mathf.Abs(denominator) < MinScaleComponent)
                return numerator;

            return numerator / denominator;
        }

        static string FormatVector3(Vector3 value)
        {
            return $"({value.x:F3}, {value.y:F3}, {value.z:F3})";
        }
    }
}
