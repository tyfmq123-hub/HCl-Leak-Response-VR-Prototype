using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play 중 HandVisualizer 등에서 생성된 추적 손 루트 Transform을 탐색합니다.
    /// 이름을 LeftHand(Clone) 등으로 가정하지 않고 L_* / R_* 26본·SkinnedMeshRenderer·Handedness 추적으로 검증합니다.
    /// </summary>
    public static class HandPoseTrackedHandFinder
    {
        public struct Candidate
        {
            public Transform handRoot;
            public string hierarchyPath;
            public string objectName;
            public bool isActive;
            public bool skeletonValid;
            public bool hasSkinnedMeshRenderer;
            public bool hasSkeletonDriver;
            public bool skeletonDriverEnabled;
            public bool hasTrackingEvents;
            public HandSide handSide;
            public bool handednessMatchesSide;
            public int jointReferenceCount;
        }

        public struct FindResult
        {
            public bool success;
            public Transform handRoot;
            public string message;
            public List<Candidate> candidates;
        }

        public static FindResult FindTrackedLeftHand()
        {
            return FindTrackedHand(HandSide.Left);
        }

        public static FindResult FindTrackedHand(HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var bonePrefix = HandSideUtility.GetBonePrefix(handSide);
            var expectedHandedness = HandSideUtility.ToHandedness(handSide);

            var result = new FindResult
            {
                candidates = new List<Candidate>(),
            };

            if (!EditorApplication.isPlaying)
            {
                result.message = $"Play Mode에서만 Find Tracked {sideLabel} Hand를 사용할 수 있습니다.";
                return result;
            }

            if (!HandPoseCaptureService.TryGetRunningSubsystem(out var subsystem, out var subsystemError))
            {
                result.message = subsystemError;
                return result;
            }

            var trackedHand = handSide == HandSide.Left ? subsystem.leftHand : subsystem.rightHand;
            if (!trackedHand.isTracked)
            {
                result.message = $"{sideLabel} Hand가 tracked 상태가 아닙니다. Quest 핸드트래킹을 확인하세요.";
                return result;
            }

            var allTransforms = Resources.FindObjectsOfTypeAll<Transform>();
            foreach (var transform in allTransforms)
            {
                if (transform == null || transform.hideFlags != HideFlags.None)
                    continue;

                if (!transform.gameObject.scene.IsValid())
                    continue;

                if (!IsCandidateTransform(transform, handSide, expectedHandedness, out var candidate))
                    continue;

                result.candidates.Add(candidate);
            }

            if (result.candidates.Count == 0)
            {
                result.message =
                    $"조건을 만족하는 {sideLabel} 손 후보를 찾지 못했습니다.\n" +
                    $"{bonePrefix}* 26본, SkinnedMeshRenderer, XRHandSkeletonDriver, " +
                    $"XRHandTrackingEvents({sideLabel})가 필요합니다.";
                return result;
            }

            if (result.candidates.Count > 1)
            {
                var sb = new StringBuilder();
                sb.AppendLine($"{sideLabel} 손 후보가 {result.candidates.Count}개 발견되었습니다. 자동 선택하지 않습니다.");
                foreach (var candidate in result.candidates)
                {
                    sb.Append("• ");
                    sb.Append(candidate.hierarchyPath);
                    sb.AppendLine();
                }

                result.message = sb.ToString().TrimEnd();
                return result;
            }

            result.success = true;
            result.handRoot = result.candidates[0].handRoot;
            result.message = $"{sideLabel} 손 후보 1개를 선택했습니다: {result.candidates[0].hierarchyPath}";
            return result;
        }

        static bool IsCandidateTransform(
            Transform transform,
            HandSide handSide,
            Handedness expectedHandedness,
            out Candidate candidate)
        {
            candidate = default;

            if (transform == null)
                return false;

            var validation = HandSkeletonCatalog.Validate(transform, handSide);
            if (!validation.isValid)
                return false;

            var skinnedMesh = transform.GetComponentInChildren<SkinnedMeshRenderer>(true);
            if (skinnedMesh == null)
                return false;

            var skeletonDriver = transform.GetComponent<XRHandSkeletonDriver>();
            if (skeletonDriver == null || !skeletonDriver.enabled)
                return false;

            var trackingEvents = transform.GetComponent<XRHandTrackingEvents>();
            if (trackingEvents == null || trackingEvents.handedness != expectedHandedness)
                return false;

            var jointRefCount = skeletonDriver.jointTransformReferences?.Count ?? 0;
            if (jointRefCount != HandSkeletonCatalog.RequiredBoneCount)
                return false;

            candidate = new Candidate
            {
                handRoot = transform,
                hierarchyPath = HandPoseCaptureService.GetHierarchyPath(transform),
                objectName = transform.name,
                isActive = transform.gameObject.activeInHierarchy,
                skeletonValid = true,
                hasSkinnedMeshRenderer = true,
                hasSkeletonDriver = true,
                skeletonDriverEnabled = skeletonDriver.enabled,
                hasTrackingEvents = true,
                handSide = handSide,
                handednessMatchesSide = trackingEvents.handedness == expectedHandedness,
                jointReferenceCount = jointRefCount,
            };

            return candidate.isActive;
        }
    }
}
