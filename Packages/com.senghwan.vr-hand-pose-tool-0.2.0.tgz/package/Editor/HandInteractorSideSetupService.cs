using System;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Controller Root에 HandInteractorSide Marker를 추가합니다.
    /// </summary>
    public static class HandInteractorSideSetupService
    {
        public struct Readiness
        {
            public bool canApply;
            public HandSide handSide;
            public Transform interactorTransform;
            public Transform controllerRoot;
            public HandInteractorSide existingMarker;
            public string controllerRootPath;
            public string interactorPath;
            public string blocker;
        }

        public struct ApplyResult
        {
            public bool success;
            public string message;
            public HandInteractorSide marker;
        }

        public static Readiness EvaluateReadiness(Transform interactorTransform, HandSide handSide)
        {
            var readiness = new Readiness { handSide = handSide };

            if (interactorTransform == null)
            {
                readiness.blocker = "Interactor가 지정되지 않았습니다.";
                return readiness;
            }

            if (Application.isPlaying)
            {
                readiness.blocker = "Play Mode에서는 HandInteractorSide를 추가할 수 없습니다.";
                return readiness;
            }

            if (PrefabStageUtility.GetCurrentPrefabStage() != null)
            {
                readiness.blocker = "Prefab Stage에서는 HandInteractorSide를 추가할 수 없습니다.";
                return readiness;
            }

            readiness.interactorTransform = interactorTransform;
            readiness.interactorPath = HandPoseCaptureService.GetHierarchyPath(interactorTransform);

            if (!TryFindControllerRoot(interactorTransform, handSide, out var controllerRoot, out var findError))
            {
                readiness.blocker = findError;
                return readiness;
            }

            readiness.controllerRoot = controllerRoot;
            readiness.controllerRootPath = HandPoseCaptureService.GetHierarchyPath(controllerRoot);

            if (!TryValidateMarkerHierarchy(controllerRoot, handSide, out var existingMarker, out var markerError))
            {
                readiness.blocker = markerError;
                return readiness;
            }

            readiness.existingMarker = existingMarker;
            readiness.canApply = true;
            return readiness;
        }

        public static ApplyResult TryAddHandInteractorSide(Transform interactorTransform, HandSide handSide)
        {
            var readiness = EvaluateReadiness(interactorTransform, handSide);
            if (!readiness.canApply)
            {
                return new ApplyResult
                {
                    success = false,
                    message = readiness.blocker ?? "HandInteractorSide를 추가할 수 없습니다.",
                };
            }

            if (readiness.existingMarker != null)
            {
                return new ApplyResult
                {
                    success = true,
                    marker = readiness.existingMarker,
                    message =
                        $"HandInteractorSide({HandSideUtility.GetLabel(handSide)})가 이미 있습니다: " +
                        readiness.controllerRootPath,
                };
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Add Hand Interactor Side");
            var undoGroup = Undo.GetCurrentGroup();

            try
            {
                var marker = Undo.AddComponent<HandInteractorSide>(readiness.controllerRoot.gameObject);
                var serializedMarker = new SerializedObject(marker);
                serializedMarker.FindProperty("m_HandSide").enumValueIndex = (int)handSide;
                serializedMarker.ApplyModifiedPropertiesWithoutUndo();
                EditorUtility.SetDirty(marker);

                if (readiness.controllerRoot.gameObject.scene.IsValid())
                    EditorSceneManager.MarkSceneDirty(readiness.controllerRoot.gameObject.scene);

                Undo.CollapseUndoOperations(undoGroup);

                return new ApplyResult
                {
                    success = true,
                    marker = marker,
                    message =
                        $"HandInteractorSide({HandSideUtility.GetLabel(handSide)}) 추가: " +
                        readiness.controllerRootPath,
                };
            }
            catch (Exception ex)
            {
                Undo.RevertAllDownToGroup(undoGroup);
                return new ApplyResult
                {
                    success = false,
                    message = $"HandInteractorSide 추가 실패: {ex.Message}",
                };
            }
        }

        public static string DescribeMarkerState(Transform interactorTransform, HandSide handSide)
        {
            if (interactorTransform == null)
                return "Interactor 미지정";

            var marker = interactorTransform.GetComponentInParent<HandInteractorSide>();
            if (marker == null)
                return "HandInteractorSide 없음 (이름 fallback 사용 가능)";

            return $"HandInteractorSide = {HandSideUtility.GetLabel(marker.HandSide)}";
        }

        static bool TryFindControllerRoot(
            Transform interactorTransform,
            HandSide handSide,
            out Transform controllerRoot,
            out string errorMessage)
        {
            controllerRoot = null;
            errorMessage = null;

            var expectedToken = HandSideUtility.GetControllerNameToken(handSide);
            var current = interactorTransform;
            while (current != null)
            {
                if (string.Equals(current.name, expectedToken, StringComparison.Ordinal))
                {
                    controllerRoot = current;
                    return true;
                }

                current = current.parent;
            }

            errorMessage =
                $"Interactor 계층에서 '{expectedToken}' Controller Root를 찾지 못했습니다.";
            return false;
        }

        static bool TryValidateMarkerHierarchy(
            Transform controllerRoot,
            HandSide expectedSide,
            out HandInteractorSide existingMarker,
            out string errorMessage)
        {
            existingMarker = null;
            errorMessage = null;

            var markers = controllerRoot.GetComponentsInParent<HandInteractorSide>(true);
            HandInteractorSide matchingMarker = null;
            foreach (var marker in markers)
            {
                if (marker == null)
                    continue;

                if (marker.HandSide == expectedSide)
                {
                    if (matchingMarker != null && matchingMarker != marker)
                    {
                        errorMessage =
                            $"Controller 계층에 {HandSideUtility.GetLabel(expectedSide)} HandInteractorSide가 여러 개 있습니다.";
                        return false;
                    }

                    matchingMarker = marker;
                    continue;
                }

                errorMessage =
                    $"Controller 계층에 반대 손 HandInteractorSide({HandSideUtility.GetLabel(marker.HandSide)})가 있습니다.";
                return false;
            }

            existingMarker = matchingMarker;
            if (existingMarker != null && !IsTransformUnderRoot(existingMarker.transform, controllerRoot))
            {
                errorMessage = "HandInteractorSide가 예상 Controller Root 아래에 있지 않습니다.";
                return false;
            }

            return true;
        }

        static bool IsTransformUnderRoot(Transform transform, Transform root)
        {
            var current = transform;
            while (current != null)
            {
                if (current == root)
                    return true;

                current = current.parent;
            }

            return false;
        }
    }
}
