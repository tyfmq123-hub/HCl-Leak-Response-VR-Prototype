using System;
using UnityEditor;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// HandGrabPoseRecord ScriptableObject를 Project Asset으로 저장합니다.
    /// </summary>
    public static class HandGrabPoseRecordFactory
    {
        public const string OutputFolder = "Assets/VRHandPoseToolOutput/GrabPoses";

        public struct SaveResult
        {
            public bool success;
            public string message;
            public string assetPath;
            public HandGrabPoseRecord asset;
            public bool pendingApplyRegistered;
            public string pendingApplyMessage;
        }

        public struct SaveOptions
        {
            public GameObject pendingApplyTarget;
            public HandSide pendingApplyHandSide;
            public bool registerPendingApply;
        }

        public static string BuildDefaultFileName(string targetObjectName, HandSide handSide)
        {
            var sanitizedTarget = HandPoseAssetFactory.SanitizeFileName(
                string.IsNullOrWhiteSpace(targetObjectName) ? "Target" : targetObjectName.Trim());
            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            return $"{sanitizedTarget}_{sideLabel}_GrabPose";
        }

        public static SaveResult SaveRecord(
            HandGrabPoseRecord record,
            string fileNameBase,
            SaveOptions? options = null)
        {
            var saveResult = new SaveResult();

            if (record == null)
            {
                saveResult.message = "저장할 HandGrabPoseRecord가 null입니다.";
                return saveResult;
            }

            if (!record.HasBoneData)
            {
                saveResult.message = "Bone 데이터가 없어 Record를 저장할 수 없습니다.";
                return saveResult;
            }

            if (string.IsNullOrWhiteSpace(fileNameBase))
            {
                saveResult.message = "파일 이름이 비어 있습니다.";
                return saveResult;
            }

            EnsureOutputFolderExists();

            var sanitizedName = HandPoseAssetFactory.SanitizeFileName(fileNameBase.Trim());
            var basePath = $"{OutputFolder}/{sanitizedName}.asset";
            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(basePath);

            try
            {
                AssetDatabase.CreateAsset(record, uniquePath);
                EditorUtility.SetDirty(record);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                var savedAsset = AssetDatabase.LoadAssetAtPath<HandGrabPoseRecord>(uniquePath);
                if (savedAsset == null)
                {
                    saveResult.message = $"에셋 저장 후 재로드 실패: {uniquePath}";
                    return saveResult;
                }

                Selection.activeObject = savedAsset;
                EditorGUIUtility.PingObject(savedAsset);

                saveResult.success = true;
                saveResult.asset = savedAsset;
                saveResult.assetPath = uniquePath;
                saveResult.message = $"Grab Pose Record 저장 완료: {uniquePath}";

                if (options.HasValue
                    && options.Value.registerPendingApply
                    && options.Value.pendingApplyTarget != null)
                {
                    var pendingResult = HandGrabPosePendingApplyBridge.TryRegisterPending(
                        options.Value.pendingApplyTarget,
                        options.Value.pendingApplyHandSide,
                        uniquePath);

                    saveResult.pendingApplyRegistered = pendingResult.success;
                    saveResult.pendingApplyMessage = pendingResult.message;

                    if (pendingResult.success)
                    {
                        saveResult.message += "\n" + pendingResult.message;
                    }
                    else
                    {
                        saveResult.message +=
                            "\nRecord Asset은 생성되었지만 Attach/Binding 자동 적용은 예약되지 않았습니다.\n" +
                            pendingResult.message;
                    }
                }
            }
            catch (Exception ex)
            {
                if (record != null && string.IsNullOrEmpty(AssetDatabase.GetAssetPath(record)))
                    UnityEngine.Object.DestroyImmediate(record);

                saveResult.message = $"Grab Pose Record 저장 실패: {ex.Message}";
            }

            return saveResult;
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");

            if (!AssetDatabase.IsValidFolder(OutputFolder))
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "GrabPoses");
        }
    }
}
