using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Hand Side별 Open/Grab AnimationClip으로 Animator Controller를 생성·검증·연결합니다.
    /// </summary>
    public static class HandAnimatorControllerSetupService
    {
        public const string GripParameterName = "Grip";

        public struct QuickConnectResult
        {
            public bool success;
            public string message;
            public string controllerPath;
            public string animatorStatus;
            public string gripParameterStatus;
            public string gripDriverStatus;
            public bool gripDriverPresent;
        }

        public struct SetupResult
        {
            public bool success;
            public bool reusedExisting;
            public bool connectedPlaybackHand;
            public string message;
            public string summary;
            public string controllerPath;
            public AnimatorController controller;
            public List<string> errors;
        }

        public static bool CanSetup(
            HandSide handSide,
            Transform playbackHandRoot,
            AnimationClip openClip,
            AnimationClip grabClip,
            out string blockerMessage)
        {
            blockerMessage = null;

            if (playbackHandRoot == null)
            {
                blockerMessage = "Playback Hand Root가 지정되지 않았습니다.";
                return false;
            }

            if (openClip == null)
            {
                blockerMessage = "Open AnimationClip이 지정되지 않았습니다.";
                return false;
            }

            if (grabClip == null)
            {
                blockerMessage = "Grab AnimationClip이 지정되지 않았습니다.";
                return false;
            }

            if (!ValidateClipBindings(openClip, handSide, out var openBindingError))
            {
                blockerMessage = openBindingError;
                return false;
            }

            if (!ValidateClipBindings(grabClip, handSide, out var grabBindingError))
            {
                blockerMessage = grabBindingError;
                return false;
            }

            var openDiagnostic = HandAnimationClipDiagnostic.Diagnose(openClip, handSide);
            if (!openDiagnostic.success || !openDiagnostic.isHealthy)
            {
                blockerMessage = $"Open Clip 진단 실패: {openClip.name}";
                return false;
            }

            var grabDiagnostic = HandAnimationClipDiagnostic.Diagnose(grabClip, handSide);
            if (!grabDiagnostic.success || !grabDiagnostic.isHealthy)
            {
                blockerMessage = $"Grab Clip 진단 실패: {grabClip.name}";
                return false;
            }

            return true;
        }

        public static SetupResult CreateOrConnect(
            HandSide handSide,
            Transform playbackHandRoot,
            AnimationClip openClip,
            AnimationClip grabClip)
        {
            var result = new SetupResult
            {
                errors = new List<string>(),
            };

            if (!CanSetup(handSide, playbackHandRoot, openClip, grabClip, out var blocker))
            {
                result.message = blocker;
                result.errors.Add(blocker);
                return result;
            }

            var controllerPath = HandSideUtility.GetAnimatorControllerPath(handSide);
            result.controllerPath = controllerPath;
            EnsureOutputFolderExists();

            var existing = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            AnimatorController controller;

            if (existing != null
                && TryValidateExistingController(existing, openClip, grabClip, out _))
            {
                controller = existing;
                result.reusedExisting = true;
            }
            else if (existing != null)
            {
                TryValidateExistingController(existing, openClip, grabClip, out var mismatchReason);
                var sideLabel = HandSideUtility.GetLabel(handSide);
                var replace = EditorUtility.DisplayDialog(
                    $"{sideLabel}손 Animator Controller 교체",
                    $"기존 Controller가 선택한 Open/Grab Clip 구성과 일치하지 않습니다.\n\n" +
                    $"경로: {controllerPath}\n" +
                    $"사유: {mismatchReason}\n\n" +
                    "기존 파일을 삭제하고 새 Controller를 생성하시겠습니까?\n" +
                    "(취소 시 기존 Controller는 수정하지 않습니다.)",
                    "교체 후 생성",
                    "취소");

                if (!replace)
                {
                    result.message =
                        "기존 Animator Controller와 Clip 구성이 일치하지 않아 작업을 취소했습니다. " +
                        "기존 파일은 수정하지 않았습니다.";
                    result.errors.Add(result.message);
                    return result;
                }

                if (!AssetDatabase.DeleteAsset(controllerPath))
                {
                    result.message = $"기존 Controller 삭제 실패: {controllerPath}";
                    result.errors.Add(result.message);
                    return result;
                }

                controller = CreateControllerAsset(controllerPath, openClip, grabClip, out var createError);
                if (controller == null)
                {
                    result.message = createError;
                    result.errors.Add(createError);
                    return result;
                }
            }
            else
            {
                controller = CreateControllerAsset(controllerPath, openClip, grabClip, out var createError);
                if (controller == null)
                {
                    result.message = createError;
                    result.errors.Add(createError);
                    return result;
                }
            }

            if (!ConnectPlaybackHandAnimator(playbackHandRoot, controller, out var connectError))
            {
                result.message = connectError;
                result.errors.Add(connectError);
                result.controller = controller;
                return result;
            }

            result.success = true;
            result.controller = controller;
            result.connectedPlaybackHand = true;
            result.message = result.reusedExisting
                ? $"기존 Animator Controller 재사용: {controllerPath}"
                : $"Animator Controller 생성 완료: {controllerPath}";

            var summary = new StringBuilder();
            summary.AppendLine(result.message);
            summary.AppendLine($"Hand Side: {HandSideUtility.GetLabel(handSide)}");
            summary.AppendLine($"Playback Hand: {playbackHandRoot.name}");
            summary.AppendLine($"Open Clip: {openClip.name} @ Grip 0");
            summary.AppendLine($"Grab Clip: {grabClip.name} @ Grip 1");
            summary.AppendLine(DescribeBlendTree(controller));
            result.summary = summary.ToString().TrimEnd();
            return result;
        }

        public static bool ValidateClipBindings(AnimationClip clip, HandSide handSide, out string errorMessage)
        {
            errorMessage = null;
            if (clip == null)
            {
                errorMessage = "AnimationClip이 null입니다.";
                return false;
            }

            var prefix = HandSideUtility.GetBonePrefix(handSide);
            var oppositePrefix = HandSideUtility.GetOppositeBonePrefix(handSide);
            var bindings = AnimationUtility.GetCurveBindings(clip);
            if (bindings.Length == 0)
            {
                errorMessage = $"{clip.name}: Transform binding이 없습니다.";
                return false;
            }

            foreach (var binding in bindings)
            {
                if (string.IsNullOrEmpty(binding.path))
                    continue;

                if (binding.path.StartsWith(oppositePrefix, StringComparison.Ordinal)
                    || binding.path.Contains("/" + oppositePrefix, StringComparison.Ordinal))
                {
                    errorMessage =
                        $"{clip.name}: 반대 손 접두사({oppositePrefix}) binding이 포함되어 있습니다: {binding.path}";
                    return false;
                }

                if (!binding.path.StartsWith(prefix, StringComparison.Ordinal)
                    && !binding.path.Contains("/" + prefix, StringComparison.Ordinal))
                {
                    errorMessage = $"{clip.name}: {prefix}* binding이 아닙니다: {binding.path}";
                    return false;
                }
            }

            return true;
        }

        public static bool TryValidateExistingController(
            AnimatorController controller,
            AnimationClip expectedOpenClip,
            AnimationClip expectedGrabClip,
            out string mismatchReason)
        {
            mismatchReason = null;
            if (controller == null)
            {
                mismatchReason = "Animator Controller가 null입니다.";
                return false;
            }

            if (!HasGripFloatParameter(controller))
            {
                mismatchReason = "Float 파라미터 'Grip'이 없습니다.";
                return false;
            }

            if (controller.layers == null || controller.layers.Length == 0)
            {
                mismatchReason = "Animator Layer가 없습니다.";
                return false;
            }

            var defaultState = controller.layers[0].stateMachine.defaultState;
            if (defaultState == null || defaultState.motion is not BlendTree blendTree)
            {
                mismatchReason = "기본 상태가 1D Blend Tree가 아닙니다.";
                return false;
            }

            if (blendTree.blendType != BlendTreeType.Simple1D)
            {
                mismatchReason = "Blend Tree 타입이 Simple1D가 아닙니다.";
                return false;
            }

            if (!string.Equals(blendTree.blendParameter, GripParameterName, StringComparison.Ordinal))
            {
                mismatchReason = $"Blend Parameter가 '{GripParameterName}'가 아닙니다.";
                return false;
            }

            if (blendTree.children == null || blendTree.children.Length != 2)
            {
                mismatchReason = "Blend Tree Motion이 2개가 아닙니다.";
                return false;
            }

            var orderedChildren = blendTree.children.OrderBy(child => child.threshold).ToArray();
            var openChild = orderedChildren[0];
            var grabChild = orderedChildren[1];

            if (Mathf.Abs(openChild.threshold) > 0.001f)
            {
                mismatchReason = "Open Clip threshold가 0이 아닙니다.";
                return false;
            }

            if (Mathf.Abs(grabChild.threshold - 1f) > 0.001f)
            {
                mismatchReason = "Grab Clip threshold가 1이 아닙니다.";
                return false;
            }

            if (!MotionMatchesClip(openChild.motion, expectedOpenClip))
            {
                mismatchReason =
                    $"Open Clip 불일치 (기대: {expectedOpenClip.name}, 실제: {GetMotionLabel(openChild.motion)}).";
                return false;
            }

            if (!MotionMatchesClip(grabChild.motion, expectedGrabClip))
            {
                mismatchReason =
                    $"Grab Clip 불일치 (기대: {expectedGrabClip.name}, 실제: {GetMotionLabel(grabChild.motion)}).";
                return false;
            }

            return true;
        }

        static AnimatorController CreateControllerAsset(
            string controllerPath,
            AnimationClip openClip,
            AnimationClip grabClip,
            out string errorMessage)
        {
            errorMessage = null;

            try
            {
                var controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
                controller.AddParameter(GripParameterName, AnimatorControllerParameterType.Float);

                var blendTree = new BlendTree
                {
                    name = "Blend Tree",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = GripParameterName,
                    blendParameterY = GripParameterName,
                    useAutomaticThresholds = true,
                };
                AssetDatabase.AddObjectToAsset(blendTree, controller);

                blendTree.AddChild(openClip, 0f);
                blendTree.AddChild(grabClip, 1f);

                var rootStateMachine = controller.layers[0].stateMachine;
                var state = rootStateMachine.AddState("Blend Tree");
                state.motion = blendTree;
                rootStateMachine.defaultState = state;

                EditorUtility.SetDirty(controller);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                return controller;
            }
            catch (Exception ex)
            {
                errorMessage = $"Animator Controller 생성 실패: {ex.Message}";
                return null;
            }
        }

        static bool ConnectPlaybackHandAnimator(
            Transform playbackHandRoot,
            RuntimeAnimatorController controller,
            out string errorMessage)
        {
            errorMessage = null;
            if (playbackHandRoot == null)
            {
                errorMessage = "Playback Hand Root가 null입니다.";
                return false;
            }

            if (controller == null)
            {
                errorMessage = "Animator Controller가 null입니다.";
                return false;
            }

            Undo.SetCurrentGroupName("Connect Hand Animator Controller");
            var undoGroup = Undo.GetCurrentGroup();

            var animator = playbackHandRoot.GetComponent<Animator>();
            if (animator == null)
            {
                animator = Undo.AddComponent<Animator>(playbackHandRoot.gameObject);
            }
            else
            {
                Undo.RecordObject(animator, "Assign Animator Controller");
            }

            animator.runtimeAnimatorController = controller;
            EditorUtility.SetDirty(animator);

            if (!Application.isPlaying && playbackHandRoot.gameObject.scene.IsValid())
            {
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);
            }

            Undo.CollapseUndoOperations(undoGroup);
            return true;
        }

        static bool HasGripFloatParameter(AnimatorController controller)
        {
            foreach (var parameter in controller.parameters)
            {
                if (string.Equals(parameter.name, GripParameterName, StringComparison.Ordinal)
                    && parameter.type == AnimatorControllerParameterType.Float)
                {
                    return true;
                }
            }

            return false;
        }

        static bool MotionMatchesClip(Motion motion, AnimationClip expectedClip)
        {
            if (motion == null || expectedClip == null)
                return false;

            if (ReferenceEquals(motion, expectedClip))
                return true;

            if (motion is not AnimationClip actualClip)
                return false;

            var actualPath = AssetDatabase.GetAssetPath(actualClip);
            var expectedPath = AssetDatabase.GetAssetPath(expectedClip);
            return !string.IsNullOrEmpty(actualPath)
                && string.Equals(actualPath, expectedPath, StringComparison.OrdinalIgnoreCase);
        }

        static string GetMotionLabel(Motion motion)
        {
            return motion != null ? motion.name : "(null)";
        }

        static string DescribeBlendTree(AnimatorController controller)
        {
            if (controller == null || controller.layers.Length == 0)
                return "Blend Tree: (none)";

            if (controller.layers[0].stateMachine.defaultState?.motion is not BlendTree blendTree)
                return "Blend Tree: (none)";

            var summary = new StringBuilder();
            summary.Append($"Blend Tree: parameter={blendTree.blendParameter}; ");
            for (var i = 0; i < blendTree.children.Length; i++)
            {
                var child = blendTree.children[i];
                summary.Append($"{GetMotionLabel(child.motion)}@{child.threshold:0.##}");
                if (i < blendTree.children.Length - 1)
                    summary.Append(", ");
            }

            return summary.ToString();
        }

        /// <summary>
        /// 프로젝트에서 Hand Side에 맞는 기존 AnimatorController를 탐색해 반환합니다.
        /// 클립이 실제로 들어 있는(animationClips.Length > 0) 컨트롤러를 우선합니다.
        /// 탐색 순서: Assets/Animations/ → Assets/VRHandPoseToolOutput/Animations/ → 프로젝트 전체.
        /// </summary>
        public static RuntimeAnimatorController FindExistingControllerForHandSide(HandSide handSide)
        {
            var nameToken = handSide == HandSide.Left ? "OculusHand_L" : "OculusHand_R";

            // 1) 프로젝트 전체에서 해당 이름 패턴 탐색 — 클립 있는 것 우선
            var guids = AssetDatabase.FindAssets($"t:AnimatorController {nameToken}");
            RuntimeAnimatorController bestWithClips = null;
            RuntimeAnimatorController bestAny = null;

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var ctrl = AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(path);
                if (ctrl == null)
                    continue;

                if (bestAny == null)
                    bestAny = ctrl;

                if (ctrl.animationClips.Length > 0 && bestWithClips == null)
                    bestWithClips = ctrl;
            }

            return bestWithClips ?? bestAny;
        }

        /// <summary>
        /// 기존 AnimatorController를 자동 탐색해 Playback Hand Animator에 연결합니다.
        /// 클립 제작 없이 빠르게 Controller 애니메이션을 설정할 때 사용합니다.
        /// </summary>
        public static QuickConnectResult QuickConnectExistingController(
            HandSide handSide,
            Transform playbackHandRoot)
        {
            var result = new QuickConnectResult();

            if (playbackHandRoot == null)
            {
                result.message = "Playback Hand Root가 지정되지 않았습니다.";
                return result;
            }

            var controller = FindExistingControllerForHandSide(handSide);
            if (controller == null)
            {
                result.message =
                    $"{HandSideUtility.GetLabel(handSide)}손 AnimatorController를 찾지 못했습니다. " +
                    "프로젝트에 OculusHand_R.controller 또는 OculusHand_L.controller가 있는지 확인하세요.";
                return result;
            }

            result.controllerPath = AssetDatabase.GetAssetPath(controller);

            if (!ConnectPlaybackHandAnimator(playbackHandRoot, controller, out var connectError))
            {
                result.message = connectError;
                return result;
            }

            result.animatorStatus = $"연결됨: {controller.name} ({result.controllerPath})";

            // Grip float 파라미터 확인
            var hasGrip = false;
            if (controller is AnimatorController animCtrl)
            {
                foreach (var param in animCtrl.parameters)
                {
                    if (string.Equals(param.name, GripParameterName, StringComparison.Ordinal)
                        && param.type == AnimatorControllerParameterType.Float)
                    {
                        hasGrip = true;
                        break;
                    }
                }
            }
            else
            {
                // RuntimeAnimatorController — 클립 수로 간접 확인
                hasGrip = controller.animationClips.Length >= 2;
            }

            result.gripParameterStatus = hasGrip
                ? $"확인됨 (Float '{GripParameterName}')"
                : $"없음 또는 확인 불가 — 수동 확인 필요";

            // ControllerHandGripAnimator 탐색 (playbackHandRoot 또는 부모)
            var gripAnimator = playbackHandRoot.GetComponentInParent<ControllerHandGripAnimator>(true);
            gripAnimator ??= playbackHandRoot.GetComponent<ControllerHandGripAnimator>();

            if (gripAnimator != null)
            {
                result.gripDriverStatus = $"기존 연결됨: {gripAnimator.gameObject.name}";
                result.gripDriverPresent = true;
            }
            else
            {
                result.gripDriverStatus = "없음 — Grip Driver를 수동으로 추가하세요";
                result.gripDriverPresent = false;
            }

            result.success = true;
            result.message = $"AnimatorController 자동 연결 완료: {controller.name}";
            return result;
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
            {
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");
            }

            if (!AssetDatabase.IsValidFolder(HandSideUtility.AnimationsOutputFolder))
            {
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "Animations");
            }
        }
    }
}
