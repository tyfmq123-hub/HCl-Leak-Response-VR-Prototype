using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play 모드에서 Tracking Hand Root의 L_* / R_* 본 Transform과 XRHandSubsystem joint pose를 캡처합니다.
    /// Bone localRotation은 실제 Transform에서만 읽으며, joint tracking rotation은 별도 저장합니다.
    /// </summary>
    public static class HandPoseCaptureService
    {
        public struct Readiness
        {
            public bool canCapture;
            public bool isPlaying;
            public HandSide handSide;
            public string trackingHandRootName;
            public bool skeletonValid;
            public string skeletonSummary;
            public bool skeletonDriverPresent;
            public bool skeletonDriverEnabled;
            public bool trackingEventsPresent;
            public Handedness handedness;
            public bool handednessIsLeft;
            public bool subsystemRunning;
            public bool leftHandTracked;
            public bool handTracked;
            public int boneCount;
            public int expectedBoneCount;
            public int validJointPoseCount;
            public int totalJointCount;
            public string targetName;
            public string trackingHandRootHierarchyPath;
            public bool hasSkinnedMeshRenderer;
            public float distanceToMainCamera;
            public float distanceToTarget;
            public bool hasTargetRelativePreview;
            public Vector3 targetRelativePositionPreview;
            public Quaternion targetRelativeRotationPreview;
            public List<string> blockers;
        }

        public static Readiness EvaluateReadiness(
            Transform trackingHandRoot,
            Transform targetTransform)
        {
            return EvaluateReadiness(trackingHandRoot, targetTransform, HandSide.Left);
        }

        public static Readiness EvaluateReadiness(
            Transform trackingHandRoot,
            Transform targetTransform,
            HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var expectedHandedness = HandSideUtility.ToHandedness(handSide);

            var readiness = new Readiness
            {
                isPlaying = EditorApplication.isPlaying,
                handSide = handSide,
                expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                boneCount = 0,
                validJointPoseCount = 0,
                totalJointCount = XRHandJointID.EndMarker.ToIndex(),
                blockers = new List<string>(),
            };

            if (targetTransform != null)
            {
                readiness.targetName = targetTransform.name;
            }
            else
            {
                readiness.targetName = "(none)";
            }

            if (!readiness.isPlaying)
            {
                readiness.blockers.Add("Play Mode가 아닙니다.");
            }

            if (trackingHandRoot == null)
            {
                readiness.blockers.Add("Tracking Hand Root가 지정되지 않았습니다.");
                readiness.canCapture = false;
                return readiness;
            }

            readiness.trackingHandRootName = trackingHandRoot.name;
            readiness.trackingHandRootHierarchyPath = GetHierarchyPath(trackingHandRoot);
            readiness.hasSkinnedMeshRenderer =
                trackingHandRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;

            var mainCamera = Camera.main;
            if (mainCamera != null)
            {
                readiness.distanceToMainCamera =
                    Vector3.Distance(mainCamera.transform.position, trackingHandRoot.position);
            }

            if (targetTransform != null)
            {
                readiness.distanceToTarget =
                    Vector3.Distance(targetTransform.position, trackingHandRoot.position);
            }

            var validation = HandSkeletonCatalog.Validate(trackingHandRoot, handSide);
            readiness.skeletonValid = validation.isValid;
            readiness.skeletonSummary = validation.summary;
            readiness.boneCount = validation.foundBoneCount;

            if (!validation.isValid)
            {
                readiness.blockers.Add("손 본 검증 실패.");
            }

            var skeletonDriver = trackingHandRoot.GetComponent<XRHandSkeletonDriver>();
            readiness.skeletonDriverPresent = skeletonDriver != null;
            readiness.skeletonDriverEnabled = skeletonDriver != null && skeletonDriver.enabled;

            if (skeletonDriver == null)
            {
                readiness.blockers.Add("XRHandSkeletonDriver가 없습니다.");
            }
            else if (!skeletonDriver.enabled)
            {
                readiness.blockers.Add("XRHandSkeletonDriver가 비활성 상태입니다.");
            }

            var trackingEvents = trackingHandRoot.GetComponent<XRHandTrackingEvents>();
            readiness.trackingEventsPresent = trackingEvents != null;

            if (trackingEvents == null)
            {
                readiness.blockers.Add("XRHandTrackingEvents가 없습니다.");
            }
            else
            {
                readiness.handedness = trackingEvents.handedness;
                readiness.handednessIsLeft = trackingEvents.handedness == Handedness.Left;

                if (trackingEvents.handedness != expectedHandedness)
                {
                    readiness.blockers.Add(
                        $"Handedness가 {sideLabel}가 아닙니다 (현재: {trackingEvents.handedness}).");
                }
            }

            if (skeletonDriver != null)
            {
                var jointRefCount = skeletonDriver.jointTransformReferences?.Count ?? 0;
                if (jointRefCount != HandSkeletonCatalog.RequiredBoneCount)
                {
                    readiness.blockers.Add(
                        $"Joint Transform References가 {jointRefCount}개입니다 (기대 {HandSkeletonCatalog.RequiredBoneCount}).");
                }
            }

            if (TryGetRunningSubsystem(out var subsystem, out var subsystemError))
            {
                readiness.subsystemRunning = true;
                readiness.leftHandTracked = subsystem.leftHand.isTracked;
                readiness.handTracked = GetTrackedHand(subsystem, handSide).isTracked;
                readiness.validJointPoseCount = CountValidJointPoses(GetTrackedHand(subsystem, handSide));

                if (!readiness.handTracked)
                {
                    readiness.blockers.Add($"{sideLabel} Hand가 tracked 상태가 아닙니다.");
                }
            }
            else
            {
                readiness.subsystemRunning = false;
                readiness.leftHandTracked = false;
                readiness.handTracked = false;
                readiness.blockers.Add(subsystemError);
            }

            if (readiness.boneCount != readiness.expectedBoneCount)
            {
                readiness.blockers.Add(
                    $"Bone 수가 {readiness.boneCount} / {readiness.expectedBoneCount}입니다.");
            }

            if (trackingHandRoot != null && targetTransform != null)
            {
                var relative = HandPoseTargetSpace.ComputeRelativePose(trackingHandRoot, targetTransform);
                readiness.hasTargetRelativePreview = relative.isValid;
                readiness.targetRelativePositionPreview = relative.relativePosition;
                readiness.targetRelativeRotationPreview = relative.relativeRotation;
            }

            readiness.canCapture = readiness.blockers.Count == 0;
            return readiness;
        }

        /// <summary>
        /// XRHandSkeletonDriver가 jointsUpdated에서 본 Transform을 갱신한 뒤의 값을 읽습니다.
        /// 버튼 클릭 시점에는 마지막 프레임의 포즈가 이미 L_* / R_* Transform에 반영되어 있습니다.
        /// </summary>
        public static HandPoseCaptureResult Capture(
            Transform trackingHandRoot,
            XRHandSkeletonDriver skeletonDriver,
            XRHandTrackingEvents trackingEvents,
            Transform targetTransform,
            string poseName)
        {
            return Capture(
                trackingHandRoot,
                skeletonDriver,
                trackingEvents,
                targetTransform,
                poseName,
                HandSide.Left);
        }

        public static HandPoseCaptureResult Capture(
            Transform trackingHandRoot,
            XRHandSkeletonDriver skeletonDriver,
            XRHandTrackingEvents trackingEvents,
            Transform targetTransform,
            string poseName,
            HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);

            var result = new HandPoseCaptureResult
            {
                success = false,
                sourceHandName = trackingHandRoot != null ? trackingHandRoot.name : null,
                targetName = targetTransform != null ? targetTransform.name : null,
            };

            var readiness = EvaluateReadiness(trackingHandRoot, targetTransform, handSide);
            if (!readiness.canCapture)
            {
                result.errors.AddRange(readiness.blockers);
                result.message = "캡처 조건을 충족하지 못했습니다.";
                return result;
            }

            if (string.IsNullOrWhiteSpace(poseName))
            {
                result.errors.Add("Pose Name이 비어 있습니다.");
                result.message = "Pose Name이 필요합니다.";
                return result;
            }

            var validation = HandSkeletonCatalog.Validate(trackingHandRoot, handSide);
            if (!validation.isValid)
            {
                result.errors.Add(validation.summary);
                result.message = "손 본 검증 실패.";
                return result;
            }

            if (!TryCaptureBones(trackingHandRoot, handSide, out var bones, out var boneError))
            {
                result.errors.Add(boneError);
                result.message = "Bone 캡처 실패.";
                return result;
            }

            if (bones.Count != HandSkeletonCatalog.RequiredBoneCount)
            {
                result.errors.Add(
                    $"Bone 개수가 {bones.Count}개입니다 (기대 {HandSkeletonCatalog.RequiredBoneCount}).");
                result.message = "Bone 개수 불일치.";
                return result;
            }

            if (!TryGetRunningSubsystem(out var subsystem, out var subsystemError))
            {
                result.errors.Add(subsystemError);
                result.message = "XRHandSubsystem을 사용할 수 없습니다.";
                return result;
            }

            var trackedHand = GetTrackedHand(subsystem, handSide);
            if (!trackedHand.isTracked)
            {
                result.errors.Add($"{sideLabel} Hand가 tracked 상태가 아닙니다.");
                result.message = "손 추적 없음.";
                return result;
            }

            var joints = CaptureJoints(trackedHand);
            result.validJointPoseCount = joints.Count(j => j.poseValid);

            if (result.validJointPoseCount == 0)
            {
                result.errors.Add("유효한 joint pose가 하나도 없습니다.");
                result.message = "Joint 캡처 실패.";
                return result;
            }

            if (result.validJointPoseCount < joints.Count)
            {
                result.warnings.Add(
                    $"일부 joint pose만 유효합니다: {result.validJointPoseCount} / {joints.Count}. " +
                    $"Bone 데이터는 {HandSideUtility.GetBonePrefix(handSide)}* Transform에서 읽었으며 joint 실패와 무관합니다.");
            }

            result.bones = CloneBoneList(bones);
            result.joints = CloneJointList(joints);

            result.rootWorldPosition = trackingHandRoot.position;
            result.rootWorldRotation = trackingHandRoot.rotation;

            var relativePose = HandPoseTargetSpace.ComputeRelativePose(trackingHandRoot, targetTransform);
            result.hasTargetRelativePose = relativePose.isValid;
            result.targetRelativePosition = relativePose.relativePosition;
            result.targetRelativeRotation = relativePose.relativeRotation;

            result.success = true;
            result.message =
                $"캡처 성공: Bone {result.bones.Count}, Joint {result.joints.Count} " +
                $"(유효 pose {result.validJointPoseCount}), Target={(relativePose.isValid ? targetTransform.name : "none")}";

            return result;
        }

        static bool TryCaptureBones(
            Transform handRoot,
            HandSide handSide,
            out List<HandBonePoseData> bones,
            out string errorMessage)
        {
            bones = new List<HandBonePoseData>();
            errorMessage = null;

            if (!HandSkeletonCatalog.TryBuildBoneMap(handRoot, handSide, out var boneMap, out var mapError))
            {
                errorMessage = mapError;
                return false;
            }

            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                if (!boneMap.TryGetValue(boneName, out var boneTransform) || boneTransform == null)
                {
                    errorMessage = $"필수 본 Transform을 찾을 수 없습니다: {boneName}";
                    bones.Clear();
                    return false;
                }

                string parentBoneName;
                if (expectedParentBoneName == null)
                {
                    parentBoneName = handRoot.name;
                }
                else if (!boneMap.TryGetValue(expectedParentBoneName, out _))
                {
                    var parent = boneTransform.parent;
                    parentBoneName = parent != null ? parent.name : handRoot.name;
                }
                else
                {
                    parentBoneName = expectedParentBoneName;
                }

                bones.Add(new HandBonePoseData
                {
                    boneName = boneName,
                    parentBoneName = parentBoneName,
                    localPosition = boneTransform.localPosition,
                    localRotation = boneTransform.localRotation,
                    localScale = boneTransform.localScale,
                });
            }

            if (bones.Count != HandSkeletonCatalog.RequiredBoneCount)
            {
                errorMessage =
                    $"Bone 수집 개수가 {bones.Count}개입니다 (기대 {HandSkeletonCatalog.RequiredBoneCount}).";
                bones.Clear();
                return false;
            }

            return true;
        }

        /// <summary>
        /// XRHandJoint.TryGetPose는 tracking-space joint pose를 반환합니다. Bone localRotation과 다릅니다.
        /// </summary>
        static List<HandJointTrackingData> CaptureJoints(XRHand hand)
        {
            var joints = new List<HandJointTrackingData>();

            for (var jointId = XRHandJointID.BeginMarker; jointId < XRHandJointID.EndMarker; ++jointId)
            {
                var joint = hand.GetJoint(jointId);
                var entry = new HandJointTrackingData { jointId = jointId };

                if (joint.TryGetPose(out var pose))
                {
                    entry.poseValid = true;
                    entry.trackingPosition = pose.position;
                    entry.trackingRotation = pose.rotation;
                }
                else
                {
                    entry.poseValid = false;
                    entry.trackingPosition = Vector3.zero;
                    entry.trackingRotation = Quaternion.identity;
                }

                joints.Add(entry);
            }

            return joints;
        }

        static int CountValidJointPoses(XRHand hand)
        {
            var count = 0;
            for (var jointId = XRHandJointID.BeginMarker; jointId < XRHandJointID.EndMarker; ++jointId)
            {
                if (hand.GetJoint(jointId).TryGetPose(out _))
                    count++;
            }

            return count;
        }

        static XRHand GetTrackedHand(XRHandSubsystem subsystem, HandSide handSide)
        {
            return handSide == HandSide.Left ? subsystem.leftHand : subsystem.rightHand;
        }

        public static string GetHierarchyPath(Transform transform)
        {
            if (transform == null)
                return "(none)";

            var parts = new List<string>();
            var current = transform;
            while (current != null)
            {
                parts.Add(current.name);
                current = current.parent;
            }

            parts.Reverse();
            return string.Join("/", parts);
        }

        public static bool TryGetRunningSubsystem(out XRHandSubsystem subsystem, out string error)
        {
            var subsystems = new List<XRHandSubsystem>();
            SubsystemManager.GetSubsystems(subsystems);

            subsystem = subsystems.FirstOrDefault(s => s.running);
            if (subsystem == null)
            {
                error = "실행 중인 XRHandSubsystem을 찾을 수 없습니다.";
                return false;
            }

            error = null;
            return true;
        }

        static List<HandBonePoseData> CloneBoneList(IReadOnlyList<HandBonePoseData> source)
        {
            var clone = new List<HandBonePoseData>(source.Count);
            foreach (var bone in source)
            {
                clone.Add(new HandBonePoseData
                {
                    boneName = bone.boneName,
                    parentBoneName = bone.parentBoneName,
                    localPosition = bone.localPosition,
                    localRotation = bone.localRotation,
                    localScale = bone.localScale,
                });
            }

            return clone;
        }

        static List<HandJointTrackingData> CloneJointList(IReadOnlyList<HandJointTrackingData> source)
        {
            var clone = new List<HandJointTrackingData>(source.Count);
            foreach (var joint in source)
            {
                clone.Add(new HandJointTrackingData
                {
                    jointId = joint.jointId,
                    poseValid = joint.poseValid,
                    trackingPosition = joint.trackingPosition,
                    trackingRotation = joint.trackingRotation,
                });
            }

            return clone;
        }
    }
}
