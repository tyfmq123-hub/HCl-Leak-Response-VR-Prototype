using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR.Hands;
using Unity.XR.CoreUtils;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// HandVisualizer Tracking Prefab을 XR Origin / Camera Offset 아래에 배치합니다.
    /// Controller 아래에는 생성하지 않습니다.
    /// </summary>
    public static class HandTrackingHandSetupService
    {
        public const string TrackingFolderName = "VR Hand Pose Tool Tracking";

        public struct SetupResult
        {
            public bool success;
            public bool reusedExisting;
            public Transform trackingHandRoot;
            public Transform trackingFolder;
            public string prefabPath;
            public string message;
        }

        public struct ExistingCandidate
        {
            public Transform handRoot;
            public string hierarchyPath;
            public bool isValid;
            public string failReason;
        }

        public static SetupResult EnsureTrackingHand(HandSide handSide, GameObject trackingPrefab, string prefabPath)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var scene = SceneManager.GetActiveScene();
            if (!scene.IsValid() || !scene.isLoaded)
            {
                return Fail("활성 씬이 없거나 로드되지 않았습니다.");
            }

            if (trackingPrefab == null)
            {
                return Fail($"{sideLabel} Tracking Prefab이 null입니다.");
            }

            if (!TryResolveCameraOffset(scene, out var cameraOffset, out var resolveError))
            {
                return Fail(resolveError);
            }

            var existing = FindExistingValidTrackingHands(scene, handSide);
            if (existing.Count > 1)
            {
                var sb = new StringBuilder();
                sb.AppendLine(
                    $"{sideLabel} Tracking Hand 유효 후보가 {existing.Count}개입니다. 자동 선택하지 않습니다.");
                foreach (var candidate in existing)
                    sb.AppendLine($"• {candidate.hierarchyPath}");
                return Fail(sb.ToString().TrimEnd());
            }

            if (existing.Count == 1)
            {
                var reused = existing[0].handRoot;
                return new SetupResult
                {
                    success = true,
                    reusedExisting = true,
                    trackingHandRoot = reused,
                    trackingFolder = FindTrackingFolder(cameraOffset),
                    prefabPath = prefabPath,
                    message =
                        $"{sideLabel} Tracking Hand 재사용: {HandPoseCaptureService.GetHierarchyPath(reused)}",
                };
            }

            var folder = FindOrCreateTrackingFolder(cameraOffset);
            var instance = PrefabUtility.InstantiatePrefab(trackingPrefab, folder) as GameObject;
            if (instance == null)
            {
                return Fail($"PrefabUtility.InstantiatePrefab 실패: {prefabPath}");
            }

            Undo.RegisterCreatedObjectUndo(instance, $"Create {sideLabel} Hand Tracking");
            instance.name = $"{sideLabel} Hand Tracking";
            instance.transform.localPosition = Vector3.zero;
            instance.transform.localRotation = Quaternion.identity;
            instance.transform.localScale = Vector3.one;

            if (!TryValidateTrackingInstance(instance, handSide, out var validateError))
            {
                return new SetupResult
                {
                    success = false,
                    trackingHandRoot = instance.transform,
                    trackingFolder = folder,
                    prefabPath = prefabPath,
                    message =
                        $"{sideLabel} Tracking Hand 생성 직후 검증 실패:\n{validateError}\n" +
                        $"경로: {HandPoseCaptureService.GetHierarchyPath(instance.transform)}",
                };
            }

            EditorSceneManager.MarkSceneDirty(scene);

            return new SetupResult
            {
                success = true,
                reusedExisting = false,
                trackingHandRoot = instance.transform,
                trackingFolder = folder,
                prefabPath = prefabPath,
                message =
                    $"{sideLabel} Tracking Hand 생성: {HandPoseCaptureService.GetHierarchyPath(instance.transform)}\n" +
                    $"Prefab: {prefabPath}",
            };
        }

        public static List<ExistingCandidate> FindExistingValidTrackingHands(Scene scene, HandSide handSide)
        {
            var results = new List<ExistingCandidate>();
            if (!scene.IsValid() || !scene.isLoaded)
                return results;

            var expected = HandSideUtility.ToHandedness(handSide);
            foreach (var root in scene.GetRootGameObjects())
            {
                if (root == null)
                    continue;

                foreach (var driver in root.GetComponentsInChildren<XRHandSkeletonDriver>(true))
                {
                    if (driver == null)
                        continue;

                    var handRoot = driver.transform;
                    if (!handRoot.gameObject.scene.IsValid() || handRoot.gameObject.scene != scene)
                        continue;

                    if (EditorUtility.IsPersistent(handRoot.gameObject))
                        continue;

                    if (!TryValidateTrackingInstance(handRoot.gameObject, handSide, out var failReason))
                        continue;

                    // 다른 손 Tracking은 후보에서 제외 (이미 handedness로 걸러지지만 명시)
                    var events = handRoot.GetComponent<XRHandTrackingEvents>()
                        ?? handRoot.GetComponentInChildren<XRHandTrackingEvents>(true);
                    if (events == null || events.handedness != expected)
                        continue;

                    results.Add(new ExistingCandidate
                    {
                        handRoot = handRoot,
                        hierarchyPath = HandPoseCaptureService.GetHierarchyPath(handRoot),
                        isValid = true,
                    });
                }
            }

            return results;
        }

        public static bool TryValidateTrackingInstance(GameObject instance, HandSide handSide, out string errorMessage)
        {
            errorMessage = null;
            if (instance == null)
            {
                errorMessage = "instance null";
                return false;
            }

            var expected = HandSideUtility.ToHandedness(handSide);
            var candidate = HandVisualizerAssetResolver.EvaluateTrackingPrefab(
                instance,
                PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(instance),
                handSide,
                expected);

            if (!candidate.isValid)
            {
                errorMessage = candidate.failReason ?? "Tracking Hand 검증 실패";
                return false;
            }

            return true;
        }

        public static bool TryResolveCameraOffset(Scene scene, out Transform cameraOffset, out string errorMessage)
        {
            cameraOffset = null;
            errorMessage = null;

            var origins = new List<XROrigin>();
            foreach (var root in scene.GetRootGameObjects())
            {
                if (root == null)
                    continue;

                origins.AddRange(root.GetComponentsInChildren<XROrigin>(true));
            }

            // 씬에 속한 것만
            origins.RemoveAll(origin =>
                origin == null
                || !origin.gameObject.scene.IsValid()
                || origin.gameObject.scene != scene);

            if (origins.Count == 0)
            {
                errorMessage =
                    "활성 씬에서 XROrigin 컴포넌트를 찾지 못했습니다. 이름만으로 XR Origin을 찾지 않습니다.";
                return false;
            }

            if (origins.Count > 1)
            {
                errorMessage =
                    $"활성 씬에서 XROrigin 컴포넌트가 {origins.Count}개입니다. 자동 선택하지 않습니다.";
                return false;
            }

            var origin = origins[0];
            var floorOffset = origin.CameraFloorOffsetObject;
            if (floorOffset == null)
            {
                errorMessage = "XROrigin.CameraFloorOffsetObject가 비어 있습니다.";
                return false;
            }

            if (floorOffset.scene != scene)
            {
                errorMessage = "CameraFloorOffsetObject가 활성 씬에 속하지 않습니다.";
                return false;
            }

            cameraOffset = floorOffset.transform;
            return true;
        }

        static Transform FindTrackingFolder(Transform cameraOffset)
        {
            if (cameraOffset == null)
                return null;

            for (var i = 0; i < cameraOffset.childCount; i++)
            {
                var child = cameraOffset.GetChild(i);
                if (string.Equals(child.name, TrackingFolderName, StringComparison.Ordinal))
                    return child;
            }

            return null;
        }

        static Transform FindOrCreateTrackingFolder(Transform cameraOffset)
        {
            var existing = FindTrackingFolder(cameraOffset);
            if (existing != null)
                return existing;

            var folder = new GameObject(TrackingFolderName);
            Undo.RegisterCreatedObjectUndo(folder, $"Create {TrackingFolderName}");
            folder.transform.SetParent(cameraOffset, false);
            folder.transform.localPosition = Vector3.zero;
            folder.transform.localRotation = Quaternion.identity;
            folder.transform.localScale = Vector3.one;
            return folder.transform;
        }

        static SetupResult Fail(string message)
        {
            return new SetupResult
            {
                success = false,
                message = message,
            };
        }
    }
}
