using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 프로젝트에서 Left/Right Grip(Value/Axis) InputAction을 찾고 InputActionReference를 재사용하거나 1회 생성합니다.
    /// 원본 .inputactions 파일은 수정하지 않습니다.
    /// </summary>
    public static class HandGripInputActionFinder
    {
        public const string PreferredActionName = "Select Value";
        public const string ReferenceOutputFolder = HandSideUtility.InputActionsOutputFolder;

        public struct CandidateInfo
        {
            public string inputActionAssetPath;
            public string actionMapName;
            public string actionName;
            public string actionId;
            public string actionType;
            public string expectedControlType;
            public string bindingPath;
            public int score;
        }

        public struct FindResult
        {
            public bool success;
            public bool requiresUserSelection;
            public List<CandidateInfo> tiedCandidates;

            public string inputActionAssetPath;
            public string actionMapName;
            public string actionName;
            public string actionId;
            public string actionType;
            public string expectedControlType;
            public string bindingPath;

            public InputActionReference inputActionReference;
            public string referenceAssetPath;
            public bool reusedExistingReference;
            public bool createdNewReference;

            public string failureReason;
            public string displaySummary;
        }

        public static FindResult FindAndResolveReference(
            HandSide handSide,
            CandidateInfo? selectedCandidate = null)
        {
            if (selectedCandidate.HasValue)
            {
                return ResolveReferenceForCandidate(handSide, selectedCandidate.Value);
            }

            var candidateResult = CollectScoredCandidates(handSide);
            if (!candidateResult.success)
            {
                return new FindResult
                {
                    success = false,
                    failureReason = candidateResult.failureReason,
                    displaySummary = candidateResult.failureReason,
                    tiedCandidates = candidateResult.tiedCandidates,
                    requiresUserSelection = candidateResult.requiresUserSelection,
                };
            }

            return ResolveReferenceForCandidate(handSide, candidateResult.bestCandidate);
        }

        public static FindResult ResolveReferenceForCandidate(HandSide handSide, CandidateInfo candidate)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var preferredReferenceAssetPath = HandSideUtility.GetGripReferenceAssetPath(handSide);

            var asset = AssetDatabase.LoadAssetAtPath<InputActionAsset>(candidate.inputActionAssetPath);
            if (asset == null)
            {
                return Fail($"InputActionAsset를 로드할 수 없습니다: {candidate.inputActionAssetPath}");
            }

            var actionMap = asset.FindActionMap(candidate.actionMapName);
            if (actionMap == null)
            {
                return Fail(
                    $"Action Map '{candidate.actionMapName}'을 찾을 수 없습니다.\n" +
                    $"Asset: {candidate.inputActionAssetPath}");
            }

            var action = actionMap.FindAction(candidate.actionName);
            if (action == null)
            {
                return Fail(
                    $"Action '{candidate.actionName}'을 찾을 수 없습니다.\n" +
                    $"Action Map: {candidate.actionMapName}");
            }

            if (!TryGetHandGripBinding(action, handSide, out var bindingPath))
            {
                return Fail(
                    $"'{candidate.actionName}'에 {sideLabel}손 Grip 바인딩이 없습니다.\n" +
                    $"{HandSideUtility.GetGripBindingToken(handSide)} usage와 Grip control이 모두 포함된 binding이 필요합니다.");
            }

            if (!ReferenceMatchesAction(action, asset, action.id.ToString()))
            {
                // action id may have changed; continue with live action id
            }

            var referenceResult = FindOrCreateReference(action, asset, preferredReferenceAssetPath);
            if (!referenceResult.success)
                return referenceResult;

            referenceResult.inputActionAssetPath = candidate.inputActionAssetPath;
            referenceResult.actionMapName = candidate.actionMapName;
            referenceResult.actionName = candidate.actionName;
            referenceResult.actionId = action.id.ToString();
            referenceResult.actionType = action.type.ToString();
            referenceResult.expectedControlType = action.expectedControlType ?? "(none)";
            referenceResult.bindingPath = bindingPath;
            referenceResult.displaySummary = BuildSuccessSummary(handSide, referenceResult);
            return referenceResult;
        }

        struct CandidateCollectionResult
        {
            public bool success;
            public bool requiresUserSelection;
            public CandidateInfo bestCandidate;
            public List<CandidateInfo> tiedCandidates;
            public string failureReason;
        }

        static CandidateCollectionResult CollectScoredCandidates(HandSide handSide)
        {
            var preferredActionMapName = HandSideUtility.GetXriInteractionActionMap(handSide);
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var gripBindingToken = HandSideUtility.GetGripBindingToken(handSide);

            var assetGuids = AssetDatabase.FindAssets("t:InputActionAsset");
            if (assetGuids.Length == 0)
            {
                return new CandidateCollectionResult
                {
                    failureReason =
                        "프로젝트에서 InputActionAsset(.inputactions)을 찾지 못했습니다.\n" +
                        "XRI Default Input Actions가 프로젝트에 포함되어 있는지 확인하세요.",
                };
            }

            var candidates = new List<CandidateInfo>();

            foreach (var guid in assetGuids)
            {
                var assetPath = AssetDatabase.GUIDToAssetPath(guid);
                var asset = AssetDatabase.LoadAssetAtPath<InputActionAsset>(assetPath);
                if (asset == null)
                    continue;

                foreach (var actionMap in asset.actionMaps)
                {
                    foreach (var action in actionMap.actions)
                    {
                        if (!TryGetHandGripBinding(action, handSide, out var bindingPath))
                            continue;

                        candidates.Add(new CandidateInfo
                        {
                            inputActionAssetPath = assetPath,
                            actionMapName = actionMap.name,
                            actionName = action.name,
                            actionId = action.id.ToString(),
                            actionType = action.type.ToString(),
                            expectedControlType = action.expectedControlType ?? "(none)",
                            bindingPath = bindingPath,
                            score = CalculateScore(actionMap.name, action, handSide),
                        });
                    }
                }
            }

            if (candidates.Count == 0)
            {
                return new CandidateCollectionResult
                {
                    failureReason =
                        $"{sideLabel}손 Grip 바인딩을 가진 Input Action을 찾지 못했습니다.\n" +
                        $"기대 Action Map: {preferredActionMapName}\n" +
                        $"기대 Action: {PreferredActionName}\n" +
                        $"Binding에 {gripBindingToken} usage와 Grip control이 포함되어야 합니다.\n" +
                        $"예: {HandSideUtility.GetRecommendedGripBinding(handSide)}",
                };
            }

            var bestScore = candidates.Max(c => c.score);
            var topCandidates = candidates.Where(c => c.score == bestScore).ToList();
            if (topCandidates.Count > 1)
            {
                return new CandidateCollectionResult
                {
                    requiresUserSelection = true,
                    tiedCandidates = topCandidates
                        .OrderBy(c => c.inputActionAssetPath, StringComparer.OrdinalIgnoreCase)
                        .ThenBy(c => c.actionMapName, StringComparer.OrdinalIgnoreCase)
                        .ThenBy(c => c.actionName, StringComparer.OrdinalIgnoreCase)
                        .ToList(),
                    failureReason =
                        $"동점 후보가 {topCandidates.Count}개 발견되어 자동 선택하지 않습니다.\n" +
                        "아래 후보 목록에서 하나를 선택하세요.",
                };
            }

            return new CandidateCollectionResult
            {
                success = true,
                bestCandidate = topCandidates[0],
            };
        }

        static int CalculateScore(string actionMapName, InputAction action, HandSide handSide)
        {
            var preferredActionMapName = HandSideUtility.GetXriInteractionActionMap(handSide);
            var score = 0;

            if (string.Equals(actionMapName, preferredActionMapName, StringComparison.Ordinal))
                score += 100;

            if (string.Equals(action.name, PreferredActionName, StringComparison.Ordinal))
                score += 100;

            if (action.type == InputActionType.Value)
                score += 50;

            if (string.Equals(action.expectedControlType, "Axis", StringComparison.OrdinalIgnoreCase))
                score += 50;

            if (TryGetHandGripBinding(action, handSide, out _))
                score += 100;

            return score;
        }

        static bool TryGetHandGripBinding(InputAction action, HandSide handSide, out string bindingPath)
        {
            bindingPath = null;
            if (action == null)
                return false;

            for (var i = 0; i < action.bindings.Count; i++)
            {
                var binding = action.bindings[i];
                if (binding.isComposite || binding.isPartOfComposite)
                    continue;

                if (!IsHandGripBinding(binding.path, handSide))
                    continue;

                bindingPath = binding.path;
                return true;
            }

            return false;
        }

        static bool IsHandGripBinding(string path, HandSide handSide)
        {
            if (string.IsNullOrEmpty(path))
                return false;

            var handToken = HandSideUtility.GetGripBindingToken(handSide).ToLowerInvariant();
            var lower = path.ToLowerInvariant();
            if (!lower.Contains(handToken))
                return false;

            return lower.Contains("{grip}") || lower.Contains("/grip");
        }

        static FindResult FindOrCreateReference(
            InputAction action,
            InputActionAsset asset,
            string preferredReferenceAssetPath)
        {
            var actionId = action.id.ToString();

            var existingReference = FindExistingReference(asset, actionId, preferredReferenceAssetPath);
            if (existingReference != null)
            {
                if (!ValidateReference(existingReference, action, asset, out var validationError))
                {
                    return Fail(validationError);
                }

                return new FindResult
                {
                    success = true,
                    inputActionReference = existingReference,
                    referenceAssetPath = AssetDatabase.GetAssetPath(existingReference),
                    reusedExistingReference = true,
                    createdNewReference = false,
                };
            }

            var preferredExisting = AssetDatabase.LoadAssetAtPath<InputActionReference>(preferredReferenceAssetPath);
            if (preferredExisting != null)
            {
                if (ValidateReference(preferredExisting, action, asset, out _))
                {
                    return new FindResult
                    {
                        success = true,
                        inputActionReference = preferredExisting,
                        referenceAssetPath = preferredReferenceAssetPath,
                        reusedExistingReference = true,
                        createdNewReference = false,
                    };
                }

                return Fail(
                    $"{preferredReferenceAssetPath}에 다른 action을 가리키는 Reference가 있습니다.\n" +
                    "기존 파일을 확인하거나 수동으로 Grip Input Action을 지정하세요.");
            }

            EnsureOutputFolderExists();

            InputActionReference createdReference = null;
            try
            {
                createdReference = InputActionReference.Create(action);
                AssetDatabase.CreateAsset(createdReference, preferredReferenceAssetPath);
                EditorUtility.SetDirty(createdReference);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                var loadedReference =
                    AssetDatabase.LoadAssetAtPath<InputActionReference>(preferredReferenceAssetPath);
                if (loadedReference == null)
                {
                    return Fail(
                        "InputActionReference 생성 후 에셋을 로드하지 못했습니다.\n" +
                        $"경로: {preferredReferenceAssetPath}");
                }

                if (!ValidateReference(loadedReference, action, asset, out var validationError))
                {
                    AssetDatabase.DeleteAsset(preferredReferenceAssetPath);
                    return Fail(validationError);
                }

                return new FindResult
                {
                    success = true,
                    inputActionReference = loadedReference,
                    referenceAssetPath = preferredReferenceAssetPath,
                    reusedExistingReference = false,
                    createdNewReference = true,
                };
            }
            catch (Exception ex)
            {
                if (createdReference != null
                    && AssetDatabase.LoadAssetAtPath<InputActionReference>(preferredReferenceAssetPath) == null)
                {
                    UnityEngine.Object.DestroyImmediate(createdReference);
                }

                return Fail(
                    "InputActionReference 생성에 실패했습니다.\n" +
                    $"원인: {ex.Message}\n" +
                    "Grip Input Action 필드에 Reference를 수동으로 지정할 수 있습니다.");
            }
        }

        static InputActionReference FindExistingReference(
            InputActionAsset asset,
            string actionId,
            string preferredReferenceAssetPath)
        {
            var guids = AssetDatabase.FindAssets("t:InputActionReference");
            InputActionReference preferredMatch = null;
            InputActionReference firstMatch = null;

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (AssetDatabase.LoadMainAssetAtPath(path) is InputActionAsset)
                    continue;

                var reference = AssetDatabase.LoadAssetAtPath<InputActionReference>(path);
                if (reference == null || !ReferenceMatchesIds(reference, asset, actionId))
                    continue;

                if (string.Equals(path, preferredReferenceAssetPath, StringComparison.OrdinalIgnoreCase))
                    preferredMatch = reference;
                else if (firstMatch == null)
                    firstMatch = reference;
            }

            return preferredMatch ?? firstMatch;
        }

        static bool ReferenceMatchesIds(InputActionReference reference, InputActionAsset asset, string actionId)
        {
            var serializedReference = new SerializedObject(reference);
            var referencedAsset = serializedReference.FindProperty("m_Asset").objectReferenceValue as InputActionAsset;
            var referencedActionId = serializedReference.FindProperty("m_ActionId").stringValue;

            return referencedAsset == asset
                && string.Equals(referencedActionId, actionId, StringComparison.Ordinal);
        }

        static bool ReferenceMatchesAction(InputAction action, InputActionAsset asset, string actionId)
        {
            return action != null
                && asset != null
                && string.Equals(action.id.ToString(), actionId, StringComparison.Ordinal);
        }

        static bool ValidateReference(
            InputActionReference reference,
            InputAction expectedAction,
            InputActionAsset expectedAsset,
            out string errorMessage)
        {
            errorMessage = null;

            if (reference == null)
            {
                errorMessage = "InputActionReference가 null입니다.";
                return false;
            }

            var serializedReference = new SerializedObject(reference);
            var referencedAsset = serializedReference.FindProperty("m_Asset").objectReferenceValue as InputActionAsset;
            var referencedActionId = serializedReference.FindProperty("m_ActionId").stringValue;

            if (referencedAsset != expectedAsset)
            {
                errorMessage =
                    "생성된 InputActionReference가 예상 InputActionAsset을 가리키지 않습니다.\n" +
                    $"Reference: {AssetDatabase.GetAssetPath(reference)}";
                return false;
            }

            if (!string.Equals(referencedActionId, expectedAction.id.ToString(), StringComparison.Ordinal))
            {
                errorMessage =
                    "생성된 InputActionReference가 예상 action ID를 가리키지 않습니다.\n" +
                    $"Reference: {AssetDatabase.GetAssetPath(reference)}";
                return false;
            }

            var resolvedAction = reference.action;
            if (resolvedAction == null)
            {
                errorMessage =
                    "InputActionReference가 action을 resolve하지 못했습니다.\n" +
                    $"Reference: {AssetDatabase.GetAssetPath(reference)}";
                return false;
            }

            if (resolvedAction.id != expectedAction.id)
            {
                errorMessage =
                    "InputActionReference가 resolve한 action ID가 원본 action과 일치하지 않습니다.";
                return false;
            }

            return true;
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
            {
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");
            }

            if (!AssetDatabase.IsValidFolder(ReferenceOutputFolder))
            {
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "InputActions");
            }
        }

        static FindResult Fail(string message)
        {
            return new FindResult
            {
                success = false,
                failureReason = message,
                displaySummary = message,
            };
        }

        static string BuildSuccessSummary(HandSide handSide, FindResult result)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var assetName = string.IsNullOrEmpty(result.inputActionAssetPath)
                ? "(unknown)"
                : Path.GetFileNameWithoutExtension(result.inputActionAssetPath);

            var referenceName = string.IsNullOrEmpty(result.referenceAssetPath)
                ? "(unknown)"
                : Path.GetFileNameWithoutExtension(result.referenceAssetPath);

            var sb = new StringBuilder();
            sb.AppendLine($"{sideLabel}손 Grip 입력을 찾았습니다.");
            sb.AppendLine();
            sb.AppendLine($"Asset:\n{assetName}");
            sb.AppendLine();
            sb.AppendLine($"Action Map:\n{result.actionMapName}");
            sb.AppendLine();
            sb.AppendLine($"Action:\n{result.actionName}");
            sb.AppendLine();
            sb.AppendLine($"Binding:\n{result.bindingPath}");
            sb.AppendLine();
            sb.AppendLine($"Reference:\n{referenceName}");
            sb.AppendLine();
            sb.AppendLine("상태:");
            sb.Append(result.reusedExistingReference
                ? "기존 Reference 재사용"
                : "Reference 자동 생성 완료");
            return sb.ToString().TrimEnd();
        }

        public static string FormatCandidateLabel(CandidateInfo candidate)
        {
            return
                $"{Path.GetFileNameWithoutExtension(candidate.inputActionAssetPath)} / " +
                $"{candidate.actionMapName} / {candidate.actionName} / {candidate.bindingPath} (score {candidate.score})";
        }
    }
}
