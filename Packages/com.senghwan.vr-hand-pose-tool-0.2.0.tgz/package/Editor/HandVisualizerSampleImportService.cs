using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.PackageManager.UI;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// XR Hands HandVisualizer Sample을 탐색하고, 필요 시 Sample API로 Import합니다.
    /// Library/PackageCache 및 Samples~ 원본은 수정하지 않습니다.
    /// </summary>
    public static class HandVisualizerSampleImportService
    {
        public const string PreferredSampleDisplayName = "HandVisualizer";

        const string PendingJsonKey = "VRHandPoseTool.HandVisualizer.PendingSetupJson";
        const string LastStatusKey = "VRHandPoseTool.HandVisualizer.LastStatus";
        const string LastNeedsManualContinueKey = "VRHandPoseTool.HandVisualizer.NeedsManualContinue";

        [Serializable]
        sealed class PendingSetupData
        {
            public int handSide;
            public bool resumeAfterImport;
            public bool openWindow;
            public string createdAtUtc;
            public string packageVersion;
            public string sampleDisplayName;
        }

        public struct SampleInfo
        {
            /// <summary>Sample API가 반환한 원본 importPath (절대경로일 수 있음).</summary>
            public string importPath;

            /// <summary>AssetDatabase용 `Assets/...` 경로.</summary>
            public string assetImportPath;

            /// <summary>파일시스템용 절대 물리 경로.</summary>
            public string physicalImportPath;

            public string displayName;
            public string description;
            public bool isImported;
            public bool matchesHandVisualizerName;
        }

        public struct FindResult
        {
            public bool success;
            public SampleInfo sample;
            public List<SampleInfo> candidates;
            public string packageVersion;
            public string message;
            public bool ambiguous;
        }

        public struct ImportResult
        {
            public bool success;
            public bool alreadyImported;
            public bool importRequested;
            public bool pendingResumeStored;
            public SampleInfo sample;
            public string packageVersion;
            public string message;
        }

        public struct PendingSetup
        {
            public bool exists;
            public HandSide handSide;
            public bool resumeAfterImport;
            public bool openWindow;
            public string packageVersion;
            public string sampleDisplayName;
            public string createdAtUtc;
        }

        public static FindResult FindHandVisualizerSample()
        {
            var result = new FindResult
            {
                candidates = new List<SampleInfo>(),
            };

            if (!XrHandsPackageResolver.IsInstalled(out var version, out var packageMessage))
            {
                result.message = packageMessage;
                return result;
            }

            result.packageVersion = version;

            IEnumerable<Sample> packageSamples;
            try
            {
                packageSamples = Sample.FindByPackage(
                    XrHandsPackageResolver.PackageName,
                    version);
            }
            catch (Exception ex)
            {
                result.message =
                    $"XR Hands({version}) Sample 목록을 가져오지 못했습니다: {ex.Message}";
                return result;
            }

            if (packageSamples == null)
            {
                result.message = $"XR Hands({version}) Sample이 0개입니다.";
                return result;
            }

            var allSamples = packageSamples.Select(ToSampleInfo).ToList();
            if (allSamples.Count == 0)
            {
                result.message = $"XR Hands({version}) Sample이 0개입니다.";
                return result;
            }

            var nameMatches = allSamples
                .Where(sample => sample.matchesHandVisualizerName)
                .ToList();

            if (nameMatches.Count == 0)
            {
                var sb = new StringBuilder();
                sb.AppendLine("HandVisualizer Sample을 찾지 못했습니다. 후보 목록:");
                foreach (var sample in allSamples)
                    sb.AppendLine($"• {DescribeSample(sample)}");
                result.candidates = allSamples;
                result.message = sb.ToString().TrimEnd();
                return result;
            }

            if (nameMatches.Count == 1)
            {
                result.success = true;
                result.sample = nameMatches[0];
                result.candidates = nameMatches;
                result.message =
                    $"HandVisualizer Sample 확인: {DescribeSample(nameMatches[0])}";
                return result;
            }

            // 여러 이름 후보 → Import된 것 우선, 그래도 복수면 모호 처리
            var importedMatches = nameMatches.Where(sample => sample.isImported).ToList();
            if (importedMatches.Count == 1)
            {
                result.success = true;
                result.sample = importedMatches[0];
                result.candidates = nameMatches;
                result.message =
                    $"여러 HandVisualizer 후보 중 Import된 Sample을 선택: {DescribeSample(importedMatches[0])}";
                return result;
            }

            result.ambiguous = true;
            result.candidates = nameMatches;
            var ambiguous = new StringBuilder();
            ambiguous.AppendLine(
                $"HandVisualizer Sample 후보가 {nameMatches.Count}개입니다. 임의 선택하지 않습니다.");
            foreach (var sample in nameMatches)
                ambiguous.AppendLine($"• {DescribeSample(sample)}");
            result.message = ambiguous.ToString().TrimEnd();
            return result;
        }

        /// <summary>
        /// Sample이 Import되지 않았다면 Import를 요청하고 pending setup을 저장합니다.
        /// 이미 Import됐다면 importPath를 그대로 반환합니다. 재Import하지 않습니다.
        /// </summary>
        public static ImportResult EnsureImported(HandSide handSide, bool openWindowOnResume = true)
        {
            var result = new ImportResult();
            var find = FindHandVisualizerSample();
            result.packageVersion = find.packageVersion;

            if (!find.success)
            {
                result.message = find.message;
                return result;
            }

            result.sample = find.sample;

            if (find.sample.isImported)
            {
                if (string.IsNullOrEmpty(find.sample.importPath))
                {
                    result.message =
                        $"Sample은 Import됨으로 표시되지만 importPath가 비어 있습니다: {find.sample.displayName}";
                    return result;
                }

                var sample = find.sample;
                if (string.IsNullOrEmpty(sample.assetImportPath)
                    && !TryFillNormalizedImportPaths(ref sample, out var normalizeError))
                {
                    result.message = normalizeError;
                    return result;
                }

                result.sample = sample;
                result.success = true;
                result.alreadyImported = true;
                result.message =
                    $"HandVisualizer Sample이 이미 Import되어 있습니다.\n" +
                    $"Asset Path: {sample.assetImportPath}\n" +
                    $"원본 importPath: {sample.importPath}";
                ClearPendingSetup();
                return result;
            }

            StorePendingSetup(new PendingSetupData
            {
                handSide = (int)handSide,
                resumeAfterImport = true,
                openWindow = openWindowOnResume,
                createdAtUtc = DateTime.UtcNow.ToString("o"),
                packageVersion = find.packageVersion,
                sampleDisplayName = find.sample.displayName,
            });
            result.pendingResumeStored = true;
            SessionState.SetBool(LastNeedsManualContinueKey, false);
            SessionState.SetString(
                LastStatusKey,
                "XR Hands HandVisualizer 샘플을 가져오는 중입니다...");

            bool importOk;
            try
            {
                // Sample struct는 Find 시점 스냅샷이므로 동일 식별로 다시 조회 후 Import
                importOk = TryImportSample(find.sample.displayName, find.packageVersion, out var importMessage);
                if (!importOk)
                {
                    ClearPendingSetup();
                    result.message = importMessage;
                    SessionState.SetString(LastStatusKey, importMessage);
                    return result;
                }
            }
            catch (Exception ex)
            {
                ClearPendingSetup();
                result.message = $"HandVisualizer Sample Import 중 예외: {ex.Message}";
                SessionState.SetString(LastStatusKey, result.message);
                return result;
            }

            result.importRequested = true;
            result.success = true;
            result.message =
                "XR Hands HandVisualizer 샘플 Import를 요청했습니다. AssetDatabase Refresh 후 자동으로 이어서 구성합니다.";
            SessionState.SetString(LastStatusKey, result.message);

            AssetDatabase.Refresh();
            return result;
        }

        static bool TryImportSample(string displayName, string packageVersion, out string message)
        {
            message = null;
            IEnumerable<Sample> packageSamples;
            try
            {
                packageSamples = Sample.FindByPackage(
                    XrHandsPackageResolver.PackageName,
                    packageVersion);
            }
            catch (Exception ex)
            {
                message = $"Import 직전 Sample 재조회 실패: {ex.Message}";
                return false;
            }

            Sample? target = null;
            foreach (var sample in packageSamples ?? Enumerable.Empty<Sample>())
            {
                if (IsHandVisualizerName(sample.displayName) || IsHandVisualizerName(sample.importPath))
                {
                    if (string.Equals(sample.displayName, displayName, StringComparison.OrdinalIgnoreCase)
                        || (string.IsNullOrEmpty(displayName) && IsHandVisualizerName(sample.displayName)))
                    {
                        target = sample;
                        break;
                    }

                    target ??= sample;
                }
            }

            if (target == null)
            {
                message = $"Import 대상 Sample을 다시 찾지 못했습니다: {displayName}";
                return false;
            }

            var sampleValue = target.Value;
            if (sampleValue.isImported)
            {
                message = "Sample이 이미 Import되어 있습니다.";
                return true;
            }

            var imported = sampleValue.Import();
            if (!imported)
            {
                message =
                    $"Sample.Import()가 실패를 반환했습니다: {sampleValue.displayName}";
                return false;
            }

            message = $"Sample Import 성공: {sampleValue.displayName}";
            return true;
        }

        public static bool TryGetImportedSample(out SampleInfo sample, out string message)
        {
            sample = default;
            var find = FindHandVisualizerSample();
            if (!find.success)
            {
                message = find.message;
                return false;
            }

            if (!find.sample.isImported || string.IsNullOrEmpty(find.sample.importPath))
            {
                message =
                    find.sample.isImported
                        ? "importPath가 비어 있습니다."
                        : "HandVisualizer Sample이 아직 Import되지 않았습니다.";
                sample = find.sample;
                return false;
            }

            sample = find.sample;
            if (string.IsNullOrEmpty(sample.assetImportPath)
                && !TryFillNormalizedImportPaths(ref sample, out var normalizeError))
            {
                message = normalizeError;
                return false;
            }

            message = find.message;
            return true;
        }

        /// <summary>
        /// Sample.importPath(절대/상대 혼용)를 AssetDatabase용 `Assets/...` 경로로 정규화합니다.
        /// </summary>
        public static bool TryNormalizeProjectAssetPath(
            string rawPath,
            out string assetPath,
            out string failureReason)
        {
            return TryNormalizeProjectAssetPath(rawPath, Application.dataPath, out assetPath, out failureReason);
        }

        /// <summary>
        /// 테스트에서 Application.dataPath를 주입할 수 있는 오버로드입니다.
        /// </summary>
        public static bool TryNormalizeProjectAssetPath(
            string rawPath,
            string applicationDataPath,
            out string assetPath,
            out string failureReason)
        {
            assetPath = null;
            failureReason = null;

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                failureReason = "경로가 비어 있습니다.";
                return false;
            }

            var slashNormalized = rawPath.Replace('\\', '/').Trim();
            while (slashNormalized.Length > 1 && slashNormalized.EndsWith("/", StringComparison.Ordinal))
                slashNormalized = slashNormalized.Substring(0, slashNormalized.Length - 1);

            if (TryAcceptAssetsRelativePath(slashNormalized, out assetPath))
                return true;

            // Unity 6 FileUtil.GetLogicalPath 시도 (반환값을 최종 검증)
            if (IsAbsolutePath(rawPath) || IsAbsolutePath(slashNormalized))
            {
                try
                {
                    var logical = FileUtil.GetLogicalPath(rawPath);
                    if (!string.IsNullOrEmpty(logical))
                    {
                        var logicalNorm = logical.Replace('\\', '/').Trim();
                        while (logicalNorm.Length > 1 && logicalNorm.EndsWith("/", StringComparison.Ordinal))
                            logicalNorm = logicalNorm.Substring(0, logicalNorm.Length - 1);

                        if (TryAcceptAssetsRelativePath(logicalNorm, out assetPath))
                            return true;
                    }
                }
                catch
                {
                    // 수동 변환으로 계속
                }

                if (string.IsNullOrWhiteSpace(applicationDataPath))
                {
                    failureReason = "Application.dataPath를 사용할 수 없습니다.";
                    return false;
                }

                string assetsPhysicalRoot;
                string rawAbsolute;
                try
                {
                    assetsPhysicalRoot = Path.GetFullPath(applicationDataPath)
                        .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                    rawAbsolute = Path.GetFullPath(rawPath)
                        .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                }
                catch (Exception ex)
                {
                    failureReason = $"경로를 정규화할 수 없습니다: {ex.Message}";
                    return false;
                }

                if (string.Equals(rawAbsolute, assetsPhysicalRoot, StringComparison.OrdinalIgnoreCase))
                {
                    assetPath = "Assets";
                    return true;
                }

                var rootPrefix = assetsPhysicalRoot + Path.DirectorySeparatorChar;
                if (!rawAbsolute.StartsWith(rootPrefix, StringComparison.OrdinalIgnoreCase))
                {
                    failureReason =
                        "현재 프로젝트의 Assets 폴더 외부 경로입니다.";
                    return false;
                }

                var relative = rawAbsolute
                    .Substring(assetsPhysicalRoot.Length)
                    .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                    .Replace('\\', '/');

                assetPath = string.IsNullOrEmpty(relative) ? "Assets" : "Assets/" + relative;
                return true;
            }

            failureReason =
                "Asset 경로(`Assets/...`) 또는 현재 프로젝트 Assets 아래 절대경로가 아닙니다.";
            return false;
        }

        /// <summary>
        /// raw importPath에서 assetImportPath와 physicalImportPath를 모두 구합니다.
        /// </summary>
        public static bool TryResolveSampleImportPaths(
            string rawImportPath,
            out string assetImportPath,
            out string physicalImportPath,
            out string failureReason)
        {
            return TryResolveSampleImportPaths(
                rawImportPath,
                Application.dataPath,
                out assetImportPath,
                out physicalImportPath,
                out failureReason);
        }

        public static bool TryResolveSampleImportPaths(
            string rawImportPath,
            string applicationDataPath,
            out string assetImportPath,
            out string physicalImportPath,
            out string failureReason)
        {
            assetImportPath = null;
            physicalImportPath = null;
            failureReason = null;

            if (!TryNormalizeProjectAssetPath(
                    rawImportPath,
                    applicationDataPath,
                    out assetImportPath,
                    out failureReason))
            {
                return false;
            }

            if (!TryBuildPhysicalPathFromAssetPath(
                    assetImportPath,
                    applicationDataPath,
                    out physicalImportPath,
                    out failureReason))
            {
                return false;
            }

            return true;
        }

        static bool TryFillNormalizedImportPaths(ref SampleInfo sample, out string errorMessage)
        {
            errorMessage = null;
            if (!TryResolveSampleImportPaths(
                    sample.importPath,
                    out var assetPath,
                    out var physicalPath,
                    out var failureReason))
            {
                errorMessage =
                    "Sample importPath를 Unity Asset 경로로 변환할 수 없습니다.\n" +
                    $"원본: {sample.importPath ?? "(null)"}\n" +
                    $"프로젝트 Assets: {Application.dataPath}\n" +
                    $"이유: {failureReason}";
                return false;
            }

            sample.assetImportPath = assetPath;
            sample.physicalImportPath = physicalPath;
            return true;
        }

        static bool TryAcceptAssetsRelativePath(string slashNormalized, out string assetPath)
        {
            assetPath = null;
            if (string.IsNullOrEmpty(slashNormalized))
                return false;

            if (string.Equals(slashNormalized, "Assets", StringComparison.OrdinalIgnoreCase))
            {
                assetPath = "Assets";
                return true;
            }

            if (slashNormalized.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
            {
                var remainder = slashNormalized.Substring("Assets/".Length);
                assetPath = string.IsNullOrEmpty(remainder) ? "Assets" : "Assets/" + remainder;
                return true;
            }

            return false;
        }

        static bool TryBuildPhysicalPathFromAssetPath(
            string assetPath,
            string applicationDataPath,
            out string physicalPath,
            out string failureReason)
        {
            physicalPath = null;
            failureReason = null;

            var canUseFileUtil = false;
            try
            {
                var injected = Path.GetFullPath(applicationDataPath)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                var actual = Path.GetFullPath(Application.dataPath)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                canUseFileUtil = string.Equals(injected, actual, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                canUseFileUtil = false;
            }

            if (canUseFileUtil)
            {
                try
                {
                    var fromFileUtil = FileUtil.GetPhysicalPath(assetPath);
                    if (!string.IsNullOrEmpty(fromFileUtil))
                    {
                        physicalPath = Path.GetFullPath(fromFileUtil)
                            .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                        return true;
                    }
                }
                catch
                {
                    // 수동 변환
                }
            }

            try
            {
                var assetsRoot = Path.GetFullPath(applicationDataPath);
                var projectRoot = Path.GetDirectoryName(assetsRoot);
                if (string.IsNullOrEmpty(projectRoot))
                {
                    failureReason = "프로젝트 루트를 결정할 수 없습니다.";
                    return false;
                }

                var combined = Path.Combine(
                    projectRoot,
                    assetPath.Replace('/', Path.DirectorySeparatorChar));
                physicalPath = Path.GetFullPath(combined)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                return true;
            }
            catch (Exception ex)
            {
                failureReason = $"물리 경로 변환 실패: {ex.Message}";
                return false;
            }
        }

        static bool IsAbsolutePath(string path)
        {
            if (string.IsNullOrEmpty(path))
                return false;

            // Windows drive / UNC, 또는 플랫폼 Path.IsPathRooted
            var platformPath = path.Replace('/', Path.DirectorySeparatorChar);
            if (Path.IsPathRooted(platformPath))
                return true;

            // "E:/..." 형태 (슬래시 유지) — 일부 환경에서 IsPathRooted가 false일 수 있음
            if (path.Length >= 3
                && char.IsLetter(path[0])
                && path[1] == ':'
                && (path[2] == '/' || path[2] == '\\'))
            {
                return true;
            }

            return false;
        }

        public static PendingSetup GetPendingSetup()
        {
            if (!TryLoadPending(out var data))
                return default;

            return new PendingSetup
            {
                exists = true,
                handSide = (HandSide)data.handSide,
                resumeAfterImport = data.resumeAfterImport,
                openWindow = data.openWindow,
                packageVersion = data.packageVersion,
                sampleDisplayName = data.sampleDisplayName,
                createdAtUtc = data.createdAtUtc,
            };
        }

        public static bool HasPendingSetup => TryLoadPending(out _);

        public static bool NeedsManualContinue =>
            SessionState.GetBool(LastNeedsManualContinueKey, false);

        public static string LastStatusMessage =>
            SessionState.GetString(LastStatusKey, string.Empty);

        public static void SetStatusMessage(string message)
        {
            SessionState.SetString(LastStatusKey, message ?? string.Empty);
        }

        public static void MarkNeedsManualContinue(string reason)
        {
            SessionState.SetBool(LastNeedsManualContinueKey, true);
            if (!string.IsNullOrEmpty(reason))
                SessionState.SetString(LastStatusKey, reason);
        }

        public static void ClearPendingSetup()
        {
            SessionState.EraseString(PendingJsonKey);
            SessionState.SetBool(LastNeedsManualContinueKey, false);
        }

        public static void ClearStatus()
        {
            SessionState.EraseString(LastStatusKey);
            SessionState.SetBool(LastNeedsManualContinueKey, false);
        }

        /// <summary>
        /// 테스트용: pending setup을 직접 기록합니다.
        /// </summary>
        internal static void StorePendingSetupForTests(HandSide handSide, bool resumeAfterImport, string packageVersion)
        {
            StorePendingSetup(new PendingSetupData
            {
                handSide = (int)handSide,
                resumeAfterImport = resumeAfterImport,
                openWindow = false,
                createdAtUtc = DateTime.UtcNow.ToString("o"),
                packageVersion = packageVersion,
                sampleDisplayName = PreferredSampleDisplayName,
            });
        }

        static void StorePendingSetup(PendingSetupData data)
        {
            SessionState.SetString(PendingJsonKey, JsonUtility.ToJson(data));
        }

        static bool TryLoadPending(out PendingSetupData data)
        {
            data = null;
            var json = SessionState.GetString(PendingJsonKey, string.Empty);
            if (string.IsNullOrEmpty(json))
                return false;

            try
            {
                data = JsonUtility.FromJson<PendingSetupData>(json);
                return data != null;
            }
            catch
            {
                return false;
            }
        }

        public static SampleInfo ToSampleInfo(Sample sample)
        {
            var info = new SampleInfo
            {
                displayName = sample.displayName,
                description = sample.description,
                importPath = sample.importPath,
                isImported = sample.isImported,
                matchesHandVisualizerName =
                    IsHandVisualizerName(sample.displayName)
                    || IsHandVisualizerName(sample.importPath),
            };

            if (!string.IsNullOrEmpty(info.importPath))
                TryFillNormalizedImportPaths(ref info, out _);

            return info;
        }

        public static bool IsHandVisualizerName(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;

            var normalized = NormalizeName(value);
            return normalized.Contains("handvisualizer");
        }

        public static string NormalizeName(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            var sb = new StringBuilder(value.Length);
            foreach (var ch in value)
            {
                if (char.IsLetterOrDigit(ch))
                    sb.Append(char.ToLowerInvariant(ch));
            }

            return sb.ToString();
        }

        public static string DescribeSample(SampleInfo sample)
        {
            var imported = sample.isImported ? "Imported" : "NotImported";
            var path = string.IsNullOrEmpty(sample.importPath) ? "(no path)" : sample.importPath;
            return $"{sample.displayName} [{imported}] path={path}";
        }
    }
}
