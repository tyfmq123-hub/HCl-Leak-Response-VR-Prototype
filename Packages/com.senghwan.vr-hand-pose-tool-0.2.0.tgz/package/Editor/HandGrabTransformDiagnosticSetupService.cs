using System;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Playback LeftHand에 HandGrabTransformDiagnostic을 추가하고 참조를 연결합니다.
    /// </summary>
    public static class HandGrabTransformDiagnosticSetupService
    {
        public struct ApplyResult
        {
            public bool success;
            public string message;
            public string summary;
            public string playbackHandHierarchyPath;
            public string wristHierarchyPath;
            public string interactorHierarchyPath;
            public bool reusedExistingComponent;
        }

        public static ApplyResult ApplyDiagnostic(
            Transform playbackHandRoot,
            InputActionReference gripActionReference)
        {
            if (playbackHandRoot == null)
            {
                return Fail("Playback Hand Root가 지정되지 않았습니다.");
            }

            var validation = HandSkeletonCatalog.Validate(playbackHandRoot);
            if (!validation.isValid)
            {
                return Fail("Playback Hand Root의 L_* 본 26개 검증에 실패했습니다.");
            }

            var wrist = FindWristTransform(playbackHandRoot);
            if (wrist == null)
            {
                return Fail(
                    "LeftHand 하위에서 이름에 'Wrist'가 포함된 Transform을 찾지 못했습니다.");
            }

            var interactor = FindInteractor(playbackHandRoot);
            if (interactor == null)
            {
                return Fail(
                    "Left Controller 계층에서 XRBaseInteractor를 찾지 못했습니다.\n" +
                    "NearFarInteractor / XRDirectInteractor가 Left Controller 하위에 있는지 확인하세요.");
            }

            Undo.SetCurrentGroupName("Add Hand Grab Transform Diagnostic");
            var undoGroup = Undo.GetCurrentGroup();

            var diagnostic = playbackHandRoot.GetComponent<HandGrabTransformDiagnostic>();
            var reusedExisting = diagnostic != null;
            if (diagnostic == null)
            {
                diagnostic = Undo.AddComponent<HandGrabTransformDiagnostic>(playbackHandRoot.gameObject);
            }
            else
            {
                Undo.RecordObject(diagnostic, "Configure Hand Grab Transform Diagnostic");
            }

            diagnostic.Configure(playbackHandRoot, wrist, interactor, gripActionReference);

            var serializedDiagnostic = new SerializedObject(diagnostic);
            serializedDiagnostic.FindProperty("playbackHandRoot").objectReferenceValue = playbackHandRoot;
            serializedDiagnostic.FindProperty("wristTransform").objectReferenceValue = wrist;
            serializedDiagnostic.FindProperty("interactor").objectReferenceValue = interactor;
            HandPoseControllerHandSetupService.SetInputActionReferencePublic(
                serializedDiagnostic.FindProperty("gripAction"),
                gripActionReference);
            serializedDiagnostic.ApplyModifiedPropertiesWithoutUndo();

            EditorUtility.SetDirty(diagnostic);
            if (!Application.isPlaying && playbackHandRoot.gameObject.scene.IsValid())
            {
                EditorSceneManager.MarkSceneDirty(playbackHandRoot.gameObject.scene);
            }

            Undo.CollapseUndoOperations(undoGroup);

            var playbackPath = HandPoseCaptureService.GetHierarchyPath(playbackHandRoot);
            var wristPath = HandPoseCaptureService.GetHierarchyPath(wrist);
            var interactorPath = HandPoseCaptureService.GetHierarchyPath(interactor.transform);

            var summary = new StringBuilder();
            summary.AppendLine("HandGrabTransformDiagnostic 연결 완료");
            summary.AppendLine($"Playback Hand Root: {playbackPath}");
            summary.AppendLine($"Wrist: {wristPath}");
            summary.AppendLine($"XR Interactor: {interactorPath} ({interactor.GetType().Name})");
            summary.AppendLine(reusedExisting
                ? "기존 HandGrabTransformDiagnostic 재사용"
                : "HandGrabTransformDiagnostic 새로 추가");
            summary.AppendLine("Play 후 Console에서 [HandGrabTransformDiagnostic] 로그를 확인하세요.");

            return new ApplyResult
            {
                success = true,
                message = "잡기 Transform 진단이 추가되었습니다.",
                summary = summary.ToString().TrimEnd(),
                playbackHandHierarchyPath = playbackPath,
                wristHierarchyPath = wristPath,
                interactorHierarchyPath = interactorPath,
                reusedExistingComponent = reusedExisting,
            };
        }

        public static Transform FindWristTransform(Transform playbackHandRoot)
        {
            if (playbackHandRoot == null)
                return null;

            Transform exactMatch = null;
            Transform firstMatch = null;

            foreach (var transform in playbackHandRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == playbackHandRoot)
                    continue;

                if (transform.name.IndexOf("Wrist", StringComparison.OrdinalIgnoreCase) < 0)
                    continue;

                if (string.Equals(transform.name, "L_Wrist", StringComparison.Ordinal))
                    exactMatch = transform;

                firstMatch ??= transform;
            }

            return exactMatch ?? firstMatch;
        }

        public static XRBaseInteractor FindInteractor(Transform playbackHandRoot)
        {
            if (playbackHandRoot == null)
                return null;

            var current = playbackHandRoot;
            while (current != null)
            {
                if (current.name.IndexOf("Left Controller", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    var onController = current.GetComponentInChildren<XRBaseInteractor>(true);
                    if (onController != null)
                        return onController;
                }

                current = current.parent;
            }

            current = playbackHandRoot;
            while (current != null)
            {
                var interactor = current.GetComponentInChildren<XRBaseInteractor>(true);
                if (interactor != null)
                    return interactor;

                current = current.parent;
            }

            return null;
        }

        static ApplyResult Fail(string message)
        {
            return new ApplyResult
            {
                success = false,
                message = message,
                summary = message,
            };
        }
    }
}
