using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// XRHandPoseAsset의 bone local Transform을 legacy HandPoseSnapshot(bones-only)으로 내보냅니다.
    /// ControllerGrabHandPose / HandPoseJointApplier 잡기 경로용입니다.
    /// </summary>
    public static class HandGrabSnapshotExporter
    {
        public const string OutputFolder = "Assets/VRHandPoseToolOutput/GrabSnapshots";
        public const string DefaultSourcePosePath = "Assets/VRHandPoseToolOutput/Poses/Left_Grab.asset";
        public const string DefaultOutputName = "Left_Grab_Bone";

        public static string GetDefaultOutputName(HandSide handSide)
        {
            return HandSideUtility.GetGrabSnapshotOutputName(handSide);
        }

        public struct ExportResult
        {
            public bool success;
            public string message;
            public string assetPath;
            public HandPoseSnapshot asset;
            public int boneCount;
            public int jointCount;
            public string boneIdentifierMode;
            public string inclusionSummary;
            public string validationSummary;
        }

        public static XRHandPoseAsset TryLoadDefaultSourcePose()
        {
            return TryLoadDefaultSourcePose(HandSide.Left);
        }

        public static XRHandPoseAsset TryLoadDefaultSourcePose(HandSide handSide)
        {
            return AssetDatabase.LoadAssetAtPath<XRHandPoseAsset>(
                HandSideUtility.GetDefaultGrabPoseAssetPath(handSide));
        }

        public static ExportResult Export(
            XRHandPoseAsset sourcePoseAsset,
            Transform playbackHandRoot,
            string outputName)
        {
            return Export(sourcePoseAsset, playbackHandRoot, outputName, HandSide.Left);
        }

        public static ExportResult Export(
            XRHandPoseAsset sourcePoseAsset,
            Transform playbackHandRoot,
            string outputName,
            HandSide handSide)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var result = new ExportResult();

            if (sourcePoseAsset == null)
            {
                result.message = "Source Pose Asset이 null입니다.";
                return result;
            }

            if (playbackHandRoot == null)
            {
                result.message =
                    $"Playback Hand Root가 null입니다. {HandSideUtility.GetPreferredHandRootName(handSide)} Playback Hand Root를 지정하세요.";
                return result;
            }

            var playbackValidation = HandSkeletonCatalog.Validate(playbackHandRoot, handSide);
            if (!playbackValidation.isValid)
            {
                result.message = $"Playback Hand Root {sideLabel} skeleton 검증 실패: {playbackValidation.summary}";
                return result;
            }

            if (string.IsNullOrWhiteSpace(outputName))
            {
                result.message = "Output Name이 비어 있습니다.";
                return result;
            }

            if (sourcePoseAsset.bones == null || sourcePoseAsset.bones.Count == 0)
            {
                result.message =
                    "Source Pose Asset에 bone 데이터가 없습니다. Play Mode에서 XRHandPoseAsset을 먼저 캡처하세요.";
                return result;
            }

            foreach (var sourceBone in sourcePoseAsset.bones)
            {
                if (sourceBone == null || string.IsNullOrEmpty(sourceBone.boneName))
                    continue;

                if (HandSideUtility.ContainsOppositeHandBonePrefix(sourceBone.boneName, handSide))
                {
                    result.message =
                        $"Source bone '{sourceBone.boneName}'은 {sideLabel} 손 prefix와 맞지 않습니다.";
                    return result;
                }
            }

            if (!HandSkeletonCatalog.TryBuildBoneMap(
                    playbackHandRoot,
                    handSide,
                    out var playbackBoneMap,
                    out var boneMapError))
            {
                result.message = $"Playback Hand Root 본 맵 생성 실패: {boneMapError}";
                return result;
            }

            var convertResult = ConvertFromSourceAsset(
                sourcePoseAsset,
                playbackHandRoot,
                playbackBoneMap,
                handSide,
                out var snapshot,
                out var convertError);

            if (!convertResult)
            {
                result.message = convertError;
                return result;
            }

            var validation = ValidateSnapshot(snapshot, playbackHandRoot, playbackBoneMap, handSide);
            result.validationSummary = validation.summary;
            if (!validation.success)
            {
                result.message = validation.summary;
                return result;
            }

            EnsureOutputFolderExists();

            var sanitizedName = HandPoseAssetFactory.SanitizeFileName(outputName.Trim());
            var assetPath = AssetDatabase.GenerateUniqueAssetPath($"{OutputFolder}/{sanitizedName}.asset");

            HandPoseSnapshot savedAsset = null;
            try
            {
                AssetDatabase.CreateAsset(snapshot, assetPath);
                EditorUtility.SetDirty(snapshot);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                savedAsset = AssetDatabase.LoadAssetAtPath<HandPoseSnapshot>(assetPath);
                if (savedAsset == null)
                {
                    result.message = $"에셋 저장 후 재로드 실패: {assetPath}";
                    return result;
                }

                var reloadValidation = ValidateReloadedAsset(savedAsset, snapshot, playbackHandRoot, handSide);
                if (!reloadValidation.success)
                {
                    result.message = reloadValidation.summary;
                    return result;
                }

                Selection.activeObject = savedAsset;
                EditorGUIUtility.PingObject(savedAsset);

                result.success = true;
                result.asset = savedAsset;
                result.assetPath = assetPath;
                result.boneCount = savedAsset.bones.Count;
                result.jointCount = savedAsset.joints?.Count ?? 0;
                result.boneIdentifierMode =
                    $"boneName (HandPoseJointApplier lookup) + path ({HandSideUtility.GetPreferredHandRootName(handSide)}-root relative hierarchy)";
                result.inclusionSummary = BuildInclusionSummary(savedAsset, playbackHandRoot.name, handSide);
                result.message =
                    $"Grab Snapshot 내보내기 완료: {assetPath}\n" +
                    $"bones={result.boneCount}, joints={result.jointCount}\n" +
                    result.inclusionSummary;
            }
            catch (Exception ex)
            {
                if (savedAsset == null && snapshot != null)
                    UnityEngine.Object.DestroyImmediate(snapshot);

                result.message = $"Grab Snapshot 저장 실패: {ex.Message}";
            }

            return result;
        }

        static bool ConvertFromSourceAsset(
            XRHandPoseAsset source,
            Transform playbackHandRoot,
            IReadOnlyDictionary<string, Transform> playbackBoneMap,
            HandSide handSide,
            out HandPoseSnapshot snapshot,
            out string errorMessage)
        {
            snapshot = ScriptableObject.CreateInstance<HandPoseSnapshot>();
            errorMessage = null;

            snapshot.poseName = string.IsNullOrEmpty(source.poseName) ? "Grab" : source.poseName;
            snapshot.handSide = HandSideUtility.GetHandSideLabelForMarker(handSide);
            snapshot.sourceHandName = playbackHandRoot.name;
            snapshot.capturedTimeUtc = string.IsNullOrEmpty(source.capturedAtIso8601)
                ? DateTime.UtcNow.ToString("o")
                : source.capturedAtIso8601;
            snapshot.rootWorldPosition = source.rootWorldPosition;
            snapshot.rootWorldRotation = source.rootWorldRotation;
            snapshot.rootWorldEulerAngles = source.rootWorldRotation.eulerAngles;
            snapshot.joints = new List<HandPoseSnapshot.HandJointRecord>();
            snapshot.bones = new List<HandPoseSnapshot.HandBoneRecord>();

            var boneNameCounts = new Dictionary<string, int>(StringComparer.Ordinal);
            var pathCounts = new Dictionary<string, int>(StringComparer.Ordinal);

            foreach (var sourceBone in source.bones)
            {
                if (sourceBone == null || string.IsNullOrEmpty(sourceBone.boneName))
                    continue;

                if (string.Equals(sourceBone.boneName, playbackHandRoot.name, StringComparison.Ordinal))
                {
                    errorMessage =
                        $"손 루트 '{playbackHandRoot.name}' 본은 내보내지 않습니다. " +
                        "HandPoseJointApplier는 handRoot 자체를 boneMap에 포함하지 않습니다.";
                    return false;
                }

                if (!playbackBoneMap.ContainsKey(sourceBone.boneName))
                {
                    errorMessage =
                        $"Source bone '{sourceBone.boneName}'을 Playback Hand Root '{playbackHandRoot.name}' 아래에서 찾지 못했습니다.";
                    return false;
                }

                if (!TryBuildRelativePath(playbackHandRoot, sourceBone.boneName, handSide, out var relativePath, out var pathError))
                {
                    errorMessage = pathError;
                    return false;
                }

                boneNameCounts.TryGetValue(sourceBone.boneName, out var boneNameCount);
                boneNameCounts[sourceBone.boneName] = boneNameCount + 1;
                if (boneNameCounts[sourceBone.boneName] > 1)
                {
                    errorMessage = $"boneName '{sourceBone.boneName}'이 Source Pose Asset에 중복됩니다.";
                    return false;
                }

                pathCounts.TryGetValue(relativePath, out var pathCount);
                pathCounts[relativePath] = pathCount + 1;
                if (pathCounts[relativePath] > 1)
                {
                    errorMessage = $"상대 경로 '{relativePath}'가 중복됩니다. boneName 충돌을 확인하세요.";
                    return false;
                }

                var playbackBone = playbackBoneMap[sourceBone.boneName];
                snapshot.bones.Add(new HandPoseSnapshot.HandBoneRecord
                {
                    path = relativePath,
                    boneName = sourceBone.boneName,
                    localPosition = sourceBone.localPosition,
                    localRotation = sourceBone.localRotation,
                    localEulerAngles = sourceBone.localRotation.eulerAngles,
                    worldPosition = playbackBone.position,
                    worldRotation = playbackBone.rotation,
                    worldEulerAngles = playbackBone.rotation.eulerAngles,
                });
            }

            if (snapshot.bones.Count == 0)
            {
                errorMessage = "변환 결과 bone이 0개입니다.";
                return false;
            }

            return true;
        }

        static bool TryBuildRelativePath(
            Transform playbackHandRoot,
            string boneName,
            HandSide handSide,
            out string relativePath,
            out string errorMessage)
        {
            relativePath = null;
            errorMessage = null;

            if (!HandSkeletonCatalog.TryBuildBoneMap(
                    playbackHandRoot,
                    handSide,
                    out var boneMap,
                    out var mapError))
            {
                errorMessage = mapError;
                return false;
            }

            if (!boneMap.TryGetValue(boneName, out var boneTransform) || boneTransform == null)
            {
                errorMessage = $"Playback Hand Root 아래에서 '{boneName}' Transform을 찾지 못했습니다.";
                return false;
            }

            var parts = new List<string>();
            var current = boneTransform;
            while (current != null && current != playbackHandRoot)
            {
                parts.Add(current.name);
                current = current.parent;
            }

            if (current != playbackHandRoot)
            {
                errorMessage = $"'{boneName}'이 Playback Hand Root '{playbackHandRoot.name}' 하위가 아닙니다.";
                return false;
            }

            parts.Reverse();
            relativePath = string.Join("/", parts);
            return true;
        }

        struct ValidationResult
        {
            public bool success;
            public string summary;
        }

        static ValidationResult ValidateSnapshot(
            HandPoseSnapshot snapshot,
            Transform playbackHandRoot,
            IReadOnlyDictionary<string, Transform> playbackBoneMap,
            HandSide handSide)
        {
            var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
            var palmSuffix = "Palm";
            var lines = new List<string>();

            if (snapshot.bones == null || snapshot.bones.Count <= 0)
            {
                return Fail("bones.Count > 0 실패");
            }

            lines.Add($"1. bones.Count = {snapshot.bones.Count} (OK)");

            var jointCount = snapshot.joints?.Count ?? 0;
            if (jointCount != 0)
            {
                return Fail($"joints.Count == 0 실패 (현재 {jointCount})");
            }

            lines.Add("2. joints.Count = 0 (OK)");

            var boneNames = new HashSet<string>(StringComparer.Ordinal);
            var paths = new HashSet<string>(StringComparer.Ordinal);
            var applierMap = HandPoseJointApplier.BuildBoneNameMap(playbackHandRoot);

            foreach (var bone in snapshot.bones)
            {
                if (string.IsNullOrEmpty(bone.boneName))
                    return Fail("비어 있는 boneName이 있습니다.");

                if (HandSideUtility.ContainsOppositeHandBonePrefix(bone.boneName, handSide))
                    return Fail($"반대 손 bone prefix: '{bone.boneName}'");

                if (!boneNames.Add(bone.boneName))
                    return Fail($"boneName 중복: '{bone.boneName}'");

                if (string.IsNullOrEmpty(bone.path))
                    return Fail($"boneName '{bone.boneName}'의 path가 비어 있습니다.");

                if (!paths.Add(bone.path))
                    return Fail($"path 중복: '{bone.path}'");

                if (!applierMap.TryGetValue(bone.boneName, out var transform) || transform == null)
                    return Fail($"HandPoseJointApplier boneMap에서 '{bone.boneName}' 탐색 실패");

                if (!playbackBoneMap.ContainsKey(bone.boneName))
                    return Fail($"Playback bone map에서 '{bone.boneName}' 탐색 실패");

                if (string.Equals(bone.boneName, playbackHandRoot.name, StringComparison.Ordinal))
                    return Fail($"손 루트 '{playbackHandRoot.name}' 회전이 bone 목록에 포함됨");
            }

            lines.Add("3. Playback Hand Root / HandPoseJointApplier boneMap 탐색 OK");
            lines.Add("4. boneName·path 중복 없음 (OK)");

            var hasHandRootBone = snapshot.bones.Any(b =>
                string.Equals(b.boneName, playbackHandRoot.name, StringComparison.Ordinal));
            if (hasHandRootBone)
                return Fail($"{HandSideUtility.GetPreferredHandRootName(handSide)} 루트 회전이 bone 목록에 포함됨");

            lines.Add($"5. {HandSideUtility.GetPreferredHandRootName(handSide)} 루트 bone 미포함 (OK)");

            var wrist = snapshot.bones.FirstOrDefault(b =>
                string.Equals(b.boneName, wristBoneName, StringComparison.Ordinal));
            var palm = snapshot.bones.FirstOrDefault(b =>
                b.boneName.EndsWith(palmSuffix, StringComparison.Ordinal)
                && HandSideUtility.IsHandBoneName(b.boneName, handSide));

            if (!string.IsNullOrEmpty(wrist.boneName))
            {
                if (!IsReasonableBoneLocalRotation(wrist.localRotation))
                    return Fail($"{wristBoneName} localRotation 값이 비정상입니다: {wrist.localRotation}");

                lines.Add(
                    $"6. {wristBoneName} 포함 · rig localRotation (ApplySnapshotBones에서 skipWrist=true로 적용 시 스킵됨)");
            }
            else
            {
                lines.Add($"6. {wristBoneName} 미포함");
            }

            if (!string.IsNullOrEmpty(palm.boneName))
            {
                if (!IsReasonableBoneLocalRotation(palm.localRotation))
                    return Fail($"{palm.boneName} localRotation 값이 비정상입니다: {palm.localRotation}");

                lines.Add($"6b. {palm.boneName} 포함 · rig localRotation (ApplySnapshotBones에서 적용됨)");
            }

            if (!HandPoseJointApplier.HasApplicablePoseData(snapshot))
                return Fail("HandPoseJointApplier.HasApplicablePoseData == false");

            if (snapshot.joints != null && snapshot.joints.Count > 0)
                return Fail("joints-only 경로가 활성화될 수 있는 joints 데이터가 남아 있습니다.");

            lines.Add("7. HandPoseJointApplier.HasApplicablePoseData == true (bones 경로)");
            lines.Add("8. 재로드 검증은 저장 직후 수행");

            return new ValidationResult
            {
                success = true,
                summary = string.Join("\n", lines),
            };
        }

        static ValidationResult ValidateReloadedAsset(
            HandPoseSnapshot reloaded,
            HandPoseSnapshot original,
            Transform playbackHandRoot,
            HandSide handSide)
        {
            if (reloaded == null)
                return Fail("재로드된 HandPoseSnapshot이 null입니다.");

            if (reloaded.bones == null || reloaded.bones.Count != original.bones.Count)
            {
                return Fail(
                    $"재로드 bones.Count 불일치: saved={original.bones.Count}, reloaded={reloaded.bones?.Count ?? 0}");
            }

            if (reloaded.joints == null || reloaded.joints.Count != 0)
                return Fail($"재로드 joints.Count != 0: {reloaded.joints?.Count ?? -1}");

            for (var i = 0; i < original.bones.Count; i++)
            {
                var before = original.bones[i];
                var after = reloaded.bones[i];

                if (!string.Equals(before.boneName, after.boneName, StringComparison.Ordinal))
                    return Fail($"재로드 boneName 불일치 index={i}");

                if (!string.Equals(before.path, after.path, StringComparison.Ordinal))
                    return Fail($"재로드 path 불일치 index={i} ({before.boneName})");

                if (Quaternion.Angle(before.localRotation, after.localRotation) > 0.01f)
                    return Fail($"재로드 localRotation 불일치: {before.boneName}");
            }

            if (!HandPoseJointApplier.HasApplicablePoseData(reloaded))
                return Fail("재로드 후 HasApplicablePoseData == false");

            if (!HandSkeletonCatalog.TryBuildBoneMap(
                    playbackHandRoot,
                    handSide,
                    out var playbackBoneMap,
                    out _))
            {
                return Fail("재로드 검증 중 Playback bone map 생성 실패");
            }

            foreach (var bone in reloaded.bones)
            {
                if (!playbackBoneMap.ContainsKey(bone.boneName))
                    return Fail($"재로드 후 Playback에서 '{bone.boneName}' 탐색 실패");
            }

            return new ValidationResult
            {
                success = true,
                summary = "8. 재로드·직렬화 값 유지 OK",
            };
        }

        static bool IsReasonableBoneLocalRotation(Quaternion rotation)
        {
            if (float.IsNaN(rotation.x) || float.IsNaN(rotation.y) || float.IsNaN(rotation.z) || float.IsNaN(rotation.w))
                return false;

            var magnitude = rotation.x * rotation.x + rotation.y * rotation.y + rotation.z * rotation.z + rotation.w * rotation.w;
            return magnitude > 0.5f && magnitude < 1.5f;
        }

        static string BuildInclusionSummary(HandPoseSnapshot snapshot, string handRootName, HandSide handSide)
        {
            var wristBoneName = HandSideUtility.GetWristBoneName(handSide);
            var hasWrist = snapshot.bones.Any(b =>
                string.Equals(b.boneName, wristBoneName, StringComparison.Ordinal));
            var hasPalm = snapshot.bones.Any(b =>
                b.boneName.EndsWith("Palm", StringComparison.Ordinal)
                && HandSideUtility.IsHandBoneName(b.boneName, handSide));
            var fingerCount = snapshot.bones.Count(b =>
                HandSkeletonCatalog.GetFingerAnimationBoneNames(handSide).Contains(b.boneName));

            var sb = new StringBuilder();
            sb.AppendLine($"손 루트 '{handRootName}' bone: 미포함 (HandPoseJointApplier가 handRoot 제외)");
            sb.Append($"{wristBoneName}: {(hasWrist ? "포함 (적용 시 skipWrist로 스킵)" : "미포함")} · ");
            sb.Append($"{HandSideUtility.GetBonePrefix(handSide)}Palm: {(hasPalm ? "포함 (적용됨)" : "미포함")} · ");
            sb.Append($"손가락 bone: {fingerCount}개");
            return sb.ToString().TrimEnd();
        }

        static ValidationResult Fail(string message)
        {
            return new ValidationResult
            {
                success = false,
                summary = message,
            };
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");

            if (!AssetDatabase.IsValidFolder(OutputFolder))
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "GrabSnapshots");
        }
    }
}
