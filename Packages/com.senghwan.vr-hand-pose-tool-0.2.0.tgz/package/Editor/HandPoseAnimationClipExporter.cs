using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// XRHandPoseAsset의 손가락 Bone localRotation을 1프레임 AnimationClip으로 내보냅니다.
    /// Joint tracking rotation, 손 루트 위치, Target 위치는 포함하지 않습니다.
    /// </summary>
    public static class HandPoseAnimationClipExporter
    {
        public const string OutputFolder = "Assets/VRHandPoseToolOutput/Animations";
        public const float FrameRate = 60f;
        public const float SecondKeyTime = 1f / FrameRate;

        static readonly string[] s_RotationProperties =
        {
            "m_LocalRotation.x",
            "m_LocalRotation.y",
            "m_LocalRotation.z",
            "m_LocalRotation.w",
        };

        static readonly HashSet<string> s_ForbiddenCurveProperties = new(StringComparer.Ordinal)
        {
            "m_LocalPosition.x",
            "m_LocalPosition.y",
            "m_LocalPosition.z",
            "localPosition.x",
            "localPosition.y",
            "localPosition.z",
            "m_LocalScale.x",
            "m_LocalScale.y",
            "m_LocalScale.z",
        };

        public struct ExportResult
        {
            public bool success;
            public string message;
            public string clipPath;
            public AnimationClip clip;
            public int animatedBoneCount;
            public int curveCount;
            public float clipLength;
            public float frameRate;
            public bool loopTime;
            public bool legacy;
            public List<string> errors;
            public List<string> warnings;
        }

        public static ExportResult ExportPoseAsset(XRHandPoseAsset poseAsset, string clipBaseName = null)
        {
            var result = new ExportResult
            {
                errors = new List<string>(),
                warnings = new List<string>(),
                frameRate = FrameRate,
            };

            if (poseAsset == null)
            {
                result.message = "XRHandPoseAsset이 지정되지 않았습니다.";
                result.errors.Add(result.message);
                return result;
            }

            if (poseAsset.bones == null || poseAsset.bones.Count != HandSkeletonCatalog.RequiredBoneCount)
            {
                result.message =
                    $"Bone 데이터가 {poseAsset.bones?.Count ?? 0}개입니다 (기대 {HandSkeletonCatalog.RequiredBoneCount}).";
                result.errors.Add(result.message);
                return result;
            }

            if (!HandSideUtility.TryInferHandSideFromBoneNames(
                    poseAsset.bones.Select(b => b.boneName),
                    out var handSide,
                    out var handSideError))
            {
                result.message = handSideError;
                result.errors.Add(handSideError);
                return result;
            }

            var handRootName = string.IsNullOrEmpty(poseAsset.sourceHandName)
                ? HandSideUtility.GetPreferredHandRootName(handSide)
                : poseAsset.sourceHandName;

            var fingerBoneNames = HandSkeletonCatalog.GetFingerAnimationBoneNames(handSide);
            var boneByName = poseAsset.bones.ToDictionary(b => b.boneName, b => b);

            EnsureOutputFolderExists();

            var exportName = string.IsNullOrWhiteSpace(clipBaseName)
                ? poseAsset.poseName
                : clipBaseName;
            exportName = HandPoseAssetFactory.SanitizeFileName(exportName);
            if (string.IsNullOrEmpty(exportName))
                exportName = "Pose";

            var basePath = $"{OutputFolder}/{exportName}.anim";
            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(basePath);

            AnimationClip clip = null;
            try
            {
                clip = new AnimationClip
                {
                    name = Path.GetFileNameWithoutExtension(uniquePath),
                    frameRate = FrameRate,
                    legacy = false,
                };

                var animatedBoneCount = 0;
                var curveCount = 0;

                foreach (var boneName in fingerBoneNames)
                {
                    if (!boneByName.TryGetValue(boneName, out var bone))
                    {
                        result.errors.Add($"Bone 데이터에 '{boneName}'이 없습니다.");
                        continue;
                    }

                    if (!HandPoseBonePathUtility.TryBuildPathFromHandRoot(
                            boneName,
                            poseAsset.bones,
                            handRootName,
                            out var bonePath,
                            out var pathError))
                    {
                        result.errors.Add(pathError);
                        continue;
                    }

                    AddRotationCurves(clip, bonePath, bone.localRotation, ref curveCount);
                    animatedBoneCount++;
                }

                if (result.errors.Count > 0 || animatedBoneCount != fingerBoneNames.Count)
                {
                    UnityEngine.Object.DestroyImmediate(clip);
                    result.message = "AnimationClip 생성 실패.";
                    return result;
                }

                var settings = AnimationUtility.GetAnimationClipSettings(clip);
                settings.loopTime = false;
                AnimationUtility.SetAnimationClipSettings(clip, settings);

                ValidateNoForbiddenCurves(clip, result.errors);

                if (result.errors.Count > 0)
                {
                    UnityEngine.Object.DestroyImmediate(clip);
                    result.message = "금지된 커브가 포함되어 저장하지 않았습니다.";
                    return result;
                }

                AssetDatabase.CreateAsset(clip, uniquePath);
                EditorUtility.SetDirty(clip);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                Selection.activeObject = clip;
                EditorGUIUtility.PingObject(clip);

                result.success = true;
                result.clip = clip;
                result.clipPath = uniquePath;
                result.animatedBoneCount = animatedBoneCount;
                result.curveCount = AnimationUtility.GetCurveBindings(clip).Length;
                result.clipLength = clip.length;
                result.loopTime = settings.loopTime;
                result.legacy = clip.legacy;
                result.message =
                    $"AnimationClip 저장 완료: {uniquePath}\n" +
                    $"본 {result.animatedBoneCount}, 커브 {result.curveCount}, 길이 {result.clipLength:F4}s, frameRate {result.frameRate}";
            }
            catch (Exception ex)
            {
                if (clip != null)
                    UnityEngine.Object.DestroyImmediate(clip);

                result.message = $"AnimationClip 저장 실패: {ex.Message}";
                result.errors.Add(result.message);
            }

            return result;
        }

        static void AddRotationCurves(AnimationClip clip, string bonePath, Quaternion rotation, ref int curveCount)
        {
            var values = new[] { rotation.x, rotation.y, rotation.z, rotation.w };
            for (var i = 0; i < s_RotationProperties.Length; i++)
            {
                var curve = AnimationCurve.Constant(0f, SecondKeyTime, values[i]);
                clip.SetCurve(bonePath, typeof(Transform), s_RotationProperties[i], curve);
                curveCount++;
            }
        }

        static void ValidateNoForbiddenCurves(AnimationClip clip, List<string> errors)
        {
            foreach (var binding in AnimationUtility.GetCurveBindings(clip))
            {
                if (s_ForbiddenCurveProperties.Contains(binding.propertyName))
                {
                    errors.Add(
                        $"금지된 커브 속성: {binding.path} · {binding.propertyName}");
                }

                if (binding.propertyName.Contains("Position", StringComparison.OrdinalIgnoreCase))
                {
                    errors.Add(
                        $"위치 커브는 허용되지 않습니다: {binding.path} · {binding.propertyName}");
                }
            }
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
            {
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");
            }

            if (!AssetDatabase.IsValidFolder(OutputFolder))
            {
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "Animations");
            }
        }
    }
}
