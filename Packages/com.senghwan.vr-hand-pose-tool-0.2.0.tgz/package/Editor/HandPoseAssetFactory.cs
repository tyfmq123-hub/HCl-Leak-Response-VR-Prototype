using System;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// HandPoseCaptureResult를 XRHandPoseAsset으로 저장합니다.
    /// </summary>
    public static class HandPoseAssetFactory
    {
        public const string OutputFolder = "Assets/VRHandPoseToolOutput/Poses";

        public struct SaveResult
        {
            public bool success;
            public string message;
            public string assetPath;
            public XRHandPoseAsset asset;
        }

        public static SaveResult SavePoseAsset(HandPoseCaptureResult captureResult, string poseName)
        {
            var saveResult = new SaveResult();

            if (captureResult == null || !captureResult.success)
            {
                saveResult.message = "유효한 캡처 결과가 없습니다.";
                return saveResult;
            }

            if (string.IsNullOrWhiteSpace(poseName))
            {
                saveResult.message = "저장할 Pose Name이 비어 있습니다.";
                return saveResult;
            }

            EnsureOutputFolderExists();

            var sanitizedName = SanitizeFileName(poseName.Trim());
            var basePath = $"{OutputFolder}/{sanitizedName}.asset";
            var uniquePath = AssetDatabase.GenerateUniqueAssetPath(basePath);

            XRHandPoseAsset asset = null;
            try
            {
                asset = ScriptableObject.CreateInstance<XRHandPoseAsset>();
                PopulateAsset(asset, captureResult, poseName.Trim());

                AssetDatabase.CreateAsset(asset, uniquePath);
                EditorUtility.SetDirty(asset);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                Selection.activeObject = asset;
                EditorGUIUtility.PingObject(asset);

                saveResult.success = true;
                saveResult.asset = asset;
                saveResult.assetPath = uniquePath;
                saveResult.message = $"에셋 저장 완료: {uniquePath}";
            }
            catch (Exception ex)
            {
                if (asset != null)
                {
                    UnityEngine.Object.DestroyImmediate(asset);
                }

                saveResult.message = $"에셋 저장 실패: {ex.Message}";
            }

            return saveResult;
        }

        static void PopulateAsset(XRHandPoseAsset asset, HandPoseCaptureResult captureResult, string poseName)
        {
            if (!HandSideUtility.TryInferHandSideFromBoneNames(
                    captureResult.bones?.Select(b => b.boneName),
                    out var handSide,
                    out _))
            {
                handSide = HandSide.Left;
            }

            asset.poseName = poseName;
            asset.handedness = HandSideUtility.ToHandedness(handSide);
            asset.sourceHandName = captureResult.sourceHandName;
            asset.sourceSkeletonName = HandSideUtility.GetHandModelDisplayFileName(handSide);
            asset.targetName = captureResult.targetName;
            asset.capturedAtIso8601 = DateTime.UtcNow.ToString("o");

            asset.rootWorldPosition = captureResult.rootWorldPosition;
            asset.rootWorldRotation = captureResult.rootWorldRotation;

            asset.hasTargetRelativePose = captureResult.hasTargetRelativePose;
            asset.targetRelativePosition = captureResult.targetRelativePosition;
            asset.targetRelativeRotation = captureResult.targetRelativeRotation;

            asset.bones = CloneBoneList(captureResult.bones);
            asset.joints = CloneJointList(captureResult.joints);

            asset.expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount;
            asset.capturedBoneCount = asset.bones?.Count ?? 0;
            asset.capturedJointCount = asset.joints?.Count ?? 0;
            asset.validJointPoseCount = captureResult.validJointPoseCount;
            asset.skeletonValid = asset.capturedBoneCount == HandSkeletonCatalog.RequiredBoneCount;

            var summary = new StringBuilder();
            summary.AppendLine($"Pose: {poseName}");
            summary.AppendLine($"Bones: {asset.capturedBoneCount} (local Transform from {HandSideUtility.GetBonePrefix(handSide)}*)");
            summary.AppendLine(
                $"Joints: {asset.capturedJointCount} total, {asset.validJointPoseCount} valid tracking poses");
            summary.AppendLine("Joint rotation = tracking-space (not bone localRotation).");
            summary.AppendLine(
                asset.hasTargetRelativePose
                    ? $"Target relative pose saved ({asset.targetName})."
                    : "No target relative pose (target was null).");
            asset.captureSummary = summary.ToString().TrimEnd();
        }

        static void EnsureOutputFolderExists()
        {
            if (!AssetDatabase.IsValidFolder("Assets/VRHandPoseToolOutput"))
            {
                AssetDatabase.CreateFolder("Assets", "VRHandPoseToolOutput");
            }

            if (!AssetDatabase.IsValidFolder(OutputFolder))
            {
                AssetDatabase.CreateFolder("Assets/VRHandPoseToolOutput", "Poses");
            }
        }

        public static string SanitizeFileName(string name)
        {
            if (string.IsNullOrEmpty(name))
                return "Pose";

            var invalidChars = Path.GetInvalidFileNameChars();
            var sb = new StringBuilder(name.Length);
            foreach (var c in name)
            {
                sb.Append(Array.IndexOf(invalidChars, c) >= 0 ? '_' : c);
            }

            return sb.ToString();
        }

        static System.Collections.Generic.List<HandBonePoseData> CloneBoneList(
            System.Collections.Generic.IReadOnlyList<HandBonePoseData> source)
        {
            var clone = new System.Collections.Generic.List<HandBonePoseData>(source?.Count ?? 0);
            if (source == null)
                return clone;

            foreach (var bone in source)
            {
                clone.Add(new HandBonePoseData
                {
                    boneName = bone.boneName,
                    parentBoneName = bone.parentBoneName,
                    localPosition = bone.localPosition,
                    localRotation = bone.localRotation,
                    localScale = bone.localScale,
                });
            }

            return clone;
        }

        static System.Collections.Generic.List<HandJointTrackingData> CloneJointList(
            System.Collections.Generic.IReadOnlyList<HandJointTrackingData> source)
        {
            var clone = new System.Collections.Generic.List<HandJointTrackingData>(source?.Count ?? 0);
            if (source == null)
                return clone;

            foreach (var joint in source)
            {
                clone.Add(new HandJointTrackingData
                {
                    jointId = joint.jointId,
                    poseValid = joint.poseValid,
                    trackingPosition = joint.trackingPosition,
                    trackingRotation = joint.trackingRotation,
                });
            }

            return clone;
        }
    }
}
