using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.SceneManagement;
using Unity.XR.CoreUtils;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// 활성 씬에서 사용자 선택 또는 XR Origin / TrackedPoseDriver 기반 부모 Transform 아래
    /// Left/Right Playback Hand 최소 계층을 구성합니다.
    /// </summary>
    public static class HandPlaybackSetupService
    {
        internal const string VisualName = "Visual";

        internal const string InputActionsPath =
            HandPoseControllerHandSetupService.RecommendedGripActionPath;

        internal const string PositionActionName = "Position";
        internal const string RotationActionName = "Rotation";
        internal const string TrackingStateActionName = "Tracking State";

        const int TrackingTypeRotationAndPosition = 0;
        const int UpdateTypeUpdateAndBeforeRender = 2;

        internal struct SceneProbeSummary
        {
            public int xrOriginCount;
            public int trackedPoseDriverCount;
            public int trackedPoseDriverSharedParentCount;
            public int mainCameraTaggedCount;
        }

        internal struct ParentResolveResult
        {
            public bool success;
            public Transform parent;
            public string sourceLabel;
            public string path;
            public string message;
            public SceneProbeSummary probe;
        }

        internal struct ExistingHandStructure
        {
            public Transform controllerRoot;
            public Transform visualRoot;
            public Transform handRoot;
            public TrackedPoseDriver driver;
            public bool hasXriBindings;
            public bool hasValidHandModel;
        }

        public struct SetupResult
        {
            public bool success;
            public string message;
            public Transform handRoot;
        }

        public static SetupResult SetupPlaybackHand(HandSide handSide, Transform placementParent)
        {
            var scene = placementParent != null && placementParent.gameObject.scene.IsValid()
                ? placementParent.gameObject.scene
                : SceneManager.GetActiveScene();

            return ExecuteSetup(handSide, placementParent, scene);
        }

        internal static SceneProbeSummary ProbeActiveScene(Scene scene)
        {
            var summary = new SceneProbeSummary();
            if (!scene.IsValid() || !scene.isLoaded)
                return summary;

            var xrOrigins = CollectXROriginsInScene(scene);
            summary.xrOriginCount = xrOrigins.Count;

            var drivers = CollectTrackedPoseDriversInScene(scene);
            summary.trackedPoseDriverCount = drivers.Count;
            summary.trackedPoseDriverSharedParentCount = CountTrackedPoseDriverSharedParents(drivers).Count;

            summary.mainCameraTaggedCount = CountMainCamerasInScene(scene);
            return summary;
        }

        internal static bool IsValidActiveSceneTransform(Transform transform, Scene activeScene)
        {
            if (transform == null || activeScene == null || !activeScene.IsValid())
                return false;

            if (!transform.gameObject.scene.IsValid() || transform.gameObject.scene != activeScene)
                return false;

            if (EditorUtility.IsPersistent(transform.gameObject))
                return false;

            if (PrefabUtility.IsPartOfPrefabAsset(transform.gameObject))
                return false;

            var prefabStage = PrefabStageUtility.GetCurrentPrefabStage();
            if (prefabStage != null)
                return false;

            return true;
        }

        internal static ParentResolveResult ResolvePlacementParent(
            Scene scene,
            Transform userAssignedParent)
        {
            var result = new ParentResolveResult
            {
                probe = ProbeActiveScene(scene),
            };

            if (!scene.IsValid() || !scene.isLoaded)
            {
                result.message = "활성 씬이 없거나 로드되지 않았습니다.";
                return result;
            }

            if (IsValidActiveSceneTransform(userAssignedParent, scene))
            {
                result.success = true;
                result.parent = userAssignedParent;
                result.sourceLabel = "사용자 지정 부모";
                result.path = HandPoseCaptureService.GetHierarchyPath(userAssignedParent);
                return result;
            }

            if (userAssignedParent != null)
            {
                result.message =
                    "배치 부모로 지정된 Transform이 활성 씬의 Scene GameObject가 아닙니다.\n" +
                    "Project Asset, Prefab Asset, Prefab Stage, 다른 씬 오브젝트는 사용할 수 없습니다.";
                return result;
            }

            if (TryResolveFromSelection(scene, out var selectionParent, out var selectionLabel))
            {
                result.success = true;
                result.parent = selectionParent;
                result.sourceLabel = selectionLabel;
                result.path = HandPoseCaptureService.GetHierarchyPath(selectionParent);
                return result;
            }

            if (TryResolveFromXROrigin(scene, out var xrParent, out var xrError))
            {
                result.success = true;
                result.parent = xrParent;
                result.sourceLabel = "XR Origin CameraFloorOffsetObject";
                result.path = HandPoseCaptureService.GetHierarchyPath(xrParent);
                return result;
            }

            if (TryResolveFromTrackedPoseDriverHierarchy(scene, out var driverParent, out var driverDetail))
            {
                result.success = true;
                result.parent = driverParent;
                result.sourceLabel = "TrackedPoseDriver 공통 부모";
                result.path = HandPoseCaptureService.GetHierarchyPath(driverParent);
                result.message = driverDetail;
                return result;
            }

            if (TryResolveFromMainCamera(scene, out var cameraParent, out var cameraDetail))
            {
                result.success = true;
                result.parent = cameraParent;
                result.sourceLabel = "Main Camera 기준 부모";
                result.path = HandPoseCaptureService.GetHierarchyPath(cameraParent);
                result.message = cameraDetail;
                return result;
            }

            result.message = BuildUnresolvedParentMessage(result.probe, xrError);
            return result;
        }

        internal static ParentResolveResult ResolveFromXROriginOnly(Scene scene)
        {
            var result = new ParentResolveResult
            {
                probe = ProbeActiveScene(scene),
            };

            if (!scene.IsValid() || !scene.isLoaded)
            {
                result.message = "활성 씬이 없거나 로드되지 않았습니다.";
                return result;
            }

            if (TryResolveFromXROrigin(scene, out var xrParent, out var xrError))
            {
                result.success = true;
                result.parent = xrParent;
                result.sourceLabel = "XR Origin CameraFloorOffsetObject";
                result.path = HandPoseCaptureService.GetHierarchyPath(xrParent);
                return result;
            }

            result.message = xrError;
            return result;
        }

        static SetupResult ExecuteSetup(HandSide handSide, Transform placementParent, Scene scene)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);

            if (!IsValidActiveSceneTransform(placementParent, scene))
            {
                return new SetupResult
                {
                    success = false,
                    message = "유효한 배치 부모 Transform이 없습니다.",
                };
            }

            var existingStructures = CollectExistingHandStructures(placementParent, handSide);
            if (existingStructures.Count > 1)
            {
                return new SetupResult
                {
                    success = false,
                    message = BuildAmbiguousStructureMessage(handSide, existingStructures),
                };
            }

            Transform controllerRoot;
            Transform visualRoot;
            Transform handRoot;

            if (existingStructures.Count == 1)
            {
                var existing = existingStructures[0];
                controllerRoot = existing.controllerRoot;
                visualRoot = existing.visualRoot != null
                    ? existing.visualRoot
                    : FindOrCreateChild(controllerRoot, VisualName);
                ResetLocalTransform(visualRoot);

                if (existing.hasValidHandModel && existing.handRoot != null)
                {
                    handRoot = existing.handRoot;
                }
                else if (!TryEnsureHandInstance(handSide, visualRoot, out handRoot, out var handError))
                {
                    return new SetupResult { success = false, message = handError };
                }
            }
            else
            {
                controllerRoot = FindOrCreateControllerRoot(handSide, placementParent, out var createError);
                if (controllerRoot == null)
                {
                    return new SetupResult { success = false, message = createError };
                }

                ResetLocalTransform(controllerRoot);
                visualRoot = FindOrCreateChild(controllerRoot, VisualName);
                ResetLocalTransform(visualRoot);

                if (!TryEnsureHandInstance(handSide, visualRoot, out handRoot, out var handError))
                {
                    return new SetupResult { success = false, message = handError };
                }
            }

            var trackedPoseDriver = EnsureTrackedPoseDriver(controllerRoot.gameObject);
            if (trackedPoseDriver == null)
            {
                return new SetupResult
                {
                    success = false,
                    message = "TrackedPoseDriver를 추가하거나 설정하지 못했습니다.",
                };
            }

            if (!TryConfigureTrackedPoseDriver(handSide, trackedPoseDriver, out var driverError))
            {
                return new SetupResult { success = false, message = driverError };
            }

            var validation = ValidateHand(handSide, handRoot);
            if (!validation.success)
            {
                return new SetupResult { success = false, message = validation.message };
            }

            EditorSceneManager.MarkSceneDirty(scene);

            var hierarchyPath = HandPoseCaptureService.GetHierarchyPath(handRoot);
            return new SetupResult
            {
                success = true,
                handRoot = handRoot,
                message =
                    $"{sideLabel} Playback Hand 최소 설정 완료.\n" +
                    $"Hand Root: {hierarchyPath}\n" +
                    validation.message +
                    "\n씬은 자동 저장되지 않았습니다.",
            };
        }

        static bool TryResolveFromSelection(Scene scene, out Transform parent, out string label)
        {
            parent = null;
            label = null;

            var selected = Selection.activeTransform;
            if (!IsValidActiveSceneTransform(selected, scene))
                return false;

            parent = selected;
            label = "Hierarchy 선택";
            return true;
        }

        static bool TryResolveFromXROrigin(Scene scene, out Transform parent, out string errorMessage)
        {
            parent = null;
            errorMessage = null;

            var origins = CollectXROriginsInScene(scene);
            if (origins.Count == 0)
            {
                errorMessage = "활성 씬에서 XROrigin 컴포넌트를 찾지 못했습니다.";
                return false;
            }

            if (origins.Count > 1)
            {
                errorMessage =
                    $"활성 씬에서 XROrigin 컴포넌트가 {origins.Count}개 발견되었습니다. 자동 선택하지 않습니다.";
                return false;
            }

            var origin = origins[0];
            var floorOffsetObject = origin.CameraFloorOffsetObject;
            if (floorOffsetObject == null)
            {
                errorMessage =
                    "XROrigin.CameraFloorOffsetObject가 비어 있습니다.";
                return false;
            }

            if (floorOffsetObject.scene != scene)
            {
                errorMessage =
                    "XROrigin.CameraFloorOffsetObject가 활성 씬에 속하지 않습니다.";
                return false;
            }

            parent = floorOffsetObject.transform;
            return true;
        }

        static bool TryResolveFromTrackedPoseDriverHierarchy(
            Scene scene,
            out Transform parent,
            out string detail)
        {
            parent = null;
            detail = null;

            var drivers = CollectTrackedPoseDriversInScene(scene);
            if (drivers.Count == 0)
                return false;

            var sharedParents = CountTrackedPoseDriverSharedParents(drivers);
            if (sharedParents.Count != 1)
                return false;

            parent = sharedParents.Keys.First();
            var driverCount = sharedParents[parent];
            detail =
                $"TrackedPoseDriver {drivers.Count}개 중 {driverCount}개가 같은 부모를 공유합니다.";
            return true;
        }

        static bool TryResolveFromMainCamera(Scene scene, out Transform parent, out string detail)
        {
            parent = null;
            detail = null;

            if (CountMainCamerasInScene(scene) != 1)
                return false;

            var mainCamera = FindMainCameraInScene(scene);
            if (mainCamera == null)
                return false;

            var cameraParent = mainCamera.transform.parent;
            if (cameraParent == null)
                return false;

            var floorOffsets = CollectXROriginFloorOffsets(scene);
            if (floorOffsets.Contains(cameraParent))
            {
                parent = cameraParent;
                detail = "Main Camera의 부모가 XROrigin.CameraFloorOffsetObject입니다.";
                return true;
            }

            var hasControllerSibling = false;
            for (var i = 0; i < cameraParent.childCount; i++)
            {
                var child = cameraParent.GetChild(i);
                if (child == mainCamera.transform)
                    continue;

                if (child.GetComponent<TrackedPoseDriver>() != null)
                {
                    hasControllerSibling = true;
                    break;
                }
            }

            if (!hasControllerSibling)
                return false;

            parent = cameraParent;
            detail = "Main Camera와 TrackedPoseDriver가 같은 부모를 공유합니다.";
            return true;
        }

        static List<XROrigin> CollectXROriginsInScene(Scene scene)
        {
            var origins = new List<XROrigin>();
            foreach (var root in scene.GetRootGameObjects())
            {
                if (root == null)
                    continue;

                origins.AddRange(root.GetComponentsInChildren<XROrigin>(true)
                    .Where(origin => origin != null && origin.gameObject.scene == scene));
            }

            return origins;
        }

        static HashSet<Transform> CollectXROriginFloorOffsets(Scene scene)
        {
            var offsets = new HashSet<Transform>();
            foreach (var origin in CollectXROriginsInScene(scene))
            {
                var floorOffsetObject = origin.CameraFloorOffsetObject;
                if (floorOffsetObject != null && floorOffsetObject.scene == scene)
                    offsets.Add(floorOffsetObject.transform);
            }

            return offsets;
        }

        static List<TrackedPoseDriver> CollectTrackedPoseDriversInScene(Scene scene)
        {
            var drivers = new List<TrackedPoseDriver>();
            foreach (var root in scene.GetRootGameObjects())
            {
                if (root == null)
                    continue;

                drivers.AddRange(root.GetComponentsInChildren<TrackedPoseDriver>(true)
                    .Where(driver => driver != null && driver.gameObject.scene == scene));
            }

            return drivers;
        }

        static Dictionary<Transform, int> CountTrackedPoseDriverSharedParents(List<TrackedPoseDriver> drivers)
        {
            var counts = new Dictionary<Transform, int>();
            foreach (var driver in drivers)
            {
                var parent = driver.transform.parent;
                if (parent == null)
                    continue;

                counts.TryGetValue(parent, out var count);
                counts[parent] = count + 1;
            }

            return counts;
        }

        static int CountMainCamerasInScene(Scene scene)
        {
            var count = 0;
            foreach (var root in scene.GetRootGameObjects())
            {
                foreach (var camera in root.GetComponentsInChildren<Camera>(true))
                {
                    if (camera != null
                        && camera.CompareTag("MainCamera")
                        && camera.gameObject.scene == scene)
                    {
                        count++;
                    }
                }
            }

            return count;
        }

        static Camera FindMainCameraInScene(Scene scene)
        {
            foreach (var root in scene.GetRootGameObjects())
            {
                foreach (var camera in root.GetComponentsInChildren<Camera>(true))
                {
                    if (camera != null
                        && camera.CompareTag("MainCamera")
                        && camera.gameObject.scene == scene)
                    {
                        return camera;
                    }
                }
            }

            return null;
        }

        static string BuildUnresolvedParentMessage(SceneProbeSummary probe, string xrOriginDetail)
        {
            var sb = new StringBuilder();
            sb.AppendLine("배치 부모 Transform을 하나로 결정하지 못했습니다.");
            sb.AppendLine("Hierarchy에서 부모 GameObject를 선택하거나 ObjectField에 지정한 뒤 다시 실행하세요.");
            sb.AppendLine();
            sb.AppendLine("탐색 요약:");
            sb.AppendLine($"• XROrigin 컴포넌트: {probe.xrOriginCount}개");
            sb.AppendLine($"• TrackedPoseDriver: {probe.trackedPoseDriverCount}개");
            sb.AppendLine($"• TrackedPoseDriver 공통 부모 후보: {probe.trackedPoseDriverSharedParentCount}개");
            sb.AppendLine($"• MainCamera 태그 카메라: {probe.mainCameraTaggedCount}개");
            if (!string.IsNullOrEmpty(xrOriginDetail))
            {
                sb.AppendLine();
                sb.AppendLine(xrOriginDetail);
            }

            return sb.ToString().TrimEnd();
        }

        static List<ExistingHandStructure> CollectExistingHandStructures(Transform anchor, HandSide handSide)
        {
            var results = new List<ExistingHandStructure>();
            var seenControllers = new HashSet<int>();

            foreach (var driver in anchor.GetComponentsInChildren<TrackedPoseDriver>(true))
            {
                if (driver == null || driver.transform == null)
                    continue;

                if (!IsTransformUnderAnchor(driver.transform, anchor))
                    continue;

                var controllerRoot = driver.transform;
                var instanceId = controllerRoot.GetInstanceID();
                if (!seenControllers.Add(instanceId))
                    continue;

                var hasBindings = HasXriBindings(driver, handSide);
                var handRoot = FindHandModelTransformUnder(handSide, controllerRoot);
                var hasValidHand = handRoot != null
                    && IsHandModelInstance(handSide, handRoot.gameObject, out _);

                if (!hasBindings && !hasValidHand)
                    continue;

                results.Add(new ExistingHandStructure
                {
                    controllerRoot = controllerRoot,
                    visualRoot = handRoot != null ? handRoot.parent : FindDirectChildByName(controllerRoot, VisualName),
                    handRoot = handRoot,
                    driver = driver,
                    hasXriBindings = hasBindings,
                    hasValidHandModel = hasValidHand,
                });
            }

            return results;
        }

        static bool IsTransformUnderAnchor(Transform transform, Transform anchor)
        {
            if (transform == null || anchor == null)
                return false;

            return transform == anchor || transform.IsChildOf(anchor);
        }

        static Transform FindOrCreateControllerRoot(HandSide handSide, Transform anchor, out string errorMessage)
        {
            errorMessage = null;
            var controllerName = HandSideUtility.GetControllerNameToken(handSide);
            var ambiguous = CollectExistingHandStructures(anchor, handSide)
                .Where(structure => structure.hasXriBindings || structure.hasValidHandModel)
                .ToList();

            if (ambiguous.Count > 1)
            {
                errorMessage = BuildAmbiguousStructureMessage(handSide, ambiguous);
                return null;
            }

            if (ambiguous.Count == 1)
                return ambiguous[0].controllerRoot;

            return FindOrCreateChild(anchor, controllerName);
        }

        static string BuildAmbiguousStructureMessage(HandSide handSide, List<ExistingHandStructure> structures)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var handModelName = HandSideUtility.GetPreferredHandRootName(handSide);
            var xriMap = HandSideUtility.GetXriTrackingActionMap(handSide);

            var sb = new StringBuilder();
            sb.AppendLine($"{sideLabel}손 Playback Hand 후보 구조가 여러 개 발견되었습니다. 자동 선택하지 않습니다.");
            foreach (var structure in structures)
            {
                sb.Append("• ");
                sb.Append(HandPoseCaptureService.GetHierarchyPath(structure.controllerRoot));
                sb.Append($" · {xriMap}=");
                sb.Append(structure.hasXriBindings ? "Y" : "N");
                sb.Append($" · {handModelName}.fbx=");
                sb.AppendLine(structure.hasValidHandModel ? "Y" : "N");
            }

            return sb.ToString().TrimEnd();
        }

        static Transform FindDirectChildByName(Transform parent, string childName)
        {
            if (parent == null)
                return null;

            for (var i = 0; i < parent.childCount; i++)
            {
                var child = parent.GetChild(i);
                if (string.Equals(child.name, childName, StringComparison.Ordinal))
                    return child;
            }

            return null;
        }

        static Transform FindHandModelTransformUnder(HandSide handSide, Transform root)
        {
            if (root == null)
                return null;

            foreach (var transform in root.GetComponentsInChildren<Transform>(true))
            {
                if (transform == root)
                    continue;

                if (IsHandModelInstance(handSide, transform.gameObject, out _))
                    return transform;
            }

            return null;
        }

        static bool HasXriBindings(TrackedPoseDriver driver, HandSide handSide)
        {
            if (driver == null)
                return false;

            var actionMapName = HandSideUtility.GetXriTrackingActionMap(handSide);
            return UsesXriActionMap(driver, actionMapName, "m_PositionInput")
                && UsesXriActionMap(driver, actionMapName, "m_RotationInput")
                && UsesXriActionMap(driver, actionMapName, "m_TrackingStateInput");
        }

        static bool UsesXriActionMap(TrackedPoseDriver driver, string actionMapName, string inputPropertyName)
        {
            var serializedDriver = new SerializedObject(driver);
            var inputProperty = serializedDriver.FindProperty(inputPropertyName);
            if (inputProperty == null)
                return false;

            var useReference = inputProperty.FindPropertyRelative("m_UseReference");
            if (useReference != null && !useReference.boolValue)
                return false;

            var reference = inputProperty.FindPropertyRelative("m_Reference").objectReferenceValue as InputActionReference;
            var action = reference != null ? reference.action : null;
            return action != null
                && string.Equals(action.actionMap?.name, actionMapName, StringComparison.Ordinal);
        }

        static Transform FindOrCreateChild(Transform parent, string childName)
        {
            var existing = FindDirectChildByName(parent, childName);
            if (existing != null)
                return existing;

            var created = new GameObject(childName);
            Undo.RegisterCreatedObjectUndo(created, $"Create {childName}");
            created.transform.SetParent(parent, false);
            return created.transform;
        }

        static void ResetLocalTransform(Transform transform)
        {
            Undo.RecordObject(transform, $"Reset {transform.name} Transform");
            transform.localPosition = Vector3.zero;
            transform.localRotation = Quaternion.identity;
            transform.localScale = Vector3.one;
        }

        static TrackedPoseDriver EnsureTrackedPoseDriver(GameObject target)
        {
            var driver = target.GetComponent<TrackedPoseDriver>();
            if (driver != null)
                return driver;

            return Undo.AddComponent<TrackedPoseDriver>(target);
        }

        static bool TryConfigureTrackedPoseDriver(
            HandSide handSide,
            TrackedPoseDriver driver,
            out string errorMessage)
        {
            errorMessage = null;
            var actionMapName = HandSideUtility.GetXriTrackingActionMap(handSide);

            var inputActions = AssetDatabase.LoadAssetAtPath<InputActionAsset>(InputActionsPath);
            if (inputActions == null)
            {
                errorMessage = $"Input Action Asset를 찾지 못했습니다: {InputActionsPath}";
                return false;
            }

            if (!TryCreateActionReference(inputActions, actionMapName, PositionActionName, out var positionReference, out errorMessage)
                || !TryCreateActionReference(inputActions, actionMapName, RotationActionName, out var rotationReference, out errorMessage)
                || !TryCreateActionReference(inputActions, actionMapName, TrackingStateActionName, out var trackingStateReference, out errorMessage))
            {
                return false;
            }

            Undo.RecordObject(driver, "Configure TrackedPoseDriver");
            var serializedDriver = new SerializedObject(driver);
            serializedDriver.FindProperty("m_TrackingType").enumValueIndex = TrackingTypeRotationAndPosition;
            serializedDriver.FindProperty("m_UpdateType").enumValueIndex = UpdateTypeUpdateAndBeforeRender;

            HandPoseControllerHandSetupService.SetInputActionReferencePublic(
                serializedDriver.FindProperty("m_PositionInput"),
                positionReference);
            HandPoseControllerHandSetupService.SetInputActionReferencePublic(
                serializedDriver.FindProperty("m_RotationInput"),
                rotationReference);
            HandPoseControllerHandSetupService.SetInputActionReferencePublic(
                serializedDriver.FindProperty("m_TrackingStateInput"),
                trackingStateReference);

            serializedDriver.ApplyModifiedPropertiesWithoutUndo();
            return true;
        }

        static bool TryCreateActionReference(
            InputActionAsset asset,
            string actionMapName,
            string actionName,
            out InputActionReference reference,
            out string errorMessage)
        {
            reference = null;
            errorMessage = null;

            var actionMap = asset.FindActionMap(actionMapName, false);
            if (actionMap == null)
            {
                errorMessage =
                    $"Action Map '{actionMapName}'을(를) 찾지 못했습니다.\nAsset: {InputActionsPath}";
                return false;
            }

            var action = actionMap.FindAction(actionName, false);
            if (action == null)
            {
                errorMessage =
                    $"Action '{actionMapName}/{actionName}'을(를) 찾지 못했습니다.\nAsset: {InputActionsPath}";
                return false;
            }

            reference = InputActionReference.Create(action);
            if (reference == null)
            {
                errorMessage = $"InputActionReference 생성 실패: {actionMapName}/{actionName}";
                return false;
            }

            return true;
        }

        static bool TryEnsureHandInstance(
            HandSide handSide,
            Transform visual,
            out Transform handRoot,
            out string errorMessage)
        {
            handRoot = null;
            errorMessage = null;

            var handName = HandSideUtility.GetPreferredHandRootName(handSide);
            var modelResolve = HandVisualizerAssetResolver.ResolvePlaybackModelForImportedSample(handSide);
            if (!modelResolve.success)
            {
                errorMessage =
                    $"{handName} Playback 모델을 HandVisualizer Sample에서 찾지 못했습니다.\n" +
                    modelResolve.message;
                return false;
            }

            var modelPath = modelResolve.assetPath;

            // 기존 유효 손 모델이 Visual 아래에 있으면 재사용 (중복 생성 방지)
            var existingValid = FindHandModelTransformUnder(handSide, visual);
            if (existingValid != null)
            {
                handRoot = existingValid;
                return true;
            }

            var existingByName = FindDirectChildByName(visual, handName);
            if (existingByName != null)
            {
                if (!IsHandModelInstance(handSide, existingByName.gameObject, out var sourceError))
                {
                    errorMessage =
                        $"{HandPoseCaptureService.GetHierarchyPath(existingByName)}가(이) 이미 존재하지만 {sourceError}\n" +
                        "자동 삭제·교체하지 않았습니다.";
                    return false;
                }

                handRoot = existingByName;
                return true;
            }

            var modelPrefab = modelResolve.prefab
                ?? AssetDatabase.LoadAssetAtPath<GameObject>(modelPath);
            if (modelPrefab == null)
            {
                errorMessage = $"{handName} 모델을 찾지 못했습니다: {modelPath}";
                return false;
            }

            var instance = PrefabUtility.InstantiatePrefab(modelPrefab, visual) as GameObject;
            if (instance == null)
            {
                errorMessage = $"{handName} 모델 인스턴스 생성에 실패했습니다: {modelPath}";
                return false;
            }

            Undo.RegisterCreatedObjectUndo(instance, $"Instantiate {handName}");
            instance.name = handName;
            ResetLocalTransform(instance.transform);
            handRoot = instance.transform;
            return true;
        }

        static bool IsHandModelInstance(HandSide handSide, GameObject handObject, out string errorMessage)
        {
            errorMessage = null;
            var handName = HandSideUtility.GetPreferredHandRootName(handSide);

            var assetPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(handObject);
            if (string.IsNullOrEmpty(assetPath))
            {
                // Prefab 인스턴스가 아니어도 스켈레톤이 유효하면 Playback으로 인정
                var validation = HandSkeletonCatalog.Validate(handObject.transform, handSide);
                var hasMesh = handObject.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;
                if (validation.isValid && hasMesh)
                    return true;

                errorMessage = $"{handName} PrefabInstance가 아니며 skeleton 검증도 실패했습니다.";
                return false;
            }

            // Tracking Prefab 혼동 금지
            if (handObject.GetComponentInChildren<UnityEngine.XR.Hands.XRHandSkeletonDriver>(true) != null
                || handObject.GetComponentInChildren<UnityEngine.XR.Hands.XRHandTrackingEvents>(true) != null)
            {
                errorMessage = "Tracking Hand Prefab 인스턴스는 Playback으로 사용할 수 없습니다.";
                return false;
            }

            // Import된 Sample 범위 + 동적 해석 경로와 일치하거나, 동일 importPath 아래 유효 모델이면 OK
            var resolved = HandVisualizerAssetResolver.ResolvePlaybackModelForImportedSample(handSide);
            if (resolved.success
                && string.Equals(assetPath, resolved.assetPath, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out _)
                && !string.IsNullOrEmpty(sample.assetImportPath ?? sample.importPath)
                && assetPath.StartsWith(
                    (sample.assetImportPath ?? sample.importPath).Replace('\\', '/') + "/",
                    StringComparison.OrdinalIgnoreCase))
            {
                var candidate = HandVisualizerAssetResolver.EvaluatePlaybackModel(
                    AssetDatabase.LoadAssetAtPath<GameObject>(assetPath) ?? handObject,
                    assetPath,
                    handSide);
                if (candidate.isValid)
                    return true;

                errorMessage = candidate.failReason ?? "Sample 내 모델 검증 실패";
                return false;
            }

            // 최후: 현재 오브젝트 자체 검증 (경로가 Sample 밖이어도 구조가 맞으면 재사용)
            var selfValidation = HandSkeletonCatalog.Validate(handObject.transform, handSide);
            var selfMesh = handObject.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;
            if (selfValidation.isValid && selfMesh)
                return true;

            errorMessage =
                $"{handName} Playback 모델이 아닙니다. (원본: {assetPath})";
            return false;
        }

        struct ValidationReport
        {
            public bool success;
            public string message;
        }

        static ValidationReport ValidateHand(HandSide handSide, Transform handRoot)
        {
            var skeleton = HandSkeletonCatalog.Validate(handRoot, handSide);
            var skinnedMesh = handRoot.GetComponentInChildren<SkinnedMeshRenderer>(true);
            var wristName = HandSideUtility.GetWristBoneName(handSide);
            var hasWrist = HasNamedBone(handRoot, wristName);

            var sb = new StringBuilder();
            sb.AppendLine("검증 결과:");
            sb.AppendLine(
                $"• {HandSideUtility.GetBonePrefix(handSide)}* skeleton: " +
                $"{skeleton.foundBoneCount}/{skeleton.expectedBoneCount} " +
                (skeleton.isValid ? "(OK)" : "(FAIL)"));
            sb.AppendLine($"• {wristName}: {(hasWrist ? "있음" : "없음")}");
            sb.AppendLine($"• SkinnedMeshRenderer: {(skinnedMesh != null ? "있음" : "없음")}");

            if (!string.IsNullOrEmpty(skeleton.summary))
                sb.AppendLine($"• {skeleton.summary}");

            var success = skeleton.isValid && hasWrist && skinnedMesh != null;
            if (!success)
                sb.AppendLine("검증 실패 — 생성된 오브젝트는 유지됩니다. Hierarchy에서 확인하세요.");

            return new ValidationReport
            {
                success = success,
                message = sb.ToString().TrimEnd(),
            };
        }

        static bool HasNamedBone(Transform handRoot, string boneName)
        {
            foreach (var transform in handRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == handRoot)
                    continue;

                if (string.Equals(transform.name, boneName, StringComparison.Ordinal))
                    return true;
            }

            return false;
        }
    }
}
