using System;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// ① 선택 손 전체 준비: XR Hands 확인 → HandVisualizer Sample Import →
    /// Tracking/Playback 생성 → Grip 연결 → 재검증.
    /// </summary>
    [InitializeOnLoad]
    public static class HandSelectedHandFullPrepService
    {
        public const string PrimaryButtonLabel = "선택 손 전체 준비 자동 구성";
        public const string ContinueButtonLabel = "샘플 준비 완료 · 손 구성 계속";
        public const string ImportProgressMessage = "XR Hands HandVisualizer 샘플을 가져오는 중입니다...";

        public struct Checklist
        {
            public bool xrHandsInstalled;
            public string xrHandsVersion;
            public bool sampleImported;
            public string sampleDisplayName;
            public string sampleImportPath;
            public bool trackingPrefabResolved;
            public string trackingPrefabPath;
            public bool trackingHandReady;
            public bool trackingJointsValid;
            public string trackingHandPath;
            public bool playbackHandReady;
            public string playbackHandPath;
            public bool gripConnected;
            public string gripActionName;
            public bool isComplete;

            public string BuildSummary()
            {
                var sb = new StringBuilder();
                sb.AppendLine(Row("XR Hands 패키지 설치됨", xrHandsInstalled, xrHandsVersion));
                sb.AppendLine(Row(
                    "HandVisualizer Sample Import됨",
                    sampleImported,
                    string.IsNullOrEmpty(sampleImportPath) ? sampleDisplayName : sampleImportPath));
                sb.AppendLine(Row("선택 손 Tracking Prefab 확인됨", trackingPrefabResolved, trackingPrefabPath));
                sb.AppendLine(Row("Tracking Hand 생성/재사용됨", trackingHandReady, trackingHandPath));
                sb.AppendLine(Row("Tracking 26 Joint 검증됨", trackingJointsValid, null));
                sb.AppendLine(Row("Playback Hand 생성/재사용됨", playbackHandReady, playbackHandPath));
                sb.AppendLine(Row("Grip Input Action 연결됨", gripConnected, gripActionName));
                sb.AppendLine();
                sb.Append(isComplete ? "전체 준비 완료" : "전체 준비 미완료");
                return sb.ToString().TrimEnd();
            }

            static string Row(string label, bool ok, string detail)
            {
                var mark = ok ? "OK" : "—";
                if (string.IsNullOrEmpty(detail))
                    return $"[{mark}] {label}";
                return $"[{mark}] {label}: {detail}";
            }
        }

        public struct PrepResult
        {
            public bool success;
            public bool importInProgress;
            public bool needsManualContinue;
            public Checklist checklist;
            public Transform trackingHandRoot;
            public Transform playbackHandRoot;
            public UnityEngine.InputSystem.InputActionReference gripInputAction;
            public string message;
            public string statusMessage;
        }

        static bool s_ResumeScheduled;

        static HandSelectedHandFullPrepService()
        {
            EditorApplication.delayCall += () =>
            {
                if (!HandVisualizerSampleImportService.HasPendingSetup)
                    return;

                ScheduleResume();
            };
        }

        public static string GetPrimaryButtonLabel()
        {
            if (HandVisualizerSampleImportService.NeedsManualContinue
                || (HandVisualizerSampleImportService.HasPendingSetup
                    && HandVisualizerSampleImportService.TryGetImportedSample(out _, out _)))
            {
                return ContinueButtonLabel;
            }

            return PrimaryButtonLabel;
        }

        public static PrepResult RunFullPrep(HandSide handSide, Transform playbackPlacementParent = null)
        {
            var result = new PrepResult
            {
                checklist = new Checklist(),
            };

            // 1) XR Hands 설치
            var package = XrHandsPackageResolver.ResolveInstalled();
            result.checklist.xrHandsInstalled = package.success;
            result.checklist.xrHandsVersion = package.version;
            if (!package.success)
            {
                return Fail(result, package.message);
            }

            // 2-4) Sample 탐색 / Import
            var ensure = HandVisualizerSampleImportService.EnsureImported(handSide, openWindowOnResume: true);
            if (!ensure.success)
            {
                return Fail(result, ensure.message);
            }

            if (ensure.importRequested && !ensure.alreadyImported)
            {
                result.importInProgress = true;
                result.statusMessage = ImportProgressMessage;
                result.message = ensure.message;
                HandVisualizerSampleImportService.SetStatusMessage(ImportProgressMessage);

                // Import 직후 같은 스택에서 Prefab을 찾지 않는다. Refresh 후 delayCall로 재개.
                EditorApplication.delayCall += () =>
                {
                    AssetDatabase.Refresh();
                    EditorApplication.delayCall += () => TryResumePendingSetup();
                };

                return result;
            }

            return ContinueAfterSampleReady(handSide, playbackPlacementParent);
        }

        public static PrepResult ContinueAfterSampleReady(
            HandSide handSide,
            Transform playbackPlacementParent = null)
        {
            var result = new PrepResult
            {
                checklist = new Checklist(),
            };

            var package = XrHandsPackageResolver.ResolveInstalled();
            result.checklist.xrHandsInstalled = package.success;
            result.checklist.xrHandsVersion = package.version;
            if (!package.success)
                return Fail(result, package.message);

            if (!HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out var sampleError))
            {
                // Domain Reload 등으로 Import가 끝났는데 아직 반영 전이면 manual continue 유도
                if (HandVisualizerSampleImportService.HasPendingSetup)
                {
                    result.needsManualContinue = true;
                    HandVisualizerSampleImportService.MarkNeedsManualContinue(
                        "샘플 Import 후 Domain Reload가 발생했을 수 있습니다.\n" +
                        $"'{ContinueButtonLabel}' 버튼으로 손 구성을 계속하세요.\n{sampleError}");
                    result.statusMessage = HandVisualizerSampleImportService.LastStatusMessage;
                    result.message = result.statusMessage;
                    return result;
                }

                return Fail(result, sampleError);
            }

            result.checklist.sampleImported = true;
            result.checklist.sampleDisplayName = sample.displayName;
            result.checklist.sampleImportPath = sample.assetImportPath ?? sample.importPath;

            // 5) Tracking Prefab 탐색
            var trackingResolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(
                handSide,
                sample.assetImportPath ?? sample.importPath);
            result.checklist.trackingPrefabResolved = trackingResolve.success;
            result.checklist.trackingPrefabPath = trackingResolve.assetPath;
            if (!trackingResolve.success)
                return Fail(result, trackingResolve.message);

            // 6) Tracking Hand 생성/재사용
            var trackingSetup = HandTrackingHandSetupService.EnsureTrackingHand(
                handSide,
                trackingResolve.prefab,
                trackingResolve.assetPath);
            result.checklist.trackingHandReady = trackingSetup.success;
            result.checklist.trackingHandPath = trackingSetup.trackingHandRoot != null
                ? HandPoseCaptureService.GetHierarchyPath(trackingSetup.trackingHandRoot)
                : null;
            result.trackingHandRoot = trackingSetup.trackingHandRoot;
            if (!trackingSetup.success)
                return Fail(result, trackingSetup.message);

            result.checklist.trackingJointsValid =
                HandTrackingHandSetupService.TryValidateTrackingInstance(
                    trackingSetup.trackingHandRoot.gameObject,
                    handSide,
                    out _);
            if (!result.checklist.trackingJointsValid)
                return Fail(result, "Tracking Hand 26 Joint 재검증에 실패했습니다.");

            // 7) Playback Hand 생성/재사용 (하드코딩 경로 없이 Resolver 사용)
            var scene = SceneManager.GetActiveScene();
            var parentResolve = HandPlaybackSetupService.ResolvePlacementParent(
                scene,
                playbackPlacementParent);
            if (!parentResolve.success)
                return Fail(result, parentResolve.message);

            var playbackSetup = HandPlaybackSetupService.SetupPlaybackHand(
                handSide,
                parentResolve.parent);
            result.checklist.playbackHandReady = playbackSetup.success;
            result.playbackHandRoot = playbackSetup.handRoot;
            result.checklist.playbackHandPath = playbackSetup.handRoot != null
                ? HandPoseCaptureService.GetHierarchyPath(playbackSetup.handRoot)
                : null;
            if (!playbackSetup.success)
                return Fail(result, playbackSetup.message);

            // 8-9) Grip 자동 연결
            var grip = HandGripInputActionFinder.FindAndResolveReference(handSide);
            if (!grip.success)
            {
                result.checklist.gripConnected = false;
                result.checklist = EvaluateChecklist(
                    handSide,
                    result.trackingHandRoot,
                    result.playbackHandRoot,
                    null);
                return Fail(
                    result,
                    "Tracking/Playback은 준비됐지만 Grip Input Action 연결에 실패했습니다.\n" +
                    (grip.failureReason ?? grip.displaySummary));
            }

            result.gripInputAction = grip.inputActionReference;
            result.checklist.gripConnected = grip.inputActionReference != null;
            result.checklist.gripActionName = grip.inputActionReference != null
                ? grip.inputActionReference.name
                : null;

            // 10) 전체 재검증
            result.checklist = EvaluateChecklist(
                handSide,
                result.trackingHandRoot,
                result.playbackHandRoot,
                result.gripInputAction);

            if (!result.checklist.isComplete)
            {
                return Fail(
                    result,
                    "재검증에서 일부 조건이 충족되지 않았습니다.\n" + result.checklist.BuildSummary());
            }

            HandVisualizerSampleImportService.ClearPendingSetup();
            HandVisualizerSampleImportService.ClearStatus();
            result.success = true;
            result.message =
                $"{HandSideUtility.GetLabel(handSide)}손 전체 준비 완료.\n" +
                result.checklist.BuildSummary();
            result.statusMessage = result.message;
            return result;
        }

        public static Checklist EvaluateChecklist(
            HandSide handSide,
            Transform trackingHandRoot,
            Transform playbackHandRoot,
            UnityEngine.InputSystem.InputActionReference gripAction)
        {
            var checklist = new Checklist();

            var package = XrHandsPackageResolver.ResolveInstalled();
            checklist.xrHandsInstalled = package.success;
            checklist.xrHandsVersion = package.version;

            if (HandVisualizerSampleImportService.TryGetImportedSample(out var sample, out _))
            {
                checklist.sampleImported = true;
                checklist.sampleDisplayName = sample.displayName;
                checklist.sampleImportPath = sample.assetImportPath ?? sample.importPath;

                var trackingResolve = HandVisualizerAssetResolver.ResolveTrackingPrefab(
                    handSide,
                    sample.assetImportPath ?? sample.importPath);
                checklist.trackingPrefabResolved = trackingResolve.success;
                checklist.trackingPrefabPath = trackingResolve.assetPath;
            }

            if (trackingHandRoot != null)
            {
                checklist.trackingHandReady = true;
                checklist.trackingHandPath = HandPoseCaptureService.GetHierarchyPath(trackingHandRoot);
                checklist.trackingJointsValid =
                    HandTrackingHandSetupService.TryValidateTrackingInstance(
                        trackingHandRoot.gameObject,
                        handSide,
                        out _);
            }

            if (playbackHandRoot != null)
            {
                var validation = HandSkeletonCatalog.Validate(playbackHandRoot, handSide);
                var hasMesh = playbackHandRoot.GetComponentInChildren<SkinnedMeshRenderer>(true) != null;
                checklist.playbackHandReady = validation.isValid && hasMesh;
                checklist.playbackHandPath = HandPoseCaptureService.GetHierarchyPath(playbackHandRoot);
            }

            checklist.gripConnected = gripAction != null;
            checklist.gripActionName = gripAction != null ? gripAction.name : null;

            checklist.isComplete =
                checklist.xrHandsInstalled
                && checklist.sampleImported
                && checklist.trackingPrefabResolved
                && checklist.trackingHandReady
                && checklist.trackingJointsValid
                && checklist.playbackHandReady
                && checklist.gripConnected;

            return checklist;
        }

        public static void TryResumePendingSetup()
        {
            s_ResumeScheduled = false;
            var pending = HandVisualizerSampleImportService.GetPendingSetup();
            if (!pending.exists || !pending.resumeAfterImport)
                return;

            if (pending.openWindow)
                HandPoseCaptureWindow.ShowWindowAndResumeFullPrep(pending.handSide);
            else
            {
                var result = ContinueAfterSampleReady(pending.handSide);
                if (!result.success && result.needsManualContinue)
                    return;

                if (!result.success && result.importInProgress)
                    return;

                if (!result.success)
                {
                    // Domain Reload 직후 Sample API가 아직 isImported=false일 수 있음
                    if (!HandVisualizerSampleImportService.TryGetImportedSample(out _, out _))
                    {
                        HandVisualizerSampleImportService.MarkNeedsManualContinue(
                            "샘플 Import 후 자동 재개가 완료되지 않았습니다.\n" +
                            $"툴 창에서 '{ContinueButtonLabel}'을 눌러 계속하세요.\n" +
                            result.message);
                    }
                }
            }
        }

        public static void ScheduleResume()
        {
            if (s_ResumeScheduled)
                return;

            s_ResumeScheduled = true;
            EditorApplication.delayCall += TryResumePendingSetup;
        }

        static PrepResult Fail(PrepResult result, string message)
        {
            result.success = false;
            result.message = message;
            result.statusMessage = message;
            HandVisualizerSampleImportService.SetStatusMessage(message);
            // Import 진행 중이 아닌 실패에서는 pending을 유지하지 않음 (재시도 가능)
            if (!result.importInProgress)
            {
                // pending이 import 재개용이면 유지; 그 외는 호출측에서 판단
            }

            return result;
        }
    }
}
