using UnityEngine;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// HandGhostFresnel 셰이더용 고스트 외형 설정입니다.
    /// </summary>
    public struct HandGhostAppearanceSettings
    {
        public float baseAlpha;
        public Color rimColor;
        public float rimPower;
        public float rimIntensity;
        public float pulseSpeed;
        public float pulseAmount;

        public static HandGhostAppearanceSettings Default => new()
        {
            baseAlpha = 0.05f,
            rimColor = new Color(0.35f, 0.85f, 1f, 1f),
            rimPower = 3f,
            rimIntensity = 2f,
            pulseSpeed = 1.2f,
            pulseAmount = 0.2f,
        };
    }
}
