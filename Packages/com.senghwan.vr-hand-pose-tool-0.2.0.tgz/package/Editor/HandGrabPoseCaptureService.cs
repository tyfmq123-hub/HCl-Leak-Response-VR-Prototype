using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// Play Mode에서 손 모양(26본)을 HandGrabPoseRecord로 캡처합니다.
    /// <para>Tracking Hand 캡처: <see cref="EvaluateTrackingReadiness"/> / <see cref="CaptureAndSaveFromTrackingHand"/> 사용.</para>
    /// <para>Playback Hand 캡처(Controller): <see cref="EvaluateReadiness(HandSide,Transform,GameObject)"/> 사용.</para>
    /// </summary>
    public static class HandGrabPoseCaptureService
    {
        public const string CaptureSourcePlaybackHand = "PlaybackHand";
        public const string CaptureSourceTrackingHand = "TrackingHand";

        public struct Readiness
        {
            public bool canCapture;
            public bool isPlaying;
            public HandSide handSide;
            public Transform playbackHandRoot;
            public XRGrabInteractable targetGrab;
            public XRBaseInteractor interactor;
            public bool isTargetGrabbed;
            public int boneCount;
            public int expectedBoneCount;
            public string playbackHandPath;
            public string interactorPath;
            public string targetName;
            public List<string> blockers;
            public List<string> warnings;
            // ── Hand Tracking 전용 필드 ──
            public bool subsystemRunning;
            public bool handTracked;
            public bool skeletonDriverPresent;
        }

        public struct CaptureResult
        {
            public bool success;
            public string message;
            public int boneCount;
            public HandGrabPoseRecordFactory.SaveResult saveResult;
            public List<string> errors;
            public List<string> warnings;
            public bool pendingApplyRegistered;
            public string pendingApplyMessage;
        }

        /// <summary>
        /// Grab/Select 상태 없이 손 모양만 캡처하기 위한 Readiness 평가.
        /// Play Mode + playbackHandRoot + 26본 + targetObject 만 확인합니다.
        /// </summary>
        public static Readiness EvaluateReadiness(
            HandSide handSide,
            Transform playbackHandRoot,
            GameObject targetObject)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var readiness = new Readiness
            {
                handSide = handSide,
                expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                blockers = new List<string>(),
                warnings = new List<string>(),
            };

            readiness.isPlaying = EditorApplication.isPlaying;
            if (!readiness.isPlaying)
                readiness.blockers.Add("Play Mode가 아닙니다.");

            if (playbackHandRoot == null)
            {
                readiness.blockers.Add("Playback Hand Root가 지정되지 않았습니다.");
            }
            else
            {
                readiness.playbackHandRoot = playbackHandRoot;
                readiness.playbackHandPath = HandPoseCaptureService.GetHierarchyPath(playbackHandRoot);

                if (!HandSideUtility.MatchesHandSide(playbackHandRoot, handSide))
                    readiness.blockers.Add($"Playback Hand Root가 {sideLabel} 손과 일치하지 않습니다.");

                var skeletonValidation = HandSkeletonCatalog.Validate(playbackHandRoot, handSide);
                if (!skeletonValidation.isValid)
                {
                    readiness.blockers.Add($"Playback Hand skeleton 검증 실패: {skeletonValidation.summary}");
                }
                else
                {
                    readiness.boneCount = skeletonValidation.foundBoneCount;
                    if (readiness.boneCount != readiness.expectedBoneCount)
                        readiness.warnings.Add($"Bone 수 {readiness.boneCount} / 기대 {readiness.expectedBoneCount}");
                }
            }

            if (targetObject == null)
            {
                readiness.blockers.Add("Target Grab Object가 지정되지 않았습니다.");
            }
            else
            {
                readiness.targetName = targetObject.name;
                readiness.targetGrab = targetObject.GetComponent<XRGrabInteractable>();
                if (readiness.targetGrab == null)
                    readiness.blockers.Add("Target Object에 XRGrabInteractable이 없습니다.");
            }

            readiness.canCapture = readiness.blockers.Count == 0;
            return readiness;
        }

        /// <summary>
        /// Grab/Select 상태 없이 현재 Playback Hand 손 모양(26본)을 캡처해 Record Asset으로 저장합니다.
        /// Attach 기준점은 XRGrabInteractable.attachTransform → Target Transform 순으로 폴백합니다.
        /// </summary>
        public static CaptureResult CaptureAndSave(
            HandSide handSide,
            Transform playbackHandRoot,
            GameObject targetObject)
        {
            var result = new CaptureResult
            {
                errors = new List<string>(),
                warnings = new List<string>(),
            };

            var readiness = EvaluateReadiness(handSide, playbackHandRoot, targetObject);
            result.warnings.AddRange(readiness.warnings);

            if (!readiness.canCapture)
            {
                result.errors.AddRange(readiness.blockers);
                result.message = "캡처 조건을 충족하지 못했습니다.";
                return result;
            }

            var targetTransform = readiness.targetGrab.transform;
            var handRoot = readiness.playbackHandRoot;

            var attachPoint = readiness.targetGrab.attachTransform != null
                ? readiness.targetGrab.attachTransform
                : targetTransform;

            if (!TryCapturePlaybackBones(handRoot, handSide, out var bones, out var boneError, out var boneWarnings))
            {
                result.errors.Add(boneError);
                result.message = boneError;
                return result;
            }

            result.warnings.AddRange(boneWarnings);
            result.boneCount = bones.Count;

            var handRelative = HandPoseTargetSpace.ComputeRelativePose(handRoot, targetTransform);
            var attachRelative = HandPoseTargetSpace.ComputeRelativePose(attachPoint, targetTransform);
            var attachToHandPosition = attachPoint.InverseTransformPoint(handRoot.position);
            var attachToHandRotation = Quaternion.Inverse(attachPoint.rotation) * handRoot.rotation;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var poseName = $"{targetObject.name}_{sideLabel}_HandPose";

            var record = ScriptableObject.CreateInstance<HandGrabPoseRecord>();
            record.Initialize(new HandGrabPoseRecord.CaptureData
            {
                poseName = poseName,
                handSide = handSide,
                captureSource = CaptureSourcePlaybackHand,
                capturedAtUtc = DateTime.UtcNow.ToString("o"),
                sourceHandRootName = handRoot.name,
                targetObjectName = targetObject.name,
                capturedWhileGrabbed = false,
                handRootLocalPosition = handRelative.relativePosition,
                handRootLocalRotation = handRelative.relativeRotation,
                attachLocalPosition = attachRelative.relativePosition,
                attachLocalRotation = attachRelative.relativeRotation,
                interactorAttachLocalPosition = attachRelative.relativePosition,
                interactorAttachLocalRotation = attachRelative.relativeRotation,
                interactorToHandRootLocalPosition = attachToHandPosition,
                interactorToHandRootLocalRotation = attachToHandRotation,
                bones = bones,
            });

            if (!record.HasBoneData)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("Record bone 데이터가 비어 있습니다.");
                result.message = result.errors[0];
                return result;
            }

            if (!record.AreSpatialRotationsValid)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("공간 회전 Quaternion이 유효하지 않습니다.");
                result.message = result.errors[0];
                return result;
            }

            var fileName = HandGrabPoseRecordFactory.BuildDefaultFileName(targetObject.name, handSide);
            var saveResult = HandGrabPoseRecordFactory.SaveRecord(
                record,
                fileName,
                new HandGrabPoseRecordFactory.SaveOptions
                {
                    pendingApplyTarget = targetObject,
                    pendingApplyHandSide = handSide,
                    registerPendingApply = EditorApplication.isPlaying,
                });
            result.saveResult = saveResult;
            result.pendingApplyRegistered = saveResult.pendingApplyRegistered;
            result.pendingApplyMessage = saveResult.pendingApplyMessage;

            if (!saveResult.success)
            {
                result.errors.Add(saveResult.message);
                result.message = saveResult.message;
                return result;
            }

            result.success = true;
            var summary = new StringBuilder();
            summary.AppendLine(saveResult.message);
            summary.AppendLine($"Bone {result.boneCount} (Playback Hand, {HandSideUtility.GetBonePrefix(handSide)}*)");
            summary.AppendLine("captureSource=PlaybackHand · capturedWhileGrabbed=false");

            if (result.warnings.Count > 0)
            {
                summary.AppendLine("경고:");
                foreach (var warning in result.warnings)
                    summary.AppendLine("• " + warning);
            }

            if (!result.pendingApplyRegistered && !string.IsNullOrWhiteSpace(result.pendingApplyMessage))
            {
                summary.AppendLine("Pending Apply:");
                summary.AppendLine("• " + result.pendingApplyMessage);
            }

            result.message = summary.ToString().TrimEnd();
            return result;
        }

        // ── Hand Tracking 기반 캡처 (Step 2 메인) ──

        /// <summary>
        /// XRHandSkeletonDriver가 구동하는 Tracking Hand의 캡처 가능 여부를 평가합니다.
        /// Controller Grip/Animator 의존 없이 XRHandSubsystem 추적 상태만 확인합니다.
        /// </summary>
        public static Readiness EvaluateTrackingReadiness(
            HandSide handSide,
            Transform trackingHandRoot,
            GameObject targetObject)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var readiness = new Readiness
            {
                handSide = handSide,
                expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                blockers = new List<string>(),
                warnings = new List<string>(),
            };

            readiness.isPlaying = EditorApplication.isPlaying;
            if (!readiness.isPlaying)
                readiness.blockers.Add("Play Mode가 아닙니다.");

            // XRHandSubsystem 실행 여부 및 추적 상태
            if (HandPoseCaptureService.TryGetRunningSubsystem(out var subsystem, out var subsystemError))
            {
                readiness.subsystemRunning = true;
                var trackedHand = handSide == HandSide.Left ? subsystem.leftHand : subsystem.rightHand;
                readiness.handTracked = trackedHand.isTracked;
                if (!readiness.handTracked)
                    readiness.blockers.Add($"{sideLabel} Hand가 추적 중이지 않습니다. 손을 카메라 앞에 올려놓으세요.");
            }
            else
            {
                readiness.subsystemRunning = false;
                readiness.blockers.Add($"XR Hand Subsystem이 실행 중이지 않습니다: {subsystemError}");
            }

            if (trackingHandRoot == null)
            {
                readiness.blockers.Add("Tracking Hand Root가 지정되지 않았습니다. '자동 탐색' 버튼을 눌러주세요.");
            }
            else
            {
                readiness.playbackHandRoot = trackingHandRoot;
                readiness.playbackHandPath = HandPoseCaptureService.GetHierarchyPath(trackingHandRoot);

                // Controller 손 차단: ControllerHandGripAnimator가 있으면 Tracking 손이 아님
                var controllerAnimator = trackingHandRoot.GetComponent<ControllerHandGripAnimator>();
                if (controllerAnimator != null)
                {
                    readiness.blockers.Add(
                        "지정된 Root에 ControllerHandGripAnimator가 있습니다. " +
                        "Controller 손이 아닌 Tracking 손(XRHandSkeletonDriver 포함)을 지정하세요.");
                }

                // XRHandSkeletonDriver 확인
                var skDriver = trackingHandRoot.GetComponent<XRHandSkeletonDriver>();
                readiness.skeletonDriverPresent = skDriver != null && skDriver.enabled;
                if (!readiness.skeletonDriverPresent)
                {
                    readiness.blockers.Add(
                        "XRHandSkeletonDriver가 없거나 비활성화되어 있습니다. " +
                        "HandVisualizer가 생성한 Tracking Hand Root를 지정하세요.");
                }
                else
                {
                    // 본 유효성 검사
                    var skeletonValidation = HandSkeletonCatalog.Validate(trackingHandRoot, handSide);
                    if (!skeletonValidation.isValid)
                    {
                        readiness.blockers.Add($"Tracking Hand skeleton 검증 실패: {skeletonValidation.summary}");
                    }
                    else
                    {
                        readiness.boneCount = skeletonValidation.foundBoneCount;
                        if (readiness.boneCount != readiness.expectedBoneCount)
                            readiness.warnings.Add(
                                $"연결된 본 {readiness.boneCount}개 (기대 {readiness.expectedBoneCount})");
                    }
                }
            }

            if (targetObject == null)
            {
                readiness.blockers.Add("Target Grab Object가 지정되지 않았습니다.");
            }
            else
            {
                readiness.targetName = targetObject.name;
                readiness.targetGrab = targetObject.GetComponent<XRGrabInteractable>();
                if (readiness.targetGrab == null)
                    readiness.blockers.Add("Target Object에 XRGrabInteractable이 없습니다.");
            }

            readiness.canCapture = readiness.blockers.Count == 0;
            return readiness;
        }

        /// <summary>
        /// XRHandSkeletonDriver가 구동하는 Tracking Hand의 현재 본 Pose를 캡처해 Record로 저장합니다.
        /// 실제 손 움직임 → XRHandSubsystem → XRHandSkeletonDriver → 본 Transform → Record.
        /// </summary>
        public static CaptureResult CaptureAndSaveFromTrackingHand(
            HandSide handSide,
            Transform trackingHandRoot,
            GameObject targetObject)
        {
            var result = new CaptureResult
            {
                errors = new List<string>(),
                warnings = new List<string>(),
            };

            var readiness = EvaluateTrackingReadiness(handSide, trackingHandRoot, targetObject);
            result.warnings.AddRange(readiness.warnings);

            if (!readiness.canCapture)
            {
                result.errors.AddRange(readiness.blockers);
                result.message = "캡처 조건을 충족하지 못했습니다.";
                return result;
            }

            var targetTransform = readiness.targetGrab.transform;
            var handRoot = readiness.playbackHandRoot;

            if (!TryCapturePlaybackBones(handRoot, handSide, out var bones, out var boneError, out var boneWarnings))
            {
                result.errors.Add(boneError);
                result.message = boneError;
                return result;
            }

            result.warnings.AddRange(boneWarnings);
            result.boneCount = bones.Count;

            var handRelative = HandPoseTargetSpace.ComputeRelativePose(handRoot, targetTransform);

            // Tracking Hand Root(Wrist)를 Attach 기준으로 사용합니다.
            // XRGrabInteractable.attachTransform이나 Target Transform fallback을 사용하지 않습니다.
            // Controller Grab 시 손 전체 정렬은 이 Wrist 기준 Attach가 담당합니다.
            var wristAttachLocalPosition = targetTransform.InverseTransformPoint(handRoot.position);
            var wristAttachLocalRotation = Quaternion.Inverse(targetTransform.rotation) * handRoot.rotation;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var poseName = $"{targetObject.name}_{sideLabel}_HandTrackingPose";

            var record = ScriptableObject.CreateInstance<HandGrabPoseRecord>();
            record.Initialize(new HandGrabPoseRecord.CaptureData
            {
                poseName = poseName,
                handSide = handSide,
                captureSource = CaptureSourceTrackingHand,
                capturedAtUtc = DateTime.UtcNow.ToString("o"),
                sourceHandRootName = handRoot.name,
                targetObjectName = targetObject.name,
                capturedWhileGrabbed = false,
                handRootLocalPosition = handRelative.relativePosition,
                handRootLocalRotation = handRelative.relativeRotation,
                attachLocalPosition = wristAttachLocalPosition,
                attachLocalRotation = wristAttachLocalRotation,
                interactorAttachLocalPosition = wristAttachLocalPosition,
                interactorAttachLocalRotation = wristAttachLocalRotation,
                interactorToHandRootLocalPosition = Vector3.zero,
                interactorToHandRootLocalRotation = Quaternion.identity,
                bones = bones,
            });

            if (!record.HasBoneData)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("Record bone 데이터가 비어 있습니다.");
                result.message = result.errors[0];
                return result;
            }

            if (!record.AreSpatialRotationsValid)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("공간 회전 Quaternion이 유효하지 않습니다.");
                result.message = result.errors[0];
                return result;
            }

            var fileName = HandGrabPoseRecordFactory.BuildDefaultFileName(targetObject.name, handSide);
            var saveResult = HandGrabPoseRecordFactory.SaveRecord(
                record,
                fileName,
                new HandGrabPoseRecordFactory.SaveOptions
                {
                    pendingApplyTarget = targetObject,
                    pendingApplyHandSide = handSide,
                    registerPendingApply = EditorApplication.isPlaying,
                });
            result.saveResult = saveResult;
            result.pendingApplyRegistered = saveResult.pendingApplyRegistered;
            result.pendingApplyMessage = saveResult.pendingApplyMessage;

            if (!saveResult.success)
            {
                result.errors.Add(saveResult.message);
                result.message = saveResult.message;
                return result;
            }

            result.success = true;
            var summary = new StringBuilder();
            summary.AppendLine(saveResult.message);
            summary.AppendLine(
                $"연결된 본 {result.boneCount}개 (Tracking Hand, {HandSideUtility.GetBonePrefix(handSide)}*)");
            summary.AppendLine("captureSource=TrackingHand · capturedWhileGrabbed=false");

            if (result.warnings.Count > 0)
            {
                summary.AppendLine("경고:");
                foreach (var warning in result.warnings)
                    summary.AppendLine("• " + warning);
            }

            if (!result.pendingApplyRegistered && !string.IsNullOrWhiteSpace(result.pendingApplyMessage))
            {
                summary.AppendLine("Pending Apply:");
                summary.AppendLine("• " + result.pendingApplyMessage);
            }

            result.message = summary.ToString().TrimEnd();
            return result;
        }

        // ── 아래는 Interactor 기반 오버로드 (Step 4 등에서 재사용) ──

        public static Readiness EvaluateReadiness(
            HandSide handSide,
            Transform playbackHandRoot,
            GameObject targetObject,
            XRBaseInteractor interactor)
        {
            var sideLabel = HandSideUtility.GetLabel(handSide);
            var readiness = new Readiness
            {
                handSide = handSide,
                expectedBoneCount = HandSkeletonCatalog.RequiredBoneCount,
                blockers = new List<string>(),
                warnings = new List<string>(),
            };

            readiness.isPlaying = EditorApplication.isPlaying;
            if (!readiness.isPlaying)
                readiness.blockers.Add("Play Mode가 아닙니다.");

            if (playbackHandRoot == null)
            {
                readiness.blockers.Add("Playback Hand Root가 지정되지 않았습니다.");
            }
            else
            {
                readiness.playbackHandRoot = playbackHandRoot;
                readiness.playbackHandPath = HandPoseCaptureService.GetHierarchyPath(playbackHandRoot);

                if (!HandSideUtility.MatchesHandSide(playbackHandRoot, handSide))
                {
                    readiness.blockers.Add(
                        $"Playback Hand Root가 {sideLabel} 손과 일치하지 않습니다.");
                }

                var skeletonValidation = HandSkeletonCatalog.Validate(playbackHandRoot, handSide);
                if (!skeletonValidation.isValid)
                {
                    readiness.blockers.Add($"Playback Hand skeleton 검증 실패: {skeletonValidation.summary}");
                }
                else
                {
                    readiness.boneCount = skeletonValidation.foundBoneCount;
                    if (readiness.boneCount != readiness.expectedBoneCount)
                    {
                        readiness.warnings.Add(
                            $"Bone 수 {readiness.boneCount} / 기대 {readiness.expectedBoneCount}");
                    }
                }
            }

            if (targetObject == null)
            {
                readiness.blockers.Add("Target Object가 지정되지 않았습니다.");
            }
            else
            {
                readiness.targetName = targetObject.name;
                readiness.targetGrab = targetObject.GetComponent<XRGrabInteractable>();
                if (readiness.targetGrab == null)
                    readiness.blockers.Add("Target Object에 XRGrabInteractable이 없습니다.");
            }

            if (interactor == null)
            {
                readiness.blockers.Add($"{sideLabel} Interactor가 지정되지 않았습니다.");
            }
            else
            {
                readiness.interactor = interactor;
                readiness.interactorPath = HandPoseCaptureService.GetHierarchyPath(interactor.transform);

                if (HandSideUtility.TryResolveInteractorHandSide(interactor.transform, out var interactorSide)
                    && interactorSide != handSide)
                {
                    readiness.blockers.Add(
                        $"{HandSideUtility.GetLabel(interactorSide)} Interactor가 선택 Hand Side({sideLabel})와 일치하지 않습니다.");
                }
            }

            if (readiness.targetGrab != null && readiness.interactor != null)
            {
                readiness.isTargetGrabbed = readiness.interactor.IsSelecting(readiness.targetGrab);
                if (!readiness.isTargetGrabbed)
                {
                    readiness.blockers.Add(
                        "현재 선택 손 Interactor가 Target을 잡고 있지 않습니다. Grip으로 Target을 잡은 뒤 캡처하세요.");
                }
            }

            readiness.canCapture = readiness.blockers.Count == 0;
            return readiness;
        }

        public static CaptureResult CaptureAndSave(
            HandSide handSide,
            Transform playbackHandRoot,
            GameObject targetObject,
            XRBaseInteractor interactor)
        {
            var result = new CaptureResult
            {
                errors = new List<string>(),
                warnings = new List<string>(),
            };

            var readiness = EvaluateReadiness(handSide, playbackHandRoot, targetObject, interactor);
            result.warnings.AddRange(readiness.warnings);

            if (!readiness.canCapture)
            {
                result.errors.AddRange(readiness.blockers);
                result.message = "캡처 조건을 충족하지 못했습니다.";
                return result;
            }

            var targetTransform = readiness.targetGrab.transform;
            var handRoot = readiness.playbackHandRoot;
            var interactorAttach = readiness.interactor.GetAttachTransform(readiness.targetGrab);
            if (interactorAttach == null)
            {
                result.errors.Add("Interactor Attach Transform을 찾지 못했습니다.");
                result.message = result.errors[0];
                return result;
            }

            if (!TryCapturePlaybackBones(handRoot, handSide, out var bones, out var boneError, out var boneWarnings))
            {
                result.errors.Add(boneError);
                result.message = boneError;
                return result;
            }

            result.warnings.AddRange(boneWarnings);
            result.boneCount = bones.Count;

            var handRelative = HandPoseTargetSpace.ComputeRelativePose(handRoot, targetTransform);
            var interactorRelative = HandPoseTargetSpace.ComputeRelativePose(interactorAttach, targetTransform);

            var interactorToHandPosition = interactorAttach.InverseTransformPoint(handRoot.position);
            var interactorToHandRotation = Quaternion.Inverse(interactorAttach.rotation) * handRoot.rotation;

            var sideLabel = HandSideUtility.GetHandSideLabelForMarker(handSide);
            var poseName = $"{targetObject.name}_{sideLabel}_GrabPose";

            var record = ScriptableObject.CreateInstance<HandGrabPoseRecord>();
            record.Initialize(new HandGrabPoseRecord.CaptureData
            {
                poseName = poseName,
                handSide = handSide,
                captureSource = CaptureSourcePlaybackHand,
                capturedAtUtc = DateTime.UtcNow.ToString("o"),
                sourceHandRootName = handRoot.name,
                targetObjectName = targetObject.name,
                capturedWhileGrabbed = true,
                handRootLocalPosition = handRelative.relativePosition,
                handRootLocalRotation = handRelative.relativeRotation,
                attachLocalPosition = interactorRelative.relativePosition,
                attachLocalRotation = interactorRelative.relativeRotation,
                interactorAttachLocalPosition = interactorRelative.relativePosition,
                interactorAttachLocalRotation = interactorRelative.relativeRotation,
                interactorToHandRootLocalPosition = interactorToHandPosition,
                interactorToHandRootLocalRotation = interactorToHandRotation,
                bones = bones,
            });

            if (!record.HasBoneData)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("Record bone 데이터가 비어 있습니다.");
                result.message = result.errors[0];
                return result;
            }

            if (!record.AreSpatialRotationsValid)
            {
                UnityEngine.Object.DestroyImmediate(record);
                result.errors.Add("공간 회전 Quaternion이 유효하지 않습니다.");
                result.message = result.errors[0];
                return result;
            }

            var fileName = HandGrabPoseRecordFactory.BuildDefaultFileName(targetObject.name, handSide);
            var saveResult = HandGrabPoseRecordFactory.SaveRecord(
                record,
                fileName,
                new HandGrabPoseRecordFactory.SaveOptions
                {
                    pendingApplyTarget = targetObject,
                    pendingApplyHandSide = handSide,
                    registerPendingApply = EditorApplication.isPlaying,
                });
            result.saveResult = saveResult;
            result.pendingApplyRegistered = saveResult.pendingApplyRegistered;
            result.pendingApplyMessage = saveResult.pendingApplyMessage;

            if (!saveResult.success)
            {
                result.errors.Add(saveResult.message);
                result.message = saveResult.message;
                return result;
            }

            result.success = true;
            var summary = new StringBuilder();
            summary.AppendLine(saveResult.message);
            summary.AppendLine($"Bone {result.boneCount} (Playback Hand, {HandSideUtility.GetBonePrefix(handSide)}*)");
            summary.AppendLine($"Target-relative Hand Root: pos={handRelative.relativePosition}, rot={handRelative.relativeRotation.eulerAngles}");
            summary.AppendLine($"Target-relative Attach: pos={interactorRelative.relativePosition}, rot={interactorRelative.relativeRotation.eulerAngles}");
            summary.AppendLine("captureSource=PlaybackHand · capturedWhileGrabbed=true");

            if (result.warnings.Count > 0)
            {
                summary.AppendLine("경고:");
                foreach (var warning in result.warnings)
                    summary.AppendLine("• " + warning);
            }

            if (!result.pendingApplyRegistered && !string.IsNullOrWhiteSpace(result.pendingApplyMessage))
            {
                summary.AppendLine("Pending Apply:");
                summary.AppendLine("• " + result.pendingApplyMessage);
            }

            result.message = summary.ToString().TrimEnd();
            return result;
        }

        static bool TryCapturePlaybackBones(
            Transform handRoot,
            HandSide handSide,
            out List<HandBonePoseData> bones,
            out string errorMessage,
            out List<string> warnings)
        {
            bones = new List<HandBonePoseData>();
            errorMessage = null;
            warnings = new List<string>();

            if (!HandSkeletonCatalog.TryBuildBoneMap(handRoot, handSide, out var boneMap, out var mapError))
            {
                errorMessage = mapError;
                return false;
            }

            foreach (var transform in handRoot.GetComponentsInChildren<Transform>(true))
            {
                if (transform == handRoot)
                    continue;

                if (HandSideUtility.ContainsOppositeHandBonePrefix(transform.name, handSide))
                {
                    errorMessage = $"반대 손 bone '{transform.name}'이 Playback Hand Root 아래에 있습니다.";
                    bones.Clear();
                    return false;
                }
            }

            foreach (var (boneName, expectedParentBoneName) in HandSkeletonCatalog.GetRequiredHierarchy(handSide))
            {
                if (!boneMap.TryGetValue(boneName, out var boneTransform) || boneTransform == null)
                {
                    errorMessage = $"필수 본 Transform을 찾을 수 없습니다: {boneName}";
                    bones.Clear();
                    return false;
                }

                string parentBoneName;
                if (expectedParentBoneName == null)
                    parentBoneName = handRoot.name;
                else if (!boneMap.TryGetValue(expectedParentBoneName, out _))
                {
                    var parent = boneTransform.parent;
                    parentBoneName = parent != null ? parent.name : handRoot.name;
                }
                else
                    parentBoneName = expectedParentBoneName;

                bones.Add(new HandBonePoseData
                {
                    boneName = boneName,
                    parentBoneName = parentBoneName,
                    localPosition = boneTransform.localPosition,
                    localRotation = boneTransform.localRotation,
                    localScale = boneTransform.localScale,
                });
            }

            if (bones.Count == 0)
            {
                errorMessage = "Bone 데이터가 0개입니다.";
                return false;
            }

            if (bones.Count != HandSkeletonCatalog.RequiredBoneCount)
            {
                warnings.Add(
                    $"Bone {bones.Count}개 저장 (기대 {HandSkeletonCatalog.RequiredBoneCount}).");
            }

            return true;
        }
    }
}
