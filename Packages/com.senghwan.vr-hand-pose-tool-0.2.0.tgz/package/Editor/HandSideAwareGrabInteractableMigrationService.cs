using System;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using VRHandPoseTool;

namespace VRHandPoseTool.Editor
{
    /// <summary>
    /// XRGrabInteractable을 HandSideAwareGrabInteractable로 안전하게 전환합니다.
    /// </summary>
    public static class HandSideAwareGrabInteractableMigrationService
    {
        /// <summary>
        /// XRI 3.4.1 XRBaseInteractable + XRGrabInteractable serialized field names.
        /// HandSideAwareGrabInteractable 전용 필드는 제외합니다.
        /// </summary>
        static readonly string[] s_GrabPropertyPaths =
        {
            // XRBaseInteractable
            "m_InteractionManager",
            "m_Colliders",
            "m_InteractionLayers",
            "m_DistanceCalculationMode",
            "m_SelectMode",
            "m_FocusMode",
            "m_StartingHoverFilters",
            "m_StartingSelectFilters",
            "m_StartingInteractionStrengthFilters",
            "m_CustomReticle",
            "m_AutoFindParentInteractableInHierarchy",
            "m_ParentInteractableObject",
            "m_AllowGazeInteraction",
            "m_AllowGazeSelect",
            "m_OverrideGazeTimeToSelect",
            "m_GazeTimeToSelect",
            "m_AllowGazeAssistance",
            "m_OverrideTimeToAutoDeselectGaze",
            "m_TimeToAutoDeselectGaze",
            "m_FirstHoverEntered",
            "m_LastHoverExited",
            "m_HoverEntered",
            "m_HoverExited",
            "m_FirstSelectEntered",
            "m_LastSelectExited",
            "m_SelectEntered",
            "m_SelectExited",
            "m_FirstFocusEntered",
            "m_LastFocusExited",
            "m_FocusEntered",
            "m_FocusExited",
            "m_Activated",
            "m_Deactivated",
            // XRGrabInteractable
            "m_AttachTransform",
            "m_SecondaryAttachTransform",
            "m_UseDynamicAttach",
            "m_MatchAttachPosition",
            "m_MatchAttachRotation",
            "m_SnapToColliderVolume",
            "m_ReinitializeDynamicAttachEverySingleGrab",
            "m_AttachEaseInTime",
            "m_MovementType",
            "m_VelocityDamping",
            "m_VelocityScale",
            "m_AngularVelocityDamping",
            "m_AngularVelocityScale",
            "m_TrackPosition",
            "m_SmoothPosition",
            "m_SmoothPositionAmount",
            "m_TightenPosition",
            "m_TrackRotation",
            "m_SmoothRotation",
            "m_SmoothRotationAmount",
            "m_TightenRotation",
            "m_TrackScale",
            "m_SmoothScale",
            "m_SmoothScaleAmount",
            "m_TightenScale",
            "m_FarAttachMode",
            "m_ThrowOnDetach",
            "m_ThrowSmoothingDuration",
            "m_ThrowSmoothingCurve",
            "m_ThrowVelocityScale",
            "m_ThrowAngularVelocityScale",
            "m_ForceGravityOnDetach",
            "m_RetainTransformParent",
            "m_AddDefaultGrabTransformers",
            "m_StartingMultipleGrabTransformers",
            "m_StartingSingleGrabTransformers",
            "m_PredictedVisualsTransform",
            "m_LimitLinearVelocity",
            "m_LimitAngularVelocity",
            "m_MaxLinearVelocityDelta",
            "m_MaxAngularVelocityDelta",
        };

        public struct Readiness
        {
            public bool canMigrate;
            public GameObject targetObject;
            public XRGrabInteractable existingGrab;
            public HandSideAwareGrabInteractable existingHandSideAware;
            public HandGrabPoseBinding binding;
            public bool hasLeftSlot;
            public bool hasRightSlot;
            public bool useDynamicAttach;
            public string grabTypeName;
            public List<string> blockers;
            public List<string> warnings;
        }

        public struct MigrationResult
        {
            public bool success;
            public string message;
            public HandSideAwareGrabInteractable migratedComponent;
        }

        struct PropertyCopyReport
        {
            public List<string> copied;
            public List<string> skippedMissingOnDestination;
            public List<string> skippedTypeMismatch;
            public List<string> skippedNullArrayElements;
            public List<string> warnings;
        }

        /// <summary>
        /// XRGrabInteractable 직렬화 값의 in-memory 백업.
        /// </summary>
        sealed class GrabInteractableSettingsBackup
        {
            public KeyGrabSettingsSnapshot keySettings;
            public List<PropertySnapshot> properties = new();

            public static GrabInteractableSettingsBackup Capture(XRGrabInteractable source)
            {
                var backup = new GrabInteractableSettingsBackup
                {
                    keySettings = KeyGrabSettingsSnapshot.From(source),
                };

                var sourceObject = new SerializedObject(source);
                foreach (var propertyPath in s_GrabPropertyPaths)
                {
                    var sourceProperty = sourceObject.FindProperty(propertyPath);
                    if (sourceProperty == null)
                        continue;

                    backup.properties.Add(PropertySnapshot.Capture(sourceProperty));
                }

                return backup;
            }

            public PropertyCopyReport ApplyTo(Component destination)
            {
                var report = new PropertyCopyReport
                {
                    copied = new List<string>(),
                    skippedMissingOnDestination = new List<string>(),
                    skippedTypeMismatch = new List<string>(),
                    skippedNullArrayElements = new List<string>(),
                    warnings = new List<string>(),
                };

                var destinationObject = new SerializedObject(destination);
                foreach (var snapshot in properties)
                {
                    var destinationProperty = destinationObject.FindProperty(snapshot.propertyPath);
                    if (destinationProperty == null)
                    {
                        report.skippedMissingOnDestination.Add(snapshot.propertyPath);
                        continue;
                    }

                    if (!snapshot.TryApply(destinationProperty, report))
                    {
                        report.skippedTypeMismatch.Add(snapshot.propertyPath);
                        continue;
                    }

                    report.copied.Add(snapshot.propertyPath);
                }

                destinationObject.ApplyModifiedPropertiesWithoutUndo();
                return report;
            }

            public bool VerifyAgainst(XRGrabInteractable grab, out string errorMessage) =>
                keySettings.Matches(grab, out errorMessage);
        }

        struct KeyGrabSettingsSnapshot
        {
            public bool useDynamicAttach;
            public XRGrabInteractable.MovementType movementType;
            public bool trackPosition;
            public bool trackRotation;
            public bool smoothPosition;
            public bool smoothRotation;
            public bool throwOnDetach;
            public bool forceGravityOnDetach;
            public bool retainTransformParent;
            public Transform attachTransform;
            public Transform secondaryAttachTransform;
            public int interactionLayers;
            public Collider[] colliders;

            public static KeyGrabSettingsSnapshot From(XRGrabInteractable grab)
            {
                var colliders = new Collider[grab.colliders.Count];
                for (var i = 0; i < grab.colliders.Count; i++)
                    colliders[i] = grab.colliders[i];

                return new KeyGrabSettingsSnapshot
                {
                    useDynamicAttach = grab.useDynamicAttach,
                    movementType = grab.movementType,
                    trackPosition = grab.trackPosition,
                    trackRotation = grab.trackRotation,
                    smoothPosition = grab.smoothPosition,
                    smoothRotation = grab.smoothRotation,
                    throwOnDetach = grab.throwOnDetach,
                    forceGravityOnDetach = grab.forceGravityOnDetach,
                    retainTransformParent = grab.retainTransformParent,
                    attachTransform = grab.attachTransform,
                    secondaryAttachTransform = grab.secondaryAttachTransform,
                    interactionLayers = grab.interactionLayers.value,
                    colliders = colliders,
                };
            }

            public bool Matches(XRGrabInteractable grab, out string errorMessage)
            {
                errorMessage = null;

                if (useDynamicAttach != grab.useDynamicAttach)
                {
                    errorMessage = "useDynamicAttach";
                    return false;
                }

                if (movementType != grab.movementType)
                {
                    errorMessage = "movementType";
                    return false;
                }

                if (trackPosition != grab.trackPosition)
                {
                    errorMessage = "trackPosition";
                    return false;
                }

                if (trackRotation != grab.trackRotation)
                {
                    errorMessage = "trackRotation";
                    return false;
                }

                if (smoothPosition != grab.smoothPosition)
                {
                    errorMessage = "smoothPosition";
                    return false;
                }

                if (smoothRotation != grab.smoothRotation)
                {
                    errorMessage = "smoothRotation";
                    return false;
                }

                if (throwOnDetach != grab.throwOnDetach)
                {
                    errorMessage = "throwOnDetach";
                    return false;
                }

                if (forceGravityOnDetach != grab.forceGravityOnDetach)
                {
                    errorMessage = "forceGravityOnDetach";
                    return false;
                }

                if (retainTransformParent != grab.retainTransformParent)
                {
                    errorMessage = "retainTransformParent";
                    return false;
                }

                if (attachTransform != grab.attachTransform)
                {
                    errorMessage = "attachTransform";
                    return false;
                }

                if (secondaryAttachTransform != grab.secondaryAttachTransform)
                {
                    errorMessage = "secondaryAttachTransform";
                    return false;
                }

                if (interactionLayers != grab.interactionLayers.value)
                {
                    errorMessage = "interactionLayers";
                    return false;
                }

                if (colliders.Length != grab.colliders.Count)
                {
                    errorMessage = "colliders.Count";
                    return false;
                }

                for (var i = 0; i < colliders.Length; i++)
                {
                    if (colliders[i] != grab.colliders[i])
                    {
                        errorMessage = $"colliders[{i}]";
                        return false;
                    }
                }

                return true;
            }
        }

        sealed class PropertySnapshot
        {
            public string propertyPath;
            public SerializedPropertyType propertyType;
            public bool isArray;
            public int intValue;
            public bool boolValue;
            public float floatValue;
            public string stringValue;
            public Color colorValue;
            public UnityEngine.Object objectReferenceValue;
            public Vector2 vector2Value;
            public Vector3 vector3Value;
            public Vector4 vector4Value;
            public Rect rectValue;
            public List<PropertySnapshot> arrayElements;
            public List<PropertySnapshot> children;

            public static PropertySnapshot Capture(SerializedProperty source)
            {
                var snapshot = new PropertySnapshot
                {
                    propertyPath = source.propertyPath,
                    propertyType = source.propertyType,
                    isArray = source.isArray && source.propertyType == SerializedPropertyType.Generic,
                };

                switch (source.propertyType)
                {
                    case SerializedPropertyType.Integer:
                    case SerializedPropertyType.LayerMask:
                        snapshot.intValue = source.intValue;
                        break;
                    case SerializedPropertyType.Boolean:
                        snapshot.boolValue = source.boolValue;
                        break;
                    case SerializedPropertyType.Float:
                        snapshot.floatValue = source.floatValue;
                        break;
                    case SerializedPropertyType.String:
                        snapshot.stringValue = source.stringValue;
                        break;
                    case SerializedPropertyType.Color:
                        snapshot.colorValue = source.colorValue;
                        break;
                    case SerializedPropertyType.ObjectReference:
                        snapshot.objectReferenceValue = source.objectReferenceValue;
                        break;
                    case SerializedPropertyType.Enum:
                        snapshot.intValue = source.enumValueIndex;
                        break;
                    case SerializedPropertyType.Vector2:
                        snapshot.vector2Value = source.vector2Value;
                        break;
                    case SerializedPropertyType.Vector3:
                        snapshot.vector3Value = source.vector3Value;
                        break;
                    case SerializedPropertyType.Vector4:
                        snapshot.vector4Value = source.vector4Value;
                        break;
                    case SerializedPropertyType.Rect:
                        snapshot.rectValue = source.rectValue;
                        break;
                    case SerializedPropertyType.Generic:
                        if (source.isArray)
                        {
                            snapshot.arrayElements = new List<PropertySnapshot>();
                            for (var i = 0; i < source.arraySize; i++)
                                snapshot.arrayElements.Add(Capture(source.GetArrayElementAtIndex(i)));
                        }
                        else
                        {
                            snapshot.children = CaptureChildren(source);
                        }

                        break;
                }

                return snapshot;
            }

            static List<PropertySnapshot> CaptureChildren(SerializedProperty source)
            {
                var children = new List<PropertySnapshot>();
                var iterator = source.Copy();
                var endProperty = source.GetEndProperty();
                if (!iterator.Next(true))
                    return children;

                do
                {
                    if (SerializedProperty.EqualContents(iterator, endProperty))
                        break;

                    var relativePath = GetRelativePropertyPath(source, iterator);
                    if (string.IsNullOrEmpty(relativePath))
                        continue;

                    var childSnapshot = Capture(iterator);
                    childSnapshot.propertyPath = relativePath;
                    children.Add(childSnapshot);
                }
                while (iterator.Next(false));

                return children;
            }

            public bool TryApply(SerializedProperty destination, PropertyCopyReport report)
            {
                if (destination.propertyType != propertyType)
                    return false;

                switch (propertyType)
                {
                    case SerializedPropertyType.Integer:
                    case SerializedPropertyType.LayerMask:
                        destination.intValue = intValue;
                        return true;
                    case SerializedPropertyType.Boolean:
                        destination.boolValue = boolValue;
                        return true;
                    case SerializedPropertyType.Float:
                        destination.floatValue = floatValue;
                        return true;
                    case SerializedPropertyType.String:
                        destination.stringValue = stringValue;
                        return true;
                    case SerializedPropertyType.Color:
                        destination.colorValue = colorValue;
                        return true;
                    case SerializedPropertyType.ObjectReference:
                        destination.objectReferenceValue = objectReferenceValue;
                        return true;
                    case SerializedPropertyType.Enum:
                        destination.enumValueIndex = intValue;
                        return true;
                    case SerializedPropertyType.Vector2:
                        destination.vector2Value = vector2Value;
                        return true;
                    case SerializedPropertyType.Vector3:
                        destination.vector3Value = vector3Value;
                        return true;
                    case SerializedPropertyType.Vector4:
                        destination.vector4Value = vector4Value;
                        return true;
                    case SerializedPropertyType.Rect:
                        destination.rectValue = rectValue;
                        return true;
                    case SerializedPropertyType.Generic:
                        return TryApplyGeneric(destination, report);
                    default:
                        return false;
                }
            }

            bool TryApplyGeneric(SerializedProperty destination, PropertyCopyReport report)
            {
                if (isArray)
                    return TryApplyArray(destination, report);

                if (children == null)
                    return true;

                foreach (var child in children)
                {
                    var destinationChild = destination.FindPropertyRelative(child.propertyPath);
                    if (destinationChild == null)
                        continue;

                    if (!child.TryApply(destinationChild, report))
                        report.warnings.Add($"{destination.propertyPath}.{child.propertyPath}: apply skipped");
                }

                return true;
            }

            bool TryApplyArray(SerializedProperty destination, PropertyCopyReport report)
            {
                if (arrayElements == null)
                {
                    destination.arraySize = 0;
                    return true;
                }

                if (IsObjectReferenceArray(arrayElements))
                    return TryApplyObjectReferenceArray(destination, report);

                destination.arraySize = arrayElements.Count;
                for (var i = 0; i < arrayElements.Count; i++)
                {
                    if (!arrayElements[i].TryApply(destination.GetArrayElementAtIndex(i), report))
                        report.warnings.Add($"{destination.propertyPath}[{i}]: apply skipped");
                }

                return true;
            }

            static bool IsObjectReferenceArray(List<PropertySnapshot> elements)
            {
                if (elements == null || elements.Count == 0)
                    return false;

                foreach (var element in elements)
                {
                    if (element.propertyType == SerializedPropertyType.ObjectReference)
                        return true;
                }

                return false;
            }

            bool TryApplyObjectReferenceArray(SerializedProperty destination, PropertyCopyReport report)
            {
                var nonNullElements = new List<PropertySnapshot>();
                for (var i = 0; i < arrayElements.Count; i++)
                {
                    var element = arrayElements[i];
                    if (element.propertyType != SerializedPropertyType.ObjectReference)
                    {
                        nonNullElements.Add(element);
                        continue;
                    }

                    if (element.objectReferenceValue == null)
                    {
                        report.skippedNullArrayElements.Add($"{destination.propertyPath}[{i}]");
                        continue;
                    }

                    nonNullElements.Add(element);
                }

                destination.arraySize = nonNullElements.Count;
                for (var i = 0; i < nonNullElements.Count; i++)
                {
                    if (!nonNullElements[i].TryApply(destination.GetArrayElementAtIndex(i), report))
                        report.warnings.Add($"{destination.propertyPath}[{i}]: apply skipped");
                }

                return true;
            }
        }

        public static Readiness EvaluateReadiness(GameObject targetObject)
        {
            var readiness = new Readiness
            {
                targetObject = targetObject,
                blockers = new List<string>(),
                warnings = new List<string>(),
            };

            if (Application.isPlaying)
                readiness.blockers.Add("Play Mode에서는 Grab Interactable을 전환할 수 없습니다.");

            if (PrefabStageUtility.GetCurrentPrefabStage() != null)
                readiness.blockers.Add("Prefab Stage에서는 Grab Interactable을 전환할 수 없습니다.");

            if (targetObject == null)
            {
                readiness.blockers.Add("Target Object가 지정되지 않았습니다.");
                return readiness;
            }

            if (!targetObject.scene.IsValid())
            {
                readiness.blockers.Add("Target Object가 열린 Scene Instance에 없습니다.");
                return readiness;
            }

            if (PrefabUtility.IsPartOfPrefabAsset(targetObject))
                readiness.blockers.Add("Prefab Asset에는 Grab Interactable을 전환할 수 없습니다.");

            var handSideAware = targetObject.GetComponent<HandSideAwareGrabInteractable>();
            var grabComponents = targetObject.GetComponents<XRGrabInteractable>();

            readiness.existingHandSideAware = handSideAware;
            readiness.existingGrab = handSideAware != null ? handSideAware : targetObject.GetComponent<XRGrabInteractable>();
            readiness.grabTypeName = readiness.existingGrab != null
                ? readiness.existingGrab.GetType().Name
                : "(none)";

            if (handSideAware != null)
            {
                readiness.warnings.Add("HandSideAwareGrabInteractable이 이미 적용되어 있습니다.");
                readiness.canMigrate = readiness.blockers.Count == 0;
                PopulateBindingState(targetObject, ref readiness);
                return readiness;
            }

            if (grabComponents.Length == 0)
                readiness.blockers.Add("Target Object에 XRGrabInteractable이 없습니다.");
            else if (grabComponents.Length > 1)
                readiness.blockers.Add("Target Object에 XRGrabInteractable이 2개 이상 있습니다.");

            var bindings = targetObject.GetComponents<HandGrabPoseBinding>();
            if (bindings.Length == 0)
                readiness.blockers.Add("HandGrabPoseBinding이 없습니다.");
            else if (bindings.Length > 1)
                readiness.blockers.Add("HandGrabPoseBinding이 2개 이상 있습니다.");
            else
                readiness.binding = bindings[0];

            PopulateBindingState(targetObject, ref readiness);

            if (!readiness.hasLeftSlot && !readiness.hasRightSlot)
            {
                readiness.blockers.Add(
                    "Left/Right Record와 Attach가 모두 비어 있습니다. " +
                    "최소 한 손의 Record와 Attach가 필요합니다.");
            }

            if (readiness.existingGrab != null && readiness.existingGrab.useDynamicAttach)
            {
                readiness.blockers.Add(
                    "useDynamicAttach=true 입니다. " +
                    "HandSideAwareGrabInteractable은 useDynamicAttach=false 환경에서 손별 Attach를 사용합니다. " +
                    "기존 설정을 확인한 뒤 Dynamic Attach를 끄고 다시 시도하세요.");
            }

            readiness.canMigrate = readiness.blockers.Count == 0 && handSideAware == null;
            return readiness;
        }

        public static MigrationResult TryMigrate(GameObject targetObject)
        {
            var readiness = EvaluateReadiness(targetObject);
            if (readiness.existingHandSideAware != null)
            {
                return new MigrationResult
                {
                    success = true,
                    migratedComponent = readiness.existingHandSideAware,
                    message = "HandSideAwareGrabInteractable이 이미 적용되어 있습니다.",
                };
            }

            if (!readiness.canMigrate)
            {
                return new MigrationResult
                {
                    success = false,
                    message = BuildBlockerMessage(readiness.blockers),
                };
            }

            var sourceGrab = readiness.existingGrab;
            if (sourceGrab == null || sourceGrab is HandSideAwareGrabInteractable)
            {
                return new MigrationResult
                {
                    success = false,
                    message = "XRGrabInteractable을 찾지 못했습니다.",
                };
            }

            GrabInteractableSettingsBackup backup;
            try
            {
                backup = GrabInteractableSettingsBackup.Capture(sourceGrab);
            }
            catch (Exception ex)
            {
                return new MigrationResult
                {
                    success = false,
                    message = $"백업 생성 실패: {ex.Message}",
                };
            }

            if (!TryVerifyPreRemovalBinding(sourceGrab, readiness.binding, out var preBindingError))
            {
                return new MigrationResult
                {
                    success = false,
                    message = $"Binding 사전 검증 실패: {preBindingError}",
                };
            }

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Migrate Hand Side Aware Grab Interactable");
            var undoGroup = Undo.GetCurrentGroup();

            HandSideAwareGrabInteractable migrated = null;
            var sourceRemoved = false;

            try
            {
                Undo.DestroyObjectImmediate(sourceGrab);
                sourceRemoved = true;

                migrated = Undo.AddComponent<HandSideAwareGrabInteractable>(targetObject);
                var copyReport = backup.ApplyTo(migrated);

                if (!backup.VerifyAgainst(migrated, out var verifyField))
                {
                    return RollbackAndFail(
                        targetObject,
                        migrated,
                        backup,
                        readiness.binding,
                        $"전환 검증 실패: {verifyField}\n{BuildCopyReportSummary(copyReport)}");
                }

                if (!TryVerifyPostRemovalState(targetObject, migrated, readiness.binding, out var postError))
                {
                    return RollbackAndFail(
                        targetObject,
                        migrated,
                        backup,
                        readiness.binding,
                        $"전환 후 검증 실패: {postError}\n{BuildCopyReportSummary(copyReport)}");
                }

                EditorUtility.SetDirty(migrated);
                EditorUtility.SetDirty(readiness.binding);
                EditorSceneManager.MarkSceneDirty(targetObject.scene);
                Undo.CollapseUndoOperations(undoGroup);

                return new MigrationResult
                {
                    success = true,
                    migratedComponent = migrated,
                    message =
                        "HandSideAwareGrabInteractable 전환 완료.\n" +
                        "손별 Attach는 HandGrabPoseBinding을 통해 GetAttachTransform에서 사용됩니다.\n" +
                        BuildCopyReportSummary(copyReport) +
                        "\nScene을 저장하세요.",
                };
            }
            catch (Exception ex)
            {
                var failureResult = sourceRemoved
                    ? RollbackAndFail(
                        targetObject,
                        migrated,
                        backup,
                        readiness.binding,
                        $"전환 중 오류: {ex.Message}")
                    : new MigrationResult
                    {
                        success = false,
                        message = $"전환 중 오류: {ex.Message}\n기존 XRGrabInteractable을 유지했습니다.",
                    };

                Debug.LogError($"[HandGrabMigration] {failureResult.message}", targetObject);
                return failureResult;
            }
        }

        static MigrationResult RollbackAndFail(
            GameObject targetObject,
            HandSideAwareGrabInteractable migrated,
            GrabInteractableSettingsBackup backup,
            HandGrabPoseBinding binding,
            string reason)
        {
            var sb = new StringBuilder();
            sb.AppendLine(reason);

            if (migrated != null)
                Undo.DestroyObjectImmediate(migrated);

            XRGrabInteractable restoredGrab = null;
            var existing = targetObject.GetComponent<XRGrabInteractable>();
            if (existing != null && existing is HandSideAwareGrabInteractable)
                Undo.DestroyObjectImmediate(existing);

            if (targetObject.GetComponent<XRGrabInteractable>() == null)
                restoredGrab = Undo.AddComponent<XRGrabInteractable>(targetObject);
            else
                restoredGrab = targetObject.GetComponent<XRGrabInteractable>();

            PropertyCopyReport? restoreReport = null;
            if (restoredGrab != null)
                restoreReport = backup.ApplyTo(restoredGrab);

            ClearBindingGrabCache(binding);

            if (restoredGrab == null)
            {
                sb.AppendLine("XRGrabInteractable 복구 실패: 컴포넌트를 다시 추가하지 못했습니다.");
            }
            else if (!backup.VerifyAgainst(restoredGrab, out var restoreField))
            {
                sb.AppendLine($"XRGrabInteractable 복구 검증 실패: {restoreField}");
                if (restoreReport != null)
                    sb.AppendLine(BuildCopyReportSummary(restoreReport.Value));
            }
            else
            {
                sb.AppendLine("XRGrabInteractable을 원래 설정으로 복구했습니다.");
                if (binding != null && binding.GrabInteractable != restoredGrab)
                    sb.AppendLine("HandGrabPoseBinding Grab 참조를 확인하세요.");
            }

            return new MigrationResult
            {
                success = false,
                message = sb.ToString().TrimEnd(),
            };
        }

        static void PopulateBindingState(GameObject targetObject, ref Readiness readiness)
        {
            if (readiness.binding == null)
                readiness.binding = targetObject.GetComponent<HandGrabPoseBinding>();

            if (readiness.binding == null)
                return;

            readiness.hasLeftSlot = HasCompleteHandSlot(readiness.binding, HandSide.Left);
            readiness.hasRightSlot = HasCompleteHandSlot(readiness.binding, HandSide.Right);
            readiness.useDynamicAttach = readiness.existingGrab != null && readiness.existingGrab.useDynamicAttach;
        }

        static bool HasCompleteHandSlot(HandGrabPoseBinding binding, HandSide handSide) =>
            binding.TryGetRecord(handSide, out _)
            && binding.TryGetAttachTransform(handSide, out var attach)
            && attach != null;

        static bool TryVerifyPreRemovalBinding(
            XRGrabInteractable sourceGrab,
            HandGrabPoseBinding binding,
            out string errorMessage)
        {
            errorMessage = null;

            if (binding == null)
            {
                errorMessage = "HandGrabPoseBinding 참조가 없습니다.";
                return false;
            }

            if (binding.gameObject != sourceGrab.gameObject)
            {
                errorMessage = "HandGrabPoseBinding이 Target Root와 같은 GameObject에 없습니다.";
                return false;
            }

            return true;
        }

        static bool TryVerifyPostRemovalState(
            GameObject targetObject,
            HandSideAwareGrabInteractable migrated,
            HandGrabPoseBinding binding,
            out string errorMessage)
        {
            errorMessage = null;

            var grabComponents = targetObject.GetComponents<XRGrabInteractable>();
            if (grabComponents.Length != 1)
            {
                errorMessage = $"XRGrabInteractable 개수가 1이 아닙니다 ({grabComponents.Length}).";
                return false;
            }

            if (grabComponents[0] != migrated)
            {
                errorMessage = "남아 있는 Grab Interactable이 HandSideAwareGrabInteractable이 아닙니다.";
                return false;
            }

            ClearBindingGrabCache(binding);

            if (binding.GrabInteractable != migrated)
            {
                errorMessage = "HandGrabPoseBinding이 새 Grab Interactable을 참조하지 않습니다.";
                return false;
            }

            if (targetObject.GetComponent<Rigidbody>() == null)
            {
                errorMessage = "Rigidbody가 없습니다.";
                return false;
            }

            return true;
        }

        static void ClearBindingGrabCache(HandGrabPoseBinding binding)
        {
            if (binding == null)
                return;

            var bindingObject = new SerializedObject(binding);
            var cacheProperty = bindingObject.FindProperty("m_CachedGrabInteractable");
            if (cacheProperty == null)
                return;

            cacheProperty.objectReferenceValue = null;
            bindingObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static string GetRelativePropertyPath(SerializedProperty root, SerializedProperty child)
        {
            var rootPath = root.propertyPath;
            var childPath = child.propertyPath;
            if (!childPath.StartsWith(rootPath, StringComparison.Ordinal))
                return null;

            return childPath.Length <= rootPath.Length
                ? string.Empty
                : childPath.Substring(rootPath.Length + 1);
        }

        static string BuildCopyReportSummary(PropertyCopyReport report)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"복사 필드: {report.copied?.Count ?? 0}개");

            if (report.skippedMissingOnDestination?.Count > 0)
            {
                sb.AppendLine(
                    "대상에 없어 건너뜀: " +
                    string.Join(", ", report.skippedMissingOnDestination));
            }

            if (report.skippedTypeMismatch?.Count > 0)
            {
                sb.AppendLine(
                    "타입 불일치로 건너뜀: " +
                    string.Join(", ", report.skippedTypeMismatch));
            }

            if (report.skippedNullArrayElements?.Count > 0)
            {
                sb.AppendLine(
                    "null array element 건너뜀: " +
                    string.Join(", ", report.skippedNullArrayElements));
            }

            if (report.warnings?.Count > 0)
            {
                sb.AppendLine(
                    "경고: " +
                    string.Join(", ", report.warnings));
            }

            return sb.ToString().TrimEnd();
        }

        static string BuildBlockerMessage(List<string> blockers)
        {
            if (blockers == null || blockers.Count == 0)
                return "Grab Interactable을 전환할 수 없습니다.";

            var sb = new StringBuilder();
            foreach (var blocker in blockers)
                sb.AppendLine("• " + blocker);

            return sb.ToString().TrimEnd();
        }
    }
}
