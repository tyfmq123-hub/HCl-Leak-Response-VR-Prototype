using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Unity.XR.CoreUtils;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.SceneManagement;
using VRHandPoseTool;

public static class VRControllerPoseDriverSetup
{
    public const string MenuPath = "Tools/VR 시험 도구/컨트롤러 Pose Driver 자동 설정";

    const string PositionActionName = "Position";
    const string RotationActionName = "Rotation";
    const string TrackingStateActionName = "Tracking State";

    const string PreferredInputActionsPath =
        "Assets/Samples/XR Interaction Toolkit/3.4.1/Starter Assets/XRI Default Input Actions.inputactions";

    const int TrackingTypeRotationAndPosition = 0;
    const int UpdateTypeUpdateAndBeforeRender = 2;

    static readonly string[] ExcludedVisualModelNames =
    {
        "Visuals",
        "Model",
        "Hand",
        "LeftHand",
        "RightHand",
    };

    [MenuItem(MenuPath)]
    static void OpenSetupWindow()
    {
        VRControllerPoseDriverSetupWindow.ShowWindow();
    }

    public static SetupResult TrySetup(HandSide handSide)
    {
        var scene = SceneManager.GetActiveScene();
        if (!scene.IsValid() || !scene.isLoaded)
        {
            return SetupResult.Fail("[VRControllerPoseDriverSetup] 열려 있는 씬이 없습니다.");
        }

        if (!TryFindCameraFloorOffset(scene, out var floorOffset, out var searchError))
            return SetupResult.Fail($"[VRControllerPoseDriverSetup] {searchError}");

        var candidates = CollectControllerCandidates(scene, floorOffset, handSide);
        var sideLabel = GetSideLabel(handSide);

        switch (candidates.Count)
        {
            case 0:
                return SetupResult.Fail(
                    $"[VRControllerPoseDriverSetup] {sideLabel} 컨트롤러 후보를 찾지 못했습니다.\n" +
                    $"씬: {scene.name}\n" +
                    $"탐색 범위: {GetHierarchyPath(floorOffset)} 하위 (활성 씬, XROrigin.CameraFloorOffsetObject)\n" +
                    $"후보 판정: 이름이 {GetControllerRootNamesDescription(handSide)}와 정확히 일치\n" +
                    $"또는 TrackedPoseDriver + 이름에 '{GetHandDirectionToken(handSide)}' 포함\n" +
                    $"제외: {string.Join(", ", ExcludedVisualModelNames)}");

            case > 1:
                var paths = new StringBuilder();
                paths.AppendLine(
                    $"[VRControllerPoseDriverSetup] {sideLabel} 컨트롤러 후보가 2개 이상입니다. 자동 설정을 중단합니다.");
                for (var i = 0; i < candidates.Count; i++)
                    paths.AppendLine($"  [{i + 1}] {GetHierarchyPath(candidates[i])}");

                return SetupResult.Fail(paths.ToString());
        }

        var actionMapName = GetActionMapName(handSide);
        if (!TryFindXriPoseInputActions(actionMapName, out var inputAsset, out var inputAssetPath, out var inputError))
            return SetupResult.Fail($"[VRControllerPoseDriverSetup] {inputError}");

        var target = candidates[0];
        var driver = target.GetComponent<TrackedPoseDriver>();
        if (driver == null)
            driver = Undo.AddComponent<TrackedPoseDriver>(target.gameObject);

        if (IsAlreadyConfigured(driver, inputAsset, actionMapName))
        {
            return SetupResult.AlreadyConfigured(
                "[VRControllerPoseDriverSetup] 이미 설정 완료 — " +
                $"'{GetHierarchyPath(target)}'\n" +
                $"Input Action Asset: {inputAssetPath}\n" +
                $"Actions: {actionMapName}/{PositionActionName}, " +
                $"{actionMapName}/{RotationActionName}, " +
                $"{actionMapName}/{TrackingStateActionName}");
        }

        if (!TryResolveActionReferences(
                inputAsset,
                inputAssetPath,
                actionMapName,
                out var positionReference,
                out var rotationReference,
                out var trackingStateReference,
                out var referenceError))
        {
            return SetupResult.Fail($"[VRControllerPoseDriverSetup] {referenceError}");
        }

        Undo.RecordObject(driver, "Setup Tracked Pose Driver");

        var serializedDriver = new SerializedObject(driver);
        serializedDriver.FindProperty("m_TrackingType").enumValueIndex = TrackingTypeRotationAndPosition;
        serializedDriver.FindProperty("m_UpdateType").enumValueIndex = UpdateTypeUpdateAndBeforeRender;
        serializedDriver.FindProperty("m_IgnoreTrackingState").boolValue = false;

        SetInputActionReference(serializedDriver.FindProperty("m_PositionInput"), positionReference);
        SetInputActionReference(serializedDriver.FindProperty("m_RotationInput"), rotationReference);
        SetInputActionReference(serializedDriver.FindProperty("m_TrackingStateInput"), trackingStateReference);

        serializedDriver.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(driver);
        EditorSceneManager.MarkSceneDirty(scene);

        return SetupResult.Success(
            "[VRControllerPoseDriverSetup] 설정 완료 — " +
            $"'{GetHierarchyPath(target)}'\n" +
            "Tracking Type: Rotation And Position\n" +
            "Update Type: Update And Before Render\n" +
            "Ignore Tracking State: false\n" +
            $"Input Action Asset: {inputAssetPath}\n" +
            $"Position Input: {actionMapName}/{PositionActionName}\n" +
            $"Rotation Input: {actionMapName}/{RotationActionName}\n" +
            $"Tracking State Input: {actionMapName}/{TrackingStateActionName}");
    }

    public readonly struct SetupResult
    {
        public enum Status
        {
            Success,
            AlreadyConfigured,
            Failed,
        }

        public Status ResultStatus { get; }
        public string Message { get; }

        SetupResult(Status status, string message)
        {
            ResultStatus = status;
            Message = message;
        }

        public static SetupResult Success(string message) => new SetupResult(Status.Success, message);
        public static SetupResult AlreadyConfigured(string message) => new SetupResult(Status.AlreadyConfigured, message);
        public static SetupResult Fail(string message) => new SetupResult(Status.Failed, message);
    }

    static bool TryFindCameraFloorOffset(Scene scene, out Transform floorOffset, out string error)
    {
        floorOffset = null;
        error = null;

        var origins = CollectXROriginsInScene(scene);
        if (origins.Count == 0)
        {
            error = $"활성 씬 '{scene.name}'에서 XROrigin 컴포넌트를 찾을 수 없습니다.";
            return false;
        }

        if (origins.Count > 1)
        {
            error =
                $"활성 씬 '{scene.name}'에서 XROrigin 컴포넌트가 {origins.Count}개 발견되었습니다. 자동 선택하지 않습니다.";
            return false;
        }

        var floorOffsetObject = origins[0].CameraFloorOffsetObject;
        if (floorOffsetObject == null)
        {
            error = "XROrigin.CameraFloorOffsetObject가 비어 있습니다.";
            return false;
        }

        if (floorOffsetObject.scene != scene)
        {
            error = "XROrigin.CameraFloorOffsetObject가 활성 씬에 속하지 않습니다.";
            return false;
        }

        floorOffset = floorOffsetObject.transform;
        return true;
    }

    static List<XROrigin> CollectXROriginsInScene(Scene scene)
    {
        var origins = new List<XROrigin>();
        foreach (var root in scene.GetRootGameObjects())
        {
            if (root == null)
                continue;

            origins.AddRange(root.GetComponentsInChildren<XROrigin>(true)
                .Where(origin => origin != null && origin.gameObject.scene == scene));
        }

        return origins;
    }

    static List<Transform> CollectControllerCandidates(Scene scene, Transform floorOffset, HandSide handSide)
    {
        var candidates = new List<Transform>();

        foreach (var transform in floorOffset.GetComponentsInChildren<Transform>(true))
        {
            if (transform == floorOffset)
                continue;

            if (transform.gameObject.scene != scene)
                continue;

            if (IsExcludedVisualModel(transform.name))
                continue;

            if (IsControllerCandidate(transform, handSide))
                candidates.Add(transform);
        }

        return candidates;
    }

    static bool IsExcludedVisualModel(string name)
    {
        foreach (var excludedName in ExcludedVisualModelNames)
        {
            if (string.Equals(name, excludedName, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }

    static bool IsControllerCandidate(Transform transform, HandSide handSide)
    {
        var name = transform.name;

        if (IsControllerRootName(name, handSide))
            return true;

        if (transform.GetComponent<TrackedPoseDriver>() == null)
            return false;

        var directionToken = GetHandDirectionToken(handSide);
        return name.IndexOf(directionToken, StringComparison.OrdinalIgnoreCase) >= 0;
    }

    static bool IsControllerRootName(string name, HandSide handSide)
    {
        foreach (var rootName in GetControllerRootNames(handSide))
        {
            if (string.Equals(name, rootName, StringComparison.OrdinalIgnoreCase))
                return true;
        }

        return false;
    }

    static string[] GetControllerRootNames(HandSide handSide)
    {
        return handSide == HandSide.Left
            ? new[] { "Left Controller", "LeftController" }
            : new[] { "Right Controller", "RightController" };
    }

    static string GetControllerRootNamesDescription(HandSide handSide)
    {
        return string.Join(" 또는 ", GetControllerRootNames(handSide));
    }

    static string GetActionMapName(HandSide handSide)
    {
        return handSide == HandSide.Left ? "XRI Left" : "XRI Right";
    }

    static string GetHandDirectionToken(HandSide handSide)
    {
        return handSide == HandSide.Left ? "Left" : "Right";
    }

    static string GetSideLabel(HandSide handSide)
    {
        return handSide == HandSide.Left ? "왼손" : "오른손";
    }

    static bool TryFindXriPoseInputActions(
        string actionMapName,
        out InputActionAsset inputAsset,
        out string inputAssetPath,
        out string error)
    {
        inputAsset = null;
        inputAssetPath = null;
        error = null;

        var matches = new List<(InputActionAsset asset, string path)>();
        foreach (var guid in AssetDatabase.FindAssets("t:InputActionAsset"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            var candidate = AssetDatabase.LoadAssetAtPath<InputActionAsset>(path);
            if (candidate == null || !HasXriPoseActions(candidate, actionMapName))
                continue;

            matches.Add((candidate, path));
        }

        if (matches.Count == 0)
        {
            error =
                $"프로젝트에서 '{actionMapName}' Action Map과 " +
                "Position/Rotation/Tracking State 액션을 포함한 InputActionAsset을 찾지 못했습니다.";
            return false;
        }

        foreach (var match in matches)
        {
            if (string.Equals(match.path, PreferredInputActionsPath, StringComparison.OrdinalIgnoreCase))
            {
                inputAsset = match.asset;
                inputAssetPath = match.path;
                return true;
            }
        }

        if (matches.Count > 1)
        {
            var paths = new StringBuilder();
            paths.AppendLine(
                $"'{actionMapName}' Pose 액션을 포함한 InputActionAsset이 여러 개입니다. 자동 설정을 중단합니다.");
            foreach (var match in matches)
                paths.AppendLine($"  - {match.path}");

            error = paths.ToString();
            return false;
        }

        inputAsset = matches[0].asset;
        inputAssetPath = matches[0].path;
        return true;
    }

    static bool HasXriPoseActions(InputActionAsset asset, string actionMapName)
    {
        var actionMap = asset.FindActionMap(actionMapName, false);
        if (actionMap == null)
            return false;

        return actionMap.FindAction(PositionActionName, false) != null
            && actionMap.FindAction(RotationActionName, false) != null
            && actionMap.FindAction(TrackingStateActionName, false) != null;
    }

    static bool TryResolveActionReferences(
        InputActionAsset inputAsset,
        string inputAssetPath,
        string actionMapName,
        out InputActionReference positionReference,
        out InputActionReference rotationReference,
        out InputActionReference trackingStateReference,
        out string error)
    {
        positionReference = null;
        rotationReference = null;
        trackingStateReference = null;
        error = null;

        if (!TryFindAction(inputAsset, inputAssetPath, actionMapName, PositionActionName, out var positionAction, out error)
            || !TryFindAction(inputAsset, inputAssetPath, actionMapName, RotationActionName, out var rotationAction, out error)
            || !TryFindAction(
                inputAsset,
                inputAssetPath,
                actionMapName,
                TrackingStateActionName,
                out var trackingStateAction,
                out error))
        {
            return false;
        }

        if (!TryFindOrCreateActionReference(inputAsset, actionMapName, positionAction, out positionReference, out error)
            || !TryFindOrCreateActionReference(inputAsset, actionMapName, rotationAction, out rotationReference, out error)
            || !TryFindOrCreateActionReference(
                inputAsset,
                actionMapName,
                trackingStateAction,
                out trackingStateReference,
                out error))
        {
            return false;
        }

        return true;
    }

    static bool TryFindAction(
        InputActionAsset inputAsset,
        string inputAssetPath,
        string actionMapName,
        string actionName,
        out InputAction action,
        out string error)
    {
        action = null;
        error = null;

        var actionMap = inputAsset.FindActionMap(actionMapName, false);
        if (actionMap == null)
        {
            error =
                $"Action Map '{actionMapName}'을(를) 찾을 수 없습니다.\n" +
                $"Asset: {inputAssetPath}";
            return false;
        }

        action = actionMap.FindAction(actionName, false);
        if (action == null)
        {
            error =
                $"Action '{actionMapName}/{actionName}'을(를) 찾을 수 없습니다.\n" +
                $"Asset: {inputAssetPath}";
            return false;
        }

        return true;
    }

    static bool TryFindOrCreateActionReference(
        InputActionAsset inputAsset,
        string actionMapName,
        InputAction action,
        out InputActionReference reference,
        out string error)
    {
        reference = FindExistingActionReference(inputAsset, action);
        if (reference != null)
        {
            error = null;
            return true;
        }

        reference = InputActionReference.Create(action);
        if (reference == null)
        {
            error =
                $"InputActionReference를 생성하지 못했습니다: {actionMapName}/{action.name}\n" +
                "새 InputActionAsset이나 동명 임시 Action은 생성하지 않습니다.";
            return false;
        }

        error = null;
        return true;
    }

    static InputActionReference FindExistingActionReference(InputActionAsset inputAsset, InputAction action)
    {
        var actionId = action.id.ToString();
        foreach (var guid in AssetDatabase.FindAssets("t:InputActionReference"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            var reference = AssetDatabase.LoadAssetAtPath<InputActionReference>(path);
            if (reference == null || reference.action == null)
                continue;

            if (reference.asset != inputAsset)
                continue;

            if (!string.Equals(reference.action.id.ToString(), actionId, StringComparison.Ordinal))
                continue;

            return reference;
        }

        return null;
    }

    static bool IsAlreadyConfigured(TrackedPoseDriver driver, InputActionAsset inputAsset, string actionMapName)
    {
        if (driver.trackingType != TrackedPoseDriver.TrackingType.RotationAndPosition)
            return false;

        if (driver.updateType != TrackedPoseDriver.UpdateType.UpdateAndBeforeRender)
            return false;

        var serializedDriver = new SerializedObject(driver);
        if (serializedDriver.FindProperty("m_IgnoreTrackingState").boolValue)
            return false;

        return UsesXriActionMap(serializedDriver, "m_PositionInput", inputAsset, actionMapName)
            && UsesXriActionMap(serializedDriver, "m_RotationInput", inputAsset, actionMapName)
            && UsesXriActionMap(serializedDriver, "m_TrackingStateInput", inputAsset, actionMapName);
    }

    static bool UsesXriActionMap(
        SerializedObject serializedDriver,
        string inputPropertyName,
        InputActionAsset inputAsset,
        string actionMapName)
    {
        var inputProperty = serializedDriver.FindProperty(inputPropertyName);
        if (inputProperty == null)
            return false;

        var useReference = inputProperty.FindPropertyRelative("m_UseReference");
        if (useReference != null && !useReference.boolValue)
            return false;

        var reference = inputProperty.FindPropertyRelative("m_Reference").objectReferenceValue as InputActionReference;
        var action = reference != null ? reference.action : null;
        return action != null
            && reference.asset == inputAsset
            && string.Equals(action.actionMap?.name, actionMapName, StringComparison.Ordinal);
    }

    static void SetInputActionReference(SerializedProperty inputActionProperty, InputActionReference reference)
    {
        var useReferenceProperty = inputActionProperty.FindPropertyRelative("m_UseReference");
        var referenceProperty = inputActionProperty.FindPropertyRelative("m_Reference");

        if (useReferenceProperty != null)
            useReferenceProperty.boolValue = true;
        if (referenceProperty != null)
            referenceProperty.objectReferenceValue = reference;
    }

    static string GetHierarchyPath(Transform transform)
    {
        if (transform == null)
            return "(none)";

        var parts = new List<string>();
        var current = transform;
        while (current != null)
        {
            parts.Add(current.name);
            current = current.parent;
        }

        parts.Reverse();
        return string.Join("/", parts);
    }
}

class VRControllerPoseDriverSetupWindow : EditorWindow
{
    HandSide m_HandSide = HandSide.Left;

    public static void ShowWindow()
    {
        var window = GetWindow<VRControllerPoseDriverSetupWindow>("Pose Driver 설정");
        window.minSize = new Vector2(320f, 120f);
        window.Show();
    }

    void OnGUI()
    {
        EditorGUILayout.LabelField("컨트롤러 Pose Driver 자동 설정", EditorStyles.boldLabel);
        EditorGUILayout.Space(4f);

        var scene = SceneManager.GetActiveScene();
        using (new EditorGUILayout.HorizontalScope())
        {
            EditorGUILayout.LabelField("활성 씬", scene.IsValid() ? scene.name : "(없음)");
        }

        EditorGUILayout.Space(4f);
        m_HandSide = (HandSide)EditorGUILayout.EnumPopup("Hand Side", m_HandSide);

        EditorGUILayout.Space(8f);
        if (GUILayout.Button("선택한 손 Pose Driver 설정", GUILayout.Height(28f)))
            RunSetup();
    }

    void RunSetup()
    {
        var result = VRControllerPoseDriverSetup.TrySetup(m_HandSide);
        switch (result.ResultStatus)
        {
            case VRControllerPoseDriverSetup.SetupResult.Status.Success:
            case VRControllerPoseDriverSetup.SetupResult.Status.AlreadyConfigured:
                Debug.Log(result.Message);
                ShowNotification(new GUIContent(
                    result.ResultStatus == VRControllerPoseDriverSetup.SetupResult.Status.AlreadyConfigured
                        ? "이미 설정 완료"
                        : "설정 완료"));
                break;

            default:
                if (result.Message.Contains("2개 이상"))
                    Debug.LogError(result.Message);
                else if (result.Message.Contains("찾지 못했습니다"))
                    Debug.LogWarning(result.Message);
                else
                    Debug.LogError(result.Message);
                break;
        }
    }
}
