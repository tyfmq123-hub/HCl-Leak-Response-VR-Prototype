using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Hands;

/// <summary>
/// Left/Right 손 리그 본 + XR Hand 조인트 포즈를 Play Mode에서 캡처합니다.
/// </summary>
[DisallowMultipleComponent]
public class HandPoseCaptureSource : MonoBehaviour
{
    static readonly List<HandPoseCaptureSource> s_ActiveSources = new();

    [SerializeField]
    Transform m_HandRoot;

    [SerializeField]
    HandCaptureSide m_HandSide = HandCaptureSide.Auto;

    XRHandTrackingEvents m_HandTrackingEvents;
    XRHand m_LastHand;
    bool m_IsTracked;

    public static IReadOnlyList<HandPoseCaptureSource> ActiveSources => s_ActiveSources;

    public Transform HandRoot => m_HandRoot != null ? m_HandRoot : transform;
    public HandCaptureSide HandSide => ResolveHandSide();
    public string HandSideLabel => HandSide == HandCaptureSide.Right ? "Right" : "Left";
    public bool IsTracked => m_IsTracked;
    public int LastCapturedBoneCount { get; private set; }
    public int LastCapturedJointCount { get; private set; }

    void Awake()
    {
        if (m_HandRoot == null)
            m_HandRoot = transform;

        m_HandTrackingEvents = GetComponent<XRHandTrackingEvents>();
    }

    void OnEnable()
    {
        if (!s_ActiveSources.Contains(this))
            s_ActiveSources.Add(this);

        if (m_HandTrackingEvents != null)
            m_HandTrackingEvents.jointsUpdated.AddListener(OnJointsUpdated);
    }

    void OnDisable()
    {
        s_ActiveSources.Remove(this);

        if (m_HandTrackingEvents != null)
            m_HandTrackingEvents.jointsUpdated.RemoveListener(OnJointsUpdated);
    }

    void OnJointsUpdated(XRHandJointsUpdatedEventArgs args)
    {
        m_LastHand = args.hand;
        m_IsTracked = args.hand.isTracked;
    }

    public bool HasHandTrackingEvents => m_HandTrackingEvents != null;

    public HandPoseSnapshot CaptureSnapshot(string poseName)
    {
        var side = ResolveHandSide();
        var snapshot = ScriptableObject.CreateInstance<HandPoseSnapshot>();
        snapshot.poseName = poseName;
        snapshot.handSide = side == HandCaptureSide.Right ? "Right" : "Left";
        snapshot.sourceHandName = HandRoot.name;
        snapshot.capturedTimeUtc = DateTime.UtcNow.ToString("o");

        var root = HandRoot;
        snapshot.rootWorldPosition = root.position;
        snapshot.rootWorldRotation = root.rotation;
        snapshot.rootWorldEulerAngles = root.eulerAngles;

        CollectBoneTransforms(root, root, string.Empty, side, snapshot.bones);
        CollectXRJoints(snapshot.joints);

        LastCapturedBoneCount = snapshot.bones.Count;
        LastCapturedJointCount = snapshot.joints.Count;

        if (LastCapturedBoneCount == 0)
        {
            Debug.LogWarning(
                $"[HandPoseCaptureSource] '{root.name}'에서 {snapshot.handSide} 리그 본(L_/R_ 또는 b_l_/b_r_)을 찾지 못했습니다. " +
                "LeftHand 같은 메시 리그에서 Record하세요.",
                this);
        }
        else if (LastCapturedJointCount == 0)
        {
            Debug.Log(
                $"[HandPoseCaptureSource] {snapshot.handSide} 리그 본 {LastCapturedBoneCount}개 저장. " +
                "(조인트는 참고용으로 비어 있을 수 있습니다.)",
                this);
        }

        return snapshot;
    }

    public static HandPoseCaptureSource FindBySide(HandCaptureSide side)
    {
        if (side == HandCaptureSide.Auto)
            return s_ActiveSources.Count > 0 ? s_ActiveSources[0] : null;

        foreach (var source in s_ActiveSources)
        {
            if (source != null && source.ResolveHandSide() == side)
                return source;
        }

        return null;
    }

    public static HandPoseCaptureSource FindPreferred(HandCaptureSide side, string[] preferredNames)
    {
        if (preferredNames != null)
        {
            foreach (var preferredName in preferredNames)
            {
                if (string.IsNullOrWhiteSpace(preferredName))
                    continue;

                foreach (var source in s_ActiveSources)
                {
                    if (source == null || source.HandRoot.name != preferredName)
                        continue;

                    if (side == HandCaptureSide.Auto || source.ResolveHandSide() == side)
                        return source;
                }
            }
        }

        return FindBySide(side);
    }

    HandCaptureSide ResolveHandSide()
    {
        if (m_HandSide != HandCaptureSide.Auto)
            return m_HandSide;

        if (m_HandTrackingEvents != null)
        {
            return m_HandTrackingEvents.handedness == Handedness.Right
                ? HandCaptureSide.Right
                : HandCaptureSide.Left;
        }

        return DetectSideFromName(HandRoot.name);
    }

    public static HandCaptureSide DetectSideFromName(string objectName)
    {
        if (string.IsNullOrEmpty(objectName))
            return HandCaptureSide.Left;

        if (objectName.Contains("_R", StringComparison.OrdinalIgnoreCase)
            || objectName.Contains("Right", StringComparison.OrdinalIgnoreCase))
            return HandCaptureSide.Right;

        if (objectName.Contains("_L", StringComparison.OrdinalIgnoreCase)
            || objectName.Contains("Left", StringComparison.OrdinalIgnoreCase))
            return HandCaptureSide.Left;

        return HandCaptureSide.Left;
    }

    public static string[] GetPreferredNames(HandCaptureSide side)
    {
        return side switch
        {
            HandCaptureSide.Right => new[] { "RightHand", "OculusHand_R", "Right Hand" },
            _ => new[] { "LeftHand", "OculusHand_L", "Left Hand" }
        };
    }

    void CollectXRJoints(List<HandPoseSnapshot.HandJointRecord> joints)
    {
        if (!m_LastHand.isTracked && !TryRefreshHandFromSubsystem())
            return;

        var endIndex = XRHandJointID.EndMarker.ToIndex();
        for (var i = 0; i < endIndex; i++)
        {
            var jointId = XRHandJointIDUtility.FromIndex(i);
            if (jointId == XRHandJointID.Invalid)
                continue;

            var joint = m_LastHand.GetJoint(jointId);
            if (!joint.TryGetPose(out var pose))
                continue;

            var hasRadius = joint.TryGetRadius(out var radius);
            joints.Add(new HandPoseSnapshot.HandJointRecord
            {
                jointId = jointId.ToString(),
                jointIdIndex = i,
                localPosition = pose.position,
                localRotation = pose.rotation,
                localEulerAngles = pose.rotation.eulerAngles,
                worldPosition = pose.position,
                worldRotation = pose.rotation,
                worldEulerAngles = pose.rotation.eulerAngles,
                radius = hasRadius ? radius : 0f,
                hasRadius = hasRadius
            });
        }
    }

    bool TryRefreshHandFromSubsystem()
    {
        var subsystems = new List<XRHandSubsystem>();
        SubsystemManager.GetSubsystems(subsystems);
        if (subsystems.Count == 0)
            return false;

        var subsystem = subsystems[0];
        var side = ResolveHandSide();
        m_LastHand = side == HandCaptureSide.Right ? subsystem.rightHand : subsystem.leftHand;
        m_IsTracked = m_LastHand.isTracked;
        return m_LastHand.isTracked;
    }

    static void CollectBoneTransforms(
        Transform root,
        Transform current,
        string relativePath,
        HandCaptureSide side,
        List<HandPoseSnapshot.HandBoneRecord> bones)
    {
        if (current != root && HandPoseRigUtility.IsRigBone(current.name, side))
        {
            bones.Add(new HandPoseSnapshot.HandBoneRecord
            {
                path = relativePath,
                boneName = current.name,
                localPosition = current.localPosition,
                localRotation = current.localRotation,
                localEulerAngles = current.localEulerAngles,
                worldPosition = current.position,
                worldRotation = current.rotation,
                worldEulerAngles = current.eulerAngles
            });
        }

        for (var i = 0; i < current.childCount; i++)
        {
            var child = current.GetChild(i);
            var childPath = current == root ? child.name : $"{relativePath}/{child.name}";
            CollectBoneTransforms(root, child, childPath, side, bones);
        }
    }

}
