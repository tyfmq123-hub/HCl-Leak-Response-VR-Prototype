using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 저장된 HandPoseSnapshot을 손 리그에 적용하거나 블렌딩합니다.
/// </summary>
[DisallowMultipleComponent]
public class HandPoseApplier : MonoBehaviour
{
    [SerializeField]
    Transform m_HandRoot;

    [SerializeField]
    HandCaptureSide m_HandSide = HandCaptureSide.Auto;

    [SerializeField]
    HandPoseSnapshot m_OpenPose;

    [SerializeField]
    HandPoseSnapshot m_TargetPose;

    [SerializeField, Range(0f, 1f)]
    float m_BlendWeight;

    readonly Dictionary<string, Transform> m_BoneMap = new();

    public HandPoseSnapshot OpenPose
    {
        get => m_OpenPose;
        set => m_OpenPose = value;
    }

    public HandPoseSnapshot TargetPose
    {
        get => m_TargetPose;
        set => m_TargetPose = value;
    }

    public float BlendWeight
    {
        get => m_BlendWeight;
        set => m_BlendWeight = Mathf.Clamp01(value);
    }

    void Awake()
    {
        if (m_HandRoot == null)
            m_HandRoot = transform;

        RebuildBoneMap();
    }

    public void RebuildBoneMap()
    {
        m_BoneMap.Clear();
        var side = m_HandSide == HandCaptureSide.Auto
            ? HandPoseCaptureSource.DetectSideFromName(m_HandRoot.name)
            : m_HandSide;
        CacheBones(m_HandRoot, m_HandRoot, string.Empty, side);
    }

    void LateUpdate()
    {
        if (m_OpenPose == null || m_TargetPose == null)
            return;

        ApplyBlendedPose(m_OpenPose, m_TargetPose, m_BlendWeight);
    }

    public void ApplyPose(HandPoseSnapshot snapshot, float weight = 1f)
    {
        if (snapshot == null)
            return;

        weight = Mathf.Clamp01(weight);
        foreach (var bone in snapshot.bones)
        {
            if (!m_BoneMap.TryGetValue(bone.path, out var boneTransform) || boneTransform == null)
                continue;

            if (weight >= 1f)
            {
                boneTransform.localPosition = bone.localPosition;
                boneTransform.localRotation = bone.localRotation;
            }
            else
            {
                boneTransform.localPosition = Vector3.Lerp(boneTransform.localPosition, bone.localPosition, weight);
                boneTransform.localRotation = Quaternion.Slerp(boneTransform.localRotation, bone.localRotation, weight);
            }
        }
    }

    public void ApplyBlendedPose(HandPoseSnapshot fromPose, HandPoseSnapshot toPose, float weight)
    {
        weight = Mathf.Clamp01(weight);
        if (weight <= 0f)
        {
            ApplyPose(fromPose, 1f);
            return;
        }

        if (weight >= 1f)
        {
            ApplyPose(toPose, 1f);
            return;
        }

        var fromLookup = BuildLookup(fromPose);
        foreach (var toBone in toPose.bones)
        {
            if (!m_BoneMap.TryGetValue(toBone.path, out var boneTransform) || boneTransform == null)
                continue;

            if (!fromLookup.TryGetValue(toBone.path, out var fromBone))
            {
                boneTransform.localPosition = toBone.localPosition;
                boneTransform.localRotation = toBone.localRotation;
                continue;
            }

            boneTransform.localPosition = Vector3.Lerp(fromBone.localPosition, toBone.localPosition, weight);
            boneTransform.localRotation = Quaternion.Slerp(fromBone.localRotation, toBone.localRotation, weight);
        }
    }

    static Dictionary<string, HandPoseSnapshot.HandBoneRecord> BuildLookup(HandPoseSnapshot snapshot)
    {
        var lookup = new Dictionary<string, HandPoseSnapshot.HandBoneRecord>();
        if (snapshot == null)
            return lookup;

        foreach (var bone in snapshot.bones)
            lookup[bone.path] = bone;

        return lookup;
    }

    void CacheBones(Transform root, Transform current, string relativePath, HandCaptureSide side)
    {
        if (current != root && HandPoseRigUtility.IsRigBone(current.name, side))
            m_BoneMap[relativePath] = current;

        for (var i = 0; i < current.childCount; i++)
        {
            var child = current.GetChild(i);
            var childPath = current == root ? child.name : $"{relativePath}/{child.name}";
            CacheBones(root, child, childPath, side);
        }
    }

}
