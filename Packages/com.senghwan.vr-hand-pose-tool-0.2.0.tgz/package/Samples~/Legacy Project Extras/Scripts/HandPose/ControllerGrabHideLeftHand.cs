using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

/// <summary>
/// Left Controller에 붙입니다. 물체를 잡으면 LeftHand를 비활성화하고, 놓으면 다시 활성화합니다.
/// </summary>
[DisallowMultipleComponent]
public class ControllerGrabHideLeftHand : MonoBehaviour
{
    [SerializeField]
    NearFarInteractor m_Interactor;

    [SerializeField]
    GameObject m_LeftHand;

    void Awake()
    {
        ResolveReferences();
    }

    void OnEnable()
    {
        if (m_Interactor == null)
            ResolveReferences();

        if (m_Interactor != null)
        {
            m_Interactor.selectEntered.AddListener(OnSelectEntered);
            m_Interactor.selectExited.AddListener(OnSelectExited);
        }
        else
        {
            Debug.LogError(
                "[ControllerGrabHideLeftHand] NearFarInteractor를 찾지 못했습니다. " +
                "Left Controller 또는 Inspector에서 연결하세요.",
                this);
        }
    }

    void OnDisable()
    {
        if (m_Interactor != null)
        {
            m_Interactor.selectEntered.RemoveListener(OnSelectEntered);
            m_Interactor.selectExited.RemoveListener(OnSelectExited);
        }

        ShowLeftHand();
    }

    void ResolveReferences()
    {
        if (m_Interactor == null)
            m_Interactor = GetComponentInChildren<NearFarInteractor>(true);

        if (m_LeftHand == null)
        {
            var visual = transform.Find("Visual");
            if (visual != null)
            {
                foreach (Transform child in visual)
                {
                    if (child.name.Contains("LeftHand"))
                    {
                        m_LeftHand = child.gameObject;
                        break;
                    }
                }
            }
        }
    }

    void OnSelectEntered(SelectEnterEventArgs args)
    {
        HideLeftHand();
    }

    void OnSelectExited(SelectExitEventArgs args)
    {
        ShowLeftHand();
    }

    void HideLeftHand()
    {
        if (m_LeftHand != null)
            m_LeftHand.SetActive(false);
    }

    void ShowLeftHand()
    {
        if (m_LeftHand != null)
            m_LeftHand.SetActive(true);
    }
}
