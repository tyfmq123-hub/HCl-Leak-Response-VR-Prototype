using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

/// <summary>
/// Left Controller에 붙입니다. Cube를 잡으면 cubeData 손모양을 LeftHand에 적용하고,
/// 놓으면 원래 본 회전으로 되돌립니다.
/// </summary>
[DisallowMultipleComponent]
public class ControllerGrabHandPose : MonoBehaviour
{
    [SerializeField]
    NearFarInteractor m_Interactor;

    [SerializeField]
    Transform m_HandRoot;

    [SerializeField]
    Animator m_HandAnimator;

    Dictionary<string, Transform> m_BoneMap = new();
    Dictionary<string, Quaternion> m_SavedRotations = new();
    bool m_IsCustomPoseActive;

    void Awake()
    {
        ResolveReferences();
        RebuildBoneMap();
    }

    void OnEnable()
    {
        if (m_Interactor == null)
            ResolveReferences();

        if (m_Interactor != null)
        {
            m_Interactor.selectEntered.AddListener(OnSelectEntered);
            m_Interactor.selectExited.AddListener(OnSelectExited);
        }
        else
        {
            Debug.LogError(
                "[ControllerGrabHandPose] NearFarInteractor를 찾지 못했습니다. " +
                "Left Controller 또는 Inspector에서 연결하세요.",
                this);
        }
    }

    void OnDisable()
    {
        if (m_Interactor != null)
        {
            m_Interactor.selectEntered.RemoveListener(OnSelectEntered);
            m_Interactor.selectExited.RemoveListener(OnSelectExited);
        }

        RestoreHandPose();
    }

    void ResolveReferences()
    {
        if (m_Interactor == null)
            m_Interactor = GetComponentInChildren<NearFarInteractor>(true);

        if (m_HandRoot == null)
        {
            var visual = transform.Find("Visual");
            if (visual != null)
            {
                foreach (Transform child in visual)
                {
                    if (child.name.Contains("LeftHand"))
                    {
                        m_HandRoot = child;
                        break;
                    }
                }
            }
        }

        if (m_HandAnimator == null && m_HandRoot != null)
            m_HandAnimator = m_HandRoot.GetComponentInChildren<Animator>();
    }

    public void RebuildBoneMap()
    {
        m_BoneMap = HandPoseJointApplier.BuildBoneNameMap(m_HandRoot);
    }

    void OnSelectEntered(SelectEnterEventArgs args)
    {
        var cube = args.interactableObject.transform.GetComponentInParent<Cube>();
        var pose = cube != null ? cube.cubeData as HandPoseSnapshot : null;
        if (!HandPoseJointApplier.HasApplicablePoseData(pose))
            return;

        ApplyPose(pose);
    }

    void OnSelectExited(SelectExitEventArgs args)
    {
        RestoreHandPose();
    }

    public void ApplyPose(HandPoseSnapshot pose)
    {
        if (pose == null || m_HandRoot == null || m_BoneMap.Count == 0)
            return;

        if (!m_IsCustomPoseActive)
            m_SavedRotations = HandPoseJointApplier.CaptureLocalRotations(m_BoneMap);

        if (m_HandAnimator != null)
            m_HandAnimator.enabled = false;

        HandPoseJointApplier.ApplySnapshot(pose, m_BoneMap);
        m_IsCustomPoseActive = true;
    }

    public void RestoreHandPose()
    {
        if (!m_IsCustomPoseActive)
            return;

        HandPoseJointApplier.RestoreLocalRotations(m_BoneMap, m_SavedRotations);

        if (m_HandAnimator != null)
            m_HandAnimator.enabled = true;

        m_IsCustomPoseActive = false;
    }
}
