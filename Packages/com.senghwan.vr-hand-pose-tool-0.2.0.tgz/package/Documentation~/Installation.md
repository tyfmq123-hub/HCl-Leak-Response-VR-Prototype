# Installation

## 1. Tarball (.tgz)

1. Unity에서 `Window > Package Manager` 열기
2. 좌측 상단 `+`
3. `Add package from tarball...`
4. `Dist/com.senghwan.vr-hand-pose-tool-<version>.tgz` 선택

## 2. Disk (Embedded / 로컬 폴더)

1. Package Manager → `+`
2. `Add package from disk...`
3. `Packages/com.senghwan.vr-hand-pose-tool/package.json` 또는 압축 해제한 패키지 폴더의 `package.json` 선택

프로젝트의 `Packages/`에 폴더를 직접 넣해도 Embedded Package로 인식됩니다.

## 3. Git URL

저장소에 이 패키지 폴더가 포함된 경우:

```
https://<git-host>/<org>/<repo>.git?path=/Packages/com.senghwan.vr-hand-pose-tool
```

Package Manager → `+` → `Add package from git URL...`에 위 URL을 입력합니다.

## 설치 후

1. `Tools > VR Hand Tools > Hand Pose Capture`
2. Hand Side 선택
3. ① 선택 손 전체 준비 자동 구성

HandVisualizer Sample은 ① 버튼에서 필요 시 **Unity 공식 Sample API**로 Import됩니다. XR Hands 공식 메시/프리팹은 이 패키지에 포함되어 있지 않습니다.
