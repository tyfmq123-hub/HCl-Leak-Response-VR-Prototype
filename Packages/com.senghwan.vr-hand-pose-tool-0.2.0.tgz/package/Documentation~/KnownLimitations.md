# Known Limitations

- 실제 Hand Tracking은 XR Provider와 기기 지원이 필요합니다.
- HandVisualizer Sample Import가 필요합니다. 이 패키지는 XR Hands 공식 FBX/Prefab/Material을 포함하지 않습니다.
- Trigger / 검지 독립 애니메이션 분리는 현재 지원하지 않습니다.
- Unity는 Play Mode Scene 변경을 종료 시 복원합니다. Controller Driver·Visual Offset은 툴의 Edit Mode 재적용 / pending 영속화 절차를 사용한 뒤 Scene을 저장해야 유지됩니다.
- Open/Grip AnimationClip과 AnimatorController는 사용자 프로젝트 Output으로 생성되며 패키지에 포함되지 않습니다.
