# Quick Start

1. XR Origin이 있는 Scene을 엽니다.
2. `Tools > VR Hand Tools > Hand Pose Capture`를 실행합니다.
3. Hand Side(Left/Right)를 선택합니다.
4. ① **선택 손 전체 준비 자동 구성**을 실행합니다.
   - XR Hands / HandVisualizer Sample이 필요하면 공식 Sample API로 Import됩니다.
5. Play Mode에서 Open / Grip Pose를 캡처합니다.
6. AnimationClip과 AnimatorController(Blend Tree)를 생성합니다.
7. ④ **Controller 연결**에서 Grip Driver / InputActionManager를 설정합니다.
8. Edit Mode에서 **현재 Edit Mode Scene에 Controller 설정 재적용**이 필요하면 실행합니다.
9. `Ctrl+S`로 Scene을 저장합니다.
10. Play Mode에서 Grip 입력으로 손 Open/Grab이 동작하는지 확인합니다.

Left와 Right는 각각 반복합니다.
