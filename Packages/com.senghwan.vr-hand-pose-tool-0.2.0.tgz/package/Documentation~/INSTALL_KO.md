# VR Hand Pose Tool 설치 안내

## Tarball 설치

1. Unity 프로젝트를 엽니다.
2. `Window > Package Manager`를 엽니다.
3. 좌측 상단 `+`를 누릅니다.
4. `Add package from tarball...`을 선택합니다.
5. `VRHandPoseTool_v0.2.0.tgz`를 선택합니다.
6. 컴파일 완료 후 Console 오류가 없는지 확인합니다.
7. `Tools > VR Hand Tools > Hand Pose Capture`를 엽니다.

## 선택 샘플 가져오기

1. Package Manager에서 `VR Hand Pose Tool`을 선택합니다.
2. `Samples` 영역의 `Legacy Project Extras`에서 `Import`를 누릅니다.
3. 샘플은 `Assets/Samples/VR Hand Pose Tool/0.2.0/` 아래로 복사됩니다.

## 제거

Package Manager에서 `VR Hand Pose Tool`을 선택하고 `Remove`를 누릅니다.

`Assets/VRHandPoseToolOutput`은 사용자가 생성한 프로젝트 데이터이므로 패키지를 제거해도 자동 삭제되지 않습니다.
