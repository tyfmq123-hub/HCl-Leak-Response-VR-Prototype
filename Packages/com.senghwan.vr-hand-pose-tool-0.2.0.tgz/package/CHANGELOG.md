# Changelog

## 0.2.0 - 2026-08-04

- Embedded UPM 패키지 위치: `Packages/com.senghwan.vr-hand-pose-tool`
- displayName을 `VR Hand Tools`로 정리 (Package ID 유지)
- Grip Driver / Visual Offset Edit Mode 영속화 보존
- XR Hands 공식 HandVisualizer 메시/프리팹 재배포 제외
- 사용자 생성 AnimationClip/AnimatorController Sample Output 제외
- Installation / QuickStart / KnownLimitations 문서 추가

## 0.1.0

- 초기 Editor/Runtime 도구 구성
