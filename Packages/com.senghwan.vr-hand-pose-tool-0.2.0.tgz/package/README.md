# VR Hand Tools

XR Hands Tracking Hand로 Open/Grip Pose를 캡처하고, Controller Hand용 AnimationClip·AnimatorController·Grip Driver와 입력 연결을 자동 구성하는 Unity Editor Tool입니다.

Package ID: `com.senghwan.vr-hand-pose-tool`

## 지원 Unity 버전

- Unity 6000.0 이상

## 필수 패키지

- Input System
- XR Interaction Toolkit
- XR Hands
- XR Core Utils

버전은 `package.json` 의존성을 따릅니다.

## 설치

자세한 내용은 [Documentation~/Installation.md](Documentation~/Installation.md)를 참고하세요.

요약:

1. `Window > Package Manager`
2. 좌측 상단 `+`
3. `Add package from tarball...`
4. `com.senghwan.vr-hand-pose-tool-<version>.tgz` 선택

## 첫 실행

1. `Tools > VR Hand Tools > Hand Pose Capture`
2. Hand Side 선택
3. ① 선택 손 전체 준비 자동 구성

상세 절차는 [Documentation~/QuickStart.md](Documentation~/QuickStart.md)를 참고하세요.

## HandVisualizer Sample

이 패키지는 XR Hands 공식 HandVisualizer FBX/Prefab/Material을 **재배포하지 않습니다**.

① 단계에서 필요할 때 Unity 공식 Sample API로 HandVisualizer Sample을 Import합니다.

## Play Mode와 Edit Mode

Unity는 Play Mode Scene 변경을 종료 시 복원합니다.

Controller 설정(Animator, Grip Driver, IAM)과 Visual Offset은 툴의 **Edit Mode 재적용 / pending 영속화** 절차로 Scene에 반영합니다. 적용 후 `Ctrl+S`로 Scene을 저장하세요.

## 생성 결과 위치

도구가 생성하는 Pose / AnimationClip / AnimatorController / Grab Pose / Ghost / Input Action은 프로젝트의 다음 폴더에 저장됩니다.

`Assets/VRHandPoseToolOutput/`

## Left / Right

왼손과 오른손은 각각 별도로 준비해야 합니다.

## 현재 미지원

- Trigger / 검지 독립 애니메이션 분리

알려진 제한은 [Documentation~/KnownLimitations.md](Documentation~/KnownLimitations.md)를 참고하세요.

## 라이선스

`UNLICENSED` (개인용 배포본)
