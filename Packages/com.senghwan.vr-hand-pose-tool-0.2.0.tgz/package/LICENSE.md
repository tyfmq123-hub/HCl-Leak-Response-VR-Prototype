Copyright (c) 2026 Senghwan Shin. All rights reserved.

This package is provided for the owner's private use. No permission is granted to copy, modify, distribute, sublicense, or sell this package without the copyright holder's explicit permission.
